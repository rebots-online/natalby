# LIBS/UI/STITCH/screens/prepaid_06_review_your_reading/code.html

Source SHA-256: 4af3116aa68f381196087291537f32d540f05ce34e1b7e22532da8d72b8c1179

| ID | Parent | Syntax kind | Lines | Source text |
| --- | --- | --- | --- | --- |
| S08b4dbca0abb_N1 | — | document | 1–209 | document  |
| S08b4dbca0abb_N2 | S08b4dbca0abb_N1 | doctype | 1–1 | &lt;!DOCTYPE html&gt; |
| S08b4dbca0abb_N3 | S08b4dbca0abb_N1 | element | 3–208 | element  |
| S08b4dbca0abb_N4 | S08b4dbca0abb_N3 | start_tag | 3–3 | start_tag  |
| S08b4dbca0abb_N5 | S08b4dbca0abb_N4 | tag_name | 3–3 | html |
| S08b4dbca0abb_N6 | S08b4dbca0abb_N4 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N7 | S08b4dbca0abb_N6 | attribute_name | 3–3 | class |
| S08b4dbca0abb_N8 | S08b4dbca0abb_N6 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N9 | S08b4dbca0abb_N8 | attribute_value | 3–3 | dark |
| S08b4dbca0abb_N10 | S08b4dbca0abb_N4 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N11 | S08b4dbca0abb_N10 | attribute_name | 3–3 | lang |
| S08b4dbca0abb_N12 | S08b4dbca0abb_N10 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N13 | S08b4dbca0abb_N12 | attribute_value | 3–3 | en |
| S08b4dbca0abb_N14 | S08b4dbca0abb_N3 | element | 3–4 | element  |
| S08b4dbca0abb_N15 | S08b4dbca0abb_N14 | start_tag | 3–3 | start_tag  |
| S08b4dbca0abb_N16 | S08b4dbca0abb_N15 | tag_name | 3–3 | head |
| S08b4dbca0abb_N17 | S08b4dbca0abb_N14 | element | 3–3 | element  |
| S08b4dbca0abb_N18 | S08b4dbca0abb_N17 | self_closing_tag | 3–3 | self_closing_tag  |
| S08b4dbca0abb_N19 | S08b4dbca0abb_N18 | tag_name | 3–3 | meta |
| S08b4dbca0abb_N20 | S08b4dbca0abb_N18 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N21 | S08b4dbca0abb_N20 | attribute_name | 3–3 | charset |
| S08b4dbca0abb_N22 | S08b4dbca0abb_N20 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N23 | S08b4dbca0abb_N22 | attribute_value | 3–3 | utf-8 |
| S08b4dbca0abb_N24 | S08b4dbca0abb_N14 | element | 3–3 | element  |
| S08b4dbca0abb_N25 | S08b4dbca0abb_N24 | self_closing_tag | 3–3 | self_closing_tag  |
| S08b4dbca0abb_N26 | S08b4dbca0abb_N25 | tag_name | 3–3 | meta |
| S08b4dbca0abb_N27 | S08b4dbca0abb_N25 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N28 | S08b4dbca0abb_N27 | attribute_name | 3–3 | content |
| S08b4dbca0abb_N29 | S08b4dbca0abb_N27 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N30 | S08b4dbca0abb_N29 | attribute_value | 3–3 | width=device-width, initial-scale=1.0 |
| S08b4dbca0abb_N31 | S08b4dbca0abb_N25 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N32 | S08b4dbca0abb_N31 | attribute_name | 3–3 | name |
| S08b4dbca0abb_N33 | S08b4dbca0abb_N31 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N34 | S08b4dbca0abb_N33 | attribute_value | 3–3 | viewport |
| S08b4dbca0abb_N35 | S08b4dbca0abb_N14 | element | 3–3 | element  |
| S08b4dbca0abb_N36 | S08b4dbca0abb_N35 | self_closing_tag | 3–3 | self_closing_tag  |
| S08b4dbca0abb_N37 | S08b4dbca0abb_N36 | tag_name | 3–3 | meta |
| S08b4dbca0abb_N38 | S08b4dbca0abb_N36 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N39 | S08b4dbca0abb_N38 | attribute_name | 3–3 | content |
| S08b4dbca0abb_N40 | S08b4dbca0abb_N38 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N41 | S08b4dbca0abb_N40 | attribute_value | 3–3 | web_standard |
| S08b4dbca0abb_N42 | S08b4dbca0abb_N36 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N43 | S08b4dbca0abb_N42 | attribute_name | 3–3 | name |
| S08b4dbca0abb_N44 | S08b4dbca0abb_N42 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N45 | S08b4dbca0abb_N44 | attribute_value | 3–3 | shell-type |
| S08b4dbca0abb_N46 | S08b4dbca0abb_N14 | element | 3–3 | element  |
| S08b4dbca0abb_N47 | S08b4dbca0abb_N46 | self_closing_tag | 3–3 | self_closing_tag  |
| S08b4dbca0abb_N48 | S08b4dbca0abb_N47 | tag_name | 3–3 | link |
| S08b4dbca0abb_N49 | S08b4dbca0abb_N47 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N50 | S08b4dbca0abb_N49 | attribute_name | 3–3 | href |
| S08b4dbca0abb_N51 | S08b4dbca0abb_N49 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N52 | S08b4dbca0abb_N51 | attribute_value | 3–3 | https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200 |
| S08b4dbca0abb_N53 | S08b4dbca0abb_N47 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N54 | S08b4dbca0abb_N53 | attribute_name | 3–3 | rel |
| S08b4dbca0abb_N55 | S08b4dbca0abb_N53 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N56 | S08b4dbca0abb_N55 | attribute_value | 3–3 | stylesheet |
| S08b4dbca0abb_N57 | S08b4dbca0abb_N14 | element | 3–3 | element  |
| S08b4dbca0abb_N58 | S08b4dbca0abb_N57 | self_closing_tag | 3–3 | self_closing_tag  |
| S08b4dbca0abb_N59 | S08b4dbca0abb_N58 | tag_name | 3–3 | link |
| S08b4dbca0abb_N60 | S08b4dbca0abb_N58 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N61 | S08b4dbca0abb_N60 | attribute_name | 3–3 | href |
| S08b4dbca0abb_N62 | S08b4dbca0abb_N60 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N63 | S08b4dbca0abb_N62 | attribute_value | 3–3 | https://fonts.googleapis.com |
| S08b4dbca0abb_N64 | S08b4dbca0abb_N58 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N65 | S08b4dbca0abb_N64 | attribute_name | 3–3 | rel |
| S08b4dbca0abb_N66 | S08b4dbca0abb_N64 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N67 | S08b4dbca0abb_N66 | attribute_value | 3–3 | preconnect |
| S08b4dbca0abb_N68 | S08b4dbca0abb_N14 | element | 3–3 | element  |
| S08b4dbca0abb_N69 | S08b4dbca0abb_N68 | self_closing_tag | 3–3 | self_closing_tag  |
| S08b4dbca0abb_N70 | S08b4dbca0abb_N69 | tag_name | 3–3 | link |
| S08b4dbca0abb_N71 | S08b4dbca0abb_N69 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N72 | S08b4dbca0abb_N71 | attribute_name | 3–3 | crossorigin |
| S08b4dbca0abb_N73 | S08b4dbca0abb_N71 | quoted_attribute_value | 3–3 | "" |
| S08b4dbca0abb_N74 | S08b4dbca0abb_N69 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N75 | S08b4dbca0abb_N74 | attribute_name | 3–3 | href |
| S08b4dbca0abb_N76 | S08b4dbca0abb_N74 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N77 | S08b4dbca0abb_N76 | attribute_value | 3–3 | https://fonts.gstatic.com |
| S08b4dbca0abb_N78 | S08b4dbca0abb_N69 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N79 | S08b4dbca0abb_N78 | attribute_name | 3–3 | rel |
| S08b4dbca0abb_N80 | S08b4dbca0abb_N78 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N81 | S08b4dbca0abb_N80 | attribute_value | 3–3 | preconnect |
| S08b4dbca0abb_N82 | S08b4dbca0abb_N14 | element | 3–3 | element  |
| S08b4dbca0abb_N83 | S08b4dbca0abb_N82 | self_closing_tag | 3–3 | self_closing_tag  |
| S08b4dbca0abb_N84 | S08b4dbca0abb_N83 | tag_name | 3–3 | link |
| S08b4dbca0abb_N85 | S08b4dbca0abb_N83 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N86 | S08b4dbca0abb_N85 | attribute_name | 3–3 | href |
| S08b4dbca0abb_N87 | S08b4dbca0abb_N85 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N88 | S08b4dbca0abb_N87 | attribute_value | 3–3 | https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,400..700;1,9..144,400..700&amp;amp;family=IBM+Plex+Mono:wght@400;500;600&amp;amp;family=Nunito+Sans:wght@400;600;700&amp;amp;display=swap |
| S08b4dbca0abb_N89 | S08b4dbca0abb_N83 | attribute | 3–3 | attribute  |
| S08b4dbca0abb_N90 | S08b4dbca0abb_N89 | attribute_name | 3–3 | rel |
| S08b4dbca0abb_N91 | S08b4dbca0abb_N89 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S08b4dbca0abb_N92 | S08b4dbca0abb_N91 | attribute_value | 3–3 | stylesheet |
| S08b4dbca0abb_N93 | S08b4dbca0abb_N14 | element | 4–4 | element  |
| S08b4dbca0abb_N94 | S08b4dbca0abb_N93 | self_closing_tag | 4–4 | self_closing_tag  |
| S08b4dbca0abb_N95 | S08b4dbca0abb_N94 | tag_name | 4–4 | link |
| S08b4dbca0abb_N96 | S08b4dbca0abb_N94 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N97 | S08b4dbca0abb_N96 | attribute_name | 4–4 | href |
| S08b4dbca0abb_N98 | S08b4dbca0abb_N96 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N99 | S08b4dbca0abb_N98 | attribute_value | 4–4 | https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;amp;display=swap |
| S08b4dbca0abb_N100 | S08b4dbca0abb_N94 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N101 | S08b4dbca0abb_N100 | attribute_name | 4–4 | rel |
| S08b4dbca0abb_N102 | S08b4dbca0abb_N100 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N103 | S08b4dbca0abb_N102 | attribute_value | 4–4 | stylesheet |
| S08b4dbca0abb_N104 | S08b4dbca0abb_N14 | style_element | 4–4 | style_element  |
| S08b4dbca0abb_N105 | S08b4dbca0abb_N104 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N106 | S08b4dbca0abb_N105 | tag_name | 4–4 | style |
| S08b4dbca0abb_N107 | S08b4dbca0abb_N104 | raw_text | 4–4 | @layer base{html,body{margin:0;padding:0;}body{overscroll-behavior:none;}main&gt;:first-child{margin-top:0!important;}main&gt;:last-child{margin-bottom:0!important;}}::-webkit-scrollbar{display:none;} |
| S08b4dbca0abb_N108 | S08b4dbca0abb_N104 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N109 | S08b4dbca0abb_N108 | tag_name | 4–4 | style |
| S08b4dbca0abb_N110 | S08b4dbca0abb_N14 | script_element | 4–4 | script_element  |
| S08b4dbca0abb_N111 | S08b4dbca0abb_N110 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N112 | S08b4dbca0abb_N111 | tag_name | 4–4 | script |
| S08b4dbca0abb_N113 | S08b4dbca0abb_N111 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N114 | S08b4dbca0abb_N113 | attribute_name | 4–4 | src |
| S08b4dbca0abb_N115 | S08b4dbca0abb_N113 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N116 | S08b4dbca0abb_N115 | attribute_value | 4–4 | https://cdn.tailwindcss.com |
| S08b4dbca0abb_N117 | S08b4dbca0abb_N110 | raw_text | 4–4 |  |
| S08b4dbca0abb_N118 | S08b4dbca0abb_N110 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N119 | S08b4dbca0abb_N118 | tag_name | 4–4 | script |
| S08b4dbca0abb_N120 | S08b4dbca0abb_N110 | program | 1–1 |  |
| S08b4dbca0abb_N121 | S08b4dbca0abb_N14 | script_element | 4–4 | script_element  |
| S08b4dbca0abb_N122 | S08b4dbca0abb_N121 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N123 | S08b4dbca0abb_N122 | tag_name | 4–4 | script |
| S08b4dbca0abb_N124 | S08b4dbca0abb_N122 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N125 | S08b4dbca0abb_N124 | attribute_name | 4–4 | id |
| S08b4dbca0abb_N126 | S08b4dbca0abb_N124 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N127 | S08b4dbca0abb_N126 | attribute_value | 4–4 | tailwind-config |
| S08b4dbca0abb_N128 | S08b4dbca0abb_N121 | raw_text | 4–4 | tailwind.config = { darkMode: "class", theme: { extend: { "colors": { "primary": "#f2ca50", "inverse-surface": "#eadef6", "on-primary-fixed": "#241a00", "on-surface": "#eadef6", "on-secondary-fixed": "#380d02", "on-error": "#690005", "tertiary-fixed": "#dce1ff", "primary-container": "#d4af37", "on-background": "#eadef6", "on-error-container": "#ffdad6", "tertiary-fixed-dim": "#b5c4ff", "surface-container-low": "#1f1929", "inverse-primary": "#735c00", "outline": "#99907c", "on-secondary": "#532112", "surface-variant": "#393243", "on-secondary-container": "#f4a58e", "on-tertiary-fixed": "#00164d", "surface-container-lowest": "#110b1b", "secondary-fixed-dim": "#ffb59f", "surface-container-high": "#2e2738", "outline-variant": "#4d4635", "on-primary-fixed-variant": "#574500", "on-tertiary-fixed-variant": "#2d4386", "tertiary-container": "#9bb0fb", "on-tertiary": "#122b6e", "primary-fixed-dim": "#e9c349", "secondary": "#ffb59f", "inverse-on-surface": "#342d3f", "error-container": "#93000a", "on-tertiary-container": "#2b4184", "on-secondary-fixed-variant": "#6f3726", "on-surface-variant": "#d0c5af", "surface-container": "#231d2d", "surface-tint": "#e9c349", "surface-container-highest": "#393243", "primary-fixed": "#ffe088", "on-primary-container": "#554300", "background": "#161021", "secondary-fixed": "#ffdbd1", "tertiary": "#c0cdff", "surface-bright": "#3d3648", "surface": "#161021", "error": "#ffb4ab", "surface-dim": "#161021", "secondary-container": "#723928", "on-primary": "#3c2f00" }, "borderRadius": { "DEFAULT": "0.25rem", "lg": "0.5rem", "xl": "0.75rem", "full": "9999px" }, "spacing": { "space-md": "1rem", "gutter-desktop": "1.5rem", "space-lg": "1.5rem", "margin-tablet": "2rem", "gutter": "1rem", "margin": "1rem", "margin-desktop": "3rem", "space-xl": "2.5rem", "space-xs": "0.25rem", "space-sm": "0.5rem" }, "fontFamily": { "headline-sm": ["Fraunces"], "display-lg": ["Fraunces"], "headline-lg": ["Fraunces"], "display-lg-mobile": ["Fraunces"], "astro-data-md": ["IBM Plex Mono"], "headline-md": ["Fraunces"], "body-md": ["Nunito Sans"], "body-lg": ["Nunito Sans"], "oracle-voice": ["Fraunces"], "body-sm": ["Nunito Sans"], "astro-data-lg": ["IBM Plex Mono"], "label-caps": ["IBM Plex Mono"] }, "fontSize": { "headline-sm": ["18px", { "lineHeight": "26px", "fontWeight": "600" }], "display-lg": ["40px", { "lineHeight": "48px", "letterSpacing": "-0.02em", "fontWeight": "600" }], "headline-lg": ["28px", { "lineHeight": "36px", "letterSpacing": "-0.01em", "fontWeight": "500" }], "display-lg-mobile": ["30px", { "lineHeight": "38px", "letterSpacing": "-0.01em", "fontWeight": "600" }], "astro-data-md": ["13px", { "lineHeight": "18px", "fontWeight": "400" }], "headline-md": ["22px", { "lineHeight": "30px", "fontWeight": "500" }], "body-md": ["15px", { "lineHeight": "22px", "fontWeight": "400" }], "body-lg": ["17px", { "lineHeight": "26px", "fontWeight": "400" }], "oracle-voice": ["16px", { "lineHeight": "24px", "letterSpacing": "0.01em", "fontWeight": "400" }], "body-sm": ["13px", { "lineHeight": "18px", "fontWeight": "400" }], "astro-data-lg": ["16px", { "lineHeight": "22px", "fontWeight": "500" }], "label-caps": ["11px", { "lineHeight": "14px", "letterSpacing": "0.08em", "fontWeight": "600" }] } } } }; |
| S08b4dbca0abb_N129 | S08b4dbca0abb_N121 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N130 | S08b4dbca0abb_N129 | tag_name | 4–4 | script |
| S08b4dbca0abb_N131 | S08b4dbca0abb_N121 | program | 1–1 | program  |
| S08b4dbca0abb_N132 | S08b4dbca0abb_N131 | expression_statement | 1–1 | expression_statement  |
| S08b4dbca0abb_N133 | S08b4dbca0abb_N132 | assignment_expression | 1–1 | assignment_expression  |
| S08b4dbca0abb_N134 | S08b4dbca0abb_N133 | member_expression | 1–1 | member_expression  |
| S08b4dbca0abb_N135 | S08b4dbca0abb_N134 | identifier | 1–1 | tailwind |
| S08b4dbca0abb_N136 | S08b4dbca0abb_N134 | property_identifier | 1–1 | config |
| S08b4dbca0abb_N137 | S08b4dbca0abb_N133 | object | 1–1 | object  |
| S08b4dbca0abb_N138 | S08b4dbca0abb_N137 | pair | 1–1 | pair  |
| S08b4dbca0abb_N139 | S08b4dbca0abb_N138 | property_identifier | 1–1 | darkMode |
| S08b4dbca0abb_N140 | S08b4dbca0abb_N138 | string | 1–1 | string  |
| S08b4dbca0abb_N141 | S08b4dbca0abb_N140 | string_fragment | 1–1 | class |
| S08b4dbca0abb_N142 | S08b4dbca0abb_N137 | pair | 1–1 | pair  |
| S08b4dbca0abb_N143 | S08b4dbca0abb_N142 | property_identifier | 1–1 | theme |
| S08b4dbca0abb_N144 | S08b4dbca0abb_N142 | object | 1–1 | object  |
| S08b4dbca0abb_N145 | S08b4dbca0abb_N144 | pair | 1–1 | pair  |
| S08b4dbca0abb_N146 | S08b4dbca0abb_N145 | property_identifier | 1–1 | extend |
| S08b4dbca0abb_N147 | S08b4dbca0abb_N145 | object | 1–1 | object  |
| S08b4dbca0abb_N148 | S08b4dbca0abb_N147 | pair | 1–1 | pair  |
| S08b4dbca0abb_N149 | S08b4dbca0abb_N148 | string | 1–1 | string  |
| S08b4dbca0abb_N150 | S08b4dbca0abb_N149 | string_fragment | 1–1 | colors |
| S08b4dbca0abb_N151 | S08b4dbca0abb_N148 | object | 1–1 | object  |
| S08b4dbca0abb_N152 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N153 | S08b4dbca0abb_N152 | string | 1–1 | string  |
| S08b4dbca0abb_N154 | S08b4dbca0abb_N153 | string_fragment | 1–1 | primary |
| S08b4dbca0abb_N155 | S08b4dbca0abb_N152 | string | 1–1 | string  |
| S08b4dbca0abb_N156 | S08b4dbca0abb_N155 | string_fragment | 1–1 | #f2ca50 |
| S08b4dbca0abb_N157 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N158 | S08b4dbca0abb_N157 | string | 1–1 | string  |
| S08b4dbca0abb_N159 | S08b4dbca0abb_N158 | string_fragment | 1–1 | inverse-surface |
| S08b4dbca0abb_N160 | S08b4dbca0abb_N157 | string | 1–1 | string  |
| S08b4dbca0abb_N161 | S08b4dbca0abb_N160 | string_fragment | 1–1 | #eadef6 |
| S08b4dbca0abb_N162 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N163 | S08b4dbca0abb_N162 | string | 1–1 | string  |
| S08b4dbca0abb_N164 | S08b4dbca0abb_N163 | string_fragment | 1–1 | on-primary-fixed |
| S08b4dbca0abb_N165 | S08b4dbca0abb_N162 | string | 1–1 | string  |
| S08b4dbca0abb_N166 | S08b4dbca0abb_N165 | string_fragment | 1–1 | #241a00 |
| S08b4dbca0abb_N167 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N168 | S08b4dbca0abb_N167 | string | 1–1 | string  |
| S08b4dbca0abb_N169 | S08b4dbca0abb_N168 | string_fragment | 1–1 | on-surface |
| S08b4dbca0abb_N170 | S08b4dbca0abb_N167 | string | 1–1 | string  |
| S08b4dbca0abb_N171 | S08b4dbca0abb_N170 | string_fragment | 1–1 | #eadef6 |
| S08b4dbca0abb_N172 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N173 | S08b4dbca0abb_N172 | string | 1–1 | string  |
| S08b4dbca0abb_N174 | S08b4dbca0abb_N173 | string_fragment | 1–1 | on-secondary-fixed |
| S08b4dbca0abb_N175 | S08b4dbca0abb_N172 | string | 1–1 | string  |
| S08b4dbca0abb_N176 | S08b4dbca0abb_N175 | string_fragment | 1–1 | #380d02 |
| S08b4dbca0abb_N177 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N178 | S08b4dbca0abb_N177 | string | 1–1 | string  |
| S08b4dbca0abb_N179 | S08b4dbca0abb_N178 | string_fragment | 1–1 | on-error |
| S08b4dbca0abb_N180 | S08b4dbca0abb_N177 | string | 1–1 | string  |
| S08b4dbca0abb_N181 | S08b4dbca0abb_N180 | string_fragment | 1–1 | #690005 |
| S08b4dbca0abb_N182 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N183 | S08b4dbca0abb_N182 | string | 1–1 | string  |
| S08b4dbca0abb_N184 | S08b4dbca0abb_N183 | string_fragment | 1–1 | tertiary-fixed |
| S08b4dbca0abb_N185 | S08b4dbca0abb_N182 | string | 1–1 | string  |
| S08b4dbca0abb_N186 | S08b4dbca0abb_N185 | string_fragment | 1–1 | #dce1ff |
| S08b4dbca0abb_N187 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N188 | S08b4dbca0abb_N187 | string | 1–1 | string  |
| S08b4dbca0abb_N189 | S08b4dbca0abb_N188 | string_fragment | 1–1 | primary-container |
| S08b4dbca0abb_N190 | S08b4dbca0abb_N187 | string | 1–1 | string  |
| S08b4dbca0abb_N191 | S08b4dbca0abb_N190 | string_fragment | 1–1 | #d4af37 |
| S08b4dbca0abb_N192 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N193 | S08b4dbca0abb_N192 | string | 1–1 | string  |
| S08b4dbca0abb_N194 | S08b4dbca0abb_N193 | string_fragment | 1–1 | on-background |
| S08b4dbca0abb_N195 | S08b4dbca0abb_N192 | string | 1–1 | string  |
| S08b4dbca0abb_N196 | S08b4dbca0abb_N195 | string_fragment | 1–1 | #eadef6 |
| S08b4dbca0abb_N197 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N198 | S08b4dbca0abb_N197 | string | 1–1 | string  |
| S08b4dbca0abb_N199 | S08b4dbca0abb_N198 | string_fragment | 1–1 | on-error-container |
| S08b4dbca0abb_N200 | S08b4dbca0abb_N197 | string | 1–1 | string  |
| S08b4dbca0abb_N201 | S08b4dbca0abb_N200 | string_fragment | 1–1 | #ffdad6 |
| S08b4dbca0abb_N202 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N203 | S08b4dbca0abb_N202 | string | 1–1 | string  |
| S08b4dbca0abb_N204 | S08b4dbca0abb_N203 | string_fragment | 1–1 | tertiary-fixed-dim |
| S08b4dbca0abb_N205 | S08b4dbca0abb_N202 | string | 1–1 | string  |
| S08b4dbca0abb_N206 | S08b4dbca0abb_N205 | string_fragment | 1–1 | #b5c4ff |
| S08b4dbca0abb_N207 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N208 | S08b4dbca0abb_N207 | string | 1–1 | string  |
| S08b4dbca0abb_N209 | S08b4dbca0abb_N208 | string_fragment | 1–1 | surface-container-low |
| S08b4dbca0abb_N210 | S08b4dbca0abb_N207 | string | 1–1 | string  |
| S08b4dbca0abb_N211 | S08b4dbca0abb_N210 | string_fragment | 1–1 | #1f1929 |
| S08b4dbca0abb_N212 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N213 | S08b4dbca0abb_N212 | string | 1–1 | string  |
| S08b4dbca0abb_N214 | S08b4dbca0abb_N213 | string_fragment | 1–1 | inverse-primary |
| S08b4dbca0abb_N215 | S08b4dbca0abb_N212 | string | 1–1 | string  |
| S08b4dbca0abb_N216 | S08b4dbca0abb_N215 | string_fragment | 1–1 | #735c00 |
| S08b4dbca0abb_N217 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N218 | S08b4dbca0abb_N217 | string | 1–1 | string  |
| S08b4dbca0abb_N219 | S08b4dbca0abb_N218 | string_fragment | 1–1 | outline |
| S08b4dbca0abb_N220 | S08b4dbca0abb_N217 | string | 1–1 | string  |
| S08b4dbca0abb_N221 | S08b4dbca0abb_N220 | string_fragment | 1–1 | #99907c |
| S08b4dbca0abb_N222 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N223 | S08b4dbca0abb_N222 | string | 1–1 | string  |
| S08b4dbca0abb_N224 | S08b4dbca0abb_N223 | string_fragment | 1–1 | on-secondary |
| S08b4dbca0abb_N225 | S08b4dbca0abb_N222 | string | 1–1 | string  |
| S08b4dbca0abb_N226 | S08b4dbca0abb_N225 | string_fragment | 1–1 | #532112 |
| S08b4dbca0abb_N227 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N228 | S08b4dbca0abb_N227 | string | 1–1 | string  |
| S08b4dbca0abb_N229 | S08b4dbca0abb_N228 | string_fragment | 1–1 | surface-variant |
| S08b4dbca0abb_N230 | S08b4dbca0abb_N227 | string | 1–1 | string  |
| S08b4dbca0abb_N231 | S08b4dbca0abb_N230 | string_fragment | 1–1 | #393243 |
| S08b4dbca0abb_N232 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N233 | S08b4dbca0abb_N232 | string | 1–1 | string  |
| S08b4dbca0abb_N234 | S08b4dbca0abb_N233 | string_fragment | 1–1 | on-secondary-container |
| S08b4dbca0abb_N235 | S08b4dbca0abb_N232 | string | 1–1 | string  |
| S08b4dbca0abb_N236 | S08b4dbca0abb_N235 | string_fragment | 1–1 | #f4a58e |
| S08b4dbca0abb_N237 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N238 | S08b4dbca0abb_N237 | string | 1–1 | string  |
| S08b4dbca0abb_N239 | S08b4dbca0abb_N238 | string_fragment | 1–1 | on-tertiary-fixed |
| S08b4dbca0abb_N240 | S08b4dbca0abb_N237 | string | 1–1 | string  |
| S08b4dbca0abb_N241 | S08b4dbca0abb_N240 | string_fragment | 1–1 | #00164d |
| S08b4dbca0abb_N242 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N243 | S08b4dbca0abb_N242 | string | 1–1 | string  |
| S08b4dbca0abb_N244 | S08b4dbca0abb_N243 | string_fragment | 1–1 | surface-container-lowest |
| S08b4dbca0abb_N245 | S08b4dbca0abb_N242 | string | 1–1 | string  |
| S08b4dbca0abb_N246 | S08b4dbca0abb_N245 | string_fragment | 1–1 | #110b1b |
| S08b4dbca0abb_N247 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N248 | S08b4dbca0abb_N247 | string | 1–1 | string  |
| S08b4dbca0abb_N249 | S08b4dbca0abb_N248 | string_fragment | 1–1 | secondary-fixed-dim |
| S08b4dbca0abb_N250 | S08b4dbca0abb_N247 | string | 1–1 | string  |
| S08b4dbca0abb_N251 | S08b4dbca0abb_N250 | string_fragment | 1–1 | #ffb59f |
| S08b4dbca0abb_N252 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N253 | S08b4dbca0abb_N252 | string | 1–1 | string  |
| S08b4dbca0abb_N254 | S08b4dbca0abb_N253 | string_fragment | 1–1 | surface-container-high |
| S08b4dbca0abb_N255 | S08b4dbca0abb_N252 | string | 1–1 | string  |
| S08b4dbca0abb_N256 | S08b4dbca0abb_N255 | string_fragment | 1–1 | #2e2738 |
| S08b4dbca0abb_N257 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N258 | S08b4dbca0abb_N257 | string | 1–1 | string  |
| S08b4dbca0abb_N259 | S08b4dbca0abb_N258 | string_fragment | 1–1 | outline-variant |
| S08b4dbca0abb_N260 | S08b4dbca0abb_N257 | string | 1–1 | string  |
| S08b4dbca0abb_N261 | S08b4dbca0abb_N260 | string_fragment | 1–1 | #4d4635 |
| S08b4dbca0abb_N262 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N263 | S08b4dbca0abb_N262 | string | 1–1 | string  |
| S08b4dbca0abb_N264 | S08b4dbca0abb_N263 | string_fragment | 1–1 | on-primary-fixed-variant |
| S08b4dbca0abb_N265 | S08b4dbca0abb_N262 | string | 1–1 | string  |
| S08b4dbca0abb_N266 | S08b4dbca0abb_N265 | string_fragment | 1–1 | #574500 |
| S08b4dbca0abb_N267 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N268 | S08b4dbca0abb_N267 | string | 1–1 | string  |
| S08b4dbca0abb_N269 | S08b4dbca0abb_N268 | string_fragment | 1–1 | on-tertiary-fixed-variant |
| S08b4dbca0abb_N270 | S08b4dbca0abb_N267 | string | 1–1 | string  |
| S08b4dbca0abb_N271 | S08b4dbca0abb_N270 | string_fragment | 1–1 | #2d4386 |
| S08b4dbca0abb_N272 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N273 | S08b4dbca0abb_N272 | string | 1–1 | string  |
| S08b4dbca0abb_N274 | S08b4dbca0abb_N273 | string_fragment | 1–1 | tertiary-container |
| S08b4dbca0abb_N275 | S08b4dbca0abb_N272 | string | 1–1 | string  |
| S08b4dbca0abb_N276 | S08b4dbca0abb_N275 | string_fragment | 1–1 | #9bb0fb |
| S08b4dbca0abb_N277 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N278 | S08b4dbca0abb_N277 | string | 1–1 | string  |
| S08b4dbca0abb_N279 | S08b4dbca0abb_N278 | string_fragment | 1–1 | on-tertiary |
| S08b4dbca0abb_N280 | S08b4dbca0abb_N277 | string | 1–1 | string  |
| S08b4dbca0abb_N281 | S08b4dbca0abb_N280 | string_fragment | 1–1 | #122b6e |
| S08b4dbca0abb_N282 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N283 | S08b4dbca0abb_N282 | string | 1–1 | string  |
| S08b4dbca0abb_N284 | S08b4dbca0abb_N283 | string_fragment | 1–1 | primary-fixed-dim |
| S08b4dbca0abb_N285 | S08b4dbca0abb_N282 | string | 1–1 | string  |
| S08b4dbca0abb_N286 | S08b4dbca0abb_N285 | string_fragment | 1–1 | #e9c349 |
| S08b4dbca0abb_N287 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N288 | S08b4dbca0abb_N287 | string | 1–1 | string  |
| S08b4dbca0abb_N289 | S08b4dbca0abb_N288 | string_fragment | 1–1 | secondary |
| S08b4dbca0abb_N290 | S08b4dbca0abb_N287 | string | 1–1 | string  |
| S08b4dbca0abb_N291 | S08b4dbca0abb_N290 | string_fragment | 1–1 | #ffb59f |
| S08b4dbca0abb_N292 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N293 | S08b4dbca0abb_N292 | string | 1–1 | string  |
| S08b4dbca0abb_N294 | S08b4dbca0abb_N293 | string_fragment | 1–1 | inverse-on-surface |
| S08b4dbca0abb_N295 | S08b4dbca0abb_N292 | string | 1–1 | string  |
| S08b4dbca0abb_N296 | S08b4dbca0abb_N295 | string_fragment | 1–1 | #342d3f |
| S08b4dbca0abb_N297 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N298 | S08b4dbca0abb_N297 | string | 1–1 | string  |
| S08b4dbca0abb_N299 | S08b4dbca0abb_N298 | string_fragment | 1–1 | error-container |
| S08b4dbca0abb_N300 | S08b4dbca0abb_N297 | string | 1–1 | string  |
| S08b4dbca0abb_N301 | S08b4dbca0abb_N300 | string_fragment | 1–1 | #93000a |
| S08b4dbca0abb_N302 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N303 | S08b4dbca0abb_N302 | string | 1–1 | string  |
| S08b4dbca0abb_N304 | S08b4dbca0abb_N303 | string_fragment | 1–1 | on-tertiary-container |
| S08b4dbca0abb_N305 | S08b4dbca0abb_N302 | string | 1–1 | string  |
| S08b4dbca0abb_N306 | S08b4dbca0abb_N305 | string_fragment | 1–1 | #2b4184 |
| S08b4dbca0abb_N307 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N308 | S08b4dbca0abb_N307 | string | 1–1 | string  |
| S08b4dbca0abb_N309 | S08b4dbca0abb_N308 | string_fragment | 1–1 | on-secondary-fixed-variant |
| S08b4dbca0abb_N310 | S08b4dbca0abb_N307 | string | 1–1 | string  |
| S08b4dbca0abb_N311 | S08b4dbca0abb_N310 | string_fragment | 1–1 | #6f3726 |
| S08b4dbca0abb_N312 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N313 | S08b4dbca0abb_N312 | string | 1–1 | string  |
| S08b4dbca0abb_N314 | S08b4dbca0abb_N313 | string_fragment | 1–1 | on-surface-variant |
| S08b4dbca0abb_N315 | S08b4dbca0abb_N312 | string | 1–1 | string  |
| S08b4dbca0abb_N316 | S08b4dbca0abb_N315 | string_fragment | 1–1 | #d0c5af |
| S08b4dbca0abb_N317 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N318 | S08b4dbca0abb_N317 | string | 1–1 | string  |
| S08b4dbca0abb_N319 | S08b4dbca0abb_N318 | string_fragment | 1–1 | surface-container |
| S08b4dbca0abb_N320 | S08b4dbca0abb_N317 | string | 1–1 | string  |
| S08b4dbca0abb_N321 | S08b4dbca0abb_N320 | string_fragment | 1–1 | #231d2d |
| S08b4dbca0abb_N322 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N323 | S08b4dbca0abb_N322 | string | 1–1 | string  |
| S08b4dbca0abb_N324 | S08b4dbca0abb_N323 | string_fragment | 1–1 | surface-tint |
| S08b4dbca0abb_N325 | S08b4dbca0abb_N322 | string | 1–1 | string  |
| S08b4dbca0abb_N326 | S08b4dbca0abb_N325 | string_fragment | 1–1 | #e9c349 |
| S08b4dbca0abb_N327 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N328 | S08b4dbca0abb_N327 | string | 1–1 | string  |
| S08b4dbca0abb_N329 | S08b4dbca0abb_N328 | string_fragment | 1–1 | surface-container-highest |
| S08b4dbca0abb_N330 | S08b4dbca0abb_N327 | string | 1–1 | string  |
| S08b4dbca0abb_N331 | S08b4dbca0abb_N330 | string_fragment | 1–1 | #393243 |
| S08b4dbca0abb_N332 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N333 | S08b4dbca0abb_N332 | string | 1–1 | string  |
| S08b4dbca0abb_N334 | S08b4dbca0abb_N333 | string_fragment | 1–1 | primary-fixed |
| S08b4dbca0abb_N335 | S08b4dbca0abb_N332 | string | 1–1 | string  |
| S08b4dbca0abb_N336 | S08b4dbca0abb_N335 | string_fragment | 1–1 | #ffe088 |
| S08b4dbca0abb_N337 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N338 | S08b4dbca0abb_N337 | string | 1–1 | string  |
| S08b4dbca0abb_N339 | S08b4dbca0abb_N338 | string_fragment | 1–1 | on-primary-container |
| S08b4dbca0abb_N340 | S08b4dbca0abb_N337 | string | 1–1 | string  |
| S08b4dbca0abb_N341 | S08b4dbca0abb_N340 | string_fragment | 1–1 | #554300 |
| S08b4dbca0abb_N342 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N343 | S08b4dbca0abb_N342 | string | 1–1 | string  |
| S08b4dbca0abb_N344 | S08b4dbca0abb_N343 | string_fragment | 1–1 | background |
| S08b4dbca0abb_N345 | S08b4dbca0abb_N342 | string | 1–1 | string  |
| S08b4dbca0abb_N346 | S08b4dbca0abb_N345 | string_fragment | 1–1 | #161021 |
| S08b4dbca0abb_N347 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N348 | S08b4dbca0abb_N347 | string | 1–1 | string  |
| S08b4dbca0abb_N349 | S08b4dbca0abb_N348 | string_fragment | 1–1 | secondary-fixed |
| S08b4dbca0abb_N350 | S08b4dbca0abb_N347 | string | 1–1 | string  |
| S08b4dbca0abb_N351 | S08b4dbca0abb_N350 | string_fragment | 1–1 | #ffdbd1 |
| S08b4dbca0abb_N352 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N353 | S08b4dbca0abb_N352 | string | 1–1 | string  |
| S08b4dbca0abb_N354 | S08b4dbca0abb_N353 | string_fragment | 1–1 | tertiary |
| S08b4dbca0abb_N355 | S08b4dbca0abb_N352 | string | 1–1 | string  |
| S08b4dbca0abb_N356 | S08b4dbca0abb_N355 | string_fragment | 1–1 | #c0cdff |
| S08b4dbca0abb_N357 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N358 | S08b4dbca0abb_N357 | string | 1–1 | string  |
| S08b4dbca0abb_N359 | S08b4dbca0abb_N358 | string_fragment | 1–1 | surface-bright |
| S08b4dbca0abb_N360 | S08b4dbca0abb_N357 | string | 1–1 | string  |
| S08b4dbca0abb_N361 | S08b4dbca0abb_N360 | string_fragment | 1–1 | #3d3648 |
| S08b4dbca0abb_N362 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N363 | S08b4dbca0abb_N362 | string | 1–1 | string  |
| S08b4dbca0abb_N364 | S08b4dbca0abb_N363 | string_fragment | 1–1 | surface |
| S08b4dbca0abb_N365 | S08b4dbca0abb_N362 | string | 1–1 | string  |
| S08b4dbca0abb_N366 | S08b4dbca0abb_N365 | string_fragment | 1–1 | #161021 |
| S08b4dbca0abb_N367 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N368 | S08b4dbca0abb_N367 | string | 1–1 | string  |
| S08b4dbca0abb_N369 | S08b4dbca0abb_N368 | string_fragment | 1–1 | error |
| S08b4dbca0abb_N370 | S08b4dbca0abb_N367 | string | 1–1 | string  |
| S08b4dbca0abb_N371 | S08b4dbca0abb_N370 | string_fragment | 1–1 | #ffb4ab |
| S08b4dbca0abb_N372 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N373 | S08b4dbca0abb_N372 | string | 1–1 | string  |
| S08b4dbca0abb_N374 | S08b4dbca0abb_N373 | string_fragment | 1–1 | surface-dim |
| S08b4dbca0abb_N375 | S08b4dbca0abb_N372 | string | 1–1 | string  |
| S08b4dbca0abb_N376 | S08b4dbca0abb_N375 | string_fragment | 1–1 | #161021 |
| S08b4dbca0abb_N377 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N378 | S08b4dbca0abb_N377 | string | 1–1 | string  |
| S08b4dbca0abb_N379 | S08b4dbca0abb_N378 | string_fragment | 1–1 | secondary-container |
| S08b4dbca0abb_N380 | S08b4dbca0abb_N377 | string | 1–1 | string  |
| S08b4dbca0abb_N381 | S08b4dbca0abb_N380 | string_fragment | 1–1 | #723928 |
| S08b4dbca0abb_N382 | S08b4dbca0abb_N151 | pair | 1–1 | pair  |
| S08b4dbca0abb_N383 | S08b4dbca0abb_N382 | string | 1–1 | string  |
| S08b4dbca0abb_N384 | S08b4dbca0abb_N383 | string_fragment | 1–1 | on-primary |
| S08b4dbca0abb_N385 | S08b4dbca0abb_N382 | string | 1–1 | string  |
| S08b4dbca0abb_N386 | S08b4dbca0abb_N385 | string_fragment | 1–1 | #3c2f00 |
| S08b4dbca0abb_N387 | S08b4dbca0abb_N147 | pair | 1–1 | pair  |
| S08b4dbca0abb_N388 | S08b4dbca0abb_N387 | string | 1–1 | string  |
| S08b4dbca0abb_N389 | S08b4dbca0abb_N388 | string_fragment | 1–1 | borderRadius |
| S08b4dbca0abb_N390 | S08b4dbca0abb_N387 | object | 1–1 | object  |
| S08b4dbca0abb_N391 | S08b4dbca0abb_N390 | pair | 1–1 | pair  |
| S08b4dbca0abb_N392 | S08b4dbca0abb_N391 | string | 1–1 | string  |
| S08b4dbca0abb_N393 | S08b4dbca0abb_N392 | string_fragment | 1–1 | DEFAULT |
| S08b4dbca0abb_N394 | S08b4dbca0abb_N391 | string | 1–1 | string  |
| S08b4dbca0abb_N395 | S08b4dbca0abb_N394 | string_fragment | 1–1 | 0.25rem |
| S08b4dbca0abb_N396 | S08b4dbca0abb_N390 | pair | 1–1 | pair  |
| S08b4dbca0abb_N397 | S08b4dbca0abb_N396 | string | 1–1 | string  |
| S08b4dbca0abb_N398 | S08b4dbca0abb_N397 | string_fragment | 1–1 | lg |
| S08b4dbca0abb_N399 | S08b4dbca0abb_N396 | string | 1–1 | string  |
| S08b4dbca0abb_N400 | S08b4dbca0abb_N399 | string_fragment | 1–1 | 0.5rem |
| S08b4dbca0abb_N401 | S08b4dbca0abb_N390 | pair | 1–1 | pair  |
| S08b4dbca0abb_N402 | S08b4dbca0abb_N401 | string | 1–1 | string  |
| S08b4dbca0abb_N403 | S08b4dbca0abb_N402 | string_fragment | 1–1 | xl |
| S08b4dbca0abb_N404 | S08b4dbca0abb_N401 | string | 1–1 | string  |
| S08b4dbca0abb_N405 | S08b4dbca0abb_N404 | string_fragment | 1–1 | 0.75rem |
| S08b4dbca0abb_N406 | S08b4dbca0abb_N390 | pair | 1–1 | pair  |
| S08b4dbca0abb_N407 | S08b4dbca0abb_N406 | string | 1–1 | string  |
| S08b4dbca0abb_N408 | S08b4dbca0abb_N407 | string_fragment | 1–1 | full |
| S08b4dbca0abb_N409 | S08b4dbca0abb_N406 | string | 1–1 | string  |
| S08b4dbca0abb_N410 | S08b4dbca0abb_N409 | string_fragment | 1–1 | 9999px |
| S08b4dbca0abb_N411 | S08b4dbca0abb_N147 | pair | 1–1 | pair  |
| S08b4dbca0abb_N412 | S08b4dbca0abb_N411 | string | 1–1 | string  |
| S08b4dbca0abb_N413 | S08b4dbca0abb_N412 | string_fragment | 1–1 | spacing |
| S08b4dbca0abb_N414 | S08b4dbca0abb_N411 | object | 1–1 | object  |
| S08b4dbca0abb_N415 | S08b4dbca0abb_N414 | pair | 1–1 | pair  |
| S08b4dbca0abb_N416 | S08b4dbca0abb_N415 | string | 1–1 | string  |
| S08b4dbca0abb_N417 | S08b4dbca0abb_N416 | string_fragment | 1–1 | space-md |
| S08b4dbca0abb_N418 | S08b4dbca0abb_N415 | string | 1–1 | string  |
| S08b4dbca0abb_N419 | S08b4dbca0abb_N418 | string_fragment | 1–1 | 1rem |
| S08b4dbca0abb_N420 | S08b4dbca0abb_N414 | pair | 1–1 | pair  |
| S08b4dbca0abb_N421 | S08b4dbca0abb_N420 | string | 1–1 | string  |
| S08b4dbca0abb_N422 | S08b4dbca0abb_N421 | string_fragment | 1–1 | gutter-desktop |
| S08b4dbca0abb_N423 | S08b4dbca0abb_N420 | string | 1–1 | string  |
| S08b4dbca0abb_N424 | S08b4dbca0abb_N423 | string_fragment | 1–1 | 1.5rem |
| S08b4dbca0abb_N425 | S08b4dbca0abb_N414 | pair | 1–1 | pair  |
| S08b4dbca0abb_N426 | S08b4dbca0abb_N425 | string | 1–1 | string  |
| S08b4dbca0abb_N427 | S08b4dbca0abb_N426 | string_fragment | 1–1 | space-lg |
| S08b4dbca0abb_N428 | S08b4dbca0abb_N425 | string | 1–1 | string  |
| S08b4dbca0abb_N429 | S08b4dbca0abb_N428 | string_fragment | 1–1 | 1.5rem |
| S08b4dbca0abb_N430 | S08b4dbca0abb_N414 | pair | 1–1 | pair  |
| S08b4dbca0abb_N431 | S08b4dbca0abb_N430 | string | 1–1 | string  |
| S08b4dbca0abb_N432 | S08b4dbca0abb_N431 | string_fragment | 1–1 | margin-tablet |
| S08b4dbca0abb_N433 | S08b4dbca0abb_N430 | string | 1–1 | string  |
| S08b4dbca0abb_N434 | S08b4dbca0abb_N433 | string_fragment | 1–1 | 2rem |
| S08b4dbca0abb_N435 | S08b4dbca0abb_N414 | pair | 1–1 | pair  |
| S08b4dbca0abb_N436 | S08b4dbca0abb_N435 | string | 1–1 | string  |
| S08b4dbca0abb_N437 | S08b4dbca0abb_N436 | string_fragment | 1–1 | gutter |
| S08b4dbca0abb_N438 | S08b4dbca0abb_N435 | string | 1–1 | string  |
| S08b4dbca0abb_N439 | S08b4dbca0abb_N438 | string_fragment | 1–1 | 1rem |
| S08b4dbca0abb_N440 | S08b4dbca0abb_N414 | pair | 1–1 | pair  |
| S08b4dbca0abb_N441 | S08b4dbca0abb_N440 | string | 1–1 | string  |
| S08b4dbca0abb_N442 | S08b4dbca0abb_N441 | string_fragment | 1–1 | margin |
| S08b4dbca0abb_N443 | S08b4dbca0abb_N440 | string | 1–1 | string  |
| S08b4dbca0abb_N444 | S08b4dbca0abb_N443 | string_fragment | 1–1 | 1rem |
| S08b4dbca0abb_N445 | S08b4dbca0abb_N414 | pair | 1–1 | pair  |
| S08b4dbca0abb_N446 | S08b4dbca0abb_N445 | string | 1–1 | string  |
| S08b4dbca0abb_N447 | S08b4dbca0abb_N446 | string_fragment | 1–1 | margin-desktop |
| S08b4dbca0abb_N448 | S08b4dbca0abb_N445 | string | 1–1 | string  |
| S08b4dbca0abb_N449 | S08b4dbca0abb_N448 | string_fragment | 1–1 | 3rem |
| S08b4dbca0abb_N450 | S08b4dbca0abb_N414 | pair | 1–1 | pair  |
| S08b4dbca0abb_N451 | S08b4dbca0abb_N450 | string | 1–1 | string  |
| S08b4dbca0abb_N452 | S08b4dbca0abb_N451 | string_fragment | 1–1 | space-xl |
| S08b4dbca0abb_N453 | S08b4dbca0abb_N450 | string | 1–1 | string  |
| S08b4dbca0abb_N454 | S08b4dbca0abb_N453 | string_fragment | 1–1 | 2.5rem |
| S08b4dbca0abb_N455 | S08b4dbca0abb_N414 | pair | 1–1 | pair  |
| S08b4dbca0abb_N456 | S08b4dbca0abb_N455 | string | 1–1 | string  |
| S08b4dbca0abb_N457 | S08b4dbca0abb_N456 | string_fragment | 1–1 | space-xs |
| S08b4dbca0abb_N458 | S08b4dbca0abb_N455 | string | 1–1 | string  |
| S08b4dbca0abb_N459 | S08b4dbca0abb_N458 | string_fragment | 1–1 | 0.25rem |
| S08b4dbca0abb_N460 | S08b4dbca0abb_N414 | pair | 1–1 | pair  |
| S08b4dbca0abb_N461 | S08b4dbca0abb_N460 | string | 1–1 | string  |
| S08b4dbca0abb_N462 | S08b4dbca0abb_N461 | string_fragment | 1–1 | space-sm |
| S08b4dbca0abb_N463 | S08b4dbca0abb_N460 | string | 1–1 | string  |
| S08b4dbca0abb_N464 | S08b4dbca0abb_N463 | string_fragment | 1–1 | 0.5rem |
| S08b4dbca0abb_N465 | S08b4dbca0abb_N147 | pair | 1–1 | pair  |
| S08b4dbca0abb_N466 | S08b4dbca0abb_N465 | string | 1–1 | string  |
| S08b4dbca0abb_N467 | S08b4dbca0abb_N466 | string_fragment | 1–1 | fontFamily |
| S08b4dbca0abb_N468 | S08b4dbca0abb_N465 | object | 1–1 | object  |
| S08b4dbca0abb_N469 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N470 | S08b4dbca0abb_N469 | string | 1–1 | string  |
| S08b4dbca0abb_N471 | S08b4dbca0abb_N470 | string_fragment | 1–1 | headline-sm |
| S08b4dbca0abb_N472 | S08b4dbca0abb_N469 | array | 1–1 | array  |
| S08b4dbca0abb_N473 | S08b4dbca0abb_N472 | string | 1–1 | string  |
| S08b4dbca0abb_N474 | S08b4dbca0abb_N473 | string_fragment | 1–1 | Fraunces |
| S08b4dbca0abb_N475 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N476 | S08b4dbca0abb_N475 | string | 1–1 | string  |
| S08b4dbca0abb_N477 | S08b4dbca0abb_N476 | string_fragment | 1–1 | display-lg |
| S08b4dbca0abb_N478 | S08b4dbca0abb_N475 | array | 1–1 | array  |
| S08b4dbca0abb_N479 | S08b4dbca0abb_N478 | string | 1–1 | string  |
| S08b4dbca0abb_N480 | S08b4dbca0abb_N479 | string_fragment | 1–1 | Fraunces |
| S08b4dbca0abb_N481 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N482 | S08b4dbca0abb_N481 | string | 1–1 | string  |
| S08b4dbca0abb_N483 | S08b4dbca0abb_N482 | string_fragment | 1–1 | headline-lg |
| S08b4dbca0abb_N484 | S08b4dbca0abb_N481 | array | 1–1 | array  |
| S08b4dbca0abb_N485 | S08b4dbca0abb_N484 | string | 1–1 | string  |
| S08b4dbca0abb_N486 | S08b4dbca0abb_N485 | string_fragment | 1–1 | Fraunces |
| S08b4dbca0abb_N487 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N488 | S08b4dbca0abb_N487 | string | 1–1 | string  |
| S08b4dbca0abb_N489 | S08b4dbca0abb_N488 | string_fragment | 1–1 | display-lg-mobile |
| S08b4dbca0abb_N490 | S08b4dbca0abb_N487 | array | 1–1 | array  |
| S08b4dbca0abb_N491 | S08b4dbca0abb_N490 | string | 1–1 | string  |
| S08b4dbca0abb_N492 | S08b4dbca0abb_N491 | string_fragment | 1–1 | Fraunces |
| S08b4dbca0abb_N493 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N494 | S08b4dbca0abb_N493 | string | 1–1 | string  |
| S08b4dbca0abb_N495 | S08b4dbca0abb_N494 | string_fragment | 1–1 | astro-data-md |
| S08b4dbca0abb_N496 | S08b4dbca0abb_N493 | array | 1–1 | array  |
| S08b4dbca0abb_N497 | S08b4dbca0abb_N496 | string | 1–1 | string  |
| S08b4dbca0abb_N498 | S08b4dbca0abb_N497 | string_fragment | 1–1 | IBM Plex Mono |
| S08b4dbca0abb_N499 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N500 | S08b4dbca0abb_N499 | string | 1–1 | string  |
| S08b4dbca0abb_N501 | S08b4dbca0abb_N500 | string_fragment | 1–1 | headline-md |
| S08b4dbca0abb_N502 | S08b4dbca0abb_N499 | array | 1–1 | array  |
| S08b4dbca0abb_N503 | S08b4dbca0abb_N502 | string | 1–1 | string  |
| S08b4dbca0abb_N504 | S08b4dbca0abb_N503 | string_fragment | 1–1 | Fraunces |
| S08b4dbca0abb_N505 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N506 | S08b4dbca0abb_N505 | string | 1–1 | string  |
| S08b4dbca0abb_N507 | S08b4dbca0abb_N506 | string_fragment | 1–1 | body-md |
| S08b4dbca0abb_N508 | S08b4dbca0abb_N505 | array | 1–1 | array  |
| S08b4dbca0abb_N509 | S08b4dbca0abb_N508 | string | 1–1 | string  |
| S08b4dbca0abb_N510 | S08b4dbca0abb_N509 | string_fragment | 1–1 | Nunito Sans |
| S08b4dbca0abb_N511 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N512 | S08b4dbca0abb_N511 | string | 1–1 | string  |
| S08b4dbca0abb_N513 | S08b4dbca0abb_N512 | string_fragment | 1–1 | body-lg |
| S08b4dbca0abb_N514 | S08b4dbca0abb_N511 | array | 1–1 | array  |
| S08b4dbca0abb_N515 | S08b4dbca0abb_N514 | string | 1–1 | string  |
| S08b4dbca0abb_N516 | S08b4dbca0abb_N515 | string_fragment | 1–1 | Nunito Sans |
| S08b4dbca0abb_N517 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N518 | S08b4dbca0abb_N517 | string | 1–1 | string  |
| S08b4dbca0abb_N519 | S08b4dbca0abb_N518 | string_fragment | 1–1 | oracle-voice |
| S08b4dbca0abb_N520 | S08b4dbca0abb_N517 | array | 1–1 | array  |
| S08b4dbca0abb_N521 | S08b4dbca0abb_N520 | string | 1–1 | string  |
| S08b4dbca0abb_N522 | S08b4dbca0abb_N521 | string_fragment | 1–1 | Fraunces |
| S08b4dbca0abb_N523 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N524 | S08b4dbca0abb_N523 | string | 1–1 | string  |
| S08b4dbca0abb_N525 | S08b4dbca0abb_N524 | string_fragment | 1–1 | body-sm |
| S08b4dbca0abb_N526 | S08b4dbca0abb_N523 | array | 1–1 | array  |
| S08b4dbca0abb_N527 | S08b4dbca0abb_N526 | string | 1–1 | string  |
| S08b4dbca0abb_N528 | S08b4dbca0abb_N527 | string_fragment | 1–1 | Nunito Sans |
| S08b4dbca0abb_N529 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N530 | S08b4dbca0abb_N529 | string | 1–1 | string  |
| S08b4dbca0abb_N531 | S08b4dbca0abb_N530 | string_fragment | 1–1 | astro-data-lg |
| S08b4dbca0abb_N532 | S08b4dbca0abb_N529 | array | 1–1 | array  |
| S08b4dbca0abb_N533 | S08b4dbca0abb_N532 | string | 1–1 | string  |
| S08b4dbca0abb_N534 | S08b4dbca0abb_N533 | string_fragment | 1–1 | IBM Plex Mono |
| S08b4dbca0abb_N535 | S08b4dbca0abb_N468 | pair | 1–1 | pair  |
| S08b4dbca0abb_N536 | S08b4dbca0abb_N535 | string | 1–1 | string  |
| S08b4dbca0abb_N537 | S08b4dbca0abb_N536 | string_fragment | 1–1 | label-caps |
| S08b4dbca0abb_N538 | S08b4dbca0abb_N535 | array | 1–1 | array  |
| S08b4dbca0abb_N539 | S08b4dbca0abb_N538 | string | 1–1 | string  |
| S08b4dbca0abb_N540 | S08b4dbca0abb_N539 | string_fragment | 1–1 | IBM Plex Mono |
| S08b4dbca0abb_N541 | S08b4dbca0abb_N147 | pair | 1–1 | pair  |
| S08b4dbca0abb_N542 | S08b4dbca0abb_N541 | string | 1–1 | string  |
| S08b4dbca0abb_N543 | S08b4dbca0abb_N542 | string_fragment | 1–1 | fontSize |
| S08b4dbca0abb_N544 | S08b4dbca0abb_N541 | object | 1–1 | object  |
| S08b4dbca0abb_N545 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N546 | S08b4dbca0abb_N545 | string | 1–1 | string  |
| S08b4dbca0abb_N547 | S08b4dbca0abb_N546 | string_fragment | 1–1 | headline-sm |
| S08b4dbca0abb_N548 | S08b4dbca0abb_N545 | array | 1–1 | array  |
| S08b4dbca0abb_N549 | S08b4dbca0abb_N548 | string | 1–1 | string  |
| S08b4dbca0abb_N550 | S08b4dbca0abb_N549 | string_fragment | 1–1 | 18px |
| S08b4dbca0abb_N551 | S08b4dbca0abb_N548 | object | 1–1 | object  |
| S08b4dbca0abb_N552 | S08b4dbca0abb_N551 | pair | 1–1 | pair  |
| S08b4dbca0abb_N553 | S08b4dbca0abb_N552 | string | 1–1 | string  |
| S08b4dbca0abb_N554 | S08b4dbca0abb_N553 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N555 | S08b4dbca0abb_N552 | string | 1–1 | string  |
| S08b4dbca0abb_N556 | S08b4dbca0abb_N555 | string_fragment | 1–1 | 26px |
| S08b4dbca0abb_N557 | S08b4dbca0abb_N551 | pair | 1–1 | pair  |
| S08b4dbca0abb_N558 | S08b4dbca0abb_N557 | string | 1–1 | string  |
| S08b4dbca0abb_N559 | S08b4dbca0abb_N558 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N560 | S08b4dbca0abb_N557 | string | 1–1 | string  |
| S08b4dbca0abb_N561 | S08b4dbca0abb_N560 | string_fragment | 1–1 | 600 |
| S08b4dbca0abb_N562 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N563 | S08b4dbca0abb_N562 | string | 1–1 | string  |
| S08b4dbca0abb_N564 | S08b4dbca0abb_N563 | string_fragment | 1–1 | display-lg |
| S08b4dbca0abb_N565 | S08b4dbca0abb_N562 | array | 1–1 | array  |
| S08b4dbca0abb_N566 | S08b4dbca0abb_N565 | string | 1–1 | string  |
| S08b4dbca0abb_N567 | S08b4dbca0abb_N566 | string_fragment | 1–1 | 40px |
| S08b4dbca0abb_N568 | S08b4dbca0abb_N565 | object | 1–1 | object  |
| S08b4dbca0abb_N569 | S08b4dbca0abb_N568 | pair | 1–1 | pair  |
| S08b4dbca0abb_N570 | S08b4dbca0abb_N569 | string | 1–1 | string  |
| S08b4dbca0abb_N571 | S08b4dbca0abb_N570 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N572 | S08b4dbca0abb_N569 | string | 1–1 | string  |
| S08b4dbca0abb_N573 | S08b4dbca0abb_N572 | string_fragment | 1–1 | 48px |
| S08b4dbca0abb_N574 | S08b4dbca0abb_N568 | pair | 1–1 | pair  |
| S08b4dbca0abb_N575 | S08b4dbca0abb_N574 | string | 1–1 | string  |
| S08b4dbca0abb_N576 | S08b4dbca0abb_N575 | string_fragment | 1–1 | letterSpacing |
| S08b4dbca0abb_N577 | S08b4dbca0abb_N574 | string | 1–1 | string  |
| S08b4dbca0abb_N578 | S08b4dbca0abb_N577 | string_fragment | 1–1 | -0.02em |
| S08b4dbca0abb_N579 | S08b4dbca0abb_N568 | pair | 1–1 | pair  |
| S08b4dbca0abb_N580 | S08b4dbca0abb_N579 | string | 1–1 | string  |
| S08b4dbca0abb_N581 | S08b4dbca0abb_N580 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N582 | S08b4dbca0abb_N579 | string | 1–1 | string  |
| S08b4dbca0abb_N583 | S08b4dbca0abb_N582 | string_fragment | 1–1 | 600 |
| S08b4dbca0abb_N584 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N585 | S08b4dbca0abb_N584 | string | 1–1 | string  |
| S08b4dbca0abb_N586 | S08b4dbca0abb_N585 | string_fragment | 1–1 | headline-lg |
| S08b4dbca0abb_N587 | S08b4dbca0abb_N584 | array | 1–1 | array  |
| S08b4dbca0abb_N588 | S08b4dbca0abb_N587 | string | 1–1 | string  |
| S08b4dbca0abb_N589 | S08b4dbca0abb_N588 | string_fragment | 1–1 | 28px |
| S08b4dbca0abb_N590 | S08b4dbca0abb_N587 | object | 1–1 | object  |
| S08b4dbca0abb_N591 | S08b4dbca0abb_N590 | pair | 1–1 | pair  |
| S08b4dbca0abb_N592 | S08b4dbca0abb_N591 | string | 1–1 | string  |
| S08b4dbca0abb_N593 | S08b4dbca0abb_N592 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N594 | S08b4dbca0abb_N591 | string | 1–1 | string  |
| S08b4dbca0abb_N595 | S08b4dbca0abb_N594 | string_fragment | 1–1 | 36px |
| S08b4dbca0abb_N596 | S08b4dbca0abb_N590 | pair | 1–1 | pair  |
| S08b4dbca0abb_N597 | S08b4dbca0abb_N596 | string | 1–1 | string  |
| S08b4dbca0abb_N598 | S08b4dbca0abb_N597 | string_fragment | 1–1 | letterSpacing |
| S08b4dbca0abb_N599 | S08b4dbca0abb_N596 | string | 1–1 | string  |
| S08b4dbca0abb_N600 | S08b4dbca0abb_N599 | string_fragment | 1–1 | -0.01em |
| S08b4dbca0abb_N601 | S08b4dbca0abb_N590 | pair | 1–1 | pair  |
| S08b4dbca0abb_N602 | S08b4dbca0abb_N601 | string | 1–1 | string  |
| S08b4dbca0abb_N603 | S08b4dbca0abb_N602 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N604 | S08b4dbca0abb_N601 | string | 1–1 | string  |
| S08b4dbca0abb_N605 | S08b4dbca0abb_N604 | string_fragment | 1–1 | 500 |
| S08b4dbca0abb_N606 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N607 | S08b4dbca0abb_N606 | string | 1–1 | string  |
| S08b4dbca0abb_N608 | S08b4dbca0abb_N607 | string_fragment | 1–1 | display-lg-mobile |
| S08b4dbca0abb_N609 | S08b4dbca0abb_N606 | array | 1–1 | array  |
| S08b4dbca0abb_N610 | S08b4dbca0abb_N609 | string | 1–1 | string  |
| S08b4dbca0abb_N611 | S08b4dbca0abb_N610 | string_fragment | 1–1 | 30px |
| S08b4dbca0abb_N612 | S08b4dbca0abb_N609 | object | 1–1 | object  |
| S08b4dbca0abb_N613 | S08b4dbca0abb_N612 | pair | 1–1 | pair  |
| S08b4dbca0abb_N614 | S08b4dbca0abb_N613 | string | 1–1 | string  |
| S08b4dbca0abb_N615 | S08b4dbca0abb_N614 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N616 | S08b4dbca0abb_N613 | string | 1–1 | string  |
| S08b4dbca0abb_N617 | S08b4dbca0abb_N616 | string_fragment | 1–1 | 38px |
| S08b4dbca0abb_N618 | S08b4dbca0abb_N612 | pair | 1–1 | pair  |
| S08b4dbca0abb_N619 | S08b4dbca0abb_N618 | string | 1–1 | string  |
| S08b4dbca0abb_N620 | S08b4dbca0abb_N619 | string_fragment | 1–1 | letterSpacing |
| S08b4dbca0abb_N621 | S08b4dbca0abb_N618 | string | 1–1 | string  |
| S08b4dbca0abb_N622 | S08b4dbca0abb_N621 | string_fragment | 1–1 | -0.01em |
| S08b4dbca0abb_N623 | S08b4dbca0abb_N612 | pair | 1–1 | pair  |
| S08b4dbca0abb_N624 | S08b4dbca0abb_N623 | string | 1–1 | string  |
| S08b4dbca0abb_N625 | S08b4dbca0abb_N624 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N626 | S08b4dbca0abb_N623 | string | 1–1 | string  |
| S08b4dbca0abb_N627 | S08b4dbca0abb_N626 | string_fragment | 1–1 | 600 |
| S08b4dbca0abb_N628 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N629 | S08b4dbca0abb_N628 | string | 1–1 | string  |
| S08b4dbca0abb_N630 | S08b4dbca0abb_N629 | string_fragment | 1–1 | astro-data-md |
| S08b4dbca0abb_N631 | S08b4dbca0abb_N628 | array | 1–1 | array  |
| S08b4dbca0abb_N632 | S08b4dbca0abb_N631 | string | 1–1 | string  |
| S08b4dbca0abb_N633 | S08b4dbca0abb_N632 | string_fragment | 1–1 | 13px |
| S08b4dbca0abb_N634 | S08b4dbca0abb_N631 | object | 1–1 | object  |
| S08b4dbca0abb_N635 | S08b4dbca0abb_N634 | pair | 1–1 | pair  |
| S08b4dbca0abb_N636 | S08b4dbca0abb_N635 | string | 1–1 | string  |
| S08b4dbca0abb_N637 | S08b4dbca0abb_N636 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N638 | S08b4dbca0abb_N635 | string | 1–1 | string  |
| S08b4dbca0abb_N639 | S08b4dbca0abb_N638 | string_fragment | 1–1 | 18px |
| S08b4dbca0abb_N640 | S08b4dbca0abb_N634 | pair | 1–1 | pair  |
| S08b4dbca0abb_N641 | S08b4dbca0abb_N640 | string | 1–1 | string  |
| S08b4dbca0abb_N642 | S08b4dbca0abb_N641 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N643 | S08b4dbca0abb_N640 | string | 1–1 | string  |
| S08b4dbca0abb_N644 | S08b4dbca0abb_N643 | string_fragment | 1–1 | 400 |
| S08b4dbca0abb_N645 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N646 | S08b4dbca0abb_N645 | string | 1–1 | string  |
| S08b4dbca0abb_N647 | S08b4dbca0abb_N646 | string_fragment | 1–1 | headline-md |
| S08b4dbca0abb_N648 | S08b4dbca0abb_N645 | array | 1–1 | array  |
| S08b4dbca0abb_N649 | S08b4dbca0abb_N648 | string | 1–1 | string  |
| S08b4dbca0abb_N650 | S08b4dbca0abb_N649 | string_fragment | 1–1 | 22px |
| S08b4dbca0abb_N651 | S08b4dbca0abb_N648 | object | 1–1 | object  |
| S08b4dbca0abb_N652 | S08b4dbca0abb_N651 | pair | 1–1 | pair  |
| S08b4dbca0abb_N653 | S08b4dbca0abb_N652 | string | 1–1 | string  |
| S08b4dbca0abb_N654 | S08b4dbca0abb_N653 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N655 | S08b4dbca0abb_N652 | string | 1–1 | string  |
| S08b4dbca0abb_N656 | S08b4dbca0abb_N655 | string_fragment | 1–1 | 30px |
| S08b4dbca0abb_N657 | S08b4dbca0abb_N651 | pair | 1–1 | pair  |
| S08b4dbca0abb_N658 | S08b4dbca0abb_N657 | string | 1–1 | string  |
| S08b4dbca0abb_N659 | S08b4dbca0abb_N658 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N660 | S08b4dbca0abb_N657 | string | 1–1 | string  |
| S08b4dbca0abb_N661 | S08b4dbca0abb_N660 | string_fragment | 1–1 | 500 |
| S08b4dbca0abb_N662 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N663 | S08b4dbca0abb_N662 | string | 1–1 | string  |
| S08b4dbca0abb_N664 | S08b4dbca0abb_N663 | string_fragment | 1–1 | body-md |
| S08b4dbca0abb_N665 | S08b4dbca0abb_N662 | array | 1–1 | array  |
| S08b4dbca0abb_N666 | S08b4dbca0abb_N665 | string | 1–1 | string  |
| S08b4dbca0abb_N667 | S08b4dbca0abb_N666 | string_fragment | 1–1 | 15px |
| S08b4dbca0abb_N668 | S08b4dbca0abb_N665 | object | 1–1 | object  |
| S08b4dbca0abb_N669 | S08b4dbca0abb_N668 | pair | 1–1 | pair  |
| S08b4dbca0abb_N670 | S08b4dbca0abb_N669 | string | 1–1 | string  |
| S08b4dbca0abb_N671 | S08b4dbca0abb_N670 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N672 | S08b4dbca0abb_N669 | string | 1–1 | string  |
| S08b4dbca0abb_N673 | S08b4dbca0abb_N672 | string_fragment | 1–1 | 22px |
| S08b4dbca0abb_N674 | S08b4dbca0abb_N668 | pair | 1–1 | pair  |
| S08b4dbca0abb_N675 | S08b4dbca0abb_N674 | string | 1–1 | string  |
| S08b4dbca0abb_N676 | S08b4dbca0abb_N675 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N677 | S08b4dbca0abb_N674 | string | 1–1 | string  |
| S08b4dbca0abb_N678 | S08b4dbca0abb_N677 | string_fragment | 1–1 | 400 |
| S08b4dbca0abb_N679 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N680 | S08b4dbca0abb_N679 | string | 1–1 | string  |
| S08b4dbca0abb_N681 | S08b4dbca0abb_N680 | string_fragment | 1–1 | body-lg |
| S08b4dbca0abb_N682 | S08b4dbca0abb_N679 | array | 1–1 | array  |
| S08b4dbca0abb_N683 | S08b4dbca0abb_N682 | string | 1–1 | string  |
| S08b4dbca0abb_N684 | S08b4dbca0abb_N683 | string_fragment | 1–1 | 17px |
| S08b4dbca0abb_N685 | S08b4dbca0abb_N682 | object | 1–1 | object  |
| S08b4dbca0abb_N686 | S08b4dbca0abb_N685 | pair | 1–1 | pair  |
| S08b4dbca0abb_N687 | S08b4dbca0abb_N686 | string | 1–1 | string  |
| S08b4dbca0abb_N688 | S08b4dbca0abb_N687 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N689 | S08b4dbca0abb_N686 | string | 1–1 | string  |
| S08b4dbca0abb_N690 | S08b4dbca0abb_N689 | string_fragment | 1–1 | 26px |
| S08b4dbca0abb_N691 | S08b4dbca0abb_N685 | pair | 1–1 | pair  |
| S08b4dbca0abb_N692 | S08b4dbca0abb_N691 | string | 1–1 | string  |
| S08b4dbca0abb_N693 | S08b4dbca0abb_N692 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N694 | S08b4dbca0abb_N691 | string | 1–1 | string  |
| S08b4dbca0abb_N695 | S08b4dbca0abb_N694 | string_fragment | 1–1 | 400 |
| S08b4dbca0abb_N696 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N697 | S08b4dbca0abb_N696 | string | 1–1 | string  |
| S08b4dbca0abb_N698 | S08b4dbca0abb_N697 | string_fragment | 1–1 | oracle-voice |
| S08b4dbca0abb_N699 | S08b4dbca0abb_N696 | array | 1–1 | array  |
| S08b4dbca0abb_N700 | S08b4dbca0abb_N699 | string | 1–1 | string  |
| S08b4dbca0abb_N701 | S08b4dbca0abb_N700 | string_fragment | 1–1 | 16px |
| S08b4dbca0abb_N702 | S08b4dbca0abb_N699 | object | 1–1 | object  |
| S08b4dbca0abb_N703 | S08b4dbca0abb_N702 | pair | 1–1 | pair  |
| S08b4dbca0abb_N704 | S08b4dbca0abb_N703 | string | 1–1 | string  |
| S08b4dbca0abb_N705 | S08b4dbca0abb_N704 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N706 | S08b4dbca0abb_N703 | string | 1–1 | string  |
| S08b4dbca0abb_N707 | S08b4dbca0abb_N706 | string_fragment | 1–1 | 24px |
| S08b4dbca0abb_N708 | S08b4dbca0abb_N702 | pair | 1–1 | pair  |
| S08b4dbca0abb_N709 | S08b4dbca0abb_N708 | string | 1–1 | string  |
| S08b4dbca0abb_N710 | S08b4dbca0abb_N709 | string_fragment | 1–1 | letterSpacing |
| S08b4dbca0abb_N711 | S08b4dbca0abb_N708 | string | 1–1 | string  |
| S08b4dbca0abb_N712 | S08b4dbca0abb_N711 | string_fragment | 1–1 | 0.01em |
| S08b4dbca0abb_N713 | S08b4dbca0abb_N702 | pair | 1–1 | pair  |
| S08b4dbca0abb_N714 | S08b4dbca0abb_N713 | string | 1–1 | string  |
| S08b4dbca0abb_N715 | S08b4dbca0abb_N714 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N716 | S08b4dbca0abb_N713 | string | 1–1 | string  |
| S08b4dbca0abb_N717 | S08b4dbca0abb_N716 | string_fragment | 1–1 | 400 |
| S08b4dbca0abb_N718 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N719 | S08b4dbca0abb_N718 | string | 1–1 | string  |
| S08b4dbca0abb_N720 | S08b4dbca0abb_N719 | string_fragment | 1–1 | body-sm |
| S08b4dbca0abb_N721 | S08b4dbca0abb_N718 | array | 1–1 | array  |
| S08b4dbca0abb_N722 | S08b4dbca0abb_N721 | string | 1–1 | string  |
| S08b4dbca0abb_N723 | S08b4dbca0abb_N722 | string_fragment | 1–1 | 13px |
| S08b4dbca0abb_N724 | S08b4dbca0abb_N721 | object | 1–1 | object  |
| S08b4dbca0abb_N725 | S08b4dbca0abb_N724 | pair | 1–1 | pair  |
| S08b4dbca0abb_N726 | S08b4dbca0abb_N725 | string | 1–1 | string  |
| S08b4dbca0abb_N727 | S08b4dbca0abb_N726 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N728 | S08b4dbca0abb_N725 | string | 1–1 | string  |
| S08b4dbca0abb_N729 | S08b4dbca0abb_N728 | string_fragment | 1–1 | 18px |
| S08b4dbca0abb_N730 | S08b4dbca0abb_N724 | pair | 1–1 | pair  |
| S08b4dbca0abb_N731 | S08b4dbca0abb_N730 | string | 1–1 | string  |
| S08b4dbca0abb_N732 | S08b4dbca0abb_N731 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N733 | S08b4dbca0abb_N730 | string | 1–1 | string  |
| S08b4dbca0abb_N734 | S08b4dbca0abb_N733 | string_fragment | 1–1 | 400 |
| S08b4dbca0abb_N735 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N736 | S08b4dbca0abb_N735 | string | 1–1 | string  |
| S08b4dbca0abb_N737 | S08b4dbca0abb_N736 | string_fragment | 1–1 | astro-data-lg |
| S08b4dbca0abb_N738 | S08b4dbca0abb_N735 | array | 1–1 | array  |
| S08b4dbca0abb_N739 | S08b4dbca0abb_N738 | string | 1–1 | string  |
| S08b4dbca0abb_N740 | S08b4dbca0abb_N739 | string_fragment | 1–1 | 16px |
| S08b4dbca0abb_N741 | S08b4dbca0abb_N738 | object | 1–1 | object  |
| S08b4dbca0abb_N742 | S08b4dbca0abb_N741 | pair | 1–1 | pair  |
| S08b4dbca0abb_N743 | S08b4dbca0abb_N742 | string | 1–1 | string  |
| S08b4dbca0abb_N744 | S08b4dbca0abb_N743 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N745 | S08b4dbca0abb_N742 | string | 1–1 | string  |
| S08b4dbca0abb_N746 | S08b4dbca0abb_N745 | string_fragment | 1–1 | 22px |
| S08b4dbca0abb_N747 | S08b4dbca0abb_N741 | pair | 1–1 | pair  |
| S08b4dbca0abb_N748 | S08b4dbca0abb_N747 | string | 1–1 | string  |
| S08b4dbca0abb_N749 | S08b4dbca0abb_N748 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N750 | S08b4dbca0abb_N747 | string | 1–1 | string  |
| S08b4dbca0abb_N751 | S08b4dbca0abb_N750 | string_fragment | 1–1 | 500 |
| S08b4dbca0abb_N752 | S08b4dbca0abb_N544 | pair | 1–1 | pair  |
| S08b4dbca0abb_N753 | S08b4dbca0abb_N752 | string | 1–1 | string  |
| S08b4dbca0abb_N754 | S08b4dbca0abb_N753 | string_fragment | 1–1 | label-caps |
| S08b4dbca0abb_N755 | S08b4dbca0abb_N752 | array | 1–1 | array  |
| S08b4dbca0abb_N756 | S08b4dbca0abb_N755 | string | 1–1 | string  |
| S08b4dbca0abb_N757 | S08b4dbca0abb_N756 | string_fragment | 1–1 | 11px |
| S08b4dbca0abb_N758 | S08b4dbca0abb_N755 | object | 1–1 | object  |
| S08b4dbca0abb_N759 | S08b4dbca0abb_N758 | pair | 1–1 | pair  |
| S08b4dbca0abb_N760 | S08b4dbca0abb_N759 | string | 1–1 | string  |
| S08b4dbca0abb_N761 | S08b4dbca0abb_N760 | string_fragment | 1–1 | lineHeight |
| S08b4dbca0abb_N762 | S08b4dbca0abb_N759 | string | 1–1 | string  |
| S08b4dbca0abb_N763 | S08b4dbca0abb_N762 | string_fragment | 1–1 | 14px |
| S08b4dbca0abb_N764 | S08b4dbca0abb_N758 | pair | 1–1 | pair  |
| S08b4dbca0abb_N765 | S08b4dbca0abb_N764 | string | 1–1 | string  |
| S08b4dbca0abb_N766 | S08b4dbca0abb_N765 | string_fragment | 1–1 | letterSpacing |
| S08b4dbca0abb_N767 | S08b4dbca0abb_N764 | string | 1–1 | string  |
| S08b4dbca0abb_N768 | S08b4dbca0abb_N767 | string_fragment | 1–1 | 0.08em |
| S08b4dbca0abb_N769 | S08b4dbca0abb_N758 | pair | 1–1 | pair  |
| S08b4dbca0abb_N770 | S08b4dbca0abb_N769 | string | 1–1 | string  |
| S08b4dbca0abb_N771 | S08b4dbca0abb_N770 | string_fragment | 1–1 | fontWeight |
| S08b4dbca0abb_N772 | S08b4dbca0abb_N769 | string | 1–1 | string  |
| S08b4dbca0abb_N773 | S08b4dbca0abb_N772 | string_fragment | 1–1 | 600 |
| S08b4dbca0abb_N774 | S08b4dbca0abb_N14 | style_element | 4–4 | style_element  |
| S08b4dbca0abb_N775 | S08b4dbca0abb_N774 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N776 | S08b4dbca0abb_N775 | tag_name | 4–4 | style |
| S08b4dbca0abb_N777 | S08b4dbca0abb_N775 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N778 | S08b4dbca0abb_N777 | attribute_name | 4–4 | data-prototype-touch-targets |
| S08b4dbca0abb_N779 | S08b4dbca0abb_N774 | raw_text | 4–4 | @media(max-width:767px){button,a[href],label:has(input[type=radio]){min-height:44px}} |
| S08b4dbca0abb_N780 | S08b4dbca0abb_N774 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N781 | S08b4dbca0abb_N780 | tag_name | 4–4 | style |
| S08b4dbca0abb_N782 | S08b4dbca0abb_N14 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N783 | S08b4dbca0abb_N782 | tag_name | 4–4 | head |
| S08b4dbca0abb_N784 | S08b4dbca0abb_N3 | element | 4–208 | element  |
| S08b4dbca0abb_N785 | S08b4dbca0abb_N784 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N786 | S08b4dbca0abb_N785 | tag_name | 4–4 | body |
| S08b4dbca0abb_N787 | S08b4dbca0abb_N785 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N788 | S08b4dbca0abb_N787 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N789 | S08b4dbca0abb_N787 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N790 | S08b4dbca0abb_N789 | attribute_value | 4–4 | bg-surface font-body-md text-on-surface min-h-screen flex flex-col selection:bg-primary-container selection:text-on-primary-container |
| S08b4dbca0abb_N791 | S08b4dbca0abb_N784 | element | 4–4 | element  |
| S08b4dbca0abb_N792 | S08b4dbca0abb_N791 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N793 | S08b4dbca0abb_N792 | tag_name | 4–4 | header |
| S08b4dbca0abb_N794 | S08b4dbca0abb_N792 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N795 | S08b4dbca0abb_N794 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N796 | S08b4dbca0abb_N794 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N797 | S08b4dbca0abb_N796 | attribute_value | 4–4 | fixed top-0 left-0 right-0 w-full z-50 bg-surface/85 backdrop-blur-xl shadow-[0_1px_8px_rgba(0,0,0,0.25)] |
| S08b4dbca0abb_N798 | S08b4dbca0abb_N791 | element | 4–4 | element  |
| S08b4dbca0abb_N799 | S08b4dbca0abb_N798 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N800 | S08b4dbca0abb_N799 | tag_name | 4–4 | div |
| S08b4dbca0abb_N801 | S08b4dbca0abb_N799 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N802 | S08b4dbca0abb_N801 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N803 | S08b4dbca0abb_N801 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N804 | S08b4dbca0abb_N803 | attribute_value | 4–4 | h-16 max-w-7xl mx-auto px-margin-desktop flex items-center justify-between |
| S08b4dbca0abb_N805 | S08b4dbca0abb_N798 | element | 4–4 | element  |
| S08b4dbca0abb_N806 | S08b4dbca0abb_N805 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N807 | S08b4dbca0abb_N806 | tag_name | 4–4 | div |
| S08b4dbca0abb_N808 | S08b4dbca0abb_N806 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N809 | S08b4dbca0abb_N808 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N810 | S08b4dbca0abb_N808 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N811 | S08b4dbca0abb_N810 | attribute_value | 4–4 | flex items-center gap-space-lg |
| S08b4dbca0abb_N812 | S08b4dbca0abb_N805 | element | 4–4 | element  |
| S08b4dbca0abb_N813 | S08b4dbca0abb_N812 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N814 | S08b4dbca0abb_N813 | tag_name | 4–4 | a |
| S08b4dbca0abb_N815 | S08b4dbca0abb_N813 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N816 | S08b4dbca0abb_N815 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N817 | S08b4dbca0abb_N815 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N818 | S08b4dbca0abb_N817 | attribute_value | 4–4 | flex items-center gap-space-sm group |
| S08b4dbca0abb_N819 | S08b4dbca0abb_N813 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N820 | S08b4dbca0abb_N819 | attribute_name | 4–4 | data-path |
| S08b4dbca0abb_N821 | S08b4dbca0abb_N819 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N822 | S08b4dbca0abb_N821 | attribute_value | 4–4 | birth-chart-entry |
| S08b4dbca0abb_N823 | S08b4dbca0abb_N813 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N824 | S08b4dbca0abb_N823 | attribute_name | 4–4 | href |
| S08b4dbca0abb_N825 | S08b4dbca0abb_N823 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N826 | S08b4dbca0abb_N825 | attribute_value | 4–4 | # |
| S08b4dbca0abb_N827 | S08b4dbca0abb_N812 | element | 4–4 | element  |
| S08b4dbca0abb_N828 | S08b4dbca0abb_N827 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N829 | S08b4dbca0abb_N828 | tag_name | 4–4 | span |
| S08b4dbca0abb_N830 | S08b4dbca0abb_N828 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N831 | S08b4dbca0abb_N830 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N832 | S08b4dbca0abb_N830 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N833 | S08b4dbca0abb_N832 | attribute_value | 4–4 | font-headline-md text-headline-md text-primary tracking-tight |
| S08b4dbca0abb_N834 | S08b4dbca0abb_N827 | text | 4–4 | Natally |
| S08b4dbca0abb_N835 | S08b4dbca0abb_N827 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N836 | S08b4dbca0abb_N835 | tag_name | 4–4 | span |
| S08b4dbca0abb_N837 | S08b4dbca0abb_N812 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N838 | S08b4dbca0abb_N837 | tag_name | 4–4 | a |
| S08b4dbca0abb_N839 | S08b4dbca0abb_N805 | element | 4–4 | element  |
| S08b4dbca0abb_N840 | S08b4dbca0abb_N839 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N841 | S08b4dbca0abb_N840 | tag_name | 4–4 | div |
| S08b4dbca0abb_N842 | S08b4dbca0abb_N840 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N843 | S08b4dbca0abb_N842 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N844 | S08b4dbca0abb_N842 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N845 | S08b4dbca0abb_N844 | attribute_value | 4–4 | h-4 w-px bg-surface-variant hidden sm:block |
| S08b4dbca0abb_N846 | S08b4dbca0abb_N839 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N847 | S08b4dbca0abb_N846 | tag_name | 4–4 | div |
| S08b4dbca0abb_N848 | S08b4dbca0abb_N805 | element | 4–4 | element  |
| S08b4dbca0abb_N849 | S08b4dbca0abb_N848 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N850 | S08b4dbca0abb_N849 | tag_name | 4–4 | nav |
| S08b4dbca0abb_N851 | S08b4dbca0abb_N849 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N852 | S08b4dbca0abb_N851 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N853 | S08b4dbca0abb_N851 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N854 | S08b4dbca0abb_N853 | attribute_value | 4–4 | hidden sm:flex items-center gap-space-md |
| S08b4dbca0abb_N855 | S08b4dbca0abb_N849 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N856 | S08b4dbca0abb_N855 | attribute_name | 4–4 | data-active-classes |
| S08b4dbca0abb_N857 | S08b4dbca0abb_N855 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N858 | S08b4dbca0abb_N857 | attribute_value | 4–4 | text-primary font-bold |
| S08b4dbca0abb_N859 | S08b4dbca0abb_N848 | element | 4–4 | element  |
| S08b4dbca0abb_N860 | S08b4dbca0abb_N859 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N861 | S08b4dbca0abb_N860 | tag_name | 4–4 | a |
| S08b4dbca0abb_N862 | S08b4dbca0abb_N860 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N863 | S08b4dbca0abb_N862 | attribute_name | 4–4 | aria-current |
| S08b4dbca0abb_N864 | S08b4dbca0abb_N862 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N865 | S08b4dbca0abb_N864 | attribute_value | 4–4 | page |
| S08b4dbca0abb_N866 | S08b4dbca0abb_N860 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N867 | S08b4dbca0abb_N866 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N868 | S08b4dbca0abb_N866 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N869 | S08b4dbca0abb_N868 | attribute_value | 4–4 | uppercase tracking-wider transition-colors text-primary font-bold |
| S08b4dbca0abb_N870 | S08b4dbca0abb_N860 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N871 | S08b4dbca0abb_N870 | attribute_name | 4–4 | data-path |
| S08b4dbca0abb_N872 | S08b4dbca0abb_N870 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N873 | S08b4dbca0abb_N872 | attribute_value | 4–4 | birth-chart-entry |
| S08b4dbca0abb_N874 | S08b4dbca0abb_N860 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N875 | S08b4dbca0abb_N874 | attribute_name | 4–4 | href |
| S08b4dbca0abb_N876 | S08b4dbca0abb_N874 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N877 | S08b4dbca0abb_N876 | attribute_value | 4–4 | # |
| S08b4dbca0abb_N878 | S08b4dbca0abb_N859 | text | 4–4 | Natal Chart |
| S08b4dbca0abb_N879 | S08b4dbca0abb_N859 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N880 | S08b4dbca0abb_N879 | tag_name | 4–4 | a |
| S08b4dbca0abb_N881 | S08b4dbca0abb_N848 | element | 4–4 | element  |
| S08b4dbca0abb_N882 | S08b4dbca0abb_N881 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N883 | S08b4dbca0abb_N882 | tag_name | 4–4 | span |
| S08b4dbca0abb_N884 | S08b4dbca0abb_N882 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N885 | S08b4dbca0abb_N884 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N886 | S08b4dbca0abb_N884 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N887 | S08b4dbca0abb_N886 | attribute_value | 4–4 | text-on-surface-variant opacity-40 font-astro-data-md text-astro-data-md |
| S08b4dbca0abb_N888 | S08b4dbca0abb_N881 | text | 4–4 | / |
| S08b4dbca0abb_N889 | S08b4dbca0abb_N881 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N890 | S08b4dbca0abb_N889 | tag_name | 4–4 | span |
| S08b4dbca0abb_N891 | S08b4dbca0abb_N848 | element | 4–4 | element  |
| S08b4dbca0abb_N892 | S08b4dbca0abb_N891 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N893 | S08b4dbca0abb_N892 | tag_name | 4–4 | a |
| S08b4dbca0abb_N894 | S08b4dbca0abb_N892 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N895 | S08b4dbca0abb_N894 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N896 | S08b4dbca0abb_N894 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N897 | S08b4dbca0abb_N896 | attribute_value | 4–4 | font-label-caps text-label-caps uppercase tracking-wider text-on-surface-variant hover:text-on-surface transition-colors |
| S08b4dbca0abb_N898 | S08b4dbca0abb_N892 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N899 | S08b4dbca0abb_N898 | attribute_name | 4–4 | data-path |
| S08b4dbca0abb_N900 | S08b4dbca0abb_N898 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N901 | S08b4dbca0abb_N900 | attribute_value | 4–4 | ephemeris-consultation |
| S08b4dbca0abb_N902 | S08b4dbca0abb_N892 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N903 | S08b4dbca0abb_N902 | attribute_name | 4–4 | href |
| S08b4dbca0abb_N904 | S08b4dbca0abb_N902 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N905 | S08b4dbca0abb_N904 | attribute_value | 4–4 | # |
| S08b4dbca0abb_N906 | S08b4dbca0abb_N891 | text | 4–4 | Ephemeris Consultation |
| S08b4dbca0abb_N907 | S08b4dbca0abb_N891 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N908 | S08b4dbca0abb_N907 | tag_name | 4–4 | a |
| S08b4dbca0abb_N909 | S08b4dbca0abb_N848 | element | 4–4 | element  |
| S08b4dbca0abb_N910 | S08b4dbca0abb_N909 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N911 | S08b4dbca0abb_N910 | tag_name | 4–4 | span |
| S08b4dbca0abb_N912 | S08b4dbca0abb_N910 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N913 | S08b4dbca0abb_N912 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N914 | S08b4dbca0abb_N912 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N915 | S08b4dbca0abb_N914 | attribute_value | 4–4 | text-on-surface-variant opacity-40 font-astro-data-md text-astro-data-md |
| S08b4dbca0abb_N916 | S08b4dbca0abb_N909 | text | 4–4 | / |
| S08b4dbca0abb_N917 | S08b4dbca0abb_N909 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N918 | S08b4dbca0abb_N917 | tag_name | 4–4 | span |
| S08b4dbca0abb_N919 | S08b4dbca0abb_N848 | element | 4–4 | element  |
| S08b4dbca0abb_N920 | S08b4dbca0abb_N919 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N921 | S08b4dbca0abb_N920 | tag_name | 4–4 | a |
| S08b4dbca0abb_N922 | S08b4dbca0abb_N920 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N923 | S08b4dbca0abb_N922 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N924 | S08b4dbca0abb_N922 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N925 | S08b4dbca0abb_N924 | attribute_value | 4–4 | font-label-caps text-label-caps uppercase tracking-wider text-on-surface-variant hover:text-on-surface transition-colors |
| S08b4dbca0abb_N926 | S08b4dbca0abb_N920 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N927 | S08b4dbca0abb_N926 | attribute_name | 4–4 | data-path |
| S08b4dbca0abb_N928 | S08b4dbca0abb_N926 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N929 | S08b4dbca0abb_N928 | attribute_value | 4–4 | celestial-synthesis |
| S08b4dbca0abb_N930 | S08b4dbca0abb_N920 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N931 | S08b4dbca0abb_N930 | attribute_name | 4–4 | href |
| S08b4dbca0abb_N932 | S08b4dbca0abb_N930 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N933 | S08b4dbca0abb_N932 | attribute_value | 4–4 | # |
| S08b4dbca0abb_N934 | S08b4dbca0abb_N919 | text | 4–4 | Synthesis |
| S08b4dbca0abb_N935 | S08b4dbca0abb_N919 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N936 | S08b4dbca0abb_N935 | tag_name | 4–4 | a |
| S08b4dbca0abb_N937 | S08b4dbca0abb_N848 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N938 | S08b4dbca0abb_N937 | tag_name | 4–4 | nav |
| S08b4dbca0abb_N939 | S08b4dbca0abb_N805 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N940 | S08b4dbca0abb_N939 | tag_name | 4–4 | div |
| S08b4dbca0abb_N941 | S08b4dbca0abb_N798 | element | 4–4 | element  |
| S08b4dbca0abb_N942 | S08b4dbca0abb_N941 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N943 | S08b4dbca0abb_N942 | tag_name | 4–4 | div |
| S08b4dbca0abb_N944 | S08b4dbca0abb_N942 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N945 | S08b4dbca0abb_N944 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N946 | S08b4dbca0abb_N944 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N947 | S08b4dbca0abb_N946 | attribute_value | 4–4 | flex items-center gap-space-md |
| S08b4dbca0abb_N948 | S08b4dbca0abb_N941 | element | 4–4 | element  |
| S08b4dbca0abb_N949 | S08b4dbca0abb_N948 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N950 | S08b4dbca0abb_N949 | tag_name | 4–4 | div |
| S08b4dbca0abb_N951 | S08b4dbca0abb_N949 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N952 | S08b4dbca0abb_N951 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N953 | S08b4dbca0abb_N951 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N954 | S08b4dbca0abb_N953 | attribute_value | 4–4 | hidden md:flex flex-col text-right |
| S08b4dbca0abb_N955 | S08b4dbca0abb_N948 | element | 4–4 | element  |
| S08b4dbca0abb_N956 | S08b4dbca0abb_N955 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N957 | S08b4dbca0abb_N956 | tag_name | 4–4 | span |
| S08b4dbca0abb_N958 | S08b4dbca0abb_N956 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N959 | S08b4dbca0abb_N958 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N960 | S08b4dbca0abb_N958 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N961 | S08b4dbca0abb_N960 | attribute_value | 4–4 | font-label-caps text-label-caps text-primary tracking-widest uppercase |
| S08b4dbca0abb_N962 | S08b4dbca0abb_N955 | text | 4–4 | Observatory Companion |
| S08b4dbca0abb_N963 | S08b4dbca0abb_N955 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N964 | S08b4dbca0abb_N963 | tag_name | 4–4 | span |
| S08b4dbca0abb_N965 | S08b4dbca0abb_N948 | element | 4–4 | element  |
| S08b4dbca0abb_N966 | S08b4dbca0abb_N965 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N967 | S08b4dbca0abb_N966 | tag_name | 4–4 | span |
| S08b4dbca0abb_N968 | S08b4dbca0abb_N966 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N969 | S08b4dbca0abb_N968 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N970 | S08b4dbca0abb_N968 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N971 | S08b4dbca0abb_N970 | attribute_value | 4–4 | font-astro-data-md text-astro-data-md text-on-surface-variant |
| S08b4dbca0abb_N972 | S08b4dbca0abb_N965 | text | 4–4 | Active Guidance |
| S08b4dbca0abb_N973 | S08b4dbca0abb_N965 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N974 | S08b4dbca0abb_N973 | tag_name | 4–4 | span |
| S08b4dbca0abb_N975 | S08b4dbca0abb_N948 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N976 | S08b4dbca0abb_N975 | tag_name | 4–4 | div |
| S08b4dbca0abb_N977 | S08b4dbca0abb_N941 | element | 4–4 | element  |
| S08b4dbca0abb_N978 | S08b4dbca0abb_N977 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N979 | S08b4dbca0abb_N978 | tag_name | 4–4 | div |
| S08b4dbca0abb_N980 | S08b4dbca0abb_N978 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N981 | S08b4dbca0abb_N980 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N982 | S08b4dbca0abb_N980 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N983 | S08b4dbca0abb_N982 | attribute_value | 4–4 | p-space-xs rounded-full bg-surface-container-high shadow-[0_0_12px_rgba(212,175,55,0.12)] |
| S08b4dbca0abb_N984 | S08b4dbca0abb_N977 | element | 4–4 | element  |
| S08b4dbca0abb_N985 | S08b4dbca0abb_N984 | self_closing_tag | 4–4 | self_closing_tag  |
| S08b4dbca0abb_N986 | S08b4dbca0abb_N985 | tag_name | 4–4 | img |
| S08b4dbca0abb_N987 | S08b4dbca0abb_N985 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N988 | S08b4dbca0abb_N987 | attribute_name | 4–4 | alt |
| S08b4dbca0abb_N989 | S08b4dbca0abb_N987 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N990 | S08b4dbca0abb_N989 | attribute_value | 4–4 | Profile |
| S08b4dbca0abb_N991 | S08b4dbca0abb_N985 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N992 | S08b4dbca0abb_N991 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N993 | S08b4dbca0abb_N991 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N994 | S08b4dbca0abb_N993 | attribute_value | 4–4 | w-8 h-8 rounded-full object-cover |
| S08b4dbca0abb_N995 | S08b4dbca0abb_N985 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N996 | S08b4dbca0abb_N995 | attribute_name | 4–4 | src |
| S08b4dbca0abb_N997 | S08b4dbca0abb_N995 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N998 | S08b4dbca0abb_N997 | attribute_value | 4–4 | ../../assets/natally-mascot.webp |
| S08b4dbca0abb_N999 | S08b4dbca0abb_N977 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N1000 | S08b4dbca0abb_N999 | tag_name | 4–4 | div |
| S08b4dbca0abb_N1001 | S08b4dbca0abb_N941 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N1002 | S08b4dbca0abb_N1001 | tag_name | 4–4 | div |
| S08b4dbca0abb_N1003 | S08b4dbca0abb_N798 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N1004 | S08b4dbca0abb_N1003 | tag_name | 4–4 | div |
| S08b4dbca0abb_N1005 | S08b4dbca0abb_N791 | end_tag | 4–4 | end_tag  |
| S08b4dbca0abb_N1006 | S08b4dbca0abb_N1005 | tag_name | 4–4 | header |
| S08b4dbca0abb_N1007 | S08b4dbca0abb_N784 | element | 4–208 | element  |
| S08b4dbca0abb_N1008 | S08b4dbca0abb_N1007 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N1009 | S08b4dbca0abb_N1008 | tag_name | 4–4 | main |
| S08b4dbca0abb_N1010 | S08b4dbca0abb_N1008 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N1011 | S08b4dbca0abb_N1010 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N1012 | S08b4dbca0abb_N1010 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N1013 | S08b4dbca0abb_N1012 | attribute_value | 4–4 | w-full flex-1 pt-16 bg-surface |
| S08b4dbca0abb_N1014 | S08b4dbca0abb_N1007 | element | 4–208 | element  |
| S08b4dbca0abb_N1015 | S08b4dbca0abb_N1014 | start_tag | 4–4 | start_tag  |
| S08b4dbca0abb_N1016 | S08b4dbca0abb_N1015 | tag_name | 4–4 | div |
| S08b4dbca0abb_N1017 | S08b4dbca0abb_N1015 | attribute | 4–4 | attribute  |
| S08b4dbca0abb_N1018 | S08b4dbca0abb_N1017 | attribute_name | 4–4 | class |
| S08b4dbca0abb_N1019 | S08b4dbca0abb_N1017 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S08b4dbca0abb_N1020 | S08b4dbca0abb_N1019 | attribute_value | 4–4 | flex flex-col w-full |
| S08b4dbca0abb_N1021 | S08b4dbca0abb_N1014 | element | 5–207 | element  |
| S08b4dbca0abb_N1022 | S08b4dbca0abb_N1021 | start_tag | 5–5 | start_tag  |
| S08b4dbca0abb_N1023 | S08b4dbca0abb_N1022 | tag_name | 5–5 | div |
| S08b4dbca0abb_N1024 | S08b4dbca0abb_N1022 | attribute | 5–5 | attribute  |
| S08b4dbca0abb_N1025 | S08b4dbca0abb_N1024 | attribute_name | 5–5 | class |
| S08b4dbca0abb_N1026 | S08b4dbca0abb_N1024 | quoted_attribute_value | 5–5 | quoted_attribute_value  |
| S08b4dbca0abb_N1027 | S08b4dbca0abb_N1026 | attribute_value | 5–5 | relative w-full overflow-hidden pb-space-xl |
| S08b4dbca0abb_N1028 | S08b4dbca0abb_N1021 | comment | 6–6 | &lt;!-- Ambient Starlight Backdrop Glow --&gt; |
| S08b4dbca0abb_N1029 | S08b4dbca0abb_N1021 | element | 7–7 | element  |
| S08b4dbca0abb_N1030 | S08b4dbca0abb_N1029 | start_tag | 7–7 | start_tag  |
| S08b4dbca0abb_N1031 | S08b4dbca0abb_N1030 | tag_name | 7–7 | div |
| S08b4dbca0abb_N1032 | S08b4dbca0abb_N1030 | attribute | 7–7 | attribute  |
| S08b4dbca0abb_N1033 | S08b4dbca0abb_N1032 | attribute_name | 7–7 | class |
| S08b4dbca0abb_N1034 | S08b4dbca0abb_N1032 | quoted_attribute_value | 7–7 | quoted_attribute_value  |
| S08b4dbca0abb_N1035 | S08b4dbca0abb_N1034 | attribute_value | 7–7 | absolute -top-32 left-1/2 -translate-x-1/2 w-[720px] h-[360px] bg-gradient-to-b from-primary/10 via-tertiary-container/5 to-transparent blur-3xl pointer-events-none rounded-full |
| S08b4dbca0abb_N1036 | S08b4dbca0abb_N1029 | end_tag | 7–7 | end_tag  |
| S08b4dbca0abb_N1037 | S08b4dbca0abb_N1036 | tag_name | 7–7 | div |
| S08b4dbca0abb_N1038 | S08b4dbca0abb_N1021 | element | 8–206 | element  |
| S08b4dbca0abb_N1039 | S08b4dbca0abb_N1038 | start_tag | 8–8 | start_tag  |
| S08b4dbca0abb_N1040 | S08b4dbca0abb_N1039 | tag_name | 8–8 | div |
| S08b4dbca0abb_N1041 | S08b4dbca0abb_N1039 | attribute | 8–8 | attribute  |
| S08b4dbca0abb_N1042 | S08b4dbca0abb_N1041 | attribute_name | 8–8 | class |
| S08b4dbca0abb_N1043 | S08b4dbca0abb_N1041 | quoted_attribute_value | 8–8 | quoted_attribute_value  |
| S08b4dbca0abb_N1044 | S08b4dbca0abb_N1043 | attribute_value | 8–8 | max-w-7xl mx-auto px-margin md:px-margin-desktop w-full relative z-10 pt-space-lg |
| S08b4dbca0abb_N1045 | S08b4dbca0abb_N1038 | comment | 9–9 | &lt;!-- Stepper Telemetry Ribbon --&gt; |
| S08b4dbca0abb_N1046 | S08b4dbca0abb_N1038 | element | 10–22 | element  |
| S08b4dbca0abb_N1047 | S08b4dbca0abb_N1046 | start_tag | 10–10 | start_tag  |
| S08b4dbca0abb_N1048 | S08b4dbca0abb_N1047 | tag_name | 10–10 | nav |
| S08b4dbca0abb_N1049 | S08b4dbca0abb_N1047 | attribute | 10–10 | attribute  |
| S08b4dbca0abb_N1050 | S08b4dbca0abb_N1049 | attribute_name | 10–10 | aria-label |
| S08b4dbca0abb_N1051 | S08b4dbca0abb_N1049 | quoted_attribute_value | 10–10 | quoted_attribute_value  |
| S08b4dbca0abb_N1052 | S08b4dbca0abb_N1051 | attribute_value | 10–10 | Order Progress |
| S08b4dbca0abb_N1053 | S08b4dbca0abb_N1047 | attribute | 10–10 | attribute  |
| S08b4dbca0abb_N1054 | S08b4dbca0abb_N1053 | attribute_name | 10–10 | class |
| S08b4dbca0abb_N1055 | S08b4dbca0abb_N1053 | quoted_attribute_value | 10–10 | quoted_attribute_value  |
| S08b4dbca0abb_N1056 | S08b4dbca0abb_N1055 | attribute_value | 10–10 | flex items-center gap-space-sm mb-space-lg font-label-caps text-label-caps text-on-surface-variant |
| S08b4dbca0abb_N1057 | S08b4dbca0abb_N1046 | element | 11–14 | element  |
| S08b4dbca0abb_N1058 | S08b4dbca0abb_N1057 | start_tag | 11–11 | start_tag  |
| S08b4dbca0abb_N1059 | S08b4dbca0abb_N1058 | tag_name | 11–11 | span |
| S08b4dbca0abb_N1060 | S08b4dbca0abb_N1058 | attribute | 11–11 | attribute  |
| S08b4dbca0abb_N1061 | S08b4dbca0abb_N1060 | attribute_name | 11–11 | class |
| S08b4dbca0abb_N1062 | S08b4dbca0abb_N1060 | quoted_attribute_value | 11–11 | quoted_attribute_value  |
| S08b4dbca0abb_N1063 | S08b4dbca0abb_N1062 | attribute_value | 11–11 | flex items-center gap-space-xs text-on-surface-variant opacity-60 |
| S08b4dbca0abb_N1064 | S08b4dbca0abb_N1057 | element | 12–12 | element  |
| S08b4dbca0abb_N1065 | S08b4dbca0abb_N1064 | start_tag | 12–12 | start_tag  |
| S08b4dbca0abb_N1066 | S08b4dbca0abb_N1065 | tag_name | 12–12 | span |
| S08b4dbca0abb_N1067 | S08b4dbca0abb_N1065 | attribute | 12–12 | attribute  |
| S08b4dbca0abb_N1068 | S08b4dbca0abb_N1067 | attribute_name | 12–12 | class |
| S08b4dbca0abb_N1069 | S08b4dbca0abb_N1067 | quoted_attribute_value | 12–12 | quoted_attribute_value  |
| S08b4dbca0abb_N1070 | S08b4dbca0abb_N1069 | attribute_value | 12–12 | material-symbols-outlined text-[15px] |
| S08b4dbca0abb_N1071 | S08b4dbca0abb_N1064 | text | 12–12 | check_circle |
| S08b4dbca0abb_N1072 | S08b4dbca0abb_N1064 | end_tag | 12–12 | end_tag  |
| S08b4dbca0abb_N1073 | S08b4dbca0abb_N1072 | tag_name | 12–12 | span |
| S08b4dbca0abb_N1074 | S08b4dbca0abb_N1057 | element | 13–13 | element  |
| S08b4dbca0abb_N1075 | S08b4dbca0abb_N1074 | start_tag | 13–13 | start_tag  |
| S08b4dbca0abb_N1076 | S08b4dbca0abb_N1075 | tag_name | 13–13 | span |
| S08b4dbca0abb_N1077 | S08b4dbca0abb_N1074 | text | 13–13 | 01 · CONSTELLATION SELECTION |
| S08b4dbca0abb_N1078 | S08b4dbca0abb_N1074 | end_tag | 13–13 | end_tag  |
| S08b4dbca0abb_N1079 | S08b4dbca0abb_N1078 | tag_name | 13–13 | span |
| S08b4dbca0abb_N1080 | S08b4dbca0abb_N1057 | end_tag | 14–14 | end_tag  |
| S08b4dbca0abb_N1081 | S08b4dbca0abb_N1080 | tag_name | 14–14 | span |
| S08b4dbca0abb_N1082 | S08b4dbca0abb_N1046 | element | 15–15 | element  |
| S08b4dbca0abb_N1083 | S08b4dbca0abb_N1082 | start_tag | 15–15 | start_tag  |
| S08b4dbca0abb_N1084 | S08b4dbca0abb_N1083 | tag_name | 15–15 | span |
| S08b4dbca0abb_N1085 | S08b4dbca0abb_N1083 | attribute | 15–15 | attribute  |
| S08b4dbca0abb_N1086 | S08b4dbca0abb_N1085 | attribute_name | 15–15 | class |
| S08b4dbca0abb_N1087 | S08b4dbca0abb_N1085 | quoted_attribute_value | 15–15 | quoted_attribute_value  |
| S08b4dbca0abb_N1088 | S08b4dbca0abb_N1087 | attribute_value | 15–15 | opacity-30 |
| S08b4dbca0abb_N1089 | S08b4dbca0abb_N1082 | text | 15–15 | / |
| S08b4dbca0abb_N1090 | S08b4dbca0abb_N1082 | end_tag | 15–15 | end_tag  |
| S08b4dbca0abb_N1091 | S08b4dbca0abb_N1090 | tag_name | 15–15 | span |
| S08b4dbca0abb_N1092 | S08b4dbca0abb_N1046 | element | 16–19 | element  |
| S08b4dbca0abb_N1093 | S08b4dbca0abb_N1092 | start_tag | 16–16 | start_tag  |
| S08b4dbca0abb_N1094 | S08b4dbca0abb_N1093 | tag_name | 16–16 | span |
| S08b4dbca0abb_N1095 | S08b4dbca0abb_N1093 | attribute | 16–16 | attribute  |
| S08b4dbca0abb_N1096 | S08b4dbca0abb_N1095 | attribute_name | 16–16 | class |
| S08b4dbca0abb_N1097 | S08b4dbca0abb_N1095 | quoted_attribute_value | 16–16 | quoted_attribute_value  |
| S08b4dbca0abb_N1098 | S08b4dbca0abb_N1097 | attribute_value | 16–16 | flex items-center gap-space-xs text-primary font-bold |
| S08b4dbca0abb_N1099 | S08b4dbca0abb_N1092 | element | 17–17 | element  |
| S08b4dbca0abb_N1100 | S08b4dbca0abb_N1099 | start_tag | 17–17 | start_tag  |
| S08b4dbca0abb_N1101 | S08b4dbca0abb_N1100 | tag_name | 17–17 | span |
| S08b4dbca0abb_N1102 | S08b4dbca0abb_N1100 | attribute | 17–17 | attribute  |
| S08b4dbca0abb_N1103 | S08b4dbca0abb_N1102 | attribute_name | 17–17 | class |
| S08b4dbca0abb_N1104 | S08b4dbca0abb_N1102 | quoted_attribute_value | 17–17 | quoted_attribute_value  |
| S08b4dbca0abb_N1105 | S08b4dbca0abb_N1104 | attribute_value | 17–17 | w-2 h-2 rounded-full bg-primary animate-pulse |
| S08b4dbca0abb_N1106 | S08b4dbca0abb_N1099 | end_tag | 17–17 | end_tag  |
| S08b4dbca0abb_N1107 | S08b4dbca0abb_N1106 | tag_name | 17–17 | span |
| S08b4dbca0abb_N1108 | S08b4dbca0abb_N1092 | element | 18–18 | element  |
| S08b4dbca0abb_N1109 | S08b4dbca0abb_N1108 | start_tag | 18–18 | start_tag  |
| S08b4dbca0abb_N1110 | S08b4dbca0abb_N1109 | tag_name | 18–18 | span |
| S08b4dbca0abb_N1111 | S08b4dbca0abb_N1108 | text | 18–18 | 02 · REVIEW DETAILS |
| S08b4dbca0abb_N1112 | S08b4dbca0abb_N1108 | end_tag | 18–18 | end_tag  |
| S08b4dbca0abb_N1113 | S08b4dbca0abb_N1112 | tag_name | 18–18 | span |
| S08b4dbca0abb_N1114 | S08b4dbca0abb_N1092 | end_tag | 19–19 | end_tag  |
| S08b4dbca0abb_N1115 | S08b4dbca0abb_N1114 | tag_name | 19–19 | span |
| S08b4dbca0abb_N1116 | S08b4dbca0abb_N1046 | element | 20–20 | element  |
| S08b4dbca0abb_N1117 | S08b4dbca0abb_N1116 | start_tag | 20–20 | start_tag  |
| S08b4dbca0abb_N1118 | S08b4dbca0abb_N1117 | tag_name | 20–20 | span |
| S08b4dbca0abb_N1119 | S08b4dbca0abb_N1117 | attribute | 20–20 | attribute  |
| S08b4dbca0abb_N1120 | S08b4dbca0abb_N1119 | attribute_name | 20–20 | class |
| S08b4dbca0abb_N1121 | S08b4dbca0abb_N1119 | quoted_attribute_value | 20–20 | quoted_attribute_value  |
| S08b4dbca0abb_N1122 | S08b4dbca0abb_N1121 | attribute_value | 20–20 | opacity-30 |
| S08b4dbca0abb_N1123 | S08b4dbca0abb_N1116 | text | 20–20 | / |
| S08b4dbca0abb_N1124 | S08b4dbca0abb_N1116 | end_tag | 20–20 | end_tag  |
| S08b4dbca0abb_N1125 | S08b4dbca0abb_N1124 | tag_name | 20–20 | span |
| S08b4dbca0abb_N1126 | S08b4dbca0abb_N1046 | element | 21–21 | element  |
| S08b4dbca0abb_N1127 | S08b4dbca0abb_N1126 | start_tag | 21–21 | start_tag  |
| S08b4dbca0abb_N1128 | S08b4dbca0abb_N1127 | tag_name | 21–21 | span |
| S08b4dbca0abb_N1129 | S08b4dbca0abb_N1127 | attribute | 21–21 | attribute  |
| S08b4dbca0abb_N1130 | S08b4dbca0abb_N1129 | attribute_name | 21–21 | class |
| S08b4dbca0abb_N1131 | S08b4dbca0abb_N1129 | quoted_attribute_value | 21–21 | quoted_attribute_value  |
| S08b4dbca0abb_N1132 | S08b4dbca0abb_N1131 | attribute_value | 21–21 | opacity-50 |
| S08b4dbca0abb_N1133 | S08b4dbca0abb_N1126 | text | 21–21 | 03 · CELESTIAL QUOTE |
| S08b4dbca0abb_N1134 | S08b4dbca0abb_N1126 | end_tag | 21–21 | end_tag  |
| S08b4dbca0abb_N1135 | S08b4dbca0abb_N1134 | tag_name | 21–21 | span |
| S08b4dbca0abb_N1136 | S08b4dbca0abb_N1046 | end_tag | 22–22 | end_tag  |
| S08b4dbca0abb_N1137 | S08b4dbca0abb_N1136 | tag_name | 22–22 | nav |
| S08b4dbca0abb_N1138 | S08b4dbca0abb_N1038 | comment | 23–23 | &lt;!-- Section Headline &amp; Ritual Tone --&gt; |
| S08b4dbca0abb_N1139 | S08b4dbca0abb_N1038 | element | 24–45 | element  |
| S08b4dbca0abb_N1140 | S08b4dbca0abb_N1139 | start_tag | 24–24 | start_tag  |
| S08b4dbca0abb_N1141 | S08b4dbca0abb_N1140 | tag_name | 24–24 | header |
| S08b4dbca0abb_N1142 | S08b4dbca0abb_N1140 | attribute | 24–24 | attribute  |
| S08b4dbca0abb_N1143 | S08b4dbca0abb_N1142 | attribute_name | 24–24 | class |
| S08b4dbca0abb_N1144 | S08b4dbca0abb_N1142 | quoted_attribute_value | 24–24 | quoted_attribute_value  |
| S08b4dbca0abb_N1145 | S08b4dbca0abb_N1144 | attribute_value | 24–24 | flex flex-col md:flex-row md:items-end justify-between gap-space-md mb-space-xl |
| S08b4dbca0abb_N1146 | S08b4dbca0abb_N1139 | element | 25–36 | element  |
| S08b4dbca0abb_N1147 | S08b4dbca0abb_N1146 | start_tag | 25–25 | start_tag  |
| S08b4dbca0abb_N1148 | S08b4dbca0abb_N1147 | tag_name | 25–25 | div |
| S08b4dbca0abb_N1149 | S08b4dbca0abb_N1147 | attribute | 25–25 | attribute  |
| S08b4dbca0abb_N1150 | S08b4dbca0abb_N1149 | attribute_name | 25–25 | class |
| S08b4dbca0abb_N1151 | S08b4dbca0abb_N1149 | quoted_attribute_value | 25–25 | quoted_attribute_value  |
| S08b4dbca0abb_N1152 | S08b4dbca0abb_N1151 | attribute_value | 25–25 | max-w-2xl space-y-space-xs |
| S08b4dbca0abb_N1153 | S08b4dbca0abb_N1146 | element | 26–29 | element  |
| S08b4dbca0abb_N1154 | S08b4dbca0abb_N1153 | start_tag | 26–26 | start_tag  |
| S08b4dbca0abb_N1155 | S08b4dbca0abb_N1154 | tag_name | 26–26 | div |
| S08b4dbca0abb_N1156 | S08b4dbca0abb_N1154 | attribute | 26–26 | attribute  |
| S08b4dbca0abb_N1157 | S08b4dbca0abb_N1156 | attribute_name | 26–26 | class |
| S08b4dbca0abb_N1158 | S08b4dbca0abb_N1156 | quoted_attribute_value | 26–26 | quoted_attribute_value  |
| S08b4dbca0abb_N1159 | S08b4dbca0abb_N1158 | attribute_value | 26–26 | inline-flex items-center gap-space-xs px-space-sm py-1 rounded-full bg-surface-container-high shadow-sm text-primary font-astro-data-md text-astro-data-md |
| S08b4dbca0abb_N1160 | S08b4dbca0abb_N1153 | element | 27–27 | element  |
| S08b4dbca0abb_N1161 | S08b4dbca0abb_N1160 | start_tag | 27–27 | start_tag  |
| S08b4dbca0abb_N1162 | S08b4dbca0abb_N1161 | tag_name | 27–27 | span |
| S08b4dbca0abb_N1163 | S08b4dbca0abb_N1161 | attribute | 27–27 | attribute  |
| S08b4dbca0abb_N1164 | S08b4dbca0abb_N1163 | attribute_name | 27–27 | class |
| S08b4dbca0abb_N1165 | S08b4dbca0abb_N1163 | quoted_attribute_value | 27–27 | quoted_attribute_value  |
| S08b4dbca0abb_N1166 | S08b4dbca0abb_N1165 | attribute_value | 27–27 | material-symbols-outlined text-[14px] |
| S08b4dbca0abb_N1167 | S08b4dbca0abb_N1160 | text | 27–27 | bedtime |
| S08b4dbca0abb_N1168 | S08b4dbca0abb_N1160 | end_tag | 27–27 | end_tag  |
| S08b4dbca0abb_N1169 | S08b4dbca0abb_N1168 | tag_name | 27–27 | span |
| S08b4dbca0abb_N1170 | S08b4dbca0abb_N1153 | element | 28–28 | element  |
| S08b4dbca0abb_N1171 | S08b4dbca0abb_N1170 | start_tag | 28–28 | start_tag  |
| S08b4dbca0abb_N1172 | S08b4dbca0abb_N1171 | tag_name | 28–28 | span |
| S08b4dbca0abb_N1173 | S08b4dbca0abb_N1170 | text | 28–28 | Ephemeris Calibration Protocol |
| S08b4dbca0abb_N1174 | S08b4dbca0abb_N1170 | end_tag | 28–28 | end_tag  |
| S08b4dbca0abb_N1175 | S08b4dbca0abb_N1174 | tag_name | 28–28 | span |
| S08b4dbca0abb_N1176 | S08b4dbca0abb_N1153 | end_tag | 29–29 | end_tag  |
| S08b4dbca0abb_N1177 | S08b4dbca0abb_N1176 | tag_name | 29–29 | div |
| S08b4dbca0abb_N1178 | S08b4dbca0abb_N1146 | element | 30–32 | element  |
| S08b4dbca0abb_N1179 | S08b4dbca0abb_N1178 | start_tag | 30–30 | start_tag  |
| S08b4dbca0abb_N1180 | S08b4dbca0abb_N1179 | tag_name | 30–30 | h1 |
| S08b4dbca0abb_N1181 | S08b4dbca0abb_N1179 | attribute | 30–30 | attribute  |
| S08b4dbca0abb_N1182 | S08b4dbca0abb_N1181 | attribute_name | 30–30 | class |
| S08b4dbca0abb_N1183 | S08b4dbca0abb_N1181 | quoted_attribute_value | 30–30 | quoted_attribute_value  |
| S08b4dbca0abb_N1184 | S08b4dbca0abb_N1183 | attribute_value | 30–30 | font-headline-lg text-headline-lg md:text-display-lg md:font-display-lg text-on-surface tracking-tight |
| S08b4dbca0abb_N1185 | S08b4dbca0abb_N1178 | text | 31–31 | Review your reading details |
| S08b4dbca0abb_N1186 | S08b4dbca0abb_N1178 | end_tag | 32–32 | end_tag  |
| S08b4dbca0abb_N1187 | S08b4dbca0abb_N1186 | tag_name | 32–32 | h1 |
| S08b4dbca0abb_N1188 | S08b4dbca0abb_N1146 | element | 33–35 | element  |
| S08b4dbca0abb_N1189 | S08b4dbca0abb_N1188 | start_tag | 33–33 | start_tag  |
| S08b4dbca0abb_N1190 | S08b4dbca0abb_N1189 | tag_name | 33–33 | p |
| S08b4dbca0abb_N1191 | S08b4dbca0abb_N1189 | attribute | 33–33 | attribute  |
| S08b4dbca0abb_N1192 | S08b4dbca0abb_N1191 | attribute_name | 33–33 | class |
| S08b4dbca0abb_N1193 | S08b4dbca0abb_N1191 | quoted_attribute_value | 33–33 | quoted_attribute_value  |
| S08b4dbca0abb_N1194 | S08b4dbca0abb_N1193 | attribute_value | 33–33 | font-body-lg text-body-lg text-on-surface-variant |
| S08b4dbca0abb_N1195 | S08b4dbca0abb_N1188 | text | 34–34 | Take a quiet moment to verify your birth information and selected package before your quote is prepared. |
| S08b4dbca0abb_N1196 | S08b4dbca0abb_N1188 | end_tag | 35–35 | end_tag  |
| S08b4dbca0abb_N1197 | S08b4dbca0abb_N1196 | tag_name | 35–35 | p |
| S08b4dbca0abb_N1198 | S08b4dbca0abb_N1146 | end_tag | 36–36 | end_tag  |
| S08b4dbca0abb_N1199 | S08b4dbca0abb_N1198 | tag_name | 36–36 | div |
| S08b4dbca0abb_N1200 | S08b4dbca0abb_N1139 | comment | 37–37 | &lt;!-- Pending Quote Status Badge --&gt; |
| S08b4dbca0abb_N1201 | S08b4dbca0abb_N1139 | element | 38–44 | element  |
| S08b4dbca0abb_N1202 | S08b4dbca0abb_N1201 | start_tag | 38–38 | start_tag  |
| S08b4dbca0abb_N1203 | S08b4dbca0abb_N1202 | tag_name | 38–38 | div |
| S08b4dbca0abb_N1204 | S08b4dbca0abb_N1202 | attribute | 38–38 | attribute  |
| S08b4dbca0abb_N1205 | S08b4dbca0abb_N1204 | attribute_name | 38–38 | class |
| S08b4dbca0abb_N1206 | S08b4dbca0abb_N1204 | quoted_attribute_value | 38–38 | quoted_attribute_value  |
| S08b4dbca0abb_N1207 | S08b4dbca0abb_N1206 | attribute_value | 38–38 | flex items-center gap-space-sm px-space-md py-space-sm rounded-xl bg-surface-container-high shadow-md self-start md:self-auto |
| S08b4dbca0abb_N1208 | S08b4dbca0abb_N1201 | element | 39–39 | element  |
| S08b4dbca0abb_N1209 | S08b4dbca0abb_N1208 | start_tag | 39–39 | start_tag  |
| S08b4dbca0abb_N1210 | S08b4dbca0abb_N1209 | tag_name | 39–39 | span |
| S08b4dbca0abb_N1211 | S08b4dbca0abb_N1209 | attribute | 39–39 | attribute  |
| S08b4dbca0abb_N1212 | S08b4dbca0abb_N1211 | attribute_name | 39–39 | class |
| S08b4dbca0abb_N1213 | S08b4dbca0abb_N1211 | quoted_attribute_value | 39–39 | quoted_attribute_value  |
| S08b4dbca0abb_N1214 | S08b4dbca0abb_N1213 | attribute_value | 39–39 | flex h-2.5 w-2.5 rounded-full bg-primary/80 animate-ping |
| S08b4dbca0abb_N1215 | S08b4dbca0abb_N1208 | end_tag | 39–39 | end_tag  |
| S08b4dbca0abb_N1216 | S08b4dbca0abb_N1215 | tag_name | 39–39 | span |
| S08b4dbca0abb_N1217 | S08b4dbca0abb_N1201 | element | 40–43 | element  |
| S08b4dbca0abb_N1218 | S08b4dbca0abb_N1217 | start_tag | 40–40 | start_tag  |
| S08b4dbca0abb_N1219 | S08b4dbca0abb_N1218 | tag_name | 40–40 | div |
| S08b4dbca0abb_N1220 | S08b4dbca0abb_N1218 | attribute | 40–40 | attribute  |
| S08b4dbca0abb_N1221 | S08b4dbca0abb_N1220 | attribute_name | 40–40 | class |
| S08b4dbca0abb_N1222 | S08b4dbca0abb_N1220 | quoted_attribute_value | 40–40 | quoted_attribute_value  |
| S08b4dbca0abb_N1223 | S08b4dbca0abb_N1222 | attribute_value | 40–40 | flex flex-col |
| S08b4dbca0abb_N1224 | S08b4dbca0abb_N1217 | element | 41–41 | element  |
| S08b4dbca0abb_N1225 | S08b4dbca0abb_N1224 | start_tag | 41–41 | start_tag  |
| S08b4dbca0abb_N1226 | S08b4dbca0abb_N1225 | tag_name | 41–41 | span |
| S08b4dbca0abb_N1227 | S08b4dbca0abb_N1225 | attribute | 41–41 | attribute  |
| S08b4dbca0abb_N1228 | S08b4dbca0abb_N1227 | attribute_name | 41–41 | class |
| S08b4dbca0abb_N1229 | S08b4dbca0abb_N1227 | quoted_attribute_value | 41–41 | quoted_attribute_value  |
| S08b4dbca0abb_N1230 | S08b4dbca0abb_N1229 | attribute_value | 41–41 | font-label-caps text-label-caps text-primary uppercase tracking-wider |
| S08b4dbca0abb_N1231 | S08b4dbca0abb_N1224 | text | 41–41 | Protocol Status |
| S08b4dbca0abb_N1232 | S08b4dbca0abb_N1224 | end_tag | 41–41 | end_tag  |
| S08b4dbca0abb_N1233 | S08b4dbca0abb_N1232 | tag_name | 41–41 | span |
| S08b4dbca0abb_N1234 | S08b4dbca0abb_N1217 | element | 42–42 | element  |
| S08b4dbca0abb_N1235 | S08b4dbca0abb_N1234 | start_tag | 42–42 | start_tag  |
| S08b4dbca0abb_N1236 | S08b4dbca0abb_N1235 | tag_name | 42–42 | span |
| S08b4dbca0abb_N1237 | S08b4dbca0abb_N1235 | attribute | 42–42 | attribute  |
| S08b4dbca0abb_N1238 | S08b4dbca0abb_N1237 | attribute_name | 42–42 | class |
| S08b4dbca0abb_N1239 | S08b4dbca0abb_N1237 | quoted_attribute_value | 42–42 | quoted_attribute_value  |
| S08b4dbca0abb_N1240 | S08b4dbca0abb_N1239 | attribute_value | 42–42 | font-astro-data-md text-astro-data-md text-on-surface font-medium |
| S08b4dbca0abb_N1241 | S08b4dbca0abb_N1234 | text | 42–42 | Quote pending review · No payment collected yet |
| S08b4dbca0abb_N1242 | S08b4dbca0abb_N1234 | end_tag | 42–42 | end_tag  |
| S08b4dbca0abb_N1243 | S08b4dbca0abb_N1242 | tag_name | 42–42 | span |
| S08b4dbca0abb_N1244 | S08b4dbca0abb_N1217 | end_tag | 43–43 | end_tag  |
| S08b4dbca0abb_N1245 | S08b4dbca0abb_N1244 | tag_name | 43–43 | div |
| S08b4dbca0abb_N1246 | S08b4dbca0abb_N1201 | end_tag | 44–44 | end_tag  |
| S08b4dbca0abb_N1247 | S08b4dbca0abb_N1246 | tag_name | 44–44 | div |
| S08b4dbca0abb_N1248 | S08b4dbca0abb_N1139 | end_tag | 45–45 | end_tag  |
| S08b4dbca0abb_N1249 | S08b4dbca0abb_N1248 | tag_name | 45–45 | header |
| S08b4dbca0abb_N1250 | S08b4dbca0abb_N1038 | comment | 46–46 | &lt;!-- Two-Column Balanced Editorial Layout --&gt; |
| S08b4dbca0abb_N1251 | S08b4dbca0abb_N1038 | element | 47–205 | element  |
| S08b4dbca0abb_N1252 | S08b4dbca0abb_N1251 | start_tag | 47–47 | start_tag  |
| S08b4dbca0abb_N1253 | S08b4dbca0abb_N1252 | tag_name | 47–47 | div |
| S08b4dbca0abb_N1254 | S08b4dbca0abb_N1252 | attribute | 47–47 | attribute  |
| S08b4dbca0abb_N1255 | S08b4dbca0abb_N1254 | attribute_name | 47–47 | class |
| S08b4dbca0abb_N1256 | S08b4dbca0abb_N1254 | quoted_attribute_value | 47–47 | quoted_attribute_value  |
| S08b4dbca0abb_N1257 | S08b4dbca0abb_N1256 | attribute_value | 47–47 | grid grid-cols-1 lg:grid-cols-12 gap-gutter-desktop items-start |
| S08b4dbca0abb_N1258 | S08b4dbca0abb_N1251 | comment | 48–48 | &lt;!-- Left / Primary Card: Birth Details Summary (7 Cols) --&gt; |
| S08b4dbca0abb_N1259 | S08b4dbca0abb_N1251 | element | 49–122 | element  |
| S08b4dbca0abb_N1260 | S08b4dbca0abb_N1259 | start_tag | 49–49 | start_tag  |
| S08b4dbca0abb_N1261 | S08b4dbca0abb_N1260 | tag_name | 49–49 | div |
| S08b4dbca0abb_N1262 | S08b4dbca0abb_N1260 | attribute | 49–49 | attribute  |
| S08b4dbca0abb_N1263 | S08b4dbca0abb_N1262 | attribute_name | 49–49 | class |
| S08b4dbca0abb_N1264 | S08b4dbca0abb_N1262 | quoted_attribute_value | 49–49 | quoted_attribute_value  |
| S08b4dbca0abb_N1265 | S08b4dbca0abb_N1264 | attribute_value | 49–49 | lg:col-span-7 flex flex-col gap-space-lg |
| S08b4dbca0abb_N1266 | S08b4dbca0abb_N1259 | element | 50–114 | element  |
| S08b4dbca0abb_N1267 | S08b4dbca0abb_N1266 | start_tag | 50–50 | start_tag  |
| S08b4dbca0abb_N1268 | S08b4dbca0abb_N1267 | tag_name | 50–50 | div |
| S08b4dbca0abb_N1269 | S08b4dbca0abb_N1267 | attribute | 50–50 | attribute  |
| S08b4dbca0abb_N1270 | S08b4dbca0abb_N1269 | attribute_name | 50–50 | class |
| S08b4dbca0abb_N1271 | S08b4dbca0abb_N1269 | quoted_attribute_value | 50–50 | quoted_attribute_value  |
| S08b4dbca0abb_N1272 | S08b4dbca0abb_N1271 | attribute_value | 50–50 | bg-surface-container rounded-xl p-space-lg shadow-xl relative overflow-hidden group |
| S08b4dbca0abb_N1273 | S08b4dbca0abb_N1266 | comment | 51–51 | &lt;!-- Brass Plate Corner Accent --&gt; |
| S08b4dbca0abb_N1274 | S08b4dbca0abb_N1266 | element | 52–52 | element  |
| S08b4dbca0abb_N1275 | S08b4dbca0abb_N1274 | start_tag | 52–52 | start_tag  |
| S08b4dbca0abb_N1276 | S08b4dbca0abb_N1275 | tag_name | 52–52 | div |
| S08b4dbca0abb_N1277 | S08b4dbca0abb_N1275 | attribute | 52–52 | attribute  |
| S08b4dbca0abb_N1278 | S08b4dbca0abb_N1277 | attribute_name | 52–52 | class |
| S08b4dbca0abb_N1279 | S08b4dbca0abb_N1277 | quoted_attribute_value | 52–52 | quoted_attribute_value  |
| S08b4dbca0abb_N1280 | S08b4dbca0abb_N1279 | attribute_value | 52–52 | absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-primary/10 to-transparent pointer-events-none rounded-bl-full |
| S08b4dbca0abb_N1281 | S08b4dbca0abb_N1274 | end_tag | 52–52 | end_tag  |
| S08b4dbca0abb_N1282 | S08b4dbca0abb_N1281 | tag_name | 52–52 | div |
| S08b4dbca0abb_N1283 | S08b4dbca0abb_N1266 | element | 53–59 | element  |
| S08b4dbca0abb_N1284 | S08b4dbca0abb_N1283 | start_tag | 53–53 | start_tag  |
| S08b4dbca0abb_N1285 | S08b4dbca0abb_N1284 | tag_name | 53–53 | div |
| S08b4dbca0abb_N1286 | S08b4dbca0abb_N1284 | attribute | 53–53 | attribute  |
| S08b4dbca0abb_N1287 | S08b4dbca0abb_N1286 | attribute_name | 53–53 | class |
| S08b4dbca0abb_N1288 | S08b4dbca0abb_N1286 | quoted_attribute_value | 53–53 | quoted_attribute_value  |
| S08b4dbca0abb_N1289 | S08b4dbca0abb_N1288 | attribute_value | 53–53 | flex items-center justify-between pb-space-md mb-space-md |
| S08b4dbca0abb_N1290 | S08b4dbca0abb_N1283 | element | 54–57 | element  |
| S08b4dbca0abb_N1291 | S08b4dbca0abb_N1290 | start_tag | 54–54 | start_tag  |
| S08b4dbca0abb_N1292 | S08b4dbca0abb_N1291 | tag_name | 54–54 | div |
| S08b4dbca0abb_N1293 | S08b4dbca0abb_N1291 | attribute | 54–54 | attribute  |
| S08b4dbca0abb_N1294 | S08b4dbca0abb_N1293 | attribute_name | 54–54 | class |
| S08b4dbca0abb_N1295 | S08b4dbca0abb_N1293 | quoted_attribute_value | 54–54 | quoted_attribute_value  |
| S08b4dbca0abb_N1296 | S08b4dbca0abb_N1295 | attribute_value | 54–54 | flex items-center gap-space-sm |
| S08b4dbca0abb_N1297 | S08b4dbca0abb_N1290 | element | 55–55 | element  |
| S08b4dbca0abb_N1298 | S08b4dbca0abb_N1297 | start_tag | 55–55 | start_tag  |
| S08b4dbca0abb_N1299 | S08b4dbca0abb_N1298 | tag_name | 55–55 | span |
| S08b4dbca0abb_N1300 | S08b4dbca0abb_N1298 | attribute | 55–55 | attribute  |
| S08b4dbca0abb_N1301 | S08b4dbca0abb_N1300 | attribute_name | 55–55 | class |
| S08b4dbca0abb_N1302 | S08b4dbca0abb_N1300 | quoted_attribute_value | 55–55 | quoted_attribute_value  |
| S08b4dbca0abb_N1303 | S08b4dbca0abb_N1302 | attribute_value | 55–55 | material-symbols-outlined text-primary text-[22px] |
| S08b4dbca0abb_N1304 | S08b4dbca0abb_N1297 | text | 55–55 | explore |
| S08b4dbca0abb_N1305 | S08b4dbca0abb_N1297 | end_tag | 55–55 | end_tag  |
| S08b4dbca0abb_N1306 | S08b4dbca0abb_N1305 | tag_name | 55–55 | span |
| S08b4dbca0abb_N1307 | S08b4dbca0abb_N1290 | element | 56–56 | element  |
| S08b4dbca0abb_N1308 | S08b4dbca0abb_N1307 | start_tag | 56–56 | start_tag  |
| S08b4dbca0abb_N1309 | S08b4dbca0abb_N1308 | tag_name | 56–56 | span |
| S08b4dbca0abb_N1310 | S08b4dbca0abb_N1308 | attribute | 56–56 | attribute  |
| S08b4dbca0abb_N1311 | S08b4dbca0abb_N1310 | attribute_name | 56–56 | class |
| S08b4dbca0abb_N1312 | S08b4dbca0abb_N1310 | quoted_attribute_value | 56–56 | quoted_attribute_value  |
| S08b4dbca0abb_N1313 | S08b4dbca0abb_N1312 | attribute_value | 56–56 | font-headline-sm text-headline-sm text-on-surface |
| S08b4dbca0abb_N1314 | S08b4dbca0abb_N1307 | text | 56–56 | Birth Details Summary |
| S08b4dbca0abb_N1315 | S08b4dbca0abb_N1307 | end_tag | 56–56 | end_tag  |
| S08b4dbca0abb_N1316 | S08b4dbca0abb_N1315 | tag_name | 56–56 | span |
| S08b4dbca0abb_N1317 | S08b4dbca0abb_N1290 | end_tag | 57–57 | end_tag  |
| S08b4dbca0abb_N1318 | S08b4dbca0abb_N1317 | tag_name | 57–57 | div |
| S08b4dbca0abb_N1319 | S08b4dbca0abb_N1283 | element | 58–58 | element  |
| S08b4dbca0abb_N1320 | S08b4dbca0abb_N1319 | start_tag | 58–58 | start_tag  |
| S08b4dbca0abb_N1321 | S08b4dbca0abb_N1320 | tag_name | 58–58 | span |
| S08b4dbca0abb_N1322 | S08b4dbca0abb_N1320 | attribute | 58–58 | attribute  |
| S08b4dbca0abb_N1323 | S08b4dbca0abb_N1322 | attribute_name | 58–58 | class |
| S08b4dbca0abb_N1324 | S08b4dbca0abb_N1322 | quoted_attribute_value | 58–58 | quoted_attribute_value  |
| S08b4dbca0abb_N1325 | S08b4dbca0abb_N1324 | attribute_value | 58–58 | font-astro-data-md text-astro-data-md text-on-surface-variant tracking-wider |
| S08b4dbca0abb_N1326 | S08b4dbca0abb_N1319 | text | 58–58 | FICTIONAL SAMPLE |
| S08b4dbca0abb_N1327 | S08b4dbca0abb_N1319 | end_tag | 58–58 | end_tag  |
| S08b4dbca0abb_N1328 | S08b4dbca0abb_N1327 | tag_name | 58–58 | span |
| S08b4dbca0abb_N1329 | S08b4dbca0abb_N1283 | end_tag | 59–59 | end_tag  |
| S08b4dbca0abb_N1330 | S08b4dbca0abb_N1329 | tag_name | 59–59 | div |
| S08b4dbca0abb_N1331 | S08b4dbca0abb_N1266 | comment | 60–60 | &lt;!-- Coordinate / Ephemeris Telemetry Grid --&gt; |
| S08b4dbca0abb_N1332 | S08b4dbca0abb_N1266 | element | 61–86 | element  |
| S08b4dbca0abb_N1333 | S08b4dbca0abb_N1332 | start_tag | 61–61 | start_tag  |
| S08b4dbca0abb_N1334 | S08b4dbca0abb_N1333 | tag_name | 61–61 | div |
| S08b4dbca0abb_N1335 | S08b4dbca0abb_N1333 | attribute | 61–61 | attribute  |
| S08b4dbca0abb_N1336 | S08b4dbca0abb_N1335 | attribute_name | 61–61 | class |
| S08b4dbca0abb_N1337 | S08b4dbca0abb_N1335 | quoted_attribute_value | 61–61 | quoted_attribute_value  |
| S08b4dbca0abb_N1338 | S08b4dbca0abb_N1337 | attribute_value | 61–61 | grid grid-cols-1 sm:grid-cols-2 gap-space-md mb-space-lg |
| S08b4dbca0abb_N1339 | S08b4dbca0abb_N1332 | comment | 62–62 | &lt;!-- Item 1: Date --&gt; |
| S08b4dbca0abb_N1340 | S08b4dbca0abb_N1332 | element | 63–67 | element  |
| S08b4dbca0abb_N1341 | S08b4dbca0abb_N1340 | start_tag | 63–63 | start_tag  |
| S08b4dbca0abb_N1342 | S08b4dbca0abb_N1341 | tag_name | 63–63 | div |
| S08b4dbca0abb_N1343 | S08b4dbca0abb_N1341 | attribute | 63–63 | attribute  |
| S08b4dbca0abb_N1344 | S08b4dbca0abb_N1343 | attribute_name | 63–63 | class |
| S08b4dbca0abb_N1345 | S08b4dbca0abb_N1343 | quoted_attribute_value | 63–63 | quoted_attribute_value  |
| S08b4dbca0abb_N1346 | S08b4dbca0abb_N1345 | attribute_value | 63–63 | bg-surface-container-low rounded-lg p-space-md shadow-inner flex flex-col gap-space-xs |
| S08b4dbca0abb_N1347 | S08b4dbca0abb_N1340 | element | 64–64 | element  |
| S08b4dbca0abb_N1348 | S08b4dbca0abb_N1347 | start_tag | 64–64 | start_tag  |
| S08b4dbca0abb_N1349 | S08b4dbca0abb_N1348 | tag_name | 64–64 | span |
| S08b4dbca0abb_N1350 | S08b4dbca0abb_N1348 | attribute | 64–64 | attribute  |
| S08b4dbca0abb_N1351 | S08b4dbca0abb_N1350 | attribute_name | 64–64 | class |
| S08b4dbca0abb_N1352 | S08b4dbca0abb_N1350 | quoted_attribute_value | 64–64 | quoted_attribute_value  |
| S08b4dbca0abb_N1353 | S08b4dbca0abb_N1352 | attribute_value | 64–64 | font-label-caps text-label-caps text-on-surface-variant uppercase |
| S08b4dbca0abb_N1354 | S08b4dbca0abb_N1347 | text | 64–64 | Birth date |
| S08b4dbca0abb_N1355 | S08b4dbca0abb_N1347 | end_tag | 64–64 | end_tag  |
| S08b4dbca0abb_N1356 | S08b4dbca0abb_N1355 | tag_name | 64–64 | span |
| S08b4dbca0abb_N1357 | S08b4dbca0abb_N1340 | element | 65–65 | element  |
| S08b4dbca0abb_N1358 | S08b4dbca0abb_N1357 | start_tag | 65–65 | start_tag  |
| S08b4dbca0abb_N1359 | S08b4dbca0abb_N1358 | tag_name | 65–65 | span |
| S08b4dbca0abb_N1360 | S08b4dbca0abb_N1358 | attribute | 65–65 | attribute  |
| S08b4dbca0abb_N1361 | S08b4dbca0abb_N1360 | attribute_name | 65–65 | class |
| S08b4dbca0abb_N1362 | S08b4dbca0abb_N1360 | quoted_attribute_value | 65–65 | quoted_attribute_value  |
| S08b4dbca0abb_N1363 | S08b4dbca0abb_N1362 | attribute_value | 65–65 | font-headline-sm text-headline-sm text-on-surface |
| S08b4dbca0abb_N1364 | S08b4dbca0abb_N1357 | text | 65–65 | December 15, 1992 · fictional example |
| S08b4dbca0abb_N1365 | S08b4dbca0abb_N1357 | end_tag | 65–65 | end_tag  |
| S08b4dbca0abb_N1366 | S08b4dbca0abb_N1365 | tag_name | 65–65 | span |
| S08b4dbca0abb_N1367 | S08b4dbca0abb_N1340 | element | 66–66 | element  |
| S08b4dbca0abb_N1368 | S08b4dbca0abb_N1367 | start_tag | 66–66 | start_tag  |
| S08b4dbca0abb_N1369 | S08b4dbca0abb_N1368 | tag_name | 66–66 | span |
| S08b4dbca0abb_N1370 | S08b4dbca0abb_N1368 | attribute | 66–66 | attribute  |
| S08b4dbca0abb_N1371 | S08b4dbca0abb_N1370 | attribute_name | 66–66 | class |
| S08b4dbca0abb_N1372 | S08b4dbca0abb_N1370 | quoted_attribute_value | 66–66 | quoted_attribute_value  |
| S08b4dbca0abb_N1373 | S08b4dbca0abb_N1372 | attribute_value | 66–66 | font-astro-data-md text-astro-data-md text-tertiary |
| S08b4dbca0abb_N1374 | S08b4dbca0abb_N1367 | text | 66–66 | Illustrative summary · not calculated |
| S08b4dbca0abb_N1375 | S08b4dbca0abb_N1367 | end_tag | 66–66 | end_tag  |
| S08b4dbca0abb_N1376 | S08b4dbca0abb_N1375 | tag_name | 66–66 | span |
| S08b4dbca0abb_N1377 | S08b4dbca0abb_N1340 | end_tag | 67–67 | end_tag  |
| S08b4dbca0abb_N1378 | S08b4dbca0abb_N1377 | tag_name | 67–67 | div |
| S08b4dbca0abb_N1379 | S08b4dbca0abb_N1332 | comment | 68–68 | &lt;!-- Item 2: Time --&gt; |
| S08b4dbca0abb_N1380 | S08b4dbca0abb_N1332 | element | 69–73 | element  |
| S08b4dbca0abb_N1381 | S08b4dbca0abb_N1380 | start_tag | 69–69 | start_tag  |
| S08b4dbca0abb_N1382 | S08b4dbca0abb_N1381 | tag_name | 69–69 | div |
| S08b4dbca0abb_N1383 | S08b4dbca0abb_N1381 | attribute | 69–69 | attribute  |
| S08b4dbca0abb_N1384 | S08b4dbca0abb_N1383 | attribute_name | 69–69 | class |
| S08b4dbca0abb_N1385 | S08b4dbca0abb_N1383 | quoted_attribute_value | 69–69 | quoted_attribute_value  |
| S08b4dbca0abb_N1386 | S08b4dbca0abb_N1385 | attribute_value | 69–69 | bg-surface-container-low rounded-lg p-space-md shadow-inner flex flex-col gap-space-xs |
| S08b4dbca0abb_N1387 | S08b4dbca0abb_N1380 | element | 70–70 | element  |
| S08b4dbca0abb_N1388 | S08b4dbca0abb_N1387 | start_tag | 70–70 | start_tag  |
| S08b4dbca0abb_N1389 | S08b4dbca0abb_N1388 | tag_name | 70–70 | span |
| S08b4dbca0abb_N1390 | S08b4dbca0abb_N1388 | attribute | 70–70 | attribute  |
| S08b4dbca0abb_N1391 | S08b4dbca0abb_N1390 | attribute_name | 70–70 | class |
| S08b4dbca0abb_N1392 | S08b4dbca0abb_N1390 | quoted_attribute_value | 70–70 | quoted_attribute_value  |
| S08b4dbca0abb_N1393 | S08b4dbca0abb_N1392 | attribute_value | 70–70 | font-label-caps text-label-caps text-on-surface-variant uppercase |
| S08b4dbca0abb_N1394 | S08b4dbca0abb_N1387 | text | 70–70 | Birth time |
| S08b4dbca0abb_N1395 | S08b4dbca0abb_N1387 | end_tag | 70–70 | end_tag  |
| S08b4dbca0abb_N1396 | S08b4dbca0abb_N1395 | tag_name | 70–70 | span |
| S08b4dbca0abb_N1397 | S08b4dbca0abb_N1380 | element | 71–71 | element  |
| S08b4dbca0abb_N1398 | S08b4dbca0abb_N1397 | start_tag | 71–71 | start_tag  |
| S08b4dbca0abb_N1399 | S08b4dbca0abb_N1398 | tag_name | 71–71 | span |
| S08b4dbca0abb_N1400 | S08b4dbca0abb_N1398 | attribute | 71–71 | attribute  |
| S08b4dbca0abb_N1401 | S08b4dbca0abb_N1400 | attribute_name | 71–71 | class |
| S08b4dbca0abb_N1402 | S08b4dbca0abb_N1400 | quoted_attribute_value | 71–71 | quoted_attribute_value  |
| S08b4dbca0abb_N1403 | S08b4dbca0abb_N1402 | attribute_value | 71–71 | font-headline-sm text-headline-sm text-on-surface |
| S08b4dbca0abb_N1404 | S08b4dbca0abb_N1397 | text | 71–71 | 12:00 |
| S08b4dbca0abb_N1405 | S08b4dbca0abb_N1397 | element | 71–71 | element  |
| S08b4dbca0abb_N1406 | S08b4dbca0abb_N1405 | start_tag | 71–71 | start_tag  |
| S08b4dbca0abb_N1407 | S08b4dbca0abb_N1406 | tag_name | 71–71 | span |
| S08b4dbca0abb_N1408 | S08b4dbca0abb_N1406 | attribute | 71–71 | attribute  |
| S08b4dbca0abb_N1409 | S08b4dbca0abb_N1408 | attribute_name | 71–71 | class |
| S08b4dbca0abb_N1410 | S08b4dbca0abb_N1408 | quoted_attribute_value | 71–71 | quoted_attribute_value  |
| S08b4dbca0abb_N1411 | S08b4dbca0abb_N1410 | attribute_value | 71–71 | text-body-sm font-normal text-on-surface-variant |
| S08b4dbca0abb_N1412 | S08b4dbca0abb_N1405 | text | 71–71 | (12:00 PM) |
| S08b4dbca0abb_N1413 | S08b4dbca0abb_N1405 | end_tag | 71–71 | end_tag  |
| S08b4dbca0abb_N1414 | S08b4dbca0abb_N1413 | tag_name | 71–71 | span |
| S08b4dbca0abb_N1415 | S08b4dbca0abb_N1397 | text | 71–71 | EST |
| S08b4dbca0abb_N1416 | S08b4dbca0abb_N1397 | end_tag | 71–71 | end_tag  |
| S08b4dbca0abb_N1417 | S08b4dbca0abb_N1416 | tag_name | 71–71 | span |
| S08b4dbca0abb_N1418 | S08b4dbca0abb_N1380 | element | 72–72 | element  |
| S08b4dbca0abb_N1419 | S08b4dbca0abb_N1418 | start_tag | 72–72 | start_tag  |
| S08b4dbca0abb_N1420 | S08b4dbca0abb_N1419 | tag_name | 72–72 | span |
| S08b4dbca0abb_N1421 | S08b4dbca0abb_N1419 | attribute | 72–72 | attribute  |
| S08b4dbca0abb_N1422 | S08b4dbca0abb_N1421 | attribute_name | 72–72 | class |
| S08b4dbca0abb_N1423 | S08b4dbca0abb_N1421 | quoted_attribute_value | 72–72 | quoted_attribute_value  |
| S08b4dbca0abb_N1424 | S08b4dbca0abb_N1423 | attribute_value | 72–72 | font-astro-data-md text-astro-data-md text-primary font-medium |
| S08b4dbca0abb_N1425 | S08b4dbca0abb_N1418 | text | 72–72 | Fictional example, not a customer record |
| S08b4dbca0abb_N1426 | S08b4dbca0abb_N1418 | end_tag | 72–72 | end_tag  |
| S08b4dbca0abb_N1427 | S08b4dbca0abb_N1426 | tag_name | 72–72 | span |
| S08b4dbca0abb_N1428 | S08b4dbca0abb_N1380 | end_tag | 73–73 | end_tag  |
| S08b4dbca0abb_N1429 | S08b4dbca0abb_N1428 | tag_name | 73–73 | div |
| S08b4dbca0abb_N1430 | S08b4dbca0abb_N1332 | comment | 74–74 | &lt;!-- Item 3: Geographic Origin --&gt; |
| S08b4dbca0abb_N1431 | S08b4dbca0abb_N1332 | element | 75–85 | element  |
| S08b4dbca0abb_N1432 | S08b4dbca0abb_N1431 | start_tag | 75–75 | start_tag  |
| S08b4dbca0abb_N1433 | S08b4dbca0abb_N1432 | tag_name | 75–75 | div |
| S08b4dbca0abb_N1434 | S08b4dbca0abb_N1432 | attribute | 75–75 | attribute  |
| S08b4dbca0abb_N1435 | S08b4dbca0abb_N1434 | attribute_name | 75–75 | class |
| S08b4dbca0abb_N1436 | S08b4dbca0abb_N1434 | quoted_attribute_value | 75–75 | quoted_attribute_value  |
| S08b4dbca0abb_N1437 | S08b4dbca0abb_N1436 | attribute_value | 75–75 | sm:col-span-2 bg-surface-container-low rounded-lg p-space-md shadow-inner flex flex-col sm:flex-row sm:items-center justify-between gap-space-sm |
| S08b4dbca0abb_N1438 | S08b4dbca0abb_N1431 | element | 76–80 | element  |
| S08b4dbca0abb_N1439 | S08b4dbca0abb_N1438 | start_tag | 76–76 | start_tag  |
| S08b4dbca0abb_N1440 | S08b4dbca0abb_N1439 | tag_name | 76–76 | div |
| S08b4dbca0abb_N1441 | S08b4dbca0abb_N1438 | element | 77–77 | element  |
| S08b4dbca0abb_N1442 | S08b4dbca0abb_N1441 | start_tag | 77–77 | start_tag  |
| S08b4dbca0abb_N1443 | S08b4dbca0abb_N1442 | tag_name | 77–77 | span |
| S08b4dbca0abb_N1444 | S08b4dbca0abb_N1442 | attribute | 77–77 | attribute  |
| S08b4dbca0abb_N1445 | S08b4dbca0abb_N1444 | attribute_name | 77–77 | class |
| S08b4dbca0abb_N1446 | S08b4dbca0abb_N1444 | quoted_attribute_value | 77–77 | quoted_attribute_value  |
| S08b4dbca0abb_N1447 | S08b4dbca0abb_N1446 | attribute_value | 77–77 | font-label-caps text-label-caps text-on-surface-variant uppercase block mb-1 |
| S08b4dbca0abb_N1448 | S08b4dbca0abb_N1441 | text | 77–77 | Geographic Coordinates |
| S08b4dbca0abb_N1449 | S08b4dbca0abb_N1441 | end_tag | 77–77 | end_tag  |
| S08b4dbca0abb_N1450 | S08b4dbca0abb_N1449 | tag_name | 77–77 | span |
| S08b4dbca0abb_N1451 | S08b4dbca0abb_N1438 | element | 78–78 | element  |
| S08b4dbca0abb_N1452 | S08b4dbca0abb_N1451 | start_tag | 78–78 | start_tag  |
| S08b4dbca0abb_N1453 | S08b4dbca0abb_N1452 | tag_name | 78–78 | div |
| S08b4dbca0abb_N1454 | S08b4dbca0abb_N1452 | attribute | 78–78 | attribute  |
| S08b4dbca0abb_N1455 | S08b4dbca0abb_N1454 | attribute_name | 78–78 | class |
| S08b4dbca0abb_N1456 | S08b4dbca0abb_N1454 | quoted_attribute_value | 78–78 | quoted_attribute_value  |
| S08b4dbca0abb_N1457 | S08b4dbca0abb_N1456 | attribute_value | 78–78 | font-body-lg text-body-lg text-on-surface font-semibold |
| S08b4dbca0abb_N1458 | S08b4dbca0abb_N1451 | text | 78–78 | Toronto, Ontario, Canada · fictional example |
| S08b4dbca0abb_N1459 | S08b4dbca0abb_N1451 | end_tag | 78–78 | end_tag  |
| S08b4dbca0abb_N1460 | S08b4dbca0abb_N1459 | tag_name | 78–78 | div |
| S08b4dbca0abb_N1461 | S08b4dbca0abb_N1438 | element | 79–79 | element  |
| S08b4dbca0abb_N1462 | S08b4dbca0abb_N1461 | start_tag | 79–79 | start_tag  |
| S08b4dbca0abb_N1463 | S08b4dbca0abb_N1462 | tag_name | 79–79 | div |
| S08b4dbca0abb_N1464 | S08b4dbca0abb_N1462 | attribute | 79–79 | attribute  |
| S08b4dbca0abb_N1465 | S08b4dbca0abb_N1464 | attribute_name | 79–79 | class |
| S08b4dbca0abb_N1466 | S08b4dbca0abb_N1464 | quoted_attribute_value | 79–79 | quoted_attribute_value  |
| S08b4dbca0abb_N1467 | S08b4dbca0abb_N1466 | attribute_value | 79–79 | font-astro-data-md text-astro-data-md text-on-surface-variant mt-1 |
| S08b4dbca0abb_N1468 | S08b4dbca0abb_N1461 | text | 79–79 | 43.65° N, 79.38° W · sample coordinates · Placidus calculation system |
| S08b4dbca0abb_N1469 | S08b4dbca0abb_N1461 | end_tag | 79–79 | end_tag  |
| S08b4dbca0abb_N1470 | S08b4dbca0abb_N1469 | tag_name | 79–79 | div |
| S08b4dbca0abb_N1471 | S08b4dbca0abb_N1438 | end_tag | 80–80 | end_tag  |
| S08b4dbca0abb_N1472 | S08b4dbca0abb_N1471 | tag_name | 80–80 | div |
| S08b4dbca0abb_N1473 | S08b4dbca0abb_N1431 | element | 81–84 | element  |
| S08b4dbca0abb_N1474 | S08b4dbca0abb_N1473 | start_tag | 81–81 | start_tag  |
| S08b4dbca0abb_N1475 | S08b4dbca0abb_N1474 | tag_name | 81–81 | div |
| S08b4dbca0abb_N1476 | S08b4dbca0abb_N1474 | attribute | 81–81 | attribute  |
| S08b4dbca0abb_N1477 | S08b4dbca0abb_N1476 | attribute_name | 81–81 | class |
| S08b4dbca0abb_N1478 | S08b4dbca0abb_N1476 | quoted_attribute_value | 81–81 | quoted_attribute_value  |
| S08b4dbca0abb_N1479 | S08b4dbca0abb_N1478 | attribute_value | 81–81 | flex items-center gap-2 self-start sm:self-center px-space-sm py-1 rounded bg-surface-container-high text-on-surface font-astro-data-md text-astro-data-md |
| S08b4dbca0abb_N1480 | S08b4dbca0abb_N1473 | element | 82–82 | element  |
| S08b4dbca0abb_N1481 | S08b4dbca0abb_N1480 | start_tag | 82–82 | start_tag  |
| S08b4dbca0abb_N1482 | S08b4dbca0abb_N1481 | tag_name | 82–82 | span |
| S08b4dbca0abb_N1483 | S08b4dbca0abb_N1481 | attribute | 82–82 | attribute  |
| S08b4dbca0abb_N1484 | S08b4dbca0abb_N1483 | attribute_name | 82–82 | class |
| S08b4dbca0abb_N1485 | S08b4dbca0abb_N1483 | quoted_attribute_value | 82–82 | quoted_attribute_value  |
| S08b4dbca0abb_N1486 | S08b4dbca0abb_N1485 | attribute_value | 82–82 | material-symbols-outlined text-[16px] text-tertiary |
| S08b4dbca0abb_N1487 | S08b4dbca0abb_N1480 | text | 82–82 | pin_drop |
| S08b4dbca0abb_N1488 | S08b4dbca0abb_N1480 | end_tag | 82–82 | end_tag  |
| S08b4dbca0abb_N1489 | S08b4dbca0abb_N1488 | tag_name | 82–82 | span |
| S08b4dbca0abb_N1490 | S08b4dbca0abb_N1473 | element | 83–83 | element  |
| S08b4dbca0abb_N1491 | S08b4dbca0abb_N1490 | start_tag | 83–83 | start_tag  |
| S08b4dbca0abb_N1492 | S08b4dbca0abb_N1491 | tag_name | 83–83 | span |
| S08b4dbca0abb_N1493 | S08b4dbca0abb_N1490 | text | 83–83 | UTC -5 |
| S08b4dbca0abb_N1494 | S08b4dbca0abb_N1490 | end_tag | 83–83 | end_tag  |
| S08b4dbca0abb_N1495 | S08b4dbca0abb_N1494 | tag_name | 83–83 | span |
| S08b4dbca0abb_N1496 | S08b4dbca0abb_N1473 | end_tag | 84–84 | end_tag  |
| S08b4dbca0abb_N1497 | S08b4dbca0abb_N1496 | tag_name | 84–84 | div |
| S08b4dbca0abb_N1498 | S08b4dbca0abb_N1431 | end_tag | 85–85 | end_tag  |
| S08b4dbca0abb_N1499 | S08b4dbca0abb_N1498 | tag_name | 85–85 | div |
| S08b4dbca0abb_N1500 | S08b4dbca0abb_N1332 | end_tag | 86–86 | end_tag  |
| S08b4dbca0abb_N1501 | S08b4dbca0abb_N1500 | tag_name | 86–86 | div |
| S08b4dbca0abb_N1502 | S08b4dbca0abb_N1266 | comment | 87–87 | &lt;!-- Planetary Vector Chartlet Snippet --&gt; |
| S08b4dbca0abb_N1503 | S08b4dbca0abb_N1266 | element | 88–105 | element  |
| S08b4dbca0abb_N1504 | S08b4dbca0abb_N1503 | start_tag | 88–88 | start_tag  |
| S08b4dbca0abb_N1505 | S08b4dbca0abb_N1504 | tag_name | 88–88 | div |
| S08b4dbca0abb_N1506 | S08b4dbca0abb_N1504 | attribute | 88–88 | attribute  |
| S08b4dbca0abb_N1507 | S08b4dbca0abb_N1506 | attribute_name | 88–88 | class |
| S08b4dbca0abb_N1508 | S08b4dbca0abb_N1506 | quoted_attribute_value | 88–88 | quoted_attribute_value  |
| S08b4dbca0abb_N1509 | S08b4dbca0abb_N1508 | attribute_value | 88–88 | bg-surface-container-lowest/80 rounded-lg p-space-md mb-space-lg flex flex-col gap-space-sm |
| S08b4dbca0abb_N1510 | S08b4dbca0abb_N1503 | element | 89–92 | element  |
| S08b4dbca0abb_N1511 | S08b4dbca0abb_N1510 | start_tag | 89–89 | start_tag  |
| S08b4dbca0abb_N1512 | S08b4dbca0abb_N1511 | tag_name | 89–89 | div |
| S08b4dbca0abb_N1513 | S08b4dbca0abb_N1511 | attribute | 89–89 | attribute  |
| S08b4dbca0abb_N1514 | S08b4dbca0abb_N1513 | attribute_name | 89–89 | class |
| S08b4dbca0abb_N1515 | S08b4dbca0abb_N1513 | quoted_attribute_value | 89–89 | quoted_attribute_value  |
| S08b4dbca0abb_N1516 | S08b4dbca0abb_N1515 | attribute_value | 89–89 | flex items-center justify-between |
| S08b4dbca0abb_N1517 | S08b4dbca0abb_N1510 | element | 90–90 | element  |
| S08b4dbca0abb_N1518 | S08b4dbca0abb_N1517 | start_tag | 90–90 | start_tag  |
| S08b4dbca0abb_N1519 | S08b4dbca0abb_N1518 | tag_name | 90–90 | span |
| S08b4dbca0abb_N1520 | S08b4dbca0abb_N1518 | attribute | 90–90 | attribute  |
| S08b4dbca0abb_N1521 | S08b4dbca0abb_N1520 | attribute_name | 90–90 | class |
| S08b4dbca0abb_N1522 | S08b4dbca0abb_N1520 | quoted_attribute_value | 90–90 | quoted_attribute_value  |
| S08b4dbca0abb_N1523 | S08b4dbca0abb_N1522 | attribute_value | 90–90 | font-label-caps text-label-caps text-on-surface-variant |
| S08b4dbca0abb_N1524 | S08b4dbca0abb_N1517 | text | 90–90 | LUMEN HARMONICS |
| S08b4dbca0abb_N1525 | S08b4dbca0abb_N1517 | end_tag | 90–90 | end_tag  |
| S08b4dbca0abb_N1526 | S08b4dbca0abb_N1525 | tag_name | 90–90 | span |
| S08b4dbca0abb_N1527 | S08b4dbca0abb_N1510 | element | 91–91 | element  |
| S08b4dbca0abb_N1528 | S08b4dbca0abb_N1527 | start_tag | 91–91 | start_tag  |
| S08b4dbca0abb_N1529 | S08b4dbca0abb_N1528 | tag_name | 91–91 | span |
| S08b4dbca0abb_N1530 | S08b4dbca0abb_N1528 | attribute | 91–91 | attribute  |
| S08b4dbca0abb_N1531 | S08b4dbca0abb_N1530 | attribute_name | 91–91 | class |
| S08b4dbca0abb_N1532 | S08b4dbca0abb_N1530 | quoted_attribute_value | 91–91 | quoted_attribute_value  |
| S08b4dbca0abb_N1533 | S08b4dbca0abb_N1532 | attribute_value | 91–91 | font-astro-data-md text-astro-data-md text-primary |
| S08b4dbca0abb_N1534 | S08b4dbca0abb_N1527 | text | 91–91 | ASC: Aries 12°08' |
| S08b4dbca0abb_N1535 | S08b4dbca0abb_N1527 | end_tag | 91–91 | end_tag  |
| S08b4dbca0abb_N1536 | S08b4dbca0abb_N1535 | tag_name | 91–91 | span |
| S08b4dbca0abb_N1537 | S08b4dbca0abb_N1510 | end_tag | 92–92 | end_tag  |
| S08b4dbca0abb_N1538 | S08b4dbca0abb_N1537 | tag_name | 92–92 | div |
| S08b4dbca0abb_N1539 | S08b4dbca0abb_N1503 | element | 93–98 | element  |
| S08b4dbca0abb_N1540 | S08b4dbca0abb_N1539 | start_tag | 93–93 | start_tag  |
| S08b4dbca0abb_N1541 | S08b4dbca0abb_N1540 | tag_name | 93–93 | div |
| S08b4dbca0abb_N1542 | S08b4dbca0abb_N1540 | attribute | 93–93 | attribute  |
| S08b4dbca0abb_N1543 | S08b4dbca0abb_N1542 | attribute_name | 93–93 | class |
| S08b4dbca0abb_N1544 | S08b4dbca0abb_N1542 | quoted_attribute_value | 93–93 | quoted_attribute_value  |
| S08b4dbca0abb_N1545 | S08b4dbca0abb_N1544 | attribute_value | 93–93 | w-full bg-surface-container h-2 rounded-full overflow-hidden flex |
| S08b4dbca0abb_N1546 | S08b4dbca0abb_N1539 | element | 94–94 | element  |
| S08b4dbca0abb_N1547 | S08b4dbca0abb_N1546 | start_tag | 94–94 | start_tag  |
| S08b4dbca0abb_N1548 | S08b4dbca0abb_N1547 | tag_name | 94–94 | div |
| S08b4dbca0abb_N1549 | S08b4dbca0abb_N1547 | attribute | 94–94 | attribute  |
| S08b4dbca0abb_N1550 | S08b4dbca0abb_N1549 | attribute_name | 94–94 | class |
| S08b4dbca0abb_N1551 | S08b4dbca0abb_N1549 | quoted_attribute_value | 94–94 | quoted_attribute_value  |
| S08b4dbca0abb_N1552 | S08b4dbca0abb_N1551 | attribute_value | 94–94 | bg-primary h-full w-[45%] |
| S08b4dbca0abb_N1553 | S08b4dbca0abb_N1547 | attribute | 94–94 | attribute  |
| S08b4dbca0abb_N1554 | S08b4dbca0abb_N1553 | attribute_name | 94–94 | title |
| S08b4dbca0abb_N1555 | S08b4dbca0abb_N1553 | quoted_attribute_value | 94–94 | quoted_attribute_value  |
| S08b4dbca0abb_N1556 | S08b4dbca0abb_N1555 | attribute_value | 94–94 | Fire (45%) |
| S08b4dbca0abb_N1557 | S08b4dbca0abb_N1546 | end_tag | 94–94 | end_tag  |
| S08b4dbca0abb_N1558 | S08b4dbca0abb_N1557 | tag_name | 94–94 | div |
| S08b4dbca0abb_N1559 | S08b4dbca0abb_N1539 | element | 95–95 | element  |
| S08b4dbca0abb_N1560 | S08b4dbca0abb_N1559 | start_tag | 95–95 | start_tag  |
| S08b4dbca0abb_N1561 | S08b4dbca0abb_N1560 | tag_name | 95–95 | div |
| S08b4dbca0abb_N1562 | S08b4dbca0abb_N1560 | attribute | 95–95 | attribute  |
| S08b4dbca0abb_N1563 | S08b4dbca0abb_N1562 | attribute_name | 95–95 | class |
| S08b4dbca0abb_N1564 | S08b4dbca0abb_N1562 | quoted_attribute_value | 95–95 | quoted_attribute_value  |
| S08b4dbca0abb_N1565 | S08b4dbca0abb_N1564 | attribute_value | 95–95 | bg-tertiary h-full w-[25%] |
| S08b4dbca0abb_N1566 | S08b4dbca0abb_N1560 | attribute | 95–95 | attribute  |
| S08b4dbca0abb_N1567 | S08b4dbca0abb_N1566 | attribute_name | 95–95 | title |
| S08b4dbca0abb_N1568 | S08b4dbca0abb_N1566 | quoted_attribute_value | 95–95 | quoted_attribute_value  |
| S08b4dbca0abb_N1569 | S08b4dbca0abb_N1568 | attribute_value | 95–95 | Water (25%) |
| S08b4dbca0abb_N1570 | S08b4dbca0abb_N1559 | end_tag | 95–95 | end_tag  |
| S08b4dbca0abb_N1571 | S08b4dbca0abb_N1570 | tag_name | 95–95 | div |
| S08b4dbca0abb_N1572 | S08b4dbca0abb_N1539 | element | 96–96 | element  |
| S08b4dbca0abb_N1573 | S08b4dbca0abb_N1572 | start_tag | 96–96 | start_tag  |
| S08b4dbca0abb_N1574 | S08b4dbca0abb_N1573 | tag_name | 96–96 | div |
| S08b4dbca0abb_N1575 | S08b4dbca0abb_N1573 | attribute | 96–96 | attribute  |
| S08b4dbca0abb_N1576 | S08b4dbca0abb_N1575 | attribute_name | 96–96 | class |
| S08b4dbca0abb_N1577 | S08b4dbca0abb_N1575 | quoted_attribute_value | 96–96 | quoted_attribute_value  |
| S08b4dbca0abb_N1578 | S08b4dbca0abb_N1577 | attribute_value | 96–96 | bg-secondary h-full w-[20%] |
| S08b4dbca0abb_N1579 | S08b4dbca0abb_N1573 | attribute | 96–96 | attribute  |
| S08b4dbca0abb_N1580 | S08b4dbca0abb_N1579 | attribute_name | 96–96 | title |
| S08b4dbca0abb_N1581 | S08b4dbca0abb_N1579 | quoted_attribute_value | 96–96 | quoted_attribute_value  |
| S08b4dbca0abb_N1582 | S08b4dbca0abb_N1581 | attribute_value | 96–96 | Air (20%) |
| S08b4dbca0abb_N1583 | S08b4dbca0abb_N1572 | end_tag | 96–96 | end_tag  |
| S08b4dbca0abb_N1584 | S08b4dbca0abb_N1583 | tag_name | 96–96 | div |
| S08b4dbca0abb_N1585 | S08b4dbca0abb_N1539 | element | 97–97 | element  |
| S08b4dbca0abb_N1586 | S08b4dbca0abb_N1585 | start_tag | 97–97 | start_tag  |
| S08b4dbca0abb_N1587 | S08b4dbca0abb_N1586 | tag_name | 97–97 | div |
| S08b4dbca0abb_N1588 | S08b4dbca0abb_N1586 | attribute | 97–97 | attribute  |
| S08b4dbca0abb_N1589 | S08b4dbca0abb_N1588 | attribute_name | 97–97 | class |
| S08b4dbca0abb_N1590 | S08b4dbca0abb_N1588 | quoted_attribute_value | 97–97 | quoted_attribute_value  |
| S08b4dbca0abb_N1591 | S08b4dbca0abb_N1590 | attribute_value | 97–97 | bg-on-surface-variant/30 h-full w-[10%] |
| S08b4dbca0abb_N1592 | S08b4dbca0abb_N1586 | attribute | 97–97 | attribute  |
| S08b4dbca0abb_N1593 | S08b4dbca0abb_N1592 | attribute_name | 97–97 | title |
| S08b4dbca0abb_N1594 | S08b4dbca0abb_N1592 | quoted_attribute_value | 97–97 | quoted_attribute_value  |
| S08b4dbca0abb_N1595 | S08b4dbca0abb_N1594 | attribute_value | 97–97 | Earth (10%) |
| S08b4dbca0abb_N1596 | S08b4dbca0abb_N1585 | end_tag | 97–97 | end_tag  |
| S08b4dbca0abb_N1597 | S08b4dbca0abb_N1596 | tag_name | 97–97 | div |
| S08b4dbca0abb_N1598 | S08b4dbca0abb_N1539 | end_tag | 98–98 | end_tag  |
| S08b4dbca0abb_N1599 | S08b4dbca0abb_N1598 | tag_name | 98–98 | div |
| S08b4dbca0abb_N1600 | S08b4dbca0abb_N1503 | element | 99–104 | element  |
| S08b4dbca0abb_N1601 | S08b4dbca0abb_N1600 | start_tag | 99–99 | start_tag  |
| S08b4dbca0abb_N1602 | S08b4dbca0abb_N1601 | tag_name | 99–99 | div |
| S08b4dbca0abb_N1603 | S08b4dbca0abb_N1601 | attribute | 99–99 | attribute  |
| S08b4dbca0abb_N1604 | S08b4dbca0abb_N1603 | attribute_name | 99–99 | class |
| S08b4dbca0abb_N1605 | S08b4dbca0abb_N1603 | quoted_attribute_value | 99–99 | quoted_attribute_value  |
| S08b4dbca0abb_N1606 | S08b4dbca0abb_N1605 | attribute_value | 99–99 | flex justify-between font-astro-data-md text-astro-data-md text-on-surface-variant text-[11px] |
| S08b4dbca0abb_N1607 | S08b4dbca0abb_N1600 | element | 100–100 | element  |
| S08b4dbca0abb_N1608 | S08b4dbca0abb_N1607 | start_tag | 100–100 | start_tag  |
| S08b4dbca0abb_N1609 | S08b4dbca0abb_N1608 | tag_name | 100–100 | span |
| S08b4dbca0abb_N1610 | S08b4dbca0abb_N1608 | attribute | 100–100 | attribute  |
| S08b4dbca0abb_N1611 | S08b4dbca0abb_N1610 | attribute_name | 100–100 | class |
| S08b4dbca0abb_N1612 | S08b4dbca0abb_N1610 | quoted_attribute_value | 100–100 | quoted_attribute_value  |
| S08b4dbca0abb_N1613 | S08b4dbca0abb_N1612 | attribute_value | 100–100 | flex items-center gap-1 |
| S08b4dbca0abb_N1614 | S08b4dbca0abb_N1607 | element | 100–100 | element  |
| S08b4dbca0abb_N1615 | S08b4dbca0abb_N1614 | start_tag | 100–100 | start_tag  |
| S08b4dbca0abb_N1616 | S08b4dbca0abb_N1615 | tag_name | 100–100 | span |
| S08b4dbca0abb_N1617 | S08b4dbca0abb_N1615 | attribute | 100–100 | attribute  |
| S08b4dbca0abb_N1618 | S08b4dbca0abb_N1617 | attribute_name | 100–100 | class |
| S08b4dbca0abb_N1619 | S08b4dbca0abb_N1617 | quoted_attribute_value | 100–100 | quoted_attribute_value  |
| S08b4dbca0abb_N1620 | S08b4dbca0abb_N1619 | attribute_value | 100–100 | w-1.5 h-1.5 rounded-full bg-primary inline-block |
| S08b4dbca0abb_N1621 | S08b4dbca0abb_N1614 | end_tag | 100–100 | end_tag  |
| S08b4dbca0abb_N1622 | S08b4dbca0abb_N1621 | tag_name | 100–100 | span |
| S08b4dbca0abb_N1623 | S08b4dbca0abb_N1607 | text | 100–100 | Fire 45% |
| S08b4dbca0abb_N1624 | S08b4dbca0abb_N1607 | end_tag | 100–100 | end_tag  |
| S08b4dbca0abb_N1625 | S08b4dbca0abb_N1624 | tag_name | 100–100 | span |
| S08b4dbca0abb_N1626 | S08b4dbca0abb_N1600 | element | 101–101 | element  |
| S08b4dbca0abb_N1627 | S08b4dbca0abb_N1626 | start_tag | 101–101 | start_tag  |
| S08b4dbca0abb_N1628 | S08b4dbca0abb_N1627 | tag_name | 101–101 | span |
| S08b4dbca0abb_N1629 | S08b4dbca0abb_N1627 | attribute | 101–101 | attribute  |
| S08b4dbca0abb_N1630 | S08b4dbca0abb_N1629 | attribute_name | 101–101 | class |
| S08b4dbca0abb_N1631 | S08b4dbca0abb_N1629 | quoted_attribute_value | 101–101 | quoted_attribute_value  |
| S08b4dbca0abb_N1632 | S08b4dbca0abb_N1631 | attribute_value | 101–101 | flex items-center gap-1 |
| S08b4dbca0abb_N1633 | S08b4dbca0abb_N1626 | element | 101–101 | element  |
| S08b4dbca0abb_N1634 | S08b4dbca0abb_N1633 | start_tag | 101–101 | start_tag  |
| S08b4dbca0abb_N1635 | S08b4dbca0abb_N1634 | tag_name | 101–101 | span |
| S08b4dbca0abb_N1636 | S08b4dbca0abb_N1634 | attribute | 101–101 | attribute  |
| S08b4dbca0abb_N1637 | S08b4dbca0abb_N1636 | attribute_name | 101–101 | class |
| S08b4dbca0abb_N1638 | S08b4dbca0abb_N1636 | quoted_attribute_value | 101–101 | quoted_attribute_value  |
| S08b4dbca0abb_N1639 | S08b4dbca0abb_N1638 | attribute_value | 101–101 | w-1.5 h-1.5 rounded-full bg-tertiary inline-block |
| S08b4dbca0abb_N1640 | S08b4dbca0abb_N1633 | end_tag | 101–101 | end_tag  |
| S08b4dbca0abb_N1641 | S08b4dbca0abb_N1640 | tag_name | 101–101 | span |
| S08b4dbca0abb_N1642 | S08b4dbca0abb_N1626 | text | 101–101 | Water 25% |
| S08b4dbca0abb_N1643 | S08b4dbca0abb_N1626 | end_tag | 101–101 | end_tag  |
| S08b4dbca0abb_N1644 | S08b4dbca0abb_N1643 | tag_name | 101–101 | span |
| S08b4dbca0abb_N1645 | S08b4dbca0abb_N1600 | element | 102–102 | element  |
| S08b4dbca0abb_N1646 | S08b4dbca0abb_N1645 | start_tag | 102–102 | start_tag  |
| S08b4dbca0abb_N1647 | S08b4dbca0abb_N1646 | tag_name | 102–102 | span |
| S08b4dbca0abb_N1648 | S08b4dbca0abb_N1646 | attribute | 102–102 | attribute  |
| S08b4dbca0abb_N1649 | S08b4dbca0abb_N1648 | attribute_name | 102–102 | class |
| S08b4dbca0abb_N1650 | S08b4dbca0abb_N1648 | quoted_attribute_value | 102–102 | quoted_attribute_value  |
| S08b4dbca0abb_N1651 | S08b4dbca0abb_N1650 | attribute_value | 102–102 | flex items-center gap-1 |
| S08b4dbca0abb_N1652 | S08b4dbca0abb_N1645 | element | 102–102 | element  |
| S08b4dbca0abb_N1653 | S08b4dbca0abb_N1652 | start_tag | 102–102 | start_tag  |
| S08b4dbca0abb_N1654 | S08b4dbca0abb_N1653 | tag_name | 102–102 | span |
| S08b4dbca0abb_N1655 | S08b4dbca0abb_N1653 | attribute | 102–102 | attribute  |
| S08b4dbca0abb_N1656 | S08b4dbca0abb_N1655 | attribute_name | 102–102 | class |
| S08b4dbca0abb_N1657 | S08b4dbca0abb_N1655 | quoted_attribute_value | 102–102 | quoted_attribute_value  |
| S08b4dbca0abb_N1658 | S08b4dbca0abb_N1657 | attribute_value | 102–102 | w-1.5 h-1.5 rounded-full bg-secondary inline-block |
| S08b4dbca0abb_N1659 | S08b4dbca0abb_N1652 | end_tag | 102–102 | end_tag  |
| S08b4dbca0abb_N1660 | S08b4dbca0abb_N1659 | tag_name | 102–102 | span |
| S08b4dbca0abb_N1661 | S08b4dbca0abb_N1645 | text | 102–102 | Air 20% |
| S08b4dbca0abb_N1662 | S08b4dbca0abb_N1645 | end_tag | 102–102 | end_tag  |
| S08b4dbca0abb_N1663 | S08b4dbca0abb_N1662 | tag_name | 102–102 | span |
| S08b4dbca0abb_N1664 | S08b4dbca0abb_N1600 | element | 103–103 | element  |
| S08b4dbca0abb_N1665 | S08b4dbca0abb_N1664 | start_tag | 103–103 | start_tag  |
| S08b4dbca0abb_N1666 | S08b4dbca0abb_N1665 | tag_name | 103–103 | span |
| S08b4dbca0abb_N1667 | S08b4dbca0abb_N1665 | attribute | 103–103 | attribute  |
| S08b4dbca0abb_N1668 | S08b4dbca0abb_N1667 | attribute_name | 103–103 | class |
| S08b4dbca0abb_N1669 | S08b4dbca0abb_N1667 | quoted_attribute_value | 103–103 | quoted_attribute_value  |
| S08b4dbca0abb_N1670 | S08b4dbca0abb_N1669 | attribute_value | 103–103 | flex items-center gap-1 |
| S08b4dbca0abb_N1671 | S08b4dbca0abb_N1664 | element | 103–103 | element  |
| S08b4dbca0abb_N1672 | S08b4dbca0abb_N1671 | start_tag | 103–103 | start_tag  |
| S08b4dbca0abb_N1673 | S08b4dbca0abb_N1672 | tag_name | 103–103 | span |
| S08b4dbca0abb_N1674 | S08b4dbca0abb_N1672 | attribute | 103–103 | attribute  |
| S08b4dbca0abb_N1675 | S08b4dbca0abb_N1674 | attribute_name | 103–103 | class |
| S08b4dbca0abb_N1676 | S08b4dbca0abb_N1674 | quoted_attribute_value | 103–103 | quoted_attribute_value  |
| S08b4dbca0abb_N1677 | S08b4dbca0abb_N1676 | attribute_value | 103–103 | w-1.5 h-1.5 rounded-full bg-on-surface-variant/40 inline-block |
| S08b4dbca0abb_N1678 | S08b4dbca0abb_N1671 | end_tag | 103–103 | end_tag  |
| S08b4dbca0abb_N1679 | S08b4dbca0abb_N1678 | tag_name | 103–103 | span |
| S08b4dbca0abb_N1680 | S08b4dbca0abb_N1664 | text | 103–103 | Earth 10% |
| S08b4dbca0abb_N1681 | S08b4dbca0abb_N1664 | end_tag | 103–103 | end_tag  |
| S08b4dbca0abb_N1682 | S08b4dbca0abb_N1681 | tag_name | 103–103 | span |
| S08b4dbca0abb_N1683 | S08b4dbca0abb_N1600 | end_tag | 104–104 | end_tag  |
| S08b4dbca0abb_N1684 | S08b4dbca0abb_N1683 | tag_name | 104–104 | div |
| S08b4dbca0abb_N1685 | S08b4dbca0abb_N1503 | end_tag | 105–105 | end_tag  |
| S08b4dbca0abb_N1686 | S08b4dbca0abb_N1685 | tag_name | 105–105 | div |
| S08b4dbca0abb_N1687 | S08b4dbca0abb_N1266 | comment | 106–106 | &lt;!-- Edit Link Navigation --&gt; |
| S08b4dbca0abb_N1688 | S08b4dbca0abb_N1266 | element | 107–113 | element  |
| S08b4dbca0abb_N1689 | S08b4dbca0abb_N1688 | start_tag | 107–107 | start_tag  |
| S08b4dbca0abb_N1690 | S08b4dbca0abb_N1689 | tag_name | 107–107 | div |
| S08b4dbca0abb_N1691 | S08b4dbca0abb_N1689 | attribute | 107–107 | attribute  |
| S08b4dbca0abb_N1692 | S08b4dbca0abb_N1691 | attribute_name | 107–107 | class |
| S08b4dbca0abb_N1693 | S08b4dbca0abb_N1691 | quoted_attribute_value | 107–107 | quoted_attribute_value  |
| S08b4dbca0abb_N1694 | S08b4dbca0abb_N1693 | attribute_value | 107–107 | flex items-center justify-between pt-space-xs |
| S08b4dbca0abb_N1695 | S08b4dbca0abb_N1688 | element | 108–108 | element  |
| S08b4dbca0abb_N1696 | S08b4dbca0abb_N1695 | start_tag | 108–108 | start_tag  |
| S08b4dbca0abb_N1697 | S08b4dbca0abb_N1696 | tag_name | 108–108 | span |
| S08b4dbca0abb_N1698 | S08b4dbca0abb_N1696 | attribute | 108–108 | attribute  |
| S08b4dbca0abb_N1699 | S08b4dbca0abb_N1698 | attribute_name | 108–108 | class |
| S08b4dbca0abb_N1700 | S08b4dbca0abb_N1698 | quoted_attribute_value | 108–108 | quoted_attribute_value  |
| S08b4dbca0abb_N1701 | S08b4dbca0abb_N1700 | attribute_value | 108–108 | font-body-sm text-body-sm text-on-surface-variant |
| S08b4dbca0abb_N1702 | S08b4dbca0abb_N1695 | text | 108–108 | Spotted an inconsistency with your clock time? |
| S08b4dbca0abb_N1703 | S08b4dbca0abb_N1695 | end_tag | 108–108 | end_tag  |
| S08b4dbca0abb_N1704 | S08b4dbca0abb_N1703 | tag_name | 108–108 | span |
| S08b4dbca0abb_N1705 | S08b4dbca0abb_N1688 | element | 109–112 | element  |
| S08b4dbca0abb_N1706 | S08b4dbca0abb_N1705 | start_tag | 109–109 | start_tag  |
| S08b4dbca0abb_N1707 | S08b4dbca0abb_N1706 | tag_name | 109–109 | a |
| S08b4dbca0abb_N1708 | S08b4dbca0abb_N1706 | attribute | 109–109 | attribute  |
| S08b4dbca0abb_N1709 | S08b4dbca0abb_N1708 | attribute_name | 109–109 | class |
| S08b4dbca0abb_N1710 | S08b4dbca0abb_N1708 | quoted_attribute_value | 109–109 | quoted_attribute_value  |
| S08b4dbca0abb_N1711 | S08b4dbca0abb_N1710 | attribute_value | 109–109 | inline-flex items-center gap-space-xs font-label-caps text-label-caps text-primary hover:text-primary-fixed transition-colors group |
| S08b4dbca0abb_N1712 | S08b4dbca0abb_N1706 | attribute | 109–109 | attribute  |
| S08b4dbca0abb_N1713 | S08b4dbca0abb_N1712 | attribute_name | 109–109 | data-path |
| S08b4dbca0abb_N1714 | S08b4dbca0abb_N1712 | quoted_attribute_value | 109–109 | quoted_attribute_value  |
| S08b4dbca0abb_N1715 | S08b4dbca0abb_N1714 | attribute_value | 109–109 | birth-chart-entry |
| S08b4dbca0abb_N1716 | S08b4dbca0abb_N1706 | attribute | 109–109 | attribute  |
| S08b4dbca0abb_N1717 | S08b4dbca0abb_N1716 | attribute_name | 109–109 | href |
| S08b4dbca0abb_N1718 | S08b4dbca0abb_N1716 | quoted_attribute_value | 109–109 | quoted_attribute_value  |
| S08b4dbca0abb_N1719 | S08b4dbca0abb_N1718 | attribute_value | 109–109 | # |
| S08b4dbca0abb_N1720 | S08b4dbca0abb_N1705 | element | 110–110 | element  |
| S08b4dbca0abb_N1721 | S08b4dbca0abb_N1720 | start_tag | 110–110 | start_tag  |
| S08b4dbca0abb_N1722 | S08b4dbca0abb_N1721 | tag_name | 110–110 | span |
| S08b4dbca0abb_N1723 | S08b4dbca0abb_N1721 | attribute | 110–110 | attribute  |
| S08b4dbca0abb_N1724 | S08b4dbca0abb_N1723 | attribute_name | 110–110 | class |
| S08b4dbca0abb_N1725 | S08b4dbca0abb_N1723 | quoted_attribute_value | 110–110 | quoted_attribute_value  |
| S08b4dbca0abb_N1726 | S08b4dbca0abb_N1725 | attribute_value | 110–110 | material-symbols-outlined text-[16px] transition-transform group-hover:-translate-x-0.5 |
| S08b4dbca0abb_N1727 | S08b4dbca0abb_N1720 | text | 110–110 | edit_calendar |
| S08b4dbca0abb_N1728 | S08b4dbca0abb_N1720 | end_tag | 110–110 | end_tag  |
| S08b4dbca0abb_N1729 | S08b4dbca0abb_N1728 | tag_name | 110–110 | span |
| S08b4dbca0abb_N1730 | S08b4dbca0abb_N1705 | element | 111–111 | element  |
| S08b4dbca0abb_N1731 | S08b4dbca0abb_N1730 | start_tag | 111–111 | start_tag  |
| S08b4dbca0abb_N1732 | S08b4dbca0abb_N1731 | tag_name | 111–111 | span |
| S08b4dbca0abb_N1733 | S08b4dbca0abb_N1731 | attribute | 111–111 | attribute  |
| S08b4dbca0abb_N1734 | S08b4dbca0abb_N1733 | attribute_name | 111–111 | class |
| S08b4dbca0abb_N1735 | S08b4dbca0abb_N1733 | quoted_attribute_value | 111–111 | quoted_attribute_value  |
| S08b4dbca0abb_N1736 | S08b4dbca0abb_N1735 | attribute_value | 111–111 | underline underline-offset-4 |
| S08b4dbca0abb_N1737 | S08b4dbca0abb_N1730 | text | 111–111 | Edit birth details |
| S08b4dbca0abb_N1738 | S08b4dbca0abb_N1730 | end_tag | 111–111 | end_tag  |
| S08b4dbca0abb_N1739 | S08b4dbca0abb_N1738 | tag_name | 111–111 | span |
| S08b4dbca0abb_N1740 | S08b4dbca0abb_N1705 | end_tag | 112–112 | end_tag  |
| S08b4dbca0abb_N1741 | S08b4dbca0abb_N1740 | tag_name | 112–112 | a |
| S08b4dbca0abb_N1742 | S08b4dbca0abb_N1688 | end_tag | 113–113 | end_tag  |
| S08b4dbca0abb_N1743 | S08b4dbca0abb_N1742 | tag_name | 113–113 | div |
| S08b4dbca0abb_N1744 | S08b4dbca0abb_N1266 | end_tag | 114–114 | end_tag  |
| S08b4dbca0abb_N1745 | S08b4dbca0abb_N1744 | tag_name | 114–114 | div |
| S08b4dbca0abb_N1746 | S08b4dbca0abb_N1259 | comment | 115–115 | &lt;!-- Astrolabe Mechanical Assurance Note --&gt; |
| S08b4dbca0abb_N1747 | S08b4dbca0abb_N1259 | element | 116–121 | element  |
| S08b4dbca0abb_N1748 | S08b4dbca0abb_N1747 | start_tag | 116–116 | start_tag  |
| S08b4dbca0abb_N1749 | S08b4dbca0abb_N1748 | tag_name | 116–116 | div |
| S08b4dbca0abb_N1750 | S08b4dbca0abb_N1748 | attribute | 116–116 | attribute  |
| S08b4dbca0abb_N1751 | S08b4dbca0abb_N1750 | attribute_name | 116–116 | class |
| S08b4dbca0abb_N1752 | S08b4dbca0abb_N1750 | quoted_attribute_value | 116–116 | quoted_attribute_value  |
| S08b4dbca0abb_N1753 | S08b4dbca0abb_N1752 | attribute_value | 116–116 | bg-surface-container-low rounded-xl p-space-md flex items-center gap-space-md shadow-md |
| S08b4dbca0abb_N1754 | S08b4dbca0abb_N1747 | element | 117–117 | element  |
| S08b4dbca0abb_N1755 | S08b4dbca0abb_N1754 | start_tag | 117–117 | start_tag  |
| S08b4dbca0abb_N1756 | S08b4dbca0abb_N1755 | tag_name | 117–117 | span |
| S08b4dbca0abb_N1757 | S08b4dbca0abb_N1755 | attribute | 117–117 | attribute  |
| S08b4dbca0abb_N1758 | S08b4dbca0abb_N1757 | attribute_name | 117–117 | class |
| S08b4dbca0abb_N1759 | S08b4dbca0abb_N1757 | quoted_attribute_value | 117–117 | quoted_attribute_value  |
| S08b4dbca0abb_N1760 | S08b4dbca0abb_N1759 | attribute_value | 117–117 | material-symbols-outlined text-primary text-[28px] shrink-0 |
| S08b4dbca0abb_N1761 | S08b4dbca0abb_N1754 | text | 117–117 | hourglass_top |
| S08b4dbca0abb_N1762 | S08b4dbca0abb_N1754 | end_tag | 117–117 | end_tag  |
| S08b4dbca0abb_N1763 | S08b4dbca0abb_N1762 | tag_name | 117–117 | span |
| S08b4dbca0abb_N1764 | S08b4dbca0abb_N1747 | element | 118–120 | element  |
| S08b4dbca0abb_N1765 | S08b4dbca0abb_N1764 | start_tag | 118–118 | start_tag  |
| S08b4dbca0abb_N1766 | S08b4dbca0abb_N1765 | tag_name | 118–118 | p |
| S08b4dbca0abb_N1767 | S08b4dbca0abb_N1765 | attribute | 118–118 | attribute  |
| S08b4dbca0abb_N1768 | S08b4dbca0abb_N1767 | attribute_name | 118–118 | class |
| S08b4dbca0abb_N1769 | S08b4dbca0abb_N1767 | quoted_attribute_value | 118–118 | quoted_attribute_value  |
| S08b4dbca0abb_N1770 | S08b4dbca0abb_N1769 | attribute_value | 118–118 | font-body-sm text-body-sm text-on-surface-variant |
| S08b4dbca0abb_N1771 | S08b4dbca0abb_N1764 | text | 119–119 | Every coordinate is translated directly against the Swiss Ephemeris algorithm at time of synthesis, safeguarding absolute degree accuracy. |
| S08b4dbca0abb_N1772 | S08b4dbca0abb_N1764 | end_tag | 120–120 | end_tag  |
| S08b4dbca0abb_N1773 | S08b4dbca0abb_N1772 | tag_name | 120–120 | p |
| S08b4dbca0abb_N1774 | S08b4dbca0abb_N1747 | end_tag | 121–121 | end_tag  |
| S08b4dbca0abb_N1775 | S08b4dbca0abb_N1774 | tag_name | 121–121 | div |
| S08b4dbca0abb_N1776 | S08b4dbca0abb_N1259 | end_tag | 122–122 | end_tag  |
| S08b4dbca0abb_N1777 | S08b4dbca0abb_N1776 | tag_name | 122–122 | div |
| S08b4dbca0abb_N1778 | S08b4dbca0abb_N1251 | comment | 123–123 | &lt;!-- Right Card: Selected Reading Package &amp; Mascot Companion (5 Cols) --&gt; |
| S08b4dbca0abb_N1779 | S08b4dbca0abb_N1251 | element | 124–204 | element  |
| S08b4dbca0abb_N1780 | S08b4dbca0abb_N1779 | start_tag | 124–124 | start_tag  |
| S08b4dbca0abb_N1781 | S08b4dbca0abb_N1780 | tag_name | 124–124 | div |
| S08b4dbca0abb_N1782 | S08b4dbca0abb_N1780 | attribute | 124–124 | attribute  |
| S08b4dbca0abb_N1783 | S08b4dbca0abb_N1782 | attribute_name | 124–124 | class |
| S08b4dbca0abb_N1784 | S08b4dbca0abb_N1782 | quoted_attribute_value | 124–124 | quoted_attribute_value  |
| S08b4dbca0abb_N1785 | S08b4dbca0abb_N1784 | attribute_value | 124–124 | lg:col-span-5 flex flex-col gap-space-lg |
| S08b4dbca0abb_N1786 | S08b4dbca0abb_N1779 | comment | 125–125 | &lt;!-- Package Card --&gt; |
| S08b4dbca0abb_N1787 | S08b4dbca0abb_N1779 | element | 126–171 | element  |
| S08b4dbca0abb_N1788 | S08b4dbca0abb_N1787 | start_tag | 126–126 | start_tag  |
| S08b4dbca0abb_N1789 | S08b4dbca0abb_N1788 | tag_name | 126–126 | div |
| S08b4dbca0abb_N1790 | S08b4dbca0abb_N1788 | attribute | 126–126 | attribute  |
| S08b4dbca0abb_N1791 | S08b4dbca0abb_N1790 | attribute_name | 126–126 | class |
| S08b4dbca0abb_N1792 | S08b4dbca0abb_N1790 | quoted_attribute_value | 126–126 | quoted_attribute_value  |
| S08b4dbca0abb_N1793 | S08b4dbca0abb_N1792 | attribute_value | 126–126 | bg-surface-container rounded-xl p-space-lg shadow-xl relative overflow-hidden |
| S08b4dbca0abb_N1794 | S08b4dbca0abb_N1787 | comment | 127–127 | &lt;!-- Faint Celestial Watermark --&gt; |
| S08b4dbca0abb_N1795 | S08b4dbca0abb_N1787 | element | 128–128 | element  |
| S08b4dbca0abb_N1796 | S08b4dbca0abb_N1795 | start_tag | 128–128 | start_tag  |
| S08b4dbca0abb_N1797 | S08b4dbca0abb_N1796 | tag_name | 128–128 | div |
| S08b4dbca0abb_N1798 | S08b4dbca0abb_N1796 | attribute | 128–128 | attribute  |
| S08b4dbca0abb_N1799 | S08b4dbca0abb_N1798 | attribute_name | 128–128 | class |
| S08b4dbca0abb_N1800 | S08b4dbca0abb_N1798 | quoted_attribute_value | 128–128 | quoted_attribute_value  |
| S08b4dbca0abb_N1801 | S08b4dbca0abb_N1800 | attribute_value | 128–128 | absolute -right-6 -bottom-6 w-32 h-32 rounded-full bg-primary/5 pointer-events-none blur-xl |
| S08b4dbca0abb_N1802 | S08b4dbca0abb_N1795 | end_tag | 128–128 | end_tag  |
| S08b4dbca0abb_N1803 | S08b4dbca0abb_N1802 | tag_name | 128–128 | div |
| S08b4dbca0abb_N1804 | S08b4dbca0abb_N1787 | element | 129–135 | element  |
| S08b4dbca0abb_N1805 | S08b4dbca0abb_N1804 | start_tag | 129–129 | start_tag  |
| S08b4dbca0abb_N1806 | S08b4dbca0abb_N1805 | tag_name | 129–129 | div |
| S08b4dbca0abb_N1807 | S08b4dbca0abb_N1805 | attribute | 129–129 | attribute  |
| S08b4dbca0abb_N1808 | S08b4dbca0abb_N1807 | attribute_name | 129–129 | class |
| S08b4dbca0abb_N1809 | S08b4dbca0abb_N1807 | quoted_attribute_value | 129–129 | quoted_attribute_value  |
| S08b4dbca0abb_N1810 | S08b4dbca0abb_N1809 | attribute_value | 129–129 | flex items-center justify-between pb-space-md mb-space-md |
| S08b4dbca0abb_N1811 | S08b4dbca0abb_N1804 | element | 130–133 | element  |
| S08b4dbca0abb_N1812 | S08b4dbca0abb_N1811 | start_tag | 130–130 | start_tag  |
| S08b4dbca0abb_N1813 | S08b4dbca0abb_N1812 | tag_name | 130–130 | div |
| S08b4dbca0abb_N1814 | S08b4dbca0abb_N1812 | attribute | 130–130 | attribute  |
| S08b4dbca0abb_N1815 | S08b4dbca0abb_N1814 | attribute_name | 130–130 | class |
| S08b4dbca0abb_N1816 | S08b4dbca0abb_N1814 | quoted_attribute_value | 130–130 | quoted_attribute_value  |
| S08b4dbca0abb_N1817 | S08b4dbca0abb_N1816 | attribute_value | 130–130 | flex items-center gap-space-sm |
| S08b4dbca0abb_N1818 | S08b4dbca0abb_N1811 | element | 131–131 | element  |
| S08b4dbca0abb_N1819 | S08b4dbca0abb_N1818 | start_tag | 131–131 | start_tag  |
| S08b4dbca0abb_N1820 | S08b4dbca0abb_N1819 | tag_name | 131–131 | span |
| S08b4dbca0abb_N1821 | S08b4dbca0abb_N1819 | attribute | 131–131 | attribute  |
| S08b4dbca0abb_N1822 | S08b4dbca0abb_N1821 | attribute_name | 131–131 | class |
| S08b4dbca0abb_N1823 | S08b4dbca0abb_N1821 | quoted_attribute_value | 131–131 | quoted_attribute_value  |
| S08b4dbca0abb_N1824 | S08b4dbca0abb_N1823 | attribute_value | 131–131 | material-symbols-outlined text-primary text-[22px] |
| S08b4dbca0abb_N1825 | S08b4dbca0abb_N1818 | text | 131–131 | auto_stories |
| S08b4dbca0abb_N1826 | S08b4dbca0abb_N1818 | end_tag | 131–131 | end_tag  |
| S08b4dbca0abb_N1827 | S08b4dbca0abb_N1826 | tag_name | 131–131 | span |
| S08b4dbca0abb_N1828 | S08b4dbca0abb_N1811 | element | 132–132 | element  |
| S08b4dbca0abb_N1829 | S08b4dbca0abb_N1828 | start_tag | 132–132 | start_tag  |
| S08b4dbca0abb_N1830 | S08b4dbca0abb_N1829 | tag_name | 132–132 | span |
| S08b4dbca0abb_N1831 | S08b4dbca0abb_N1829 | attribute | 132–132 | attribute  |
| S08b4dbca0abb_N1832 | S08b4dbca0abb_N1831 | attribute_name | 132–132 | class |
| S08b4dbca0abb_N1833 | S08b4dbca0abb_N1831 | quoted_attribute_value | 132–132 | quoted_attribute_value  |
| S08b4dbca0abb_N1834 | S08b4dbca0abb_N1833 | attribute_value | 132–132 | font-headline-sm text-headline-sm text-on-surface |
| S08b4dbca0abb_N1835 | S08b4dbca0abb_N1828 | text | 132–132 | Selected Reading |
| S08b4dbca0abb_N1836 | S08b4dbca0abb_N1828 | end_tag | 132–132 | end_tag  |
| S08b4dbca0abb_N1837 | S08b4dbca0abb_N1836 | tag_name | 132–132 | span |
| S08b4dbca0abb_N1838 | S08b4dbca0abb_N1811 | end_tag | 133–133 | end_tag  |
| S08b4dbca0abb_N1839 | S08b4dbca0abb_N1838 | tag_name | 133–133 | div |
| S08b4dbca0abb_N1840 | S08b4dbca0abb_N1804 | element | 134–134 | element  |
| S08b4dbca0abb_N1841 | S08b4dbca0abb_N1840 | start_tag | 134–134 | start_tag  |
| S08b4dbca0abb_N1842 | S08b4dbca0abb_N1841 | tag_name | 134–134 | span |
| S08b4dbca0abb_N1843 | S08b4dbca0abb_N1841 | attribute | 134–134 | attribute  |
| S08b4dbca0abb_N1844 | S08b4dbca0abb_N1843 | attribute_name | 134–134 | class |
| S08b4dbca0abb_N1845 | S08b4dbca0abb_N1843 | quoted_attribute_value | 134–134 | quoted_attribute_value  |
| S08b4dbca0abb_N1846 | S08b4dbca0abb_N1845 | attribute_value | 134–134 | px-space-xs py-0.5 rounded bg-primary-container/20 text-primary font-label-caps text-label-caps uppercase |
| S08b4dbca0abb_N1847 | S08b4dbca0abb_N1840 | text | 134–134 | PREPAID CONFIRM |
| S08b4dbca0abb_N1848 | S08b4dbca0abb_N1840 | end_tag | 134–134 | end_tag  |
| S08b4dbca0abb_N1849 | S08b4dbca0abb_N1848 | tag_name | 134–134 | span |
| S08b4dbca0abb_N1850 | S08b4dbca0abb_N1804 | end_tag | 135–135 | end_tag  |
| S08b4dbca0abb_N1851 | S08b4dbca0abb_N1850 | tag_name | 135–135 | div |
| S08b4dbca0abb_N1852 | S08b4dbca0abb_N1787 | element | 136–170 | element  |
| S08b4dbca0abb_N1853 | S08b4dbca0abb_N1852 | start_tag | 136–136 | start_tag  |
| S08b4dbca0abb_N1854 | S08b4dbca0abb_N1853 | tag_name | 136–136 | div |
| S08b4dbca0abb_N1855 | S08b4dbca0abb_N1853 | attribute | 136–136 | attribute  |
| S08b4dbca0abb_N1856 | S08b4dbca0abb_N1855 | attribute_name | 136–136 | class |
| S08b4dbca0abb_N1857 | S08b4dbca0abb_N1855 | quoted_attribute_value | 136–136 | quoted_attribute_value  |
| S08b4dbca0abb_N1858 | S08b4dbca0abb_N1857 | attribute_value | 136–136 | space-y-space-md |
| S08b4dbca0abb_N1859 | S08b4dbca0abb_N1852 | comment | 137–137 | &lt;!-- Offer Title --&gt; |
| S08b4dbca0abb_N1860 | S08b4dbca0abb_N1852 | element | 138–144 | element  |
| S08b4dbca0abb_N1861 | S08b4dbca0abb_N1860 | start_tag | 138–138 | start_tag  |
| S08b4dbca0abb_N1862 | S08b4dbca0abb_N1861 | tag_name | 138–138 | div |
| S08b4dbca0abb_N1863 | S08b4dbca0abb_N1860 | element | 139–139 | element  |
| S08b4dbca0abb_N1864 | S08b4dbca0abb_N1863 | start_tag | 139–139 | start_tag  |
| S08b4dbca0abb_N1865 | S08b4dbca0abb_N1864 | tag_name | 139–139 | span |
| S08b4dbca0abb_N1866 | S08b4dbca0abb_N1864 | attribute | 139–139 | attribute  |
| S08b4dbca0abb_N1867 | S08b4dbca0abb_N1866 | attribute_name | 139–139 | class |
| S08b4dbca0abb_N1868 | S08b4dbca0abb_N1866 | quoted_attribute_value | 139–139 | quoted_attribute_value  |
| S08b4dbca0abb_N1869 | S08b4dbca0abb_N1868 | attribute_value | 139–139 | font-label-caps text-label-caps text-on-surface-variant uppercase |
| S08b4dbca0abb_N1870 | S08b4dbca0abb_N1863 | text | 139–139 | Reading Offer |
| S08b4dbca0abb_N1871 | S08b4dbca0abb_N1863 | end_tag | 139–139 | end_tag  |
| S08b4dbca0abb_N1872 | S08b4dbca0abb_N1871 | tag_name | 139–139 | span |
| S08b4dbca0abb_N1873 | S08b4dbca0abb_N1860 | element | 140–140 | element  |
| S08b4dbca0abb_N1874 | S08b4dbca0abb_N1873 | start_tag | 140–140 | start_tag  |
| S08b4dbca0abb_N1875 | S08b4dbca0abb_N1874 | tag_name | 140–140 | h3 |
| S08b4dbca0abb_N1876 | S08b4dbca0abb_N1874 | attribute | 140–140 | attribute  |
| S08b4dbca0abb_N1877 | S08b4dbca0abb_N1876 | attribute_name | 140–140 | class |
| S08b4dbca0abb_N1878 | S08b4dbca0abb_N1876 | quoted_attribute_value | 140–140 | quoted_attribute_value  |
| S08b4dbca0abb_N1879 | S08b4dbca0abb_N1878 | attribute_value | 140–140 | font-headline-md text-headline-md text-on-surface mt-0.5 |
| S08b4dbca0abb_N1880 | S08b4dbca0abb_N1873 | text | 140–140 | Natal chart — PDF + SPA |
| S08b4dbca0abb_N1881 | S08b4dbca0abb_N1873 | end_tag | 140–140 | end_tag  |
| S08b4dbca0abb_N1882 | S08b4dbca0abb_N1881 | tag_name | 140–140 | h3 |
| S08b4dbca0abb_N1883 | S08b4dbca0abb_N1860 | element | 141–143 | element  |
| S08b4dbca0abb_N1884 | S08b4dbca0abb_N1883 | start_tag | 141–141 | start_tag  |
| S08b4dbca0abb_N1885 | S08b4dbca0abb_N1884 | tag_name | 141–141 | p |
| S08b4dbca0abb_N1886 | S08b4dbca0abb_N1884 | attribute | 141–141 | attribute  |
| S08b4dbca0abb_N1887 | S08b4dbca0abb_N1886 | attribute_name | 141–141 | class |
| S08b4dbca0abb_N1888 | S08b4dbca0abb_N1886 | quoted_attribute_value | 141–141 | quoted_attribute_value  |
| S08b4dbca0abb_N1889 | S08b4dbca0abb_N1888 | attribute_value | 141–141 | font-body-sm text-body-sm text-on-surface-variant mt-1 |
| S08b4dbca0abb_N1890 | S08b4dbca0abb_N1883 | element | 142–142 | element  |
| S08b4dbca0abb_N1891 | S08b4dbca0abb_N1890 | start_tag | 142–142 | start_tag  |
| S08b4dbca0abb_N1892 | S08b4dbca0abb_N1891 | tag_name | 142–142 | span |
| S08b4dbca0abb_N1893 | S08b4dbca0abb_N1891 | attribute | 142–142 | attribute  |
| S08b4dbca0abb_N1894 | S08b4dbca0abb_N1893 | attribute_name | 142–142 | data-prototype-offer-description |
| S08b4dbca0abb_N1895 | S08b4dbca0abb_N1890 | text | 142–142 | A natal reading to download, plus an interactive chart in your browser. |
| S08b4dbca0abb_N1896 | S08b4dbca0abb_N1890 | end_tag | 142–142 | end_tag  |
| S08b4dbca0abb_N1897 | S08b4dbca0abb_N1896 | tag_name | 142–142 | span |
| S08b4dbca0abb_N1898 | S08b4dbca0abb_N1883 | end_tag | 143–143 | end_tag  |
| S08b4dbca0abb_N1899 | S08b4dbca0abb_N1898 | tag_name | 143–143 | p |
| S08b4dbca0abb_N1900 | S08b4dbca0abb_N1860 | end_tag | 144–144 | end_tag  |
| S08b4dbca0abb_N1901 | S08b4dbca0abb_N1900 | tag_name | 144–144 | div |
| S08b4dbca0abb_N1902 | S08b4dbca0abb_N1852 | comment | 145–145 | &lt;!-- Settlement Details --&gt; |
| S08b4dbca0abb_N1903 | S08b4dbca0abb_N1852 | element | 146–162 | element  |
| S08b4dbca0abb_N1904 | S08b4dbca0abb_N1903 | start_tag | 146–146 | start_tag  |
| S08b4dbca0abb_N1905 | S08b4dbca0abb_N1904 | tag_name | 146–146 | div |
| S08b4dbca0abb_N1906 | S08b4dbca0abb_N1904 | attribute | 146–146 | attribute  |
| S08b4dbca0abb_N1907 | S08b4dbca0abb_N1906 | attribute_name | 146–146 | class |
| S08b4dbca0abb_N1908 | S08b4dbca0abb_N1906 | quoted_attribute_value | 146–146 | quoted_attribute_value  |
| S08b4dbca0abb_N1909 | S08b4dbca0abb_N1908 | attribute_value | 146–146 | bg-surface-container-low rounded-lg p-space-md shadow-inner space-y-space-sm |
| S08b4dbca0abb_N1910 | S08b4dbca0abb_N1903 | element | 147–150 | element  |
| S08b4dbca0abb_N1911 | S08b4dbca0abb_N1910 | start_tag | 147–147 | start_tag  |
| S08b4dbca0abb_N1912 | S08b4dbca0abb_N1911 | tag_name | 147–147 | div |
| S08b4dbca0abb_N1913 | S08b4dbca0abb_N1911 | attribute | 147–147 | attribute  |
| S08b4dbca0abb_N1914 | S08b4dbca0abb_N1913 | attribute_name | 147–147 | class |
| S08b4dbca0abb_N1915 | S08b4dbca0abb_N1913 | quoted_attribute_value | 147–147 | quoted_attribute_value  |
| S08b4dbca0abb_N1916 | S08b4dbca0abb_N1915 | attribute_value | 147–147 | flex items-center justify-between |
| S08b4dbca0abb_N1917 | S08b4dbca0abb_N1910 | element | 148–148 | element  |
| S08b4dbca0abb_N1918 | S08b4dbca0abb_N1917 | start_tag | 148–148 | start_tag  |
| S08b4dbca0abb_N1919 | S08b4dbca0abb_N1918 | tag_name | 148–148 | span |
| S08b4dbca0abb_N1920 | S08b4dbca0abb_N1918 | attribute | 148–148 | attribute  |
| S08b4dbca0abb_N1921 | S08b4dbca0abb_N1920 | attribute_name | 148–148 | class |
| S08b4dbca0abb_N1922 | S08b4dbca0abb_N1920 | quoted_attribute_value | 148–148 | quoted_attribute_value  |
| S08b4dbca0abb_N1923 | S08b4dbca0abb_N1922 | attribute_value | 148–148 | font-astro-data-md text-astro-data-md text-on-surface-variant |
| S08b4dbca0abb_N1924 | S08b4dbca0abb_N1917 | text | 148–148 | Settlement Type |
| S08b4dbca0abb_N1925 | S08b4dbca0abb_N1917 | end_tag | 148–148 | end_tag  |
| S08b4dbca0abb_N1926 | S08b4dbca0abb_N1925 | tag_name | 148–148 | span |
| S08b4dbca0abb_N1927 | S08b4dbca0abb_N1910 | element | 149–149 | element  |
| S08b4dbca0abb_N1928 | S08b4dbca0abb_N1927 | start_tag | 149–149 | start_tag  |
| S08b4dbca0abb_N1929 | S08b4dbca0abb_N1928 | tag_name | 149–149 | span |
| S08b4dbca0abb_N1930 | S08b4dbca0abb_N1928 | attribute | 149–149 | attribute  |
| S08b4dbca0abb_N1931 | S08b4dbca0abb_N1930 | attribute_name | 149–149 | class |
| S08b4dbca0abb_N1932 | S08b4dbca0abb_N1930 | quoted_attribute_value | 149–149 | quoted_attribute_value  |
| S08b4dbca0abb_N1933 | S08b4dbca0abb_N1932 | attribute_value | 149–149 | font-astro-data-md text-astro-data-md text-on-surface font-semibold |
| S08b4dbca0abb_N1934 | S08b4dbca0abb_N1927 | text | 149–149 | One-time prepaid |
| S08b4dbca0abb_N1935 | S08b4dbca0abb_N1927 | end_tag | 149–149 | end_tag  |
| S08b4dbca0abb_N1936 | S08b4dbca0abb_N1935 | tag_name | 149–149 | span |
| S08b4dbca0abb_N1937 | S08b4dbca0abb_N1910 | end_tag | 150–150 | end_tag  |
| S08b4dbca0abb_N1938 | S08b4dbca0abb_N1937 | tag_name | 150–150 | div |
| S08b4dbca0abb_N1939 | S08b4dbca0abb_N1903 | element | 151–154 | element  |
| S08b4dbca0abb_N1940 | S08b4dbca0abb_N1939 | start_tag | 151–151 | start_tag  |
| S08b4dbca0abb_N1941 | S08b4dbca0abb_N1940 | tag_name | 151–151 | div |
| S08b4dbca0abb_N1942 | S08b4dbca0abb_N1940 | attribute | 151–151 | attribute  |
| S08b4dbca0abb_N1943 | S08b4dbca0abb_N1942 | attribute_name | 151–151 | class |
| S08b4dbca0abb_N1944 | S08b4dbca0abb_N1942 | quoted_attribute_value | 151–151 | quoted_attribute_value  |
| S08b4dbca0abb_N1945 | S08b4dbca0abb_N1944 | attribute_value | 151–151 | flex items-center justify-between |
| S08b4dbca0abb_N1946 | S08b4dbca0abb_N1939 | element | 152–152 | element  |
| S08b4dbca0abb_N1947 | S08b4dbca0abb_N1946 | start_tag | 152–152 | start_tag  |
| S08b4dbca0abb_N1948 | S08b4dbca0abb_N1947 | tag_name | 152–152 | span |
| S08b4dbca0abb_N1949 | S08b4dbca0abb_N1947 | attribute | 152–152 | attribute  |
| S08b4dbca0abb_N1950 | S08b4dbca0abb_N1949 | attribute_name | 152–152 | class |
| S08b4dbca0abb_N1951 | S08b4dbca0abb_N1949 | quoted_attribute_value | 152–152 | quoted_attribute_value  |
| S08b4dbca0abb_N1952 | S08b4dbca0abb_N1951 | attribute_value | 152–152 | font-astro-data-md text-astro-data-md text-on-surface-variant |
| S08b4dbca0abb_N1953 | S08b4dbca0abb_N1946 | text | 152–152 | Cost Baseline |
| S08b4dbca0abb_N1954 | S08b4dbca0abb_N1946 | end_tag | 152–152 | end_tag  |
| S08b4dbca0abb_N1955 | S08b4dbca0abb_N1954 | tag_name | 152–152 | span |
| S08b4dbca0abb_N1956 | S08b4dbca0abb_N1939 | element | 153–153 | element  |
| S08b4dbca0abb_N1957 | S08b4dbca0abb_N1956 | start_tag | 153–153 | start_tag  |
| S08b4dbca0abb_N1958 | S08b4dbca0abb_N1957 | tag_name | 153–153 | span |
| S08b4dbca0abb_N1959 | S08b4dbca0abb_N1957 | attribute | 153–153 | attribute  |
| S08b4dbca0abb_N1960 | S08b4dbca0abb_N1959 | attribute_name | 153–153 | class |
| S08b4dbca0abb_N1961 | S08b4dbca0abb_N1959 | quoted_attribute_value | 153–153 | quoted_attribute_value  |
| S08b4dbca0abb_N1962 | S08b4dbca0abb_N1961 | attribute_value | 153–153 | font-astro-data-md text-astro-data-md text-primary font-semibold |
| S08b4dbca0abb_N1963 | S08b4dbca0abb_N1956 | text | 153–153 | Price shown in your quote |
| S08b4dbca0abb_N1964 | S08b4dbca0abb_N1956 | end_tag | 153–153 | end_tag  |
| S08b4dbca0abb_N1965 | S08b4dbca0abb_N1964 | tag_name | 153–153 | span |
| S08b4dbca0abb_N1966 | S08b4dbca0abb_N1939 | end_tag | 154–154 | end_tag  |
| S08b4dbca0abb_N1967 | S08b4dbca0abb_N1966 | tag_name | 154–154 | div |
| S08b4dbca0abb_N1968 | S08b4dbca0abb_N1903 | element | 155–161 | element  |
| S08b4dbca0abb_N1969 | S08b4dbca0abb_N1968 | start_tag | 155–155 | start_tag  |
| S08b4dbca0abb_N1970 | S08b4dbca0abb_N1969 | tag_name | 155–155 | div |
| S08b4dbca0abb_N1971 | S08b4dbca0abb_N1969 | attribute | 155–155 | attribute  |
| S08b4dbca0abb_N1972 | S08b4dbca0abb_N1971 | attribute_name | 155–155 | class |
| S08b4dbca0abb_N1973 | S08b4dbca0abb_N1971 | quoted_attribute_value | 155–155 | quoted_attribute_value  |
| S08b4dbca0abb_N1974 | S08b4dbca0abb_N1973 | attribute_value | 155–155 | flex items-center justify-between pt-1 |
| S08b4dbca0abb_N1975 | S08b4dbca0abb_N1968 | element | 156–156 | element  |
| S08b4dbca0abb_N1976 | S08b4dbca0abb_N1975 | start_tag | 156–156 | start_tag  |
| S08b4dbca0abb_N1977 | S08b4dbca0abb_N1976 | tag_name | 156–156 | span |
| S08b4dbca0abb_N1978 | S08b4dbca0abb_N1976 | attribute | 156–156 | attribute  |
| S08b4dbca0abb_N1979 | S08b4dbca0abb_N1978 | attribute_name | 156–156 | class |
| S08b4dbca0abb_N1980 | S08b4dbca0abb_N1978 | quoted_attribute_value | 156–156 | quoted_attribute_value  |
| S08b4dbca0abb_N1981 | S08b4dbca0abb_N1980 | attribute_value | 156–156 | font-astro-data-md text-astro-data-md text-on-surface-variant |
| S08b4dbca0abb_N1982 | S08b4dbca0abb_N1975 | text | 156–156 | Chosen Channel |
| S08b4dbca0abb_N1983 | S08b4dbca0abb_N1975 | end_tag | 156–156 | end_tag  |
| S08b4dbca0abb_N1984 | S08b4dbca0abb_N1983 | tag_name | 156–156 | span |
| S08b4dbca0abb_N1985 | S08b4dbca0abb_N1968 | element | 157–160 | element  |
| S08b4dbca0abb_N1986 | S08b4dbca0abb_N1985 | start_tag | 157–157 | start_tag  |
| S08b4dbca0abb_N1987 | S08b4dbca0abb_N1986 | tag_name | 157–157 | span |
| S08b4dbca0abb_N1988 | S08b4dbca0abb_N1986 | attribute | 157–157 | attribute  |
| S08b4dbca0abb_N1989 | S08b4dbca0abb_N1988 | attribute_name | 157–157 | data-prototype-channel |
| S08b4dbca0abb_N1990 | S08b4dbca0abb_N1986 | attribute | 157–157 | attribute  |
| S08b4dbca0abb_N1991 | S08b4dbca0abb_N1990 | attribute_name | 157–157 | class |
| S08b4dbca0abb_N1992 | S08b4dbca0abb_N1990 | quoted_attribute_value | 157–157 | quoted_attribute_value  |
| S08b4dbca0abb_N1993 | S08b4dbca0abb_N1992 | attribute_value | 157–157 | inline-flex items-center gap-1 font-astro-data-md text-astro-data-md text-secondary |
| S08b4dbca0abb_N1994 | S08b4dbca0abb_N1985 | element | 158–158 | element  |
| S08b4dbca0abb_N1995 | S08b4dbca0abb_N1994 | start_tag | 158–158 | start_tag  |
| S08b4dbca0abb_N1996 | S08b4dbca0abb_N1995 | tag_name | 158–158 | span |
| S08b4dbca0abb_N1997 | S08b4dbca0abb_N1995 | attribute | 158–158 | attribute  |
| S08b4dbca0abb_N1998 | S08b4dbca0abb_N1997 | attribute_name | 158–158 | class |
| S08b4dbca0abb_N1999 | S08b4dbca0abb_N1997 | quoted_attribute_value | 158–158 | quoted_attribute_value  |
| S08b4dbca0abb_N2000 | S08b4dbca0abb_N1999 | attribute_value | 158–158 | material-symbols-outlined text-[14px] |
| S08b4dbca0abb_N2001 | S08b4dbca0abb_N1994 | text | 158–158 | bolt |
| S08b4dbca0abb_N2002 | S08b4dbca0abb_N1994 | end_tag | 158–158 | end_tag  |
| S08b4dbca0abb_N2003 | S08b4dbca0abb_N2002 | tag_name | 158–158 | span |
| S08b4dbca0abb_N2004 | S08b4dbca0abb_N1985 | text | 159–159 | Direct / Lightning (Alby) |
| S08b4dbca0abb_N2005 | S08b4dbca0abb_N1985 | end_tag | 160–160 | end_tag  |
| S08b4dbca0abb_N2006 | S08b4dbca0abb_N2005 | tag_name | 160–160 | span |
| S08b4dbca0abb_N2007 | S08b4dbca0abb_N1968 | end_tag | 161–161 | end_tag  |
| S08b4dbca0abb_N2008 | S08b4dbca0abb_N2007 | tag_name | 161–161 | div |
| S08b4dbca0abb_N2009 | S08b4dbca0abb_N1903 | end_tag | 162–162 | end_tag  |
| S08b4dbca0abb_N2010 | S08b4dbca0abb_N2009 | tag_name | 162–162 | div |
| S08b4dbca0abb_N2011 | S08b4dbca0abb_N1852 | comment | 163–163 | &lt;!-- Change Package Action --&gt; |
| S08b4dbca0abb_N2012 | S08b4dbca0abb_N1852 | element | 164–169 | element  |
| S08b4dbca0abb_N2013 | S08b4dbca0abb_N2012 | start_tag | 164–164 | start_tag  |
| S08b4dbca0abb_N2014 | S08b4dbca0abb_N2013 | tag_name | 164–164 | div |
| S08b4dbca0abb_N2015 | S08b4dbca0abb_N2013 | attribute | 164–164 | attribute  |
| S08b4dbca0abb_N2016 | S08b4dbca0abb_N2015 | attribute_name | 164–164 | class |
| S08b4dbca0abb_N2017 | S08b4dbca0abb_N2015 | quoted_attribute_value | 164–164 | quoted_attribute_value  |
| S08b4dbca0abb_N2018 | S08b4dbca0abb_N2017 | attribute_value | 164–164 | flex justify-end pt-space-xs |
| S08b4dbca0abb_N2019 | S08b4dbca0abb_N2012 | element | 165–168 | element  |
| S08b4dbca0abb_N2020 | S08b4dbca0abb_N2019 | start_tag | 165–165 | start_tag  |
| S08b4dbca0abb_N2021 | S08b4dbca0abb_N2020 | tag_name | 165–165 | a |
| S08b4dbca0abb_N2022 | S08b4dbca0abb_N2020 | attribute | 165–165 | attribute  |
| S08b4dbca0abb_N2023 | S08b4dbca0abb_N2022 | attribute_name | 165–165 | class |
| S08b4dbca0abb_N2024 | S08b4dbca0abb_N2022 | quoted_attribute_value | 165–165 | quoted_attribute_value  |
| S08b4dbca0abb_N2025 | S08b4dbca0abb_N2024 | attribute_value | 165–165 | inline-flex items-center gap-space-xs font-label-caps text-label-caps text-primary hover:text-primary-fixed transition-colors group |
| S08b4dbca0abb_N2026 | S08b4dbca0abb_N2020 | attribute | 165–165 | attribute  |
| S08b4dbca0abb_N2027 | S08b4dbca0abb_N2026 | attribute_name | 165–165 | data-path |
| S08b4dbca0abb_N2028 | S08b4dbca0abb_N2026 | quoted_attribute_value | 165–165 | quoted_attribute_value  |
| S08b4dbca0abb_N2029 | S08b4dbca0abb_N2028 | attribute_value | 165–165 | birth-chart-entry |
| S08b4dbca0abb_N2030 | S08b4dbca0abb_N2020 | attribute | 165–165 | attribute  |
| S08b4dbca0abb_N2031 | S08b4dbca0abb_N2030 | attribute_name | 165–165 | href |
| S08b4dbca0abb_N2032 | S08b4dbca0abb_N2030 | quoted_attribute_value | 165–165 | quoted_attribute_value  |
| S08b4dbca0abb_N2033 | S08b4dbca0abb_N2032 | attribute_value | 165–165 | # |
| S08b4dbca0abb_N2034 | S08b4dbca0abb_N2019 | element | 166–166 | element  |
| S08b4dbca0abb_N2035 | S08b4dbca0abb_N2034 | start_tag | 166–166 | start_tag  |
| S08b4dbca0abb_N2036 | S08b4dbca0abb_N2035 | tag_name | 166–166 | span |
| S08b4dbca0abb_N2037 | S08b4dbca0abb_N2035 | attribute | 166–166 | attribute  |
| S08b4dbca0abb_N2038 | S08b4dbca0abb_N2037 | attribute_name | 166–166 | class |
| S08b4dbca0abb_N2039 | S08b4dbca0abb_N2037 | quoted_attribute_value | 166–166 | quoted_attribute_value  |
| S08b4dbca0abb_N2040 | S08b4dbca0abb_N2039 | attribute_value | 166–166 | material-symbols-outlined text-[16px] transition-transform group-hover:rotate-45 |
| S08b4dbca0abb_N2041 | S08b4dbca0abb_N2034 | text | 166–166 | tune |
| S08b4dbca0abb_N2042 | S08b4dbca0abb_N2034 | end_tag | 166–166 | end_tag  |
| S08b4dbca0abb_N2043 | S08b4dbca0abb_N2042 | tag_name | 166–166 | span |
| S08b4dbca0abb_N2044 | S08b4dbca0abb_N2019 | element | 167–167 | element  |
| S08b4dbca0abb_N2045 | S08b4dbca0abb_N2044 | start_tag | 167–167 | start_tag  |
| S08b4dbca0abb_N2046 | S08b4dbca0abb_N2045 | tag_name | 167–167 | span |
| S08b4dbca0abb_N2047 | S08b4dbca0abb_N2045 | attribute | 167–167 | attribute  |
| S08b4dbca0abb_N2048 | S08b4dbca0abb_N2047 | attribute_name | 167–167 | class |
| S08b4dbca0abb_N2049 | S08b4dbca0abb_N2047 | quoted_attribute_value | 167–167 | quoted_attribute_value  |
| S08b4dbca0abb_N2050 | S08b4dbca0abb_N2049 | attribute_value | 167–167 | underline underline-offset-4 |
| S08b4dbca0abb_N2051 | S08b4dbca0abb_N2044 | text | 167–167 | Change package |
| S08b4dbca0abb_N2052 | S08b4dbca0abb_N2044 | end_tag | 167–167 | end_tag  |
| S08b4dbca0abb_N2053 | S08b4dbca0abb_N2052 | tag_name | 167–167 | span |
| S08b4dbca0abb_N2054 | S08b4dbca0abb_N2019 | end_tag | 168–168 | end_tag  |
| S08b4dbca0abb_N2055 | S08b4dbca0abb_N2054 | tag_name | 168–168 | a |
| S08b4dbca0abb_N2056 | S08b4dbca0abb_N2012 | end_tag | 169–169 | end_tag  |
| S08b4dbca0abb_N2057 | S08b4dbca0abb_N2056 | tag_name | 169–169 | div |
| S08b4dbca0abb_N2058 | S08b4dbca0abb_N1852 | end_tag | 170–170 | end_tag  |
| S08b4dbca0abb_N2059 | S08b4dbca0abb_N2058 | tag_name | 170–170 | div |
| S08b4dbca0abb_N2060 | S08b4dbca0abb_N1787 | end_tag | 171–171 | end_tag  |
| S08b4dbca0abb_N2061 | S08b4dbca0abb_N2060 | tag_name | 171–171 | div |
| S08b4dbca0abb_N2062 | S08b4dbca0abb_N1779 | comment | 172–172 | &lt;!-- Mascot Touch: Natally Companion Card --&gt; |
| S08b4dbca0abb_N2063 | S08b4dbca0abb_N1779 | element | 173–191 | element  |
| S08b4dbca0abb_N2064 | S08b4dbca0abb_N2063 | start_tag | 173–173 | start_tag  |
| S08b4dbca0abb_N2065 | S08b4dbca0abb_N2064 | tag_name | 173–173 | div |
| S08b4dbca0abb_N2066 | S08b4dbca0abb_N2064 | attribute | 173–173 | attribute  |
| S08b4dbca0abb_N2067 | S08b4dbca0abb_N2066 | attribute_name | 173–173 | class |
| S08b4dbca0abb_N2068 | S08b4dbca0abb_N2066 | quoted_attribute_value | 173–173 | quoted_attribute_value  |
| S08b4dbca0abb_N2069 | S08b4dbca0abb_N2068 | attribute_value | 173–173 | bg-surface-container-high rounded-xl p-space-md shadow-xl flex items-center gap-space-md relative overflow-hidden |
| S08b4dbca0abb_N2070 | S08b4dbca0abb_N2063 | element | 174–181 | element  |
| S08b4dbca0abb_N2071 | S08b4dbca0abb_N2070 | start_tag | 174–174 | start_tag  |
| S08b4dbca0abb_N2072 | S08b4dbca0abb_N2071 | tag_name | 174–174 | div |
| S08b4dbca0abb_N2073 | S08b4dbca0abb_N2071 | attribute | 174–174 | attribute  |
| S08b4dbca0abb_N2074 | S08b4dbca0abb_N2073 | attribute_name | 174–174 | class |
| S08b4dbca0abb_N2075 | S08b4dbca0abb_N2073 | quoted_attribute_value | 174–174 | quoted_attribute_value  |
| S08b4dbca0abb_N2076 | S08b4dbca0abb_N2075 | attribute_value | 174–174 | relative shrink-0 |
| S08b4dbca0abb_N2077 | S08b4dbca0abb_N2070 | element | 175–177 | element  |
| S08b4dbca0abb_N2078 | S08b4dbca0abb_N2077 | start_tag | 175–175 | start_tag  |
| S08b4dbca0abb_N2079 | S08b4dbca0abb_N2078 | tag_name | 175–175 | div |
| S08b4dbca0abb_N2080 | S08b4dbca0abb_N2078 | attribute | 175–175 | attribute  |
| S08b4dbca0abb_N2081 | S08b4dbca0abb_N2080 | attribute_name | 175–175 | class |
| S08b4dbca0abb_N2082 | S08b4dbca0abb_N2080 | quoted_attribute_value | 175–175 | quoted_attribute_value  |
| S08b4dbca0abb_N2083 | S08b4dbca0abb_N2082 | attribute_value | 175–175 | w-20 h-20 rounded-full overflow-hidden bg-surface-container-lowest p-1 shadow-inner flex items-center justify-center |
| S08b4dbca0abb_N2084 | S08b4dbca0abb_N2077 | element | 176–176 | element  |
| S08b4dbca0abb_N2085 | S08b4dbca0abb_N2084 | self_closing_tag | 176–176 | self_closing_tag  |
| S08b4dbca0abb_N2086 | S08b4dbca0abb_N2085 | tag_name | 176–176 | img |
| S08b4dbca0abb_N2087 | S08b4dbca0abb_N2085 | attribute | 176–176 | attribute  |
| S08b4dbca0abb_N2088 | S08b4dbca0abb_N2087 | attribute_name | 176–176 | alt |
| S08b4dbca0abb_N2089 | S08b4dbca0abb_N2087 | quoted_attribute_value | 176–176 | quoted_attribute_value  |
| S08b4dbca0abb_N2090 | S08b4dbca0abb_N2089 | attribute_value | 176–176 | Natally the mechanical astrolabe companion |
| S08b4dbca0abb_N2091 | S08b4dbca0abb_N2085 | attribute | 176–176 | attribute  |
| S08b4dbca0abb_N2092 | S08b4dbca0abb_N2091 | attribute_name | 176–176 | class |
| S08b4dbca0abb_N2093 | S08b4dbca0abb_N2091 | quoted_attribute_value | 176–176 | quoted_attribute_value  |
| S08b4dbca0abb_N2094 | S08b4dbca0abb_N2093 | attribute_value | 176–176 | w-full h-full object-cover rounded-full |
| S08b4dbca0abb_N2095 | S08b4dbca0abb_N2085 | attribute | 176–176 | attribute  |
| S08b4dbca0abb_N2096 | S08b4dbca0abb_N2095 | attribute_name | 176–176 | src |
| S08b4dbca0abb_N2097 | S08b4dbca0abb_N2095 | quoted_attribute_value | 176–176 | quoted_attribute_value  |
| S08b4dbca0abb_N2098 | S08b4dbca0abb_N2097 | attribute_value | 176–176 | ../../assets/natally-mascot.webp |
| S08b4dbca0abb_N2099 | S08b4dbca0abb_N2077 | end_tag | 177–177 | end_tag  |
| S08b4dbca0abb_N2100 | S08b4dbca0abb_N2099 | tag_name | 177–177 | div |
| S08b4dbca0abb_N2101 | S08b4dbca0abb_N2070 | element | 178–180 | element  |
| S08b4dbca0abb_N2102 | S08b4dbca0abb_N2101 | start_tag | 178–178 | start_tag  |
| S08b4dbca0abb_N2103 | S08b4dbca0abb_N2102 | tag_name | 178–178 | span |
| S08b4dbca0abb_N2104 | S08b4dbca0abb_N2102 | attribute | 178–178 | attribute  |
| S08b4dbca0abb_N2105 | S08b4dbca0abb_N2104 | attribute_name | 178–178 | class |
| S08b4dbca0abb_N2106 | S08b4dbca0abb_N2104 | quoted_attribute_value | 178–178 | quoted_attribute_value  |
| S08b4dbca0abb_N2107 | S08b4dbca0abb_N2106 | attribute_value | 178–178 | absolute bottom-0 right-0 w-4 h-4 rounded-full bg-primary flex items-center justify-center text-[10px] text-on-primary font-bold shadow-sm |
| S08b4dbca0abb_N2108 | S08b4dbca0abb_N2101 | text | 179–179 | ✦ |
| S08b4dbca0abb_N2109 | S08b4dbca0abb_N2101 | end_tag | 180–180 | end_tag  |
| S08b4dbca0abb_N2110 | S08b4dbca0abb_N2109 | tag_name | 180–180 | span |
| S08b4dbca0abb_N2111 | S08b4dbca0abb_N2070 | end_tag | 181–181 | end_tag  |
| S08b4dbca0abb_N2112 | S08b4dbca0abb_N2111 | tag_name | 181–181 | div |
| S08b4dbca0abb_N2113 | S08b4dbca0abb_N2063 | element | 182–190 | element  |
| S08b4dbca0abb_N2114 | S08b4dbca0abb_N2113 | start_tag | 182–182 | start_tag  |
| S08b4dbca0abb_N2115 | S08b4dbca0abb_N2114 | tag_name | 182–182 | div |
| S08b4dbca0abb_N2116 | S08b4dbca0abb_N2114 | attribute | 182–182 | attribute  |
| S08b4dbca0abb_N2117 | S08b4dbca0abb_N2116 | attribute_name | 182–182 | class |
| S08b4dbca0abb_N2118 | S08b4dbca0abb_N2116 | quoted_attribute_value | 182–182 | quoted_attribute_value  |
| S08b4dbca0abb_N2119 | S08b4dbca0abb_N2118 | attribute_value | 182–182 | flex flex-col gap-1 min-w-0 |
| S08b4dbca0abb_N2120 | S08b4dbca0abb_N2113 | element | 183–186 | element  |
| S08b4dbca0abb_N2121 | S08b4dbca0abb_N2120 | start_tag | 183–183 | start_tag  |
| S08b4dbca0abb_N2122 | S08b4dbca0abb_N2121 | tag_name | 183–183 | div |
| S08b4dbca0abb_N2123 | S08b4dbca0abb_N2121 | attribute | 183–183 | attribute  |
| S08b4dbca0abb_N2124 | S08b4dbca0abb_N2123 | attribute_name | 183–183 | class |
| S08b4dbca0abb_N2125 | S08b4dbca0abb_N2123 | quoted_attribute_value | 183–183 | quoted_attribute_value  |
| S08b4dbca0abb_N2126 | S08b4dbca0abb_N2125 | attribute_value | 183–183 | flex items-center gap-space-xs |
| S08b4dbca0abb_N2127 | S08b4dbca0abb_N2120 | element | 184–184 | element  |
| S08b4dbca0abb_N2128 | S08b4dbca0abb_N2127 | start_tag | 184–184 | start_tag  |
| S08b4dbca0abb_N2129 | S08b4dbca0abb_N2128 | tag_name | 184–184 | span |
| S08b4dbca0abb_N2130 | S08b4dbca0abb_N2128 | attribute | 184–184 | attribute  |
| S08b4dbca0abb_N2131 | S08b4dbca0abb_N2130 | attribute_name | 184–184 | class |
| S08b4dbca0abb_N2132 | S08b4dbca0abb_N2130 | quoted_attribute_value | 184–184 | quoted_attribute_value  |
| S08b4dbca0abb_N2133 | S08b4dbca0abb_N2132 | attribute_value | 184–184 | font-label-caps text-label-caps text-primary uppercase tracking-widest |
| S08b4dbca0abb_N2134 | S08b4dbca0abb_N2127 | text | 184–184 | Natally Observatory |
| S08b4dbca0abb_N2135 | S08b4dbca0abb_N2127 | end_tag | 184–184 | end_tag  |
| S08b4dbca0abb_N2136 | S08b4dbca0abb_N2135 | tag_name | 184–184 | span |
| S08b4dbca0abb_N2137 | S08b4dbca0abb_N2120 | element | 185–185 | element  |
| S08b4dbca0abb_N2138 | S08b4dbca0abb_N2137 | start_tag | 185–185 | start_tag  |
| S08b4dbca0abb_N2139 | S08b4dbca0abb_N2138 | tag_name | 185–185 | span |
| S08b4dbca0abb_N2140 | S08b4dbca0abb_N2138 | attribute | 185–185 | attribute  |
| S08b4dbca0abb_N2141 | S08b4dbca0abb_N2140 | attribute_name | 185–185 | class |
| S08b4dbca0abb_N2142 | S08b4dbca0abb_N2140 | quoted_attribute_value | 185–185 | quoted_attribute_value  |
| S08b4dbca0abb_N2143 | S08b4dbca0abb_N2142 | attribute_value | 185–185 | text-on-surface-variant opacity-40 font-astro-data-md text-astro-data-md |
| S08b4dbca0abb_N2144 | S08b4dbca0abb_N2137 | text | 185–185 | · Companion |
| S08b4dbca0abb_N2145 | S08b4dbca0abb_N2137 | end_tag | 185–185 | end_tag  |
| S08b4dbca0abb_N2146 | S08b4dbca0abb_N2145 | tag_name | 185–185 | span |
| S08b4dbca0abb_N2147 | S08b4dbca0abb_N2120 | end_tag | 186–186 | end_tag  |
| S08b4dbca0abb_N2148 | S08b4dbca0abb_N2147 | tag_name | 186–186 | div |
| S08b4dbca0abb_N2149 | S08b4dbca0abb_N2113 | element | 187–189 | element  |
| S08b4dbca0abb_N2150 | S08b4dbca0abb_N2149 | start_tag | 187–187 | start_tag  |
| S08b4dbca0abb_N2151 | S08b4dbca0abb_N2150 | tag_name | 187–187 | p |
| S08b4dbca0abb_N2152 | S08b4dbca0abb_N2150 | attribute | 187–187 | attribute  |
| S08b4dbca0abb_N2153 | S08b4dbca0abb_N2152 | attribute_name | 187–187 | class |
| S08b4dbca0abb_N2154 | S08b4dbca0abb_N2152 | quoted_attribute_value | 187–187 | quoted_attribute_value  |
| S08b4dbca0abb_N2155 | S08b4dbca0abb_N2154 | attribute_value | 187–187 | font-oracle-voice text-oracle-voice text-on-surface italic leading-snug |
| S08b4dbca0abb_N2156 | S08b4dbca0abb_N2149 | text | 188–188 | “Your natal chart is crafted with patience and precision. Once confirmed, your unique quote will be calculated.” |
| S08b4dbca0abb_N2157 | S08b4dbca0abb_N2149 | end_tag | 189–189 | end_tag  |
| S08b4dbca0abb_N2158 | S08b4dbca0abb_N2157 | tag_name | 189–189 | p |
| S08b4dbca0abb_N2159 | S08b4dbca0abb_N2113 | end_tag | 190–190 | end_tag  |
| S08b4dbca0abb_N2160 | S08b4dbca0abb_N2159 | tag_name | 190–190 | div |
| S08b4dbca0abb_N2161 | S08b4dbca0abb_N2063 | end_tag | 191–191 | end_tag  |
| S08b4dbca0abb_N2162 | S08b4dbca0abb_N2161 | tag_name | 191–191 | div |
| S08b4dbca0abb_N2163 | S08b4dbca0abb_N1779 | comment | 192–192 | &lt;!-- Primary Actions Console --&gt; |
| S08b4dbca0abb_N2164 | S08b4dbca0abb_N1779 | element | 193–203 | element  |
| S08b4dbca0abb_N2165 | S08b4dbca0abb_N2164 | start_tag | 193–193 | start_tag  |
| S08b4dbca0abb_N2166 | S08b4dbca0abb_N2165 | tag_name | 193–193 | div |
| S08b4dbca0abb_N2167 | S08b4dbca0abb_N2165 | attribute | 193–193 | attribute  |
| S08b4dbca0abb_N2168 | S08b4dbca0abb_N2167 | attribute_name | 193–193 | class |
| S08b4dbca0abb_N2169 | S08b4dbca0abb_N2167 | quoted_attribute_value | 193–193 | quoted_attribute_value  |
| S08b4dbca0abb_N2170 | S08b4dbca0abb_N2169 | attribute_value | 193–193 | bg-surface-container rounded-xl p-space-md shadow-xl flex flex-col gap-space-sm |
| S08b4dbca0abb_N2171 | S08b4dbca0abb_N2164 | comment | 194–194 | &lt;!-- Primary Action: Gold Button --&gt; |
| S08b4dbca0abb_N2172 | S08b4dbca0abb_N2164 | element | 195–198 | element  |
| S08b4dbca0abb_N2173 | S08b4dbca0abb_N2172 | start_tag | 195–195 | start_tag  |
| S08b4dbca0abb_N2174 | S08b4dbca0abb_N2173 | tag_name | 195–195 | button |
| S08b4dbca0abb_N2175 | S08b4dbca0abb_N2173 | attribute | 195–195 | attribute  |
| S08b4dbca0abb_N2176 | S08b4dbca0abb_N2175 | attribute_name | 195–195 | class |
| S08b4dbca0abb_N2177 | S08b4dbca0abb_N2175 | quoted_attribute_value | 195–195 | quoted_attribute_value  |
| S08b4dbca0abb_N2178 | S08b4dbca0abb_N2177 | attribute_value | 195–195 | w-full py-space-sm px-space-lg rounded-xl bg-primary text-on-primary font-body-lg text-body-lg font-bold flex items-center justify-center gap-space-sm shadow-[0_0_20px_rgba(242,202,80,0.25)] hover:shadow-[0_0_28px_rgba(242,202,80,0.4)] hover:bg-primary-fixed transition-all cursor-pointer |
| S08b4dbca0abb_N2179 | S08b4dbca0abb_N2173 | attribute | 195–195 | attribute  |
| S08b4dbca0abb_N2180 | S08b4dbca0abb_N2179 | attribute_name | 195–195 | type |
| S08b4dbca0abb_N2181 | S08b4dbca0abb_N2179 | quoted_attribute_value | 195–195 | quoted_attribute_value  |
| S08b4dbca0abb_N2182 | S08b4dbca0abb_N2181 | attribute_value | 195–195 | button |
| S08b4dbca0abb_N2183 | S08b4dbca0abb_N2172 | element | 196–196 | element  |
| S08b4dbca0abb_N2184 | S08b4dbca0abb_N2183 | start_tag | 196–196 | start_tag  |
| S08b4dbca0abb_N2185 | S08b4dbca0abb_N2184 | tag_name | 196–196 | span |
| S08b4dbca0abb_N2186 | S08b4dbca0abb_N2183 | text | 196–196 | Continue to quote summary |
| S08b4dbca0abb_N2187 | S08b4dbca0abb_N2183 | end_tag | 196–196 | end_tag  |
| S08b4dbca0abb_N2188 | S08b4dbca0abb_N2187 | tag_name | 196–196 | span |
| S08b4dbca0abb_N2189 | S08b4dbca0abb_N2172 | element | 197–197 | element  |
| S08b4dbca0abb_N2190 | S08b4dbca0abb_N2189 | start_tag | 197–197 | start_tag  |
| S08b4dbca0abb_N2191 | S08b4dbca0abb_N2190 | tag_name | 197–197 | span |
| S08b4dbca0abb_N2192 | S08b4dbca0abb_N2190 | attribute | 197–197 | attribute  |
| S08b4dbca0abb_N2193 | S08b4dbca0abb_N2192 | attribute_name | 197–197 | class |
| S08b4dbca0abb_N2194 | S08b4dbca0abb_N2192 | quoted_attribute_value | 197–197 | quoted_attribute_value  |
| S08b4dbca0abb_N2195 | S08b4dbca0abb_N2194 | attribute_value | 197–197 | material-symbols-outlined text-[20px] |
| S08b4dbca0abb_N2196 | S08b4dbca0abb_N2189 | text | 197–197 | arrow_forward |
| S08b4dbca0abb_N2197 | S08b4dbca0abb_N2189 | end_tag | 197–197 | end_tag  |
| S08b4dbca0abb_N2198 | S08b4dbca0abb_N2197 | tag_name | 197–197 | span |
| S08b4dbca0abb_N2199 | S08b4dbca0abb_N2172 | end_tag | 198–198 | end_tag  |
| S08b4dbca0abb_N2200 | S08b4dbca0abb_N2199 | tag_name | 198–198 | button |
| S08b4dbca0abb_N2201 | S08b4dbca0abb_N2164 | comment | 199–199 | &lt;!-- Secondary Action: Back to offers --&gt; |
| S08b4dbca0abb_N2202 | S08b4dbca0abb_N2164 | element | 200–202 | element  |
| S08b4dbca0abb_N2203 | S08b4dbca0abb_N2202 | start_tag | 200–200 | start_tag  |
| S08b4dbca0abb_N2204 | S08b4dbca0abb_N2203 | tag_name | 200–200 | a |
| S08b4dbca0abb_N2205 | S08b4dbca0abb_N2203 | attribute | 200–200 | attribute  |
| S08b4dbca0abb_N2206 | S08b4dbca0abb_N2205 | attribute_name | 200–200 | class |
| S08b4dbca0abb_N2207 | S08b4dbca0abb_N2205 | quoted_attribute_value | 200–200 | quoted_attribute_value  |
| S08b4dbca0abb_N2208 | S08b4dbca0abb_N2207 | attribute_value | 200–200 | w-full py-space-sm px-space-md rounded-xl bg-surface-container-low hover:bg-surface-container-high text-on-surface font-body-md text-body-md text-center transition-colors |
| S08b4dbca0abb_N2209 | S08b4dbca0abb_N2203 | attribute | 200–200 | attribute  |
| S08b4dbca0abb_N2210 | S08b4dbca0abb_N2209 | attribute_name | 200–200 | data-path |
| S08b4dbca0abb_N2211 | S08b4dbca0abb_N2209 | quoted_attribute_value | 200–200 | quoted_attribute_value  |
| S08b4dbca0abb_N2212 | S08b4dbca0abb_N2211 | attribute_value | 200–200 | birth-chart-entry |
| S08b4dbca0abb_N2213 | S08b4dbca0abb_N2203 | attribute | 200–200 | attribute  |
| S08b4dbca0abb_N2214 | S08b4dbca0abb_N2213 | attribute_name | 200–200 | href |
| S08b4dbca0abb_N2215 | S08b4dbca0abb_N2213 | quoted_attribute_value | 200–200 | quoted_attribute_value  |
| S08b4dbca0abb_N2216 | S08b4dbca0abb_N2215 | attribute_value | 200–200 | # |
| S08b4dbca0abb_N2217 | S08b4dbca0abb_N2202 | text | 201–201 | Back to offers |
| S08b4dbca0abb_N2218 | S08b4dbca0abb_N2202 | end_tag | 202–202 | end_tag  |
| S08b4dbca0abb_N2219 | S08b4dbca0abb_N2218 | tag_name | 202–202 | a |
| S08b4dbca0abb_N2220 | S08b4dbca0abb_N2164 | end_tag | 203–203 | end_tag  |
| S08b4dbca0abb_N2221 | S08b4dbca0abb_N2220 | tag_name | 203–203 | div |
| S08b4dbca0abb_N2222 | S08b4dbca0abb_N1779 | end_tag | 204–204 | end_tag  |
| S08b4dbca0abb_N2223 | S08b4dbca0abb_N2222 | tag_name | 204–204 | div |
| S08b4dbca0abb_N2224 | S08b4dbca0abb_N1251 | end_tag | 205–205 | end_tag  |
| S08b4dbca0abb_N2225 | S08b4dbca0abb_N2224 | tag_name | 205–205 | div |
| S08b4dbca0abb_N2226 | S08b4dbca0abb_N1038 | end_tag | 206–206 | end_tag  |
| S08b4dbca0abb_N2227 | S08b4dbca0abb_N2226 | tag_name | 206–206 | div |
| S08b4dbca0abb_N2228 | S08b4dbca0abb_N1021 | end_tag | 207–207 | end_tag  |
| S08b4dbca0abb_N2229 | S08b4dbca0abb_N2228 | tag_name | 207–207 | div |
| S08b4dbca0abb_N2230 | S08b4dbca0abb_N1014 | end_tag | 208–208 | end_tag  |
| S08b4dbca0abb_N2231 | S08b4dbca0abb_N2230 | tag_name | 208–208 | div |
| S08b4dbca0abb_N2232 | S08b4dbca0abb_N1007 | end_tag | 208–208 | end_tag  |
| S08b4dbca0abb_N2233 | S08b4dbca0abb_N2232 | tag_name | 208–208 | main |
| S08b4dbca0abb_N2234 | S08b4dbca0abb_N784 | element | 208–208 | element  |
| S08b4dbca0abb_N2235 | S08b4dbca0abb_N2234 | start_tag | 208–208 | start_tag  |
| S08b4dbca0abb_N2236 | S08b4dbca0abb_N2235 | tag_name | 208–208 | footer |
| S08b4dbca0abb_N2237 | S08b4dbca0abb_N2235 | attribute | 208–208 | attribute  |
| S08b4dbca0abb_N2238 | S08b4dbca0abb_N2237 | attribute_name | 208–208 | class |
| S08b4dbca0abb_N2239 | S08b4dbca0abb_N2237 | quoted_attribute_value | 208–208 | quoted_attribute_value  |
| S08b4dbca0abb_N2240 | S08b4dbca0abb_N2239 | attribute_value | 208–208 | w-full bg-surface-container-lowest py-space-xl shadow-[0_-1px_12px_rgba(0,0,0,0.3)] |
| S08b4dbca0abb_N2241 | S08b4dbca0abb_N2234 | element | 208–208 | element  |
| S08b4dbca0abb_N2242 | S08b4dbca0abb_N2241 | start_tag | 208–208 | start_tag  |
| S08b4dbca0abb_N2243 | S08b4dbca0abb_N2242 | tag_name | 208–208 | div |
| S08b4dbca0abb_N2244 | S08b4dbca0abb_N2242 | attribute | 208–208 | attribute  |
| S08b4dbca0abb_N2245 | S08b4dbca0abb_N2244 | attribute_name | 208–208 | class |
| S08b4dbca0abb_N2246 | S08b4dbca0abb_N2244 | quoted_attribute_value | 208–208 | quoted_attribute_value  |
| S08b4dbca0abb_N2247 | S08b4dbca0abb_N2246 | attribute_value | 208–208 | max-w-7xl mx-auto px-margin-desktop flex flex-col md:flex-row items-center justify-between gap-space-md text-center md:text-left |
| S08b4dbca0abb_N2248 | S08b4dbca0abb_N2241 | element | 208–208 | element  |
| S08b4dbca0abb_N2249 | S08b4dbca0abb_N2248 | start_tag | 208–208 | start_tag  |
| S08b4dbca0abb_N2250 | S08b4dbca0abb_N2249 | tag_name | 208–208 | div |
| S08b4dbca0abb_N2251 | S08b4dbca0abb_N2249 | attribute | 208–208 | attribute  |
| S08b4dbca0abb_N2252 | S08b4dbca0abb_N2251 | attribute_name | 208–208 | class |
| S08b4dbca0abb_N2253 | S08b4dbca0abb_N2251 | quoted_attribute_value | 208–208 | quoted_attribute_value  |
| S08b4dbca0abb_N2254 | S08b4dbca0abb_N2253 | attribute_value | 208–208 | flex flex-col sm:flex-row items-center gap-space-sm sm:gap-space-md text-on-surface-variant font-astro-data-md text-astro-data-md |
| S08b4dbca0abb_N2255 | S08b4dbca0abb_N2248 | element | 208–208 | element  |
| S08b4dbca0abb_N2256 | S08b4dbca0abb_N2255 | start_tag | 208–208 | start_tag  |
| S08b4dbca0abb_N2257 | S08b4dbca0abb_N2256 | tag_name | 208–208 | span |
| S08b4dbca0abb_N2258 | S08b4dbca0abb_N2256 | attribute | 208–208 | attribute  |
| S08b4dbca0abb_N2259 | S08b4dbca0abb_N2258 | attribute_name | 208–208 | class |
| S08b4dbca0abb_N2260 | S08b4dbca0abb_N2258 | quoted_attribute_value | 208–208 | quoted_attribute_value  |
| S08b4dbca0abb_N2261 | S08b4dbca0abb_N2260 | attribute_value | 208–208 | text-primary font-label-caps text-label-caps uppercase tracking-wider |
| S08b4dbca0abb_N2262 | S08b4dbca0abb_N2255 | text | 208–208 | Design prototype · no payment is collected |
| S08b4dbca0abb_N2263 | S08b4dbca0abb_N2255 | end_tag | 208–208 | end_tag  |
| S08b4dbca0abb_N2264 | S08b4dbca0abb_N2263 | tag_name | 208–208 | span |
| S08b4dbca0abb_N2265 | S08b4dbca0abb_N2248 | element | 208–208 | element  |
| S08b4dbca0abb_N2266 | S08b4dbca0abb_N2265 | start_tag | 208–208 | start_tag  |
| S08b4dbca0abb_N2267 | S08b4dbca0abb_N2266 | tag_name | 208–208 | span |
| S08b4dbca0abb_N2268 | S08b4dbca0abb_N2266 | attribute | 208–208 | attribute  |
| S08b4dbca0abb_N2269 | S08b4dbca0abb_N2268 | attribute_name | 208–208 | class |
| S08b4dbca0abb_N2270 | S08b4dbca0abb_N2268 | quoted_attribute_value | 208–208 | quoted_attribute_value  |
| S08b4dbca0abb_N2271 | S08b4dbca0abb_N2270 | attribute_value | 208–208 | hidden sm:inline text-surface-variant |
| S08b4dbca0abb_N2272 | S08b4dbca0abb_N2265 | text | 208–208 | • |
| S08b4dbca0abb_N2273 | S08b4dbca0abb_N2265 | end_tag | 208–208 | end_tag  |
| S08b4dbca0abb_N2274 | S08b4dbca0abb_N2273 | tag_name | 208–208 | span |
| S08b4dbca0abb_N2275 | S08b4dbca0abb_N2248 | element | 208–208 | element  |
| S08b4dbca0abb_N2276 | S08b4dbca0abb_N2275 | start_tag | 208–208 | start_tag  |
| S08b4dbca0abb_N2277 | S08b4dbca0abb_N2276 | tag_name | 208–208 | span |
| S08b4dbca0abb_N2278 | S08b4dbca0abb_N2275 | text | 208–208 | Simulated astrolabe consultation |
| S08b4dbca0abb_N2279 | S08b4dbca0abb_N2275 | end_tag | 208–208 | end_tag  |
| S08b4dbca0abb_N2280 | S08b4dbca0abb_N2279 | tag_name | 208–208 | span |
| S08b4dbca0abb_N2281 | S08b4dbca0abb_N2248 | end_tag | 208–208 | end_tag  |
| S08b4dbca0abb_N2282 | S08b4dbca0abb_N2281 | tag_name | 208–208 | div |
| S08b4dbca0abb_N2283 | S08b4dbca0abb_N2241 | element | 208–208 | element  |
| S08b4dbca0abb_N2284 | S08b4dbca0abb_N2283 | start_tag | 208–208 | start_tag  |
| S08b4dbca0abb_N2285 | S08b4dbca0abb_N2284 | tag_name | 208–208 | div |
| S08b4dbca0abb_N2286 | S08b4dbca0abb_N2284 | attribute | 208–208 | attribute  |
| S08b4dbca0abb_N2287 | S08b4dbca0abb_N2286 | attribute_name | 208–208 | class |
| S08b4dbca0abb_N2288 | S08b4dbca0abb_N2286 | quoted_attribute_value | 208–208 | quoted_attribute_value  |
| S08b4dbca0abb_N2289 | S08b4dbca0abb_N2288 | attribute_value | 208–208 | text-on-surface-variant font-astro-data-md text-astro-data-md opacity-75 |
| S08b4dbca0abb_N2290 | S08b4dbca0abb_N2283 | text | 208–208 | © 2025 Natally Observatory Systems. All rights reserved. |
| S08b4dbca0abb_N2291 | S08b4dbca0abb_N2283 | end_tag | 208–208 | end_tag  |
| S08b4dbca0abb_N2292 | S08b4dbca0abb_N2291 | tag_name | 208–208 | div |
| S08b4dbca0abb_N2293 | S08b4dbca0abb_N2241 | end_tag | 208–208 | end_tag  |
| S08b4dbca0abb_N2294 | S08b4dbca0abb_N2293 | tag_name | 208–208 | div |
| S08b4dbca0abb_N2295 | S08b4dbca0abb_N2234 | end_tag | 208–208 | end_tag  |
| S08b4dbca0abb_N2296 | S08b4dbca0abb_N2295 | tag_name | 208–208 | footer |
| S08b4dbca0abb_N2297 | S08b4dbca0abb_N784 | end_tag | 208–208 | end_tag  |
| S08b4dbca0abb_N2298 | S08b4dbca0abb_N2297 | tag_name | 208–208 | body |
| S08b4dbca0abb_N2299 | S08b4dbca0abb_N3 | end_tag | 208–208 | end_tag  |
| S08b4dbca0abb_N2300 | S08b4dbca0abb_N2299 | tag_name | 208–208 | html |