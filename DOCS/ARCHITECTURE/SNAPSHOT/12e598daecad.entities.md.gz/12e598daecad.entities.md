# metadata.json

Source SHA-256: 423c75ab27e26e279ad81caf070ce99c243abed7ea2f64a7ed38133874a3df8e

| ID | Parent | Syntax kind | Lines | Source text |
| --- | --- | --- | --- | --- |
| S12e598daecad_N1 | — | document | 1–8 | document  |
| S12e598daecad_N2 | S12e598daecad_N1 | object | 1–8 | object  |
| S12e598daecad_N3 | S12e598daecad_N2 | pair | 2–2 | pair  |
| S12e598daecad_N4 | S12e598daecad_N3 | string | 2–2 | string  |
| S12e598daecad_N5 | S12e598daecad_N4 | string_content | 2–2 | name |
| S12e598daecad_N6 | S12e598daecad_N3 | string | 2–2 | string  |
| S12e598daecad_N7 | S12e598daecad_N6 | string_content | 2–2 | Remix AstroSphere 3D |
| S12e598daecad_N8 | S12e598daecad_N2 | pair | 3–3 | pair  |
| S12e598daecad_N9 | S12e598daecad_N8 | string | 3–3 | string  |
| S12e598daecad_N10 | S12e598daecad_N9 | string_content | 3–3 | description |
| S12e598daecad_N11 | S12e598daecad_N8 | string | 3–3 | string  |
| S12e598daecad_N12 | S12e598daecad_N11 | string_content | 3–3 | Calculate your precise natal chart and visualize it on an interactive 3D astrolabe using Swiss Ephemeris data. |
| S12e598daecad_N13 | S12e598daecad_N2 | pair | 4–4 | pair  |
| S12e598daecad_N14 | S12e598daecad_N13 | string | 4–4 | string  |
| S12e598daecad_N15 | S12e598daecad_N14 | string_content | 4–4 | requestFramePermissions |
| S12e598daecad_N16 | S12e598daecad_N13 | array | 4–4 | [] |
| S12e598daecad_N17 | S12e598daecad_N2 | pair | 5–7 | pair  |
| S12e598daecad_N18 | S12e598daecad_N17 | string | 5–5 | string  |
| S12e598daecad_N19 | S12e598daecad_N18 | string_content | 5–5 | majorCapabilities |
| S12e598daecad_N20 | S12e598daecad_N17 | array | 5–7 | array  |
| S12e598daecad_N21 | S12e598daecad_N20 | string | 6–6 | string  |
| S12e598daecad_N22 | S12e598daecad_N21 | string_content | 6–6 | MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API |