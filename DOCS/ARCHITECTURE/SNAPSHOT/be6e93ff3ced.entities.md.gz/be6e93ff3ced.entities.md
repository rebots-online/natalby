# scripts/voice-instrumentation-landmarks.ts

Source SHA-256: 3885aed113f5d02ffd162a22730a5f0a9150e52476e21cc17de335707368182a

| ID | Parent | Syntax kind | Lines | Source text |
| --- | --- | --- | --- | --- |
| Sbe6e93ff3ced_N1 | — | program | 1–17 | program  |
| Sbe6e93ff3ced_N2 | Sbe6e93ff3ced_N1 | import_statement | 1–1 | import_statement  |
| Sbe6e93ff3ced_N3 | Sbe6e93ff3ced_N2 | import_clause | 1–1 | import_clause  |
| Sbe6e93ff3ced_N4 | Sbe6e93ff3ced_N3 | named_imports | 1–1 | named_imports  |
| Sbe6e93ff3ced_N5 | Sbe6e93ff3ced_N4 | import_specifier | 1–1 | import_specifier createRequire |
| Sbe6e93ff3ced_N6 | Sbe6e93ff3ced_N5 | identifier | 1–1 | createRequire |
| Sbe6e93ff3ced_N7 | Sbe6e93ff3ced_N2 | string | 1–1 | string  |
| Sbe6e93ff3ced_N8 | Sbe6e93ff3ced_N7 | string_fragment | 1–1 | node:module |
| Sbe6e93ff3ced_N9 | Sbe6e93ff3ced_N1 | import_statement | 2–2 | import_statement  |
| Sbe6e93ff3ced_N10 | Sbe6e93ff3ced_N9 | import_clause | 2–2 | import_clause  |
| Sbe6e93ff3ced_N11 | Sbe6e93ff3ced_N10 | named_imports | 2–2 | named_imports  |
| Sbe6e93ff3ced_N12 | Sbe6e93ff3ced_N11 | import_specifier | 2–2 | import_specifier readFileSync |
| Sbe6e93ff3ced_N13 | Sbe6e93ff3ced_N12 | identifier | 2–2 | readFileSync |
| Sbe6e93ff3ced_N14 | Sbe6e93ff3ced_N9 | string | 2–2 | string  |
| Sbe6e93ff3ced_N15 | Sbe6e93ff3ced_N14 | string_fragment | 2–2 | node:fs |
| Sbe6e93ff3ced_N16 | Sbe6e93ff3ced_N1 | import_statement | 3–3 | import_statement  |
| Sbe6e93ff3ced_N17 | Sbe6e93ff3ced_N16 | import_clause | 3–3 | import_clause  |
| Sbe6e93ff3ced_N18 | Sbe6e93ff3ced_N17 | named_imports | 3–3 | named_imports  |
| Sbe6e93ff3ced_N19 | Sbe6e93ff3ced_N18 | import_specifier | 3–3 | import_specifier dirname |
| Sbe6e93ff3ced_N20 | Sbe6e93ff3ced_N19 | identifier | 3–3 | dirname |
| Sbe6e93ff3ced_N21 | Sbe6e93ff3ced_N18 | import_specifier | 3–3 | import_specifier resolve |
| Sbe6e93ff3ced_N22 | Sbe6e93ff3ced_N21 | identifier | 3–3 | resolve |
| Sbe6e93ff3ced_N23 | Sbe6e93ff3ced_N16 | string | 3–3 | string  |
| Sbe6e93ff3ced_N24 | Sbe6e93ff3ced_N23 | string_fragment | 3–3 | node:path |
| Sbe6e93ff3ced_N25 | Sbe6e93ff3ced_N1 | import_statement | 4–4 | import_statement  |
| Sbe6e93ff3ced_N26 | Sbe6e93ff3ced_N25 | import_clause | 4–4 | import_clause  |
| Sbe6e93ff3ced_N27 | Sbe6e93ff3ced_N26 | named_imports | 4–4 | named_imports  |
| Sbe6e93ff3ced_N28 | Sbe6e93ff3ced_N27 | import_specifier | 4–4 | import_specifier createHash |
| Sbe6e93ff3ced_N29 | Sbe6e93ff3ced_N28 | identifier | 4–4 | createHash |
| Sbe6e93ff3ced_N30 | Sbe6e93ff3ced_N25 | string | 4–4 | string  |
| Sbe6e93ff3ced_N31 | Sbe6e93ff3ced_N30 | string_fragment | 4–4 | node:crypto |
| Sbe6e93ff3ced_N32 | Sbe6e93ff3ced_N1 | import_statement | 5–5 | import_statement  |
| Sbe6e93ff3ced_N33 | Sbe6e93ff3ced_N32 | import_clause | 5–5 | import_clause  |
| Sbe6e93ff3ced_N34 | Sbe6e93ff3ced_N33 | named_imports | 5–5 | named_imports  |
| Sbe6e93ff3ced_N35 | Sbe6e93ff3ced_N34 | import_specifier | 5–5 | import_specifier patchFileReadSource |
| Sbe6e93ff3ced_N36 | Sbe6e93ff3ced_N35 | identifier | 5–5 | patchFileReadSource |
| Sbe6e93ff3ced_N37 | Sbe6e93ff3ced_N34 | import_specifier | 5–5 | import_specifier patchOnnxRuntime |
| Sbe6e93ff3ced_N38 | Sbe6e93ff3ced_N37 | identifier | 5–5 | patchOnnxRuntime |
| Sbe6e93ff3ced_N39 | Sbe6e93ff3ced_N32 | string | 5–5 | string  |
| Sbe6e93ff3ced_N40 | Sbe6e93ff3ced_N39 | string_fragment | 5–5 | ./onnx-progress-plugin |
| Sbe6e93ff3ced_N41 | Sbe6e93ff3ced_N1 | lexical_declaration | 7–7 | lexical_declaration  |
| Sbe6e93ff3ced_N42 | Sbe6e93ff3ced_N41 | variable_declarator | 7–7 | variable_declarator require |
| Sbe6e93ff3ced_N43 | Sbe6e93ff3ced_N42 | identifier | 7–7 | require |
| Sbe6e93ff3ced_N44 | Sbe6e93ff3ced_N42 | call_expression | 7–7 | call_expression  |
| Sbe6e93ff3ced_N45 | Sbe6e93ff3ced_N44 | identifier | 7–7 | createRequire |
| Sbe6e93ff3ced_N46 | Sbe6e93ff3ced_N44 | arguments | 7–7 | arguments  |
| Sbe6e93ff3ced_N47 | Sbe6e93ff3ced_N46 | member_expression | 7–7 | member_expression  |
| Sbe6e93ff3ced_N48 | Sbe6e93ff3ced_N47 | member_expression | 7–7 | member_expression  |
| Sbe6e93ff3ced_N49 | Sbe6e93ff3ced_N48 | import | 7–7 | import |
| Sbe6e93ff3ced_N50 | Sbe6e93ff3ced_N48 | property_identifier | 7–7 | meta |
| Sbe6e93ff3ced_N51 | Sbe6e93ff3ced_N47 | property_identifier | 7–7 | url |
| Sbe6e93ff3ced_N52 | Sbe6e93ff3ced_N1 | lexical_declaration | 8–8 | lexical_declaration  |
| Sbe6e93ff3ced_N53 | Sbe6e93ff3ced_N52 | variable_declarator | 8–8 | variable_declarator dist |
| Sbe6e93ff3ced_N54 | Sbe6e93ff3ced_N53 | identifier | 8–8 | dist |
| Sbe6e93ff3ced_N55 | Sbe6e93ff3ced_N53 | call_expression | 8–8 | call_expression  |
| Sbe6e93ff3ced_N56 | Sbe6e93ff3ced_N55 | identifier | 8–8 | dirname |
| Sbe6e93ff3ced_N57 | Sbe6e93ff3ced_N55 | arguments | 8–8 | arguments  |
| Sbe6e93ff3ced_N58 | Sbe6e93ff3ced_N57 | call_expression | 8–8 | call_expression  |
| Sbe6e93ff3ced_N59 | Sbe6e93ff3ced_N58 | member_expression | 8–8 | member_expression  |
| Sbe6e93ff3ced_N60 | Sbe6e93ff3ced_N59 | identifier | 8–8 | require |
| Sbe6e93ff3ced_N61 | Sbe6e93ff3ced_N59 | property_identifier | 8–8 | resolve |
| Sbe6e93ff3ced_N62 | Sbe6e93ff3ced_N58 | arguments | 8–8 | arguments  |
| Sbe6e93ff3ced_N63 | Sbe6e93ff3ced_N62 | string | 8–8 | string  |
| Sbe6e93ff3ced_N64 | Sbe6e93ff3ced_N63 | string_fragment | 8–8 | @huggingface/transformers |
| Sbe6e93ff3ced_N65 | Sbe6e93ff3ced_N1 | lexical_declaration | 9–9 | lexical_declaration  |
| Sbe6e93ff3ced_N66 | Sbe6e93ff3ced_N65 | variable_declarator | 9–9 | variable_declarator file |
| Sbe6e93ff3ced_N67 | Sbe6e93ff3ced_N66 | identifier | 9–9 | file |
| Sbe6e93ff3ced_N68 | Sbe6e93ff3ced_N66 | call_expression | 9–9 | call_expression  |
| Sbe6e93ff3ced_N69 | Sbe6e93ff3ced_N68 | identifier | 9–9 | resolve |
| Sbe6e93ff3ced_N70 | Sbe6e93ff3ced_N68 | arguments | 9–9 | arguments  |
| Sbe6e93ff3ced_N71 | Sbe6e93ff3ced_N70 | identifier | 9–9 | dist |
| Sbe6e93ff3ced_N72 | Sbe6e93ff3ced_N70 | string | 9–9 | string  |
| Sbe6e93ff3ced_N73 | Sbe6e93ff3ced_N72 | string_fragment | 9–9 | transformers.web.js |
| Sbe6e93ff3ced_N74 | Sbe6e93ff3ced_N1 | lexical_declaration | 10–10 | lexical_declaration  |
| Sbe6e93ff3ced_N75 | Sbe6e93ff3ced_N74 | variable_declarator | 10–10 | variable_declarator source |
| Sbe6e93ff3ced_N76 | Sbe6e93ff3ced_N75 | identifier | 10–10 | source |
| Sbe6e93ff3ced_N77 | Sbe6e93ff3ced_N75 | call_expression | 10–10 | call_expression  |
| Sbe6e93ff3ced_N78 | Sbe6e93ff3ced_N77 | identifier | 10–10 | readFileSync |
| Sbe6e93ff3ced_N79 | Sbe6e93ff3ced_N77 | arguments | 10–10 | arguments  |
| Sbe6e93ff3ced_N80 | Sbe6e93ff3ced_N79 | identifier | 10–10 | file |
| Sbe6e93ff3ced_N81 | Sbe6e93ff3ced_N79 | string | 10–10 | string  |
| Sbe6e93ff3ced_N82 | Sbe6e93ff3ced_N81 | string_fragment | 10–10 | utf8 |
| Sbe6e93ff3ced_N83 | Sbe6e93ff3ced_N1 | expression_statement | 11–11 | expression_statement  |
| Sbe6e93ff3ced_N84 | Sbe6e93ff3ced_N83 | call_expression | 11–11 | call_expression  |
| Sbe6e93ff3ced_N85 | Sbe6e93ff3ced_N84 | identifier | 11–11 | patchFileReadSource |
| Sbe6e93ff3ced_N86 | Sbe6e93ff3ced_N84 | arguments | 11–11 | arguments  |
| Sbe6e93ff3ced_N87 | Sbe6e93ff3ced_N86 | call_expression | 11–11 | call_expression  |
| Sbe6e93ff3ced_N88 | Sbe6e93ff3ced_N87 | identifier | 11–11 | patchOnnxRuntime |
| Sbe6e93ff3ced_N89 | Sbe6e93ff3ced_N87 | arguments | 11–11 | arguments  |
| Sbe6e93ff3ced_N90 | Sbe6e93ff3ced_N89 | identifier | 11–11 | source |
| Sbe6e93ff3ced_N91 | Sbe6e93ff3ced_N1 | comment | 11–11 | // Fail loudly on source drift. |
| Sbe6e93ff3ced_N92 | Sbe6e93ff3ced_N1 | lexical_declaration | 12–12 | lexical_declaration  |
| Sbe6e93ff3ced_N93 | Sbe6e93ff3ced_N92 | variable_declarator | 12–12 | variable_declarator anchors |
| Sbe6e93ff3ced_N94 | Sbe6e93ff3ced_N93 | identifier | 12–12 | anchors |
| Sbe6e93ff3ced_N95 | Sbe6e93ff3ced_N93 | array | 12–12 | array  |
| Sbe6e93ff3ced_N96 | Sbe6e93ff3ced_N95 | string | 12–12 | string  |
| Sbe6e93ff3ced_N97 | Sbe6e93ff3ced_N96 | string_fragment | 12–12 | var InferenceSession = ONNX.InferenceSession; |
| Sbe6e93ff3ced_N98 | Sbe6e93ff3ced_N95 | string | 12–12 | string  |
| Sbe6e93ff3ced_N99 | Sbe6e93ff3ced_N98 | string_fragment | 12–12 | status: "download", |
| Sbe6e93ff3ced_N100 | Sbe6e93ff3ced_N98 | escape_sequence | 12–12 | \n |
| Sbe6e93ff3ced_N101 | Sbe6e93ff3ced_N98 | string_fragment | 12–12 |     name: path_or_repo_id, |
| Sbe6e93ff3ced_N102 | Sbe6e93ff3ced_N98 | escape_sequence | 12–12 | \n |
| Sbe6e93ff3ced_N103 | Sbe6e93ff3ced_N98 | string_fragment | 12–12 |     file: filename |
| Sbe6e93ff3ced_N104 | Sbe6e93ff3ced_N1 | expression_statement | 13–16 | expression_statement  |
| Sbe6e93ff3ced_N105 | Sbe6e93ff3ced_N104 | call_expression | 13–16 | call_expression  |
| Sbe6e93ff3ced_N106 | Sbe6e93ff3ced_N105 | member_expression | 13–13 | member_expression  |
| Sbe6e93ff3ced_N107 | Sbe6e93ff3ced_N106 | identifier | 13–13 | console |
| Sbe6e93ff3ced_N108 | Sbe6e93ff3ced_N106 | property_identifier | 13–13 | log |
| Sbe6e93ff3ced_N109 | Sbe6e93ff3ced_N105 | arguments | 13–16 | arguments  |
| Sbe6e93ff3ced_N110 | Sbe6e93ff3ced_N109 | call_expression | 13–16 | call_expression  |
| Sbe6e93ff3ced_N111 | Sbe6e93ff3ced_N110 | member_expression | 13–13 | member_expression  |
| Sbe6e93ff3ced_N112 | Sbe6e93ff3ced_N111 | identifier | 13–13 | JSON |
| Sbe6e93ff3ced_N113 | Sbe6e93ff3ced_N111 | property_identifier | 13–13 | stringify |
| Sbe6e93ff3ced_N114 | Sbe6e93ff3ced_N110 | arguments | 13–16 | arguments  |
| Sbe6e93ff3ced_N115 | Sbe6e93ff3ced_N114 | object | 13–16 | object  |
| Sbe6e93ff3ced_N116 | Sbe6e93ff3ced_N115 | pair | 13–13 | pair  |
| Sbe6e93ff3ced_N117 | Sbe6e93ff3ced_N116 | property_identifier | 13–13 | runtime |
| Sbe6e93ff3ced_N118 | Sbe6e93ff3ced_N116 | string | 13–13 | string  |
| Sbe6e93ff3ced_N119 | Sbe6e93ff3ced_N118 | string_fragment | 13–13 | @huggingface/transformers@4.3.1 |
| Sbe6e93ff3ced_N120 | Sbe6e93ff3ced_N115 | pair | 13–13 | pair  |
| Sbe6e93ff3ced_N121 | Sbe6e93ff3ced_N120 | property_identifier | 13–13 | sourceSha256 |
| Sbe6e93ff3ced_N122 | Sbe6e93ff3ced_N120 | call_expression | 13–13 | call_expression  |
| Sbe6e93ff3ced_N123 | Sbe6e93ff3ced_N122 | member_expression | 13–13 | member_expression  |
| Sbe6e93ff3ced_N124 | Sbe6e93ff3ced_N123 | call_expression | 13–13 | call_expression  |
| Sbe6e93ff3ced_N125 | Sbe6e93ff3ced_N124 | member_expression | 13–13 | member_expression  |
| Sbe6e93ff3ced_N126 | Sbe6e93ff3ced_N125 | call_expression | 13–13 | call_expression  |
| Sbe6e93ff3ced_N127 | Sbe6e93ff3ced_N126 | identifier | 13–13 | createHash |
| Sbe6e93ff3ced_N128 | Sbe6e93ff3ced_N126 | arguments | 13–13 | arguments  |
| Sbe6e93ff3ced_N129 | Sbe6e93ff3ced_N128 | string | 13–13 | string  |
| Sbe6e93ff3ced_N130 | Sbe6e93ff3ced_N129 | string_fragment | 13–13 | sha256 |
| Sbe6e93ff3ced_N131 | Sbe6e93ff3ced_N125 | property_identifier | 13–13 | update |
| Sbe6e93ff3ced_N132 | Sbe6e93ff3ced_N124 | arguments | 13–13 | arguments  |
| Sbe6e93ff3ced_N133 | Sbe6e93ff3ced_N132 | identifier | 13–13 | source |
| Sbe6e93ff3ced_N134 | Sbe6e93ff3ced_N123 | property_identifier | 13–13 | digest |
| Sbe6e93ff3ced_N135 | Sbe6e93ff3ced_N122 | arguments | 13–13 | arguments  |
| Sbe6e93ff3ced_N136 | Sbe6e93ff3ced_N135 | string | 13–13 | string  |
| Sbe6e93ff3ced_N137 | Sbe6e93ff3ced_N136 | string_fragment | 13–13 | hex |
| Sbe6e93ff3ced_N138 | Sbe6e93ff3ced_N115 | pair | 14–15 | pair  |
| Sbe6e93ff3ced_N139 | Sbe6e93ff3ced_N138 | property_identifier | 14–14 | landmarks |
| Sbe6e93ff3ced_N140 | Sbe6e93ff3ced_N138 | call_expression | 14–15 | call_expression  |
| Sbe6e93ff3ced_N141 | Sbe6e93ff3ced_N140 | member_expression | 14–14 | member_expression  |
| Sbe6e93ff3ced_N142 | Sbe6e93ff3ced_N141 | identifier | 14–14 | anchors |
| Sbe6e93ff3ced_N143 | Sbe6e93ff3ced_N141 | property_identifier | 14–14 | map |
| Sbe6e93ff3ced_N144 | Sbe6e93ff3ced_N140 | arguments | 14–15 | arguments  |
| Sbe6e93ff3ced_N145 | Sbe6e93ff3ced_N144 | arrow_function | 14–15 | arrow_function  |
| Sbe6e93ff3ced_N146 | Sbe6e93ff3ced_N145 | identifier | 14–14 | anchor |
| Sbe6e93ff3ced_N147 | Sbe6e93ff3ced_N145 | parenthesized_expression | 14–15 | parenthesized_expression  |
| Sbe6e93ff3ced_N148 | Sbe6e93ff3ced_N147 | object | 14–15 | object  |
| Sbe6e93ff3ced_N149 | Sbe6e93ff3ced_N148 | shorthand_property_identifier | 14–14 | anchor |
| Sbe6e93ff3ced_N150 | Sbe6e93ff3ced_N148 | pair | 14–14 | pair  |
| Sbe6e93ff3ced_N151 | Sbe6e93ff3ced_N150 | property_identifier | 14–14 | line |
| Sbe6e93ff3ced_N152 | Sbe6e93ff3ced_N150 | member_expression | 14–14 | member_expression  |
| Sbe6e93ff3ced_N153 | Sbe6e93ff3ced_N152 | call_expression | 14–14 | call_expression  |
| Sbe6e93ff3ced_N154 | Sbe6e93ff3ced_N153 | member_expression | 14–14 | member_expression  |
| Sbe6e93ff3ced_N155 | Sbe6e93ff3ced_N154 | call_expression | 14–14 | call_expression  |
| Sbe6e93ff3ced_N156 | Sbe6e93ff3ced_N155 | member_expression | 14–14 | member_expression  |
| Sbe6e93ff3ced_N157 | Sbe6e93ff3ced_N156 | identifier | 14–14 | source |
| Sbe6e93ff3ced_N158 | Sbe6e93ff3ced_N156 | property_identifier | 14–14 | slice |
| Sbe6e93ff3ced_N159 | Sbe6e93ff3ced_N155 | arguments | 14–14 | arguments  |
| Sbe6e93ff3ced_N160 | Sbe6e93ff3ced_N159 | number | 14–14 | 0 |
| Sbe6e93ff3ced_N161 | Sbe6e93ff3ced_N159 | call_expression | 14–14 | call_expression  |
| Sbe6e93ff3ced_N162 | Sbe6e93ff3ced_N161 | member_expression | 14–14 | member_expression  |
| Sbe6e93ff3ced_N163 | Sbe6e93ff3ced_N162 | identifier | 14–14 | source |
| Sbe6e93ff3ced_N164 | Sbe6e93ff3ced_N162 | property_identifier | 14–14 | indexOf |
| Sbe6e93ff3ced_N165 | Sbe6e93ff3ced_N161 | arguments | 14–14 | arguments  |
| Sbe6e93ff3ced_N166 | Sbe6e93ff3ced_N165 | identifier | 14–14 | anchor |
| Sbe6e93ff3ced_N167 | Sbe6e93ff3ced_N154 | property_identifier | 14–14 | split |
| Sbe6e93ff3ced_N168 | Sbe6e93ff3ced_N153 | arguments | 14–14 | arguments  |
| Sbe6e93ff3ced_N169 | Sbe6e93ff3ced_N168 | string | 14–14 | string  |
| Sbe6e93ff3ced_N170 | Sbe6e93ff3ced_N169 | escape_sequence | 14–14 | \n |
| Sbe6e93ff3ced_N171 | Sbe6e93ff3ced_N152 | property_identifier | 14–14 | length |
| Sbe6e93ff3ced_N172 | Sbe6e93ff3ced_N148 | pair | 15–15 | pair  |
| Sbe6e93ff3ced_N173 | Sbe6e93ff3ced_N172 | property_identifier | 15–15 | source |
| Sbe6e93ff3ced_N174 | Sbe6e93ff3ced_N172 | call_expression | 15–15 | call_expression  |
| Sbe6e93ff3ced_N175 | Sbe6e93ff3ced_N174 | member_expression | 15–15 | member_expression  |
| Sbe6e93ff3ced_N176 | Sbe6e93ff3ced_N175 | identifier | 15–15 | source |
| Sbe6e93ff3ced_N177 | Sbe6e93ff3ced_N175 | property_identifier | 15–15 | slice |
| Sbe6e93ff3ced_N178 | Sbe6e93ff3ced_N174 | arguments | 15–15 | arguments  |
| Sbe6e93ff3ced_N179 | Sbe6e93ff3ced_N178 | call_expression | 15–15 | call_expression  |
| Sbe6e93ff3ced_N180 | Sbe6e93ff3ced_N179 | member_expression | 15–15 | member_expression  |
| Sbe6e93ff3ced_N181 | Sbe6e93ff3ced_N180 | identifier | 15–15 | Math |
| Sbe6e93ff3ced_N182 | Sbe6e93ff3ced_N180 | property_identifier | 15–15 | max |
| Sbe6e93ff3ced_N183 | Sbe6e93ff3ced_N179 | arguments | 15–15 | arguments  |
| Sbe6e93ff3ced_N184 | Sbe6e93ff3ced_N183 | number | 15–15 | 0 |
| Sbe6e93ff3ced_N185 | Sbe6e93ff3ced_N183 | binary_expression | 15–15 | binary_expression  |
| Sbe6e93ff3ced_N186 | Sbe6e93ff3ced_N185 | call_expression | 15–15 | call_expression  |
| Sbe6e93ff3ced_N187 | Sbe6e93ff3ced_N186 | member_expression | 15–15 | member_expression  |
| Sbe6e93ff3ced_N188 | Sbe6e93ff3ced_N187 | identifier | 15–15 | source |
| Sbe6e93ff3ced_N189 | Sbe6e93ff3ced_N187 | property_identifier | 15–15 | indexOf |
| Sbe6e93ff3ced_N190 | Sbe6e93ff3ced_N186 | arguments | 15–15 | arguments  |
| Sbe6e93ff3ced_N191 | Sbe6e93ff3ced_N190 | identifier | 15–15 | anchor |
| Sbe6e93ff3ced_N192 | Sbe6e93ff3ced_N185 | number | 15–15 | 150 |
| Sbe6e93ff3ced_N193 | Sbe6e93ff3ced_N178 | binary_expression | 15–15 | binary_expression  |
| Sbe6e93ff3ced_N194 | Sbe6e93ff3ced_N193 | binary_expression | 15–15 | binary_expression  |
| Sbe6e93ff3ced_N195 | Sbe6e93ff3ced_N194 | call_expression | 15–15 | call_expression  |
| Sbe6e93ff3ced_N196 | Sbe6e93ff3ced_N195 | member_expression | 15–15 | member_expression  |
| Sbe6e93ff3ced_N197 | Sbe6e93ff3ced_N196 | identifier | 15–15 | source |
| Sbe6e93ff3ced_N198 | Sbe6e93ff3ced_N196 | property_identifier | 15–15 | indexOf |
| Sbe6e93ff3ced_N199 | Sbe6e93ff3ced_N195 | arguments | 15–15 | arguments  |
| Sbe6e93ff3ced_N200 | Sbe6e93ff3ced_N199 | identifier | 15–15 | anchor |
| Sbe6e93ff3ced_N201 | Sbe6e93ff3ced_N194 | member_expression | 15–15 | member_expression  |
| Sbe6e93ff3ced_N202 | Sbe6e93ff3ced_N201 | identifier | 15–15 | anchor |
| Sbe6e93ff3ced_N203 | Sbe6e93ff3ced_N201 | property_identifier | 15–15 | length |
| Sbe6e93ff3ced_N204 | Sbe6e93ff3ced_N193 | number | 15–15 | 350 |
| Sbe6e93ff3ced_N205 | Sbe6e93ff3ced_N115 | pair | 16–16 | pair  |
| Sbe6e93ff3ced_N206 | Sbe6e93ff3ced_N205 | property_identifier | 16–16 | instruction |
| Sbe6e93ff3ced_N207 | Sbe6e93ff3ced_N205 | string | 16–16 | string  |
| Sbe6e93ff3ced_N208 | Sbe6e93ff3ced_N207 | string_fragment | 16–16 | Instrument these verified source boundaries. Emit start before actual work and complete only after the native promise resolves; emit error and rethrow the same rejection. Retain native receiver, options, results and device selection. Report exact file, actual cacheHit source, backend and monotonic duration. A heartbeat acknowledges responsiveness, never completion. Use measured bytes and native graph completions for progress. Add pending-promise and error-preservation tests. Refuse ambiguous or changed anchors. Keep participant recording opt-in; whitelist exports, do not upload. See DOCS/HONEST-PROGRESS-SOP.md. |
| Sbe6e93ff3ced_N209 | Sbe6e93ff3ced_N114 | null | 16–16 | null |
| Sbe6e93ff3ced_N210 | Sbe6e93ff3ced_N114 | number | 16–16 | 2 |