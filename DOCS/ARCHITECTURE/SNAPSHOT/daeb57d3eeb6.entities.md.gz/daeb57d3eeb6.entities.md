# firebase-applet-config.json

Source SHA-256: eb4c48611320e8bcd752c79bf8ed8e9f4d90c7ed6ebb7bb2799a0a4c2d3246f6

| ID | Parent | Syntax kind | Lines | Source text |
| --- | --- | --- | --- | --- |
| Sdaeb57d3eeb6_N1 | — | document | 1–12 | document  |
| Sdaeb57d3eeb6_N2 | Sdaeb57d3eeb6_N1 | object | 1–12 | object  |
| Sdaeb57d3eeb6_N3 | Sdaeb57d3eeb6_N2 | pair | 2–2 | pair  |
| Sdaeb57d3eeb6_N4 | Sdaeb57d3eeb6_N3 | string | 2–2 | string  |
| Sdaeb57d3eeb6_N5 | Sdaeb57d3eeb6_N4 | string_content | 2–2 | projectId |
| Sdaeb57d3eeb6_N6 | Sdaeb57d3eeb6_N3 | string | 2–2 | string  |
| Sdaeb57d3eeb6_N7 | Sdaeb57d3eeb6_N6 | string_content | 2–2 | gen-lang-client-0714568880 |
| Sdaeb57d3eeb6_N8 | Sdaeb57d3eeb6_N2 | pair | 3–3 | pair  |
| Sdaeb57d3eeb6_N9 | Sdaeb57d3eeb6_N8 | string | 3–3 | string  |
| Sdaeb57d3eeb6_N10 | Sdaeb57d3eeb6_N9 | string_content | 3–3 | appId |
| Sdaeb57d3eeb6_N11 | Sdaeb57d3eeb6_N8 | string | 3–3 | string  |
| Sdaeb57d3eeb6_N12 | Sdaeb57d3eeb6_N11 | string_content | 3–3 | 1:358982402678:web:b58ae851992532cf66d557 |
| Sdaeb57d3eeb6_N13 | Sdaeb57d3eeb6_N2 | pair | 4–4 | pair  |
| Sdaeb57d3eeb6_N14 | Sdaeb57d3eeb6_N13 | string | 4–4 | string  |
| Sdaeb57d3eeb6_N15 | Sdaeb57d3eeb6_N14 | string_content | 4–4 | apiKey |
| Sdaeb57d3eeb6_N16 | Sdaeb57d3eeb6_N13 | string | 4–4 | string  |
| Sdaeb57d3eeb6_N17 | Sdaeb57d3eeb6_N16 | string_content | 4–4 | AIzaSyBC-CojN4V2e5feWm8sosvp5Jm0Thk9tN8 |
| Sdaeb57d3eeb6_N18 | Sdaeb57d3eeb6_N2 | pair | 5–5 | pair  |
| Sdaeb57d3eeb6_N19 | Sdaeb57d3eeb6_N18 | string | 5–5 | string  |
| Sdaeb57d3eeb6_N20 | Sdaeb57d3eeb6_N19 | string_content | 5–5 | authDomain |
| Sdaeb57d3eeb6_N21 | Sdaeb57d3eeb6_N18 | string | 5–5 | string  |
| Sdaeb57d3eeb6_N22 | Sdaeb57d3eeb6_N21 | string_content | 5–5 | gen-lang-client-0714568880.firebaseapp.com |
| Sdaeb57d3eeb6_N23 | Sdaeb57d3eeb6_N2 | pair | 6–6 | pair  |
| Sdaeb57d3eeb6_N24 | Sdaeb57d3eeb6_N23 | string | 6–6 | string  |
| Sdaeb57d3eeb6_N25 | Sdaeb57d3eeb6_N24 | string_content | 6–6 | firestoreDatabaseId |
| Sdaeb57d3eeb6_N26 | Sdaeb57d3eeb6_N23 | string | 6–6 | string  |
| Sdaeb57d3eeb6_N27 | Sdaeb57d3eeb6_N26 | string_content | 6–6 | ai-studio-remixastrosphere-1ee57c33-6487-411a-a872-59fbf4cbfc63 |
| Sdaeb57d3eeb6_N28 | Sdaeb57d3eeb6_N2 | pair | 7–7 | pair  |
| Sdaeb57d3eeb6_N29 | Sdaeb57d3eeb6_N28 | string | 7–7 | string  |
| Sdaeb57d3eeb6_N30 | Sdaeb57d3eeb6_N29 | string_content | 7–7 | storageBucket |
| Sdaeb57d3eeb6_N31 | Sdaeb57d3eeb6_N28 | string | 7–7 | string  |
| Sdaeb57d3eeb6_N32 | Sdaeb57d3eeb6_N31 | string_content | 7–7 | gen-lang-client-0714568880.firebasestorage.app |
| Sdaeb57d3eeb6_N33 | Sdaeb57d3eeb6_N2 | pair | 8–8 | pair  |
| Sdaeb57d3eeb6_N34 | Sdaeb57d3eeb6_N33 | string | 8–8 | string  |
| Sdaeb57d3eeb6_N35 | Sdaeb57d3eeb6_N34 | string_content | 8–8 | messagingSenderId |
| Sdaeb57d3eeb6_N36 | Sdaeb57d3eeb6_N33 | string | 8–8 | string  |
| Sdaeb57d3eeb6_N37 | Sdaeb57d3eeb6_N36 | string_content | 8–8 | 358982402678 |
| Sdaeb57d3eeb6_N38 | Sdaeb57d3eeb6_N2 | pair | 9–9 | pair  |
| Sdaeb57d3eeb6_N39 | Sdaeb57d3eeb6_N38 | string | 9–9 | string  |
| Sdaeb57d3eeb6_N40 | Sdaeb57d3eeb6_N39 | string_content | 9–9 | measurementId |
| Sdaeb57d3eeb6_N41 | Sdaeb57d3eeb6_N38 | string | 9–9 | "" |
| Sdaeb57d3eeb6_N42 | Sdaeb57d3eeb6_N2 | pair | 10–10 | pair  |
| Sdaeb57d3eeb6_N43 | Sdaeb57d3eeb6_N42 | string | 10–10 | string  |
| Sdaeb57d3eeb6_N44 | Sdaeb57d3eeb6_N43 | string_content | 10–10 | oAuthClientId |
| Sdaeb57d3eeb6_N45 | Sdaeb57d3eeb6_N42 | string | 10–10 | string  |
| Sdaeb57d3eeb6_N46 | Sdaeb57d3eeb6_N45 | string_content | 10–10 | 358982402678-uap9cjq5u7tkjaei1etc8e6q97tqg70c.apps.googleusercontent.com |
| Sdaeb57d3eeb6_N47 | Sdaeb57d3eeb6_N2 | pair | 11–11 | pair  |
| Sdaeb57d3eeb6_N48 | Sdaeb57d3eeb6_N47 | string | 11–11 | string  |
| Sdaeb57d3eeb6_N49 | Sdaeb57d3eeb6_N48 | string_content | 11–11 | recaptchaSiteKey |
| Sdaeb57d3eeb6_N50 | Sdaeb57d3eeb6_N47 | string | 11–11 | "" |