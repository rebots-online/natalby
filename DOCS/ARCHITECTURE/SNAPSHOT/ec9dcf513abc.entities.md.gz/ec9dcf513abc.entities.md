# LIBS/UI/STITCH/branch-preview-20261021/profile.source.html

Source SHA-256: 302685475a299408c28af56edf5edbbe739f814c59f2eac53dc15089946cdeb4

| ID | Parent | Syntax kind | Lines | Source text |
| --- | --- | --- | --- | --- |
| Sec9dcf513abc_N1 | — | document | 1–624 | document  |
| Sec9dcf513abc_N2 | Sec9dcf513abc_N1 | doctype | 1–1 | &lt;!DOCTYPE html&gt; |
| Sec9dcf513abc_N3 | Sec9dcf513abc_N1 | element | 3–624 | element  |
| Sec9dcf513abc_N4 | Sec9dcf513abc_N3 | start_tag | 3–3 | start_tag  |
| Sec9dcf513abc_N5 | Sec9dcf513abc_N4 | tag_name | 3–3 | html |
| Sec9dcf513abc_N6 | Sec9dcf513abc_N4 | attribute | 3–3 | attribute  |
| Sec9dcf513abc_N7 | Sec9dcf513abc_N6 | attribute_name | 3–3 | lang |
| Sec9dcf513abc_N8 | Sec9dcf513abc_N6 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| Sec9dcf513abc_N9 | Sec9dcf513abc_N8 | attribute_value | 3–3 | en |
| Sec9dcf513abc_N10 | Sec9dcf513abc_N3 | element | 4–65 | element  |
| Sec9dcf513abc_N11 | Sec9dcf513abc_N10 | start_tag | 4–4 | start_tag  |
| Sec9dcf513abc_N12 | Sec9dcf513abc_N11 | tag_name | 4–4 | head |
| Sec9dcf513abc_N13 | Sec9dcf513abc_N10 | element | 5–5 | element  |
| Sec9dcf513abc_N14 | Sec9dcf513abc_N13 | self_closing_tag | 5–5 | self_closing_tag  |
| Sec9dcf513abc_N15 | Sec9dcf513abc_N14 | tag_name | 5–5 | meta |
| Sec9dcf513abc_N16 | Sec9dcf513abc_N14 | attribute | 5–5 | attribute  |
| Sec9dcf513abc_N17 | Sec9dcf513abc_N16 | attribute_name | 5–5 | charset |
| Sec9dcf513abc_N18 | Sec9dcf513abc_N16 | quoted_attribute_value | 5–5 | quoted_attribute_value  |
| Sec9dcf513abc_N19 | Sec9dcf513abc_N18 | attribute_value | 5–5 | utf-8 |
| Sec9dcf513abc_N20 | Sec9dcf513abc_N10 | element | 6–6 | element  |
| Sec9dcf513abc_N21 | Sec9dcf513abc_N20 | self_closing_tag | 6–6 | self_closing_tag  |
| Sec9dcf513abc_N22 | Sec9dcf513abc_N21 | tag_name | 6–6 | meta |
| Sec9dcf513abc_N23 | Sec9dcf513abc_N21 | attribute | 6–6 | attribute  |
| Sec9dcf513abc_N24 | Sec9dcf513abc_N23 | attribute_name | 6–6 | content |
| Sec9dcf513abc_N25 | Sec9dcf513abc_N23 | quoted_attribute_value | 6–6 | quoted_attribute_value  |
| Sec9dcf513abc_N26 | Sec9dcf513abc_N25 | attribute_value | 6–6 | width=device-width, initial-scale=1.0 |
| Sec9dcf513abc_N27 | Sec9dcf513abc_N21 | attribute | 6–6 | attribute  |
| Sec9dcf513abc_N28 | Sec9dcf513abc_N27 | attribute_name | 6–6 | name |
| Sec9dcf513abc_N29 | Sec9dcf513abc_N27 | quoted_attribute_value | 6–6 | quoted_attribute_value  |
| Sec9dcf513abc_N30 | Sec9dcf513abc_N29 | attribute_value | 6–6 | viewport |
| Sec9dcf513abc_N31 | Sec9dcf513abc_N10 | element | 7–7 | element  |
| Sec9dcf513abc_N32 | Sec9dcf513abc_N31 | start_tag | 7–7 | start_tag  |
| Sec9dcf513abc_N33 | Sec9dcf513abc_N32 | tag_name | 7–7 | title |
| Sec9dcf513abc_N34 | Sec9dcf513abc_N31 | text | 7–7 | natally-ai-studio — Profile and billing preview |
| Sec9dcf513abc_N35 | Sec9dcf513abc_N31 | end_tag | 7–7 | end_tag  |
| Sec9dcf513abc_N36 | Sec9dcf513abc_N35 | tag_name | 7–7 | title |
| Sec9dcf513abc_N37 | Sec9dcf513abc_N10 | comment | 8–8 | &lt;!-- Google Fonts: Fraunces, Nunito Sans, IBM Plex Mono --&gt; |
| Sec9dcf513abc_N38 | Sec9dcf513abc_N10 | element | 9–9 | element  |
| Sec9dcf513abc_N39 | Sec9dcf513abc_N38 | self_closing_tag | 9–9 | self_closing_tag  |
| Sec9dcf513abc_N40 | Sec9dcf513abc_N39 | tag_name | 9–9 | link |
| Sec9dcf513abc_N41 | Sec9dcf513abc_N39 | attribute | 9–9 | attribute  |
| Sec9dcf513abc_N42 | Sec9dcf513abc_N41 | attribute_name | 9–9 | href |
| Sec9dcf513abc_N43 | Sec9dcf513abc_N41 | quoted_attribute_value | 9–9 | quoted_attribute_value  |
| Sec9dcf513abc_N44 | Sec9dcf513abc_N43 | attribute_value | 9–9 | https://fonts.googleapis.com |
| Sec9dcf513abc_N45 | Sec9dcf513abc_N39 | attribute | 9–9 | attribute  |
| Sec9dcf513abc_N46 | Sec9dcf513abc_N45 | attribute_name | 9–9 | rel |
| Sec9dcf513abc_N47 | Sec9dcf513abc_N45 | quoted_attribute_value | 9–9 | quoted_attribute_value  |
| Sec9dcf513abc_N48 | Sec9dcf513abc_N47 | attribute_value | 9–9 | preconnect |
| Sec9dcf513abc_N49 | Sec9dcf513abc_N10 | element | 10–10 | element  |
| Sec9dcf513abc_N50 | Sec9dcf513abc_N49 | self_closing_tag | 10–10 | self_closing_tag  |
| Sec9dcf513abc_N51 | Sec9dcf513abc_N50 | tag_name | 10–10 | link |
| Sec9dcf513abc_N52 | Sec9dcf513abc_N50 | attribute | 10–10 | attribute  |
| Sec9dcf513abc_N53 | Sec9dcf513abc_N52 | attribute_name | 10–10 | crossorigin |
| Sec9dcf513abc_N54 | Sec9dcf513abc_N52 | quoted_attribute_value | 10–10 | "" |
| Sec9dcf513abc_N55 | Sec9dcf513abc_N50 | attribute | 10–10 | attribute  |
| Sec9dcf513abc_N56 | Sec9dcf513abc_N55 | attribute_name | 10–10 | href |
| Sec9dcf513abc_N57 | Sec9dcf513abc_N55 | quoted_attribute_value | 10–10 | quoted_attribute_value  |
| Sec9dcf513abc_N58 | Sec9dcf513abc_N57 | attribute_value | 10–10 | https://fonts.gstatic.com |
| Sec9dcf513abc_N59 | Sec9dcf513abc_N50 | attribute | 10–10 | attribute  |
| Sec9dcf513abc_N60 | Sec9dcf513abc_N59 | attribute_name | 10–10 | rel |
| Sec9dcf513abc_N61 | Sec9dcf513abc_N59 | quoted_attribute_value | 10–10 | quoted_attribute_value  |
| Sec9dcf513abc_N62 | Sec9dcf513abc_N61 | attribute_value | 10–10 | preconnect |
| Sec9dcf513abc_N63 | Sec9dcf513abc_N10 | element | 11–11 | element  |
| Sec9dcf513abc_N64 | Sec9dcf513abc_N63 | self_closing_tag | 11–11 | self_closing_tag  |
| Sec9dcf513abc_N65 | Sec9dcf513abc_N64 | tag_name | 11–11 | link |
| Sec9dcf513abc_N66 | Sec9dcf513abc_N64 | attribute | 11–11 | attribute  |
| Sec9dcf513abc_N67 | Sec9dcf513abc_N66 | attribute_name | 11–11 | href |
| Sec9dcf513abc_N68 | Sec9dcf513abc_N66 | quoted_attribute_value | 11–11 | quoted_attribute_value  |
| Sec9dcf513abc_N69 | Sec9dcf513abc_N68 | attribute_value | 11–11 | https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300..700;1,9..144,300..700&amp;amp;family=IBM+Plex+Mono:wght@400;500;600&amp;amp;family=Nunito+Sans:ital,wght@0,300;0,400;0,600;0,700;1,400&amp;amp;display=swap |
| Sec9dcf513abc_N70 | Sec9dcf513abc_N64 | attribute | 11–11 | attribute  |
| Sec9dcf513abc_N71 | Sec9dcf513abc_N70 | attribute_name | 11–11 | rel |
| Sec9dcf513abc_N72 | Sec9dcf513abc_N70 | quoted_attribute_value | 11–11 | quoted_attribute_value  |
| Sec9dcf513abc_N73 | Sec9dcf513abc_N72 | attribute_value | 11–11 | stylesheet |
| Sec9dcf513abc_N74 | Sec9dcf513abc_N10 | script_element | 12–12 | script_element  |
| Sec9dcf513abc_N75 | Sec9dcf513abc_N74 | start_tag | 12–12 | start_tag  |
| Sec9dcf513abc_N76 | Sec9dcf513abc_N75 | tag_name | 12–12 | script |
| Sec9dcf513abc_N77 | Sec9dcf513abc_N75 | attribute | 12–12 | attribute  |
| Sec9dcf513abc_N78 | Sec9dcf513abc_N77 | attribute_name | 12–12 | src |
| Sec9dcf513abc_N79 | Sec9dcf513abc_N77 | quoted_attribute_value | 12–12 | quoted_attribute_value  |
| Sec9dcf513abc_N80 | Sec9dcf513abc_N79 | attribute_value | 12–12 | https://cdn.tailwindcss.com |
| Sec9dcf513abc_N81 | Sec9dcf513abc_N74 | raw_text | 12–12 |  |
| Sec9dcf513abc_N82 | Sec9dcf513abc_N74 | end_tag | 12–12 | end_tag  |
| Sec9dcf513abc_N83 | Sec9dcf513abc_N82 | tag_name | 12–12 | script |
| Sec9dcf513abc_N84 | Sec9dcf513abc_N74 | program | 1–1 |  |
| Sec9dcf513abc_N85 | Sec9dcf513abc_N10 | script_element | 13–38 | script_element  |
| Sec9dcf513abc_N86 | Sec9dcf513abc_N85 | start_tag | 13–13 | start_tag  |
| Sec9dcf513abc_N87 | Sec9dcf513abc_N86 | tag_name | 13–13 | script |
| Sec9dcf513abc_N88 | Sec9dcf513abc_N85 | raw_text | 13–38 |      tailwind.config = {       darkMode: 'class',       theme: {         extend: {           colors: {             observatory: '#18161B',             'raised-charcoal': '#242127',             'surface-dim': '#141217',             'surface-bright': '#3b383e',             starlight: '#F5F2E9',             ash: '#B8B2BA',             hairline: '#514953',             'celestial-brass': '#C9AA60',             'celestial-brass-hover': '#DFBE72',             'brass-dim': 'rgba(201, 170, 96, 0.15)',           },           fontFamily: {             display: ['Fraunces', 'serif'],             body: ['"Nunito Sans"', 'sans-serif'],             mono: ['"IBM Plex Mono"', 'monospace'],           }         }       }     }    |
| Sec9dcf513abc_N89 | Sec9dcf513abc_N85 | end_tag | 38–38 | end_tag  |
| Sec9dcf513abc_N90 | Sec9dcf513abc_N89 | tag_name | 38–38 | script |
| Sec9dcf513abc_N91 | Sec9dcf513abc_N85 | program | 2–26 | program  |
| Sec9dcf513abc_N92 | Sec9dcf513abc_N91 | expression_statement | 2–25 | expression_statement  |
| Sec9dcf513abc_N93 | Sec9dcf513abc_N92 | assignment_expression | 2–25 | assignment_expression  |
| Sec9dcf513abc_N94 | Sec9dcf513abc_N93 | member_expression | 2–2 | member_expression  |
| Sec9dcf513abc_N95 | Sec9dcf513abc_N94 | identifier | 2–2 | tailwind |
| Sec9dcf513abc_N96 | Sec9dcf513abc_N94 | property_identifier | 2–2 | config |
| Sec9dcf513abc_N97 | Sec9dcf513abc_N93 | object | 2–25 | object  |
| Sec9dcf513abc_N98 | Sec9dcf513abc_N97 | pair | 3–3 | pair  |
| Sec9dcf513abc_N99 | Sec9dcf513abc_N98 | property_identifier | 3–3 | darkMode |
| Sec9dcf513abc_N100 | Sec9dcf513abc_N98 | string | 3–3 | string  |
| Sec9dcf513abc_N101 | Sec9dcf513abc_N100 | string_fragment | 3–3 | class |
| Sec9dcf513abc_N102 | Sec9dcf513abc_N97 | pair | 4–24 | pair  |
| Sec9dcf513abc_N103 | Sec9dcf513abc_N102 | property_identifier | 4–4 | theme |
| Sec9dcf513abc_N104 | Sec9dcf513abc_N102 | object | 4–24 | object  |
| Sec9dcf513abc_N105 | Sec9dcf513abc_N104 | pair | 5–23 | pair  |
| Sec9dcf513abc_N106 | Sec9dcf513abc_N105 | property_identifier | 5–5 | extend |
| Sec9dcf513abc_N107 | Sec9dcf513abc_N105 | object | 5–23 | object  |
| Sec9dcf513abc_N108 | Sec9dcf513abc_N107 | pair | 6–17 | pair  |
| Sec9dcf513abc_N109 | Sec9dcf513abc_N108 | property_identifier | 6–6 | colors |
| Sec9dcf513abc_N110 | Sec9dcf513abc_N108 | object | 6–17 | object  |
| Sec9dcf513abc_N111 | Sec9dcf513abc_N110 | pair | 7–7 | pair  |
| Sec9dcf513abc_N112 | Sec9dcf513abc_N111 | property_identifier | 7–7 | observatory |
| Sec9dcf513abc_N113 | Sec9dcf513abc_N111 | string | 7–7 | string  |
| Sec9dcf513abc_N114 | Sec9dcf513abc_N113 | string_fragment | 7–7 | #18161B |
| Sec9dcf513abc_N115 | Sec9dcf513abc_N110 | pair | 8–8 | pair  |
| Sec9dcf513abc_N116 | Sec9dcf513abc_N115 | string | 8–8 | string  |
| Sec9dcf513abc_N117 | Sec9dcf513abc_N116 | string_fragment | 8–8 | raised-charcoal |
| Sec9dcf513abc_N118 | Sec9dcf513abc_N115 | string | 8–8 | string  |
| Sec9dcf513abc_N119 | Sec9dcf513abc_N118 | string_fragment | 8–8 | #242127 |
| Sec9dcf513abc_N120 | Sec9dcf513abc_N110 | pair | 9–9 | pair  |
| Sec9dcf513abc_N121 | Sec9dcf513abc_N120 | string | 9–9 | string  |
| Sec9dcf513abc_N122 | Sec9dcf513abc_N121 | string_fragment | 9–9 | surface-dim |
| Sec9dcf513abc_N123 | Sec9dcf513abc_N120 | string | 9–9 | string  |
| Sec9dcf513abc_N124 | Sec9dcf513abc_N123 | string_fragment | 9–9 | #141217 |
| Sec9dcf513abc_N125 | Sec9dcf513abc_N110 | pair | 10–10 | pair  |
| Sec9dcf513abc_N126 | Sec9dcf513abc_N125 | string | 10–10 | string  |
| Sec9dcf513abc_N127 | Sec9dcf513abc_N126 | string_fragment | 10–10 | surface-bright |
| Sec9dcf513abc_N128 | Sec9dcf513abc_N125 | string | 10–10 | string  |
| Sec9dcf513abc_N129 | Sec9dcf513abc_N128 | string_fragment | 10–10 | #3b383e |
| Sec9dcf513abc_N130 | Sec9dcf513abc_N110 | pair | 11–11 | pair  |
| Sec9dcf513abc_N131 | Sec9dcf513abc_N130 | property_identifier | 11–11 | starlight |
| Sec9dcf513abc_N132 | Sec9dcf513abc_N130 | string | 11–11 | string  |
| Sec9dcf513abc_N133 | Sec9dcf513abc_N132 | string_fragment | 11–11 | #F5F2E9 |
| Sec9dcf513abc_N134 | Sec9dcf513abc_N110 | pair | 12–12 | pair  |
| Sec9dcf513abc_N135 | Sec9dcf513abc_N134 | property_identifier | 12–12 | ash |
| Sec9dcf513abc_N136 | Sec9dcf513abc_N134 | string | 12–12 | string  |
| Sec9dcf513abc_N137 | Sec9dcf513abc_N136 | string_fragment | 12–12 | #B8B2BA |
| Sec9dcf513abc_N138 | Sec9dcf513abc_N110 | pair | 13–13 | pair  |
| Sec9dcf513abc_N139 | Sec9dcf513abc_N138 | property_identifier | 13–13 | hairline |
| Sec9dcf513abc_N140 | Sec9dcf513abc_N138 | string | 13–13 | string  |
| Sec9dcf513abc_N141 | Sec9dcf513abc_N140 | string_fragment | 13–13 | #514953 |
| Sec9dcf513abc_N142 | Sec9dcf513abc_N110 | pair | 14–14 | pair  |
| Sec9dcf513abc_N143 | Sec9dcf513abc_N142 | string | 14–14 | string  |
| Sec9dcf513abc_N144 | Sec9dcf513abc_N143 | string_fragment | 14–14 | celestial-brass |
| Sec9dcf513abc_N145 | Sec9dcf513abc_N142 | string | 14–14 | string  |
| Sec9dcf513abc_N146 | Sec9dcf513abc_N145 | string_fragment | 14–14 | #C9AA60 |
| Sec9dcf513abc_N147 | Sec9dcf513abc_N110 | pair | 15–15 | pair  |
| Sec9dcf513abc_N148 | Sec9dcf513abc_N147 | string | 15–15 | string  |
| Sec9dcf513abc_N149 | Sec9dcf513abc_N148 | string_fragment | 15–15 | celestial-brass-hover |
| Sec9dcf513abc_N150 | Sec9dcf513abc_N147 | string | 15–15 | string  |
| Sec9dcf513abc_N151 | Sec9dcf513abc_N150 | string_fragment | 15–15 | #DFBE72 |
| Sec9dcf513abc_N152 | Sec9dcf513abc_N110 | pair | 16–16 | pair  |
| Sec9dcf513abc_N153 | Sec9dcf513abc_N152 | string | 16–16 | string  |
| Sec9dcf513abc_N154 | Sec9dcf513abc_N153 | string_fragment | 16–16 | brass-dim |
| Sec9dcf513abc_N155 | Sec9dcf513abc_N152 | string | 16–16 | string  |
| Sec9dcf513abc_N156 | Sec9dcf513abc_N155 | string_fragment | 16–16 | rgba(201, 170, 96, 0.15) |
| Sec9dcf513abc_N157 | Sec9dcf513abc_N107 | pair | 18–22 | pair  |
| Sec9dcf513abc_N158 | Sec9dcf513abc_N157 | property_identifier | 18–18 | fontFamily |
| Sec9dcf513abc_N159 | Sec9dcf513abc_N157 | object | 18–22 | object  |
| Sec9dcf513abc_N160 | Sec9dcf513abc_N159 | pair | 19–19 | pair  |
| Sec9dcf513abc_N161 | Sec9dcf513abc_N160 | property_identifier | 19–19 | display |
| Sec9dcf513abc_N162 | Sec9dcf513abc_N160 | array | 19–19 | array  |
| Sec9dcf513abc_N163 | Sec9dcf513abc_N162 | string | 19–19 | string  |
| Sec9dcf513abc_N164 | Sec9dcf513abc_N163 | string_fragment | 19–19 | Fraunces |
| Sec9dcf513abc_N165 | Sec9dcf513abc_N162 | string | 19–19 | string  |
| Sec9dcf513abc_N166 | Sec9dcf513abc_N165 | string_fragment | 19–19 | serif |
| Sec9dcf513abc_N167 | Sec9dcf513abc_N159 | pair | 20–20 | pair  |
| Sec9dcf513abc_N168 | Sec9dcf513abc_N167 | property_identifier | 20–20 | body |
| Sec9dcf513abc_N169 | Sec9dcf513abc_N167 | array | 20–20 | array  |
| Sec9dcf513abc_N170 | Sec9dcf513abc_N169 | string | 20–20 | string  |
| Sec9dcf513abc_N171 | Sec9dcf513abc_N170 | string_fragment | 20–20 | "Nunito Sans" |
| Sec9dcf513abc_N172 | Sec9dcf513abc_N169 | string | 20–20 | string  |
| Sec9dcf513abc_N173 | Sec9dcf513abc_N172 | string_fragment | 20–20 | sans-serif |
| Sec9dcf513abc_N174 | Sec9dcf513abc_N159 | pair | 21–21 | pair  |
| Sec9dcf513abc_N175 | Sec9dcf513abc_N174 | property_identifier | 21–21 | mono |
| Sec9dcf513abc_N176 | Sec9dcf513abc_N174 | array | 21–21 | array  |
| Sec9dcf513abc_N177 | Sec9dcf513abc_N176 | string | 21–21 | string  |
| Sec9dcf513abc_N178 | Sec9dcf513abc_N177 | string_fragment | 21–21 | "IBM Plex Mono" |
| Sec9dcf513abc_N179 | Sec9dcf513abc_N176 | string | 21–21 | string  |
| Sec9dcf513abc_N180 | Sec9dcf513abc_N179 | string_fragment | 21–21 | monospace |
| Sec9dcf513abc_N181 | Sec9dcf513abc_N10 | style_element | 39–64 | style_element  |
| Sec9dcf513abc_N182 | Sec9dcf513abc_N181 | start_tag | 39–39 | start_tag  |
| Sec9dcf513abc_N183 | Sec9dcf513abc_N182 | tag_name | 39–39 | style |
| Sec9dcf513abc_N184 | Sec9dcf513abc_N181 | raw_text | 39–64 |      body {       background-color: #18161B;       color: #F5F2E9;       font-family: 'Nunito Sans', sans-serif;       min-height: 100dvh;     }     .font-fraunces { font-family: 'Fraunces', serif; }     .font-mono { font-family: 'IBM Plex Mono', monospace; }          /* View switching logic */     .view-section { display: none; }     .view-section.active { display: block; }          /* Subtle focus states */     a:focus-visible, button:focus-visible, input:focus-visible, textarea:focus-visible {       outline: 2px solid #C9AA60;       outline-offset: 2px;     }          /* Custom scrollbar */     ::-webkit-scrollbar { width: 6px; height: 6px; }     ::-webkit-scrollbar-track { background: #18161B; }     ::-webkit-scrollbar-thumb { background: #514953; border-radius: 3px; }     ::-webkit-scrollbar-thumb:hover { background: #C9AA60; }    |
| Sec9dcf513abc_N185 | Sec9dcf513abc_N181 | end_tag | 64–64 | end_tag  |
| Sec9dcf513abc_N186 | Sec9dcf513abc_N185 | tag_name | 64–64 | style |
| Sec9dcf513abc_N187 | Sec9dcf513abc_N10 | end_tag | 65–65 | end_tag  |
| Sec9dcf513abc_N188 | Sec9dcf513abc_N187 | tag_name | 65–65 | head |
| Sec9dcf513abc_N189 | Sec9dcf513abc_N3 | element | 66–623 | element  |
| Sec9dcf513abc_N190 | Sec9dcf513abc_N189 | start_tag | 66–66 | start_tag  |
| Sec9dcf513abc_N191 | Sec9dcf513abc_N190 | tag_name | 66–66 | body |
| Sec9dcf513abc_N192 | Sec9dcf513abc_N190 | attribute | 66–66 | attribute  |
| Sec9dcf513abc_N193 | Sec9dcf513abc_N192 | attribute_name | 66–66 | class |
| Sec9dcf513abc_N194 | Sec9dcf513abc_N192 | quoted_attribute_value | 66–66 | quoted_attribute_value  |
| Sec9dcf513abc_N195 | Sec9dcf513abc_N194 | attribute_value | 66–66 | bg-observatory text-starlight antialiased selection:bg-celestial-brass selection:text-observatory flex flex-col min-h-screen |
| Sec9dcf513abc_N196 | Sec9dcf513abc_N189 | comment | 67–67 | &lt;!-- TOP HEADER / BANNER --&gt; |
| Sec9dcf513abc_N197 | Sec9dcf513abc_N189 | element | 68–99 | element  |
| Sec9dcf513abc_N198 | Sec9dcf513abc_N197 | start_tag | 68–68 | start_tag  |
| Sec9dcf513abc_N199 | Sec9dcf513abc_N198 | tag_name | 68–68 | header |
| Sec9dcf513abc_N200 | Sec9dcf513abc_N198 | attribute | 68–68 | attribute  |
| Sec9dcf513abc_N201 | Sec9dcf513abc_N200 | attribute_name | 68–68 | class |
| Sec9dcf513abc_N202 | Sec9dcf513abc_N200 | quoted_attribute_value | 68–68 | quoted_attribute_value  |
| Sec9dcf513abc_N203 | Sec9dcf513abc_N202 | attribute_value | 68–68 | border-b border-hairline/60 bg-surface-dim/90 sticky top-0 z-40 backdrop-blur-md |
| Sec9dcf513abc_N204 | Sec9dcf513abc_N197 | element | 69–98 | element  |
| Sec9dcf513abc_N205 | Sec9dcf513abc_N204 | start_tag | 69–69 | start_tag  |
| Sec9dcf513abc_N206 | Sec9dcf513abc_N205 | tag_name | 69–69 | div |
| Sec9dcf513abc_N207 | Sec9dcf513abc_N205 | attribute | 69–69 | attribute  |
| Sec9dcf513abc_N208 | Sec9dcf513abc_N207 | attribute_name | 69–69 | class |
| Sec9dcf513abc_N209 | Sec9dcf513abc_N207 | quoted_attribute_value | 69–69 | quoted_attribute_value  |
| Sec9dcf513abc_N210 | Sec9dcf513abc_N209 | attribute_value | 69–69 | max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between |
| Sec9dcf513abc_N211 | Sec9dcf513abc_N204 | comment | 70–70 | &lt;!-- Left: Brand / Studio Identity --&gt; |
| Sec9dcf513abc_N212 | Sec9dcf513abc_N204 | element | 71–82 | element  |
| Sec9dcf513abc_N213 | Sec9dcf513abc_N212 | start_tag | 71–71 | start_tag  |
| Sec9dcf513abc_N214 | Sec9dcf513abc_N213 | tag_name | 71–71 | div |
| Sec9dcf513abc_N215 | Sec9dcf513abc_N213 | attribute | 71–71 | attribute  |
| Sec9dcf513abc_N216 | Sec9dcf513abc_N215 | attribute_name | 71–71 | class |
| Sec9dcf513abc_N217 | Sec9dcf513abc_N215 | quoted_attribute_value | 71–71 | quoted_attribute_value  |
| Sec9dcf513abc_N218 | Sec9dcf513abc_N217 | attribute_value | 71–71 | flex items-center space-x-3 |
| Sec9dcf513abc_N219 | Sec9dcf513abc_N212 | element | 72–74 | element  |
| Sec9dcf513abc_N220 | Sec9dcf513abc_N219 | start_tag | 72–72 | start_tag  |
| Sec9dcf513abc_N221 | Sec9dcf513abc_N220 | tag_name | 72–72 | div |
| Sec9dcf513abc_N222 | Sec9dcf513abc_N220 | attribute | 72–72 | attribute  |
| Sec9dcf513abc_N223 | Sec9dcf513abc_N222 | attribute_name | 72–72 | class |
| Sec9dcf513abc_N224 | Sec9dcf513abc_N222 | quoted_attribute_value | 72–72 | quoted_attribute_value  |
| Sec9dcf513abc_N225 | Sec9dcf513abc_N224 | attribute_value | 72–72 | w-8 h-8 rounded-full border border-celestial-brass/50 overflow-hidden flex-shrink-0 bg-raised-charcoal |
| Sec9dcf513abc_N226 | Sec9dcf513abc_N219 | element | 73–73 | element  |
| Sec9dcf513abc_N227 | Sec9dcf513abc_N226 | self_closing_tag | 73–73 | self_closing_tag  |
| Sec9dcf513abc_N228 | Sec9dcf513abc_N227 | tag_name | 73–73 | img |
| Sec9dcf513abc_N229 | Sec9dcf513abc_N227 | attribute | 73–73 | attribute  |
| Sec9dcf513abc_N230 | Sec9dcf513abc_N229 | attribute_name | 73–73 | alt |
| Sec9dcf513abc_N231 | Sec9dcf513abc_N229 | quoted_attribute_value | 73–73 | quoted_attribute_value  |
| Sec9dcf513abc_N232 | Sec9dcf513abc_N231 | attribute_value | 73–73 | Natally Automaton Mascot |
| Sec9dcf513abc_N233 | Sec9dcf513abc_N227 | attribute | 73–73 | attribute  |
| Sec9dcf513abc_N234 | Sec9dcf513abc_N233 | attribute_name | 73–73 | class |
| Sec9dcf513abc_N235 | Sec9dcf513abc_N233 | quoted_attribute_value | 73–73 | quoted_attribute_value  |
| Sec9dcf513abc_N236 | Sec9dcf513abc_N235 | attribute_value | 73–73 | w-full h-full object-cover |
| Sec9dcf513abc_N237 | Sec9dcf513abc_N227 | attribute | 73–73 | attribute  |
| Sec9dcf513abc_N238 | Sec9dcf513abc_N237 | attribute_name | 73–73 | onerror |
| Sec9dcf513abc_N239 | Sec9dcf513abc_N237 | quoted_attribute_value | 73–73 | quoted_attribute_value  |
| Sec9dcf513abc_N240 | Sec9dcf513abc_N239 | attribute_value | 73–73 | this.src='https://lh3.googleusercontent.com/aida-public/AB6AXuCrfhL4lciCS2D4SfH-I-Aq0qL6NisgPYvi8x0pRtoqm0ZT-d8DZ3OiEaetjs5aI6RcGmyzIEtUDxgO7_ke3koF5-QzSocUK-zRvNfNbssqYzFQsKrwpdaw8gTTc1ps8FBv401bQfGhzP2rbE6JEcZieIy58sIGyoSB5Eco9eB1AdxjP5bHxO8HY-EZMKACzNBCGQh6blsU9a75CNgoqxX2h-uOp59BV_C7bbgi42rkaNBJBBZ2Z7wIRxEYVpgFod3LF91tPeOSRGM' |
| Sec9dcf513abc_N241 | Sec9dcf513abc_N227 | attribute | 73–73 | attribute  |
| Sec9dcf513abc_N242 | Sec9dcf513abc_N241 | attribute_name | 73–73 | src |
| Sec9dcf513abc_N243 | Sec9dcf513abc_N241 | quoted_attribute_value | 73–73 | quoted_attribute_value  |
| Sec9dcf513abc_N244 | Sec9dcf513abc_N243 | attribute_value | 73–73 | https://www.gstatic.com/labs-code/stitch/stitch-placeholder-300x300.svg |
| Sec9dcf513abc_N245 | Sec9dcf513abc_N219 | end_tag | 74–74 | end_tag  |
| Sec9dcf513abc_N246 | Sec9dcf513abc_N245 | tag_name | 74–74 | div |
| Sec9dcf513abc_N247 | Sec9dcf513abc_N212 | element | 75–81 | element  |
| Sec9dcf513abc_N248 | Sec9dcf513abc_N247 | start_tag | 75–75 | start_tag  |
| Sec9dcf513abc_N249 | Sec9dcf513abc_N248 | tag_name | 75–75 | div |
| Sec9dcf513abc_N250 | Sec9dcf513abc_N248 | attribute | 75–75 | attribute  |
| Sec9dcf513abc_N251 | Sec9dcf513abc_N250 | attribute_name | 75–75 | class |
| Sec9dcf513abc_N252 | Sec9dcf513abc_N250 | quoted_attribute_value | 75–75 | quoted_attribute_value  |
| Sec9dcf513abc_N253 | Sec9dcf513abc_N252 | attribute_value | 75–75 | flex flex-col |
| Sec9dcf513abc_N254 | Sec9dcf513abc_N247 | element | 76–79 | element  |
| Sec9dcf513abc_N255 | Sec9dcf513abc_N254 | start_tag | 76–76 | start_tag  |
| Sec9dcf513abc_N256 | Sec9dcf513abc_N255 | tag_name | 76–76 | div |
| Sec9dcf513abc_N257 | Sec9dcf513abc_N255 | attribute | 76–76 | attribute  |
| Sec9dcf513abc_N258 | Sec9dcf513abc_N257 | attribute_name | 76–76 | class |
| Sec9dcf513abc_N259 | Sec9dcf513abc_N257 | quoted_attribute_value | 76–76 | quoted_attribute_value  |
| Sec9dcf513abc_N260 | Sec9dcf513abc_N259 | attribute_value | 76–76 | flex items-center space-x-2 |
| Sec9dcf513abc_N261 | Sec9dcf513abc_N254 | element | 77–77 | element  |
| Sec9dcf513abc_N262 | Sec9dcf513abc_N261 | start_tag | 77–77 | start_tag  |
| Sec9dcf513abc_N263 | Sec9dcf513abc_N262 | tag_name | 77–77 | span |
| Sec9dcf513abc_N264 | Sec9dcf513abc_N262 | attribute | 77–77 | attribute  |
| Sec9dcf513abc_N265 | Sec9dcf513abc_N264 | attribute_name | 77–77 | class |
| Sec9dcf513abc_N266 | Sec9dcf513abc_N264 | quoted_attribute_value | 77–77 | quoted_attribute_value  |
| Sec9dcf513abc_N267 | Sec9dcf513abc_N266 | attribute_value | 77–77 | font-display font-semibold tracking-wide text-starlight text-lg leading-tight |
| Sec9dcf513abc_N268 | Sec9dcf513abc_N261 | text | 77–77 | Natally |
| Sec9dcf513abc_N269 | Sec9dcf513abc_N261 | end_tag | 77–77 | end_tag  |
| Sec9dcf513abc_N270 | Sec9dcf513abc_N269 | tag_name | 77–77 | span |
| Sec9dcf513abc_N271 | Sec9dcf513abc_N254 | element | 78–78 | element  |
| Sec9dcf513abc_N272 | Sec9dcf513abc_N271 | start_tag | 78–78 | start_tag  |
| Sec9dcf513abc_N273 | Sec9dcf513abc_N272 | tag_name | 78–78 | span |
| Sec9dcf513abc_N274 | Sec9dcf513abc_N272 | attribute | 78–78 | attribute  |
| Sec9dcf513abc_N275 | Sec9dcf513abc_N274 | attribute_name | 78–78 | class |
| Sec9dcf513abc_N276 | Sec9dcf513abc_N274 | quoted_attribute_value | 78–78 | quoted_attribute_value  |
| Sec9dcf513abc_N277 | Sec9dcf513abc_N276 | attribute_value | 78–78 | text-[10px] font-mono uppercase px-1.5 py-0.5 rounded border border-hairline text-ash |
| Sec9dcf513abc_N278 | Sec9dcf513abc_N271 | text | 78–78 | natally-ai-studio |
| Sec9dcf513abc_N279 | Sec9dcf513abc_N271 | end_tag | 78–78 | end_tag  |
| Sec9dcf513abc_N280 | Sec9dcf513abc_N279 | tag_name | 78–78 | span |
| Sec9dcf513abc_N281 | Sec9dcf513abc_N254 | end_tag | 79–79 | end_tag  |
| Sec9dcf513abc_N282 | Sec9dcf513abc_N281 | tag_name | 79–79 | div |
| Sec9dcf513abc_N283 | Sec9dcf513abc_N247 | element | 80–80 | element  |
| Sec9dcf513abc_N284 | Sec9dcf513abc_N283 | start_tag | 80–80 | start_tag  |
| Sec9dcf513abc_N285 | Sec9dcf513abc_N284 | tag_name | 80–80 | span |
| Sec9dcf513abc_N286 | Sec9dcf513abc_N284 | attribute | 80–80 | attribute  |
| Sec9dcf513abc_N287 | Sec9dcf513abc_N286 | attribute_name | 80–80 | class |
| Sec9dcf513abc_N288 | Sec9dcf513abc_N286 | quoted_attribute_value | 80–80 | quoted_attribute_value  |
| Sec9dcf513abc_N289 | Sec9dcf513abc_N288 | attribute_value | 80–80 | text-[11px] text-ash font-mono |
| Sec9dcf513abc_N290 | Sec9dcf513abc_N283 | text | 80–80 | codex/revenuecat-alby-preview |
| Sec9dcf513abc_N291 | Sec9dcf513abc_N283 | end_tag | 80–80 | end_tag  |
| Sec9dcf513abc_N292 | Sec9dcf513abc_N291 | tag_name | 80–80 | span |
| Sec9dcf513abc_N293 | Sec9dcf513abc_N247 | end_tag | 81–81 | end_tag  |
| Sec9dcf513abc_N294 | Sec9dcf513abc_N293 | tag_name | 81–81 | div |
| Sec9dcf513abc_N295 | Sec9dcf513abc_N212 | end_tag | 82–82 | end_tag  |
| Sec9dcf513abc_N296 | Sec9dcf513abc_N295 | tag_name | 82–82 | div |
| Sec9dcf513abc_N297 | Sec9dcf513abc_N204 | comment | 83–83 | &lt;!-- Center: Truthful Status Banner --&gt; |
| Sec9dcf513abc_N298 | Sec9dcf513abc_N204 | element | 84–87 | element  |
| Sec9dcf513abc_N299 | Sec9dcf513abc_N298 | start_tag | 84–84 | start_tag  |
| Sec9dcf513abc_N300 | Sec9dcf513abc_N299 | tag_name | 84–84 | div |
| Sec9dcf513abc_N301 | Sec9dcf513abc_N299 | attribute | 84–84 | attribute  |
| Sec9dcf513abc_N302 | Sec9dcf513abc_N301 | attribute_name | 84–84 | class |
| Sec9dcf513abc_N303 | Sec9dcf513abc_N301 | quoted_attribute_value | 84–84 | quoted_attribute_value  |
| Sec9dcf513abc_N304 | Sec9dcf513abc_N303 | attribute_value | 84–84 | hidden md:flex items-center space-x-2 px-3 py-1 rounded-full border border-hairline bg-raised-charcoal/70 |
| Sec9dcf513abc_N305 | Sec9dcf513abc_N298 | element | 85–85 | element  |
| Sec9dcf513abc_N306 | Sec9dcf513abc_N305 | start_tag | 85–85 | start_tag  |
| Sec9dcf513abc_N307 | Sec9dcf513abc_N306 | tag_name | 85–85 | span |
| Sec9dcf513abc_N308 | Sec9dcf513abc_N306 | attribute | 85–85 | attribute  |
| Sec9dcf513abc_N309 | Sec9dcf513abc_N308 | attribute_name | 85–85 | class |
| Sec9dcf513abc_N310 | Sec9dcf513abc_N308 | quoted_attribute_value | 85–85 | quoted_attribute_value  |
| Sec9dcf513abc_N311 | Sec9dcf513abc_N310 | attribute_value | 85–85 | w-2 h-2 rounded-full bg-celestial-brass animate-pulse |
| Sec9dcf513abc_N312 | Sec9dcf513abc_N305 | end_tag | 85–85 | end_tag  |
| Sec9dcf513abc_N313 | Sec9dcf513abc_N312 | tag_name | 85–85 | span |
| Sec9dcf513abc_N314 | Sec9dcf513abc_N298 | element | 86–86 | element  |
| Sec9dcf513abc_N315 | Sec9dcf513abc_N314 | start_tag | 86–86 | start_tag  |
| Sec9dcf513abc_N316 | Sec9dcf513abc_N315 | tag_name | 86–86 | span |
| Sec9dcf513abc_N317 | Sec9dcf513abc_N315 | attribute | 86–86 | attribute  |
| Sec9dcf513abc_N318 | Sec9dcf513abc_N317 | attribute_name | 86–86 | class |
| Sec9dcf513abc_N319 | Sec9dcf513abc_N317 | quoted_attribute_value | 86–86 | quoted_attribute_value  |
| Sec9dcf513abc_N320 | Sec9dcf513abc_N319 | attribute_value | 86–86 | text-xs font-mono text-ash tracking-tight |
| Sec9dcf513abc_N321 | Sec9dcf513abc_N314 | text | 86–86 | Branch preview — payments not connected |
| Sec9dcf513abc_N322 | Sec9dcf513abc_N314 | end_tag | 86–86 | end_tag  |
| Sec9dcf513abc_N323 | Sec9dcf513abc_N322 | tag_name | 86–86 | span |
| Sec9dcf513abc_N324 | Sec9dcf513abc_N298 | end_tag | 87–87 | end_tag  |
| Sec9dcf513abc_N325 | Sec9dcf513abc_N324 | tag_name | 87–87 | div |
| Sec9dcf513abc_N326 | Sec9dcf513abc_N204 | comment | 88–88 | &lt;!-- Right: User Name Clickable Trigger --&gt; |
| Sec9dcf513abc_N327 | Sec9dcf513abc_N204 | element | 89–97 | element  |
| Sec9dcf513abc_N328 | Sec9dcf513abc_N327 | start_tag | 89–89 | start_tag  |
| Sec9dcf513abc_N329 | Sec9dcf513abc_N328 | tag_name | 89–89 | div |
| Sec9dcf513abc_N330 | Sec9dcf513abc_N328 | attribute | 89–89 | attribute  |
| Sec9dcf513abc_N331 | Sec9dcf513abc_N330 | attribute_name | 89–89 | class |
| Sec9dcf513abc_N332 | Sec9dcf513abc_N330 | quoted_attribute_value | 89–89 | quoted_attribute_value  |
| Sec9dcf513abc_N333 | Sec9dcf513abc_N332 | attribute_value | 89–89 | flex items-center space-x-3 |
| Sec9dcf513abc_N334 | Sec9dcf513abc_N327 | element | 90–96 | element  |
| Sec9dcf513abc_N335 | Sec9dcf513abc_N334 | start_tag | 90–90 | start_tag  |
| Sec9dcf513abc_N336 | Sec9dcf513abc_N335 | tag_name | 90–90 | button |
| Sec9dcf513abc_N337 | Sec9dcf513abc_N335 | attribute | 90–90 | attribute  |
| Sec9dcf513abc_N338 | Sec9dcf513abc_N337 | attribute_name | 90–90 | aria-label |
| Sec9dcf513abc_N339 | Sec9dcf513abc_N337 | quoted_attribute_value | 90–90 | quoted_attribute_value  |
| Sec9dcf513abc_N340 | Sec9dcf513abc_N339 | attribute_value | 90–90 | Open profile account management |
| Sec9dcf513abc_N341 | Sec9dcf513abc_N335 | attribute | 90–90 | attribute  |
| Sec9dcf513abc_N342 | Sec9dcf513abc_N341 | attribute_name | 90–90 | class |
| Sec9dcf513abc_N343 | Sec9dcf513abc_N341 | quoted_attribute_value | 90–90 | quoted_attribute_value  |
| Sec9dcf513abc_N344 | Sec9dcf513abc_N343 | attribute_value | 90–90 | flex items-center space-x-2 text-sm text-starlight hover:text-celestial-brass transition-colors py-1.5 px-3 rounded-md hover:bg-raised-charcoal border border-transparent hover:border-hairline |
| Sec9dcf513abc_N345 | Sec9dcf513abc_N335 | attribute | 90–90 | attribute  |
| Sec9dcf513abc_N346 | Sec9dcf513abc_N345 | attribute_name | 90–90 | id |
| Sec9dcf513abc_N347 | Sec9dcf513abc_N345 | quoted_attribute_value | 90–90 | quoted_attribute_value  |
| Sec9dcf513abc_N348 | Sec9dcf513abc_N347 | attribute_value | 90–90 | profile-name |
| Sec9dcf513abc_N349 | Sec9dcf513abc_N335 | attribute | 90–90 | attribute  |
| Sec9dcf513abc_N350 | Sec9dcf513abc_N349 | attribute_name | 90–90 | onclick |
| Sec9dcf513abc_N351 | Sec9dcf513abc_N349 | quoted_attribute_value | 90–90 | quoted_attribute_value  |
| Sec9dcf513abc_N352 | Sec9dcf513abc_N351 | attribute_value | 90–90 | switchView('profile') |
| Sec9dcf513abc_N353 | Sec9dcf513abc_N334 | element | 91–91 | element  |
| Sec9dcf513abc_N354 | Sec9dcf513abc_N353 | start_tag | 91–91 | start_tag  |
| Sec9dcf513abc_N355 | Sec9dcf513abc_N354 | tag_name | 91–91 | span |
| Sec9dcf513abc_N356 | Sec9dcf513abc_N354 | attribute | 91–91 | attribute  |
| Sec9dcf513abc_N357 | Sec9dcf513abc_N356 | attribute_name | 91–91 | class |
| Sec9dcf513abc_N358 | Sec9dcf513abc_N356 | quoted_attribute_value | 91–91 | quoted_attribute_value  |
| Sec9dcf513abc_N359 | Sec9dcf513abc_N358 | attribute_value | 91–91 | w-2 h-2 rounded-full bg-celestial-brass/80 |
| Sec9dcf513abc_N360 | Sec9dcf513abc_N353 | end_tag | 91–91 | end_tag  |
| Sec9dcf513abc_N361 | Sec9dcf513abc_N360 | tag_name | 91–91 | span |
| Sec9dcf513abc_N362 | Sec9dcf513abc_N334 | element | 92–92 | element  |
| Sec9dcf513abc_N363 | Sec9dcf513abc_N362 | start_tag | 92–92 | start_tag  |
| Sec9dcf513abc_N364 | Sec9dcf513abc_N363 | tag_name | 92–92 | span |
| Sec9dcf513abc_N365 | Sec9dcf513abc_N363 | attribute | 92–92 | attribute  |
| Sec9dcf513abc_N366 | Sec9dcf513abc_N365 | attribute_name | 92–92 | class |
| Sec9dcf513abc_N367 | Sec9dcf513abc_N365 | quoted_attribute_value | 92–92 | quoted_attribute_value  |
| Sec9dcf513abc_N368 | Sec9dcf513abc_N367 | attribute_value | 92–92 | font-medium underline underline-offset-4 decoration-celestial-brass/50 |
| Sec9dcf513abc_N369 | Sec9dcf513abc_N362 | text | 92–92 | Reading preview |
| Sec9dcf513abc_N370 | Sec9dcf513abc_N362 | end_tag | 92–92 | end_tag  |
| Sec9dcf513abc_N371 | Sec9dcf513abc_N370 | tag_name | 92–92 | span |
| Sec9dcf513abc_N372 | Sec9dcf513abc_N334 | element | 93–95 | element  |
| Sec9dcf513abc_N373 | Sec9dcf513abc_N372 | start_tag | 93–93 | start_tag  |
| Sec9dcf513abc_N374 | Sec9dcf513abc_N373 | tag_name | 93–93 | svg |
| Sec9dcf513abc_N375 | Sec9dcf513abc_N373 | attribute | 93–93 | attribute  |
| Sec9dcf513abc_N376 | Sec9dcf513abc_N375 | attribute_name | 93–93 | class |
| Sec9dcf513abc_N377 | Sec9dcf513abc_N375 | quoted_attribute_value | 93–93 | quoted_attribute_value  |
| Sec9dcf513abc_N378 | Sec9dcf513abc_N377 | attribute_value | 93–93 | w-4 h-4 text-ash |
| Sec9dcf513abc_N379 | Sec9dcf513abc_N373 | attribute | 93–93 | attribute  |
| Sec9dcf513abc_N380 | Sec9dcf513abc_N379 | attribute_name | 93–93 | fill |
| Sec9dcf513abc_N381 | Sec9dcf513abc_N379 | quoted_attribute_value | 93–93 | quoted_attribute_value  |
| Sec9dcf513abc_N382 | Sec9dcf513abc_N381 | attribute_value | 93–93 | none |
| Sec9dcf513abc_N383 | Sec9dcf513abc_N373 | attribute | 93–93 | attribute  |
| Sec9dcf513abc_N384 | Sec9dcf513abc_N383 | attribute_name | 93–93 | stroke |
| Sec9dcf513abc_N385 | Sec9dcf513abc_N383 | quoted_attribute_value | 93–93 | quoted_attribute_value  |
| Sec9dcf513abc_N386 | Sec9dcf513abc_N385 | attribute_value | 93–93 | currentColor |
| Sec9dcf513abc_N387 | Sec9dcf513abc_N373 | attribute | 93–93 | attribute  |
| Sec9dcf513abc_N388 | Sec9dcf513abc_N387 | attribute_name | 93–93 | viewbox |
| Sec9dcf513abc_N389 | Sec9dcf513abc_N387 | quoted_attribute_value | 93–93 | quoted_attribute_value  |
| Sec9dcf513abc_N390 | Sec9dcf513abc_N389 | attribute_value | 93–93 | 0 0 24 24 |
| Sec9dcf513abc_N391 | Sec9dcf513abc_N372 | element | 94–94 | element  |
| Sec9dcf513abc_N392 | Sec9dcf513abc_N391 | start_tag | 94–94 | start_tag  |
| Sec9dcf513abc_N393 | Sec9dcf513abc_N392 | tag_name | 94–94 | path |
| Sec9dcf513abc_N394 | Sec9dcf513abc_N392 | attribute | 94–94 | attribute  |
| Sec9dcf513abc_N395 | Sec9dcf513abc_N394 | attribute_name | 94–94 | d |
| Sec9dcf513abc_N396 | Sec9dcf513abc_N394 | quoted_attribute_value | 94–94 | quoted_attribute_value  |
| Sec9dcf513abc_N397 | Sec9dcf513abc_N396 | attribute_value | 94–94 | M19 9l-7 7-7-7 |
| Sec9dcf513abc_N398 | Sec9dcf513abc_N392 | attribute | 94–94 | attribute  |
| Sec9dcf513abc_N399 | Sec9dcf513abc_N398 | attribute_name | 94–94 | stroke-linecap |
| Sec9dcf513abc_N400 | Sec9dcf513abc_N398 | quoted_attribute_value | 94–94 | quoted_attribute_value  |
| Sec9dcf513abc_N401 | Sec9dcf513abc_N400 | attribute_value | 94–94 | round |
| Sec9dcf513abc_N402 | Sec9dcf513abc_N392 | attribute | 94–94 | attribute  |
| Sec9dcf513abc_N403 | Sec9dcf513abc_N402 | attribute_name | 94–94 | stroke-linejoin |
| Sec9dcf513abc_N404 | Sec9dcf513abc_N402 | quoted_attribute_value | 94–94 | quoted_attribute_value  |
| Sec9dcf513abc_N405 | Sec9dcf513abc_N404 | attribute_value | 94–94 | round |
| Sec9dcf513abc_N406 | Sec9dcf513abc_N392 | attribute | 94–94 | attribute  |
| Sec9dcf513abc_N407 | Sec9dcf513abc_N406 | attribute_name | 94–94 | stroke-width |
| Sec9dcf513abc_N408 | Sec9dcf513abc_N406 | quoted_attribute_value | 94–94 | quoted_attribute_value  |
| Sec9dcf513abc_N409 | Sec9dcf513abc_N408 | attribute_value | 94–94 | 2 |
| Sec9dcf513abc_N410 | Sec9dcf513abc_N391 | end_tag | 94–94 | end_tag  |
| Sec9dcf513abc_N411 | Sec9dcf513abc_N410 | tag_name | 94–94 | path |
| Sec9dcf513abc_N412 | Sec9dcf513abc_N372 | end_tag | 95–95 | end_tag  |
| Sec9dcf513abc_N413 | Sec9dcf513abc_N412 | tag_name | 95–95 | svg |
| Sec9dcf513abc_N414 | Sec9dcf513abc_N334 | end_tag | 96–96 | end_tag  |
| Sec9dcf513abc_N415 | Sec9dcf513abc_N414 | tag_name | 96–96 | button |
| Sec9dcf513abc_N416 | Sec9dcf513abc_N327 | end_tag | 97–97 | end_tag  |
| Sec9dcf513abc_N417 | Sec9dcf513abc_N416 | tag_name | 97–97 | div |
| Sec9dcf513abc_N418 | Sec9dcf513abc_N204 | end_tag | 98–98 | end_tag  |
| Sec9dcf513abc_N419 | Sec9dcf513abc_N418 | tag_name | 98–98 | div |
| Sec9dcf513abc_N420 | Sec9dcf513abc_N197 | end_tag | 99–99 | end_tag  |
| Sec9dcf513abc_N421 | Sec9dcf513abc_N420 | tag_name | 99–99 | header |
| Sec9dcf513abc_N422 | Sec9dcf513abc_N189 | comment | 100–100 | &lt;!-- LIVE ACCESSIBILITY ANNOUNCER --&gt; |
| Sec9dcf513abc_N423 | Sec9dcf513abc_N189 | element | 101–103 | element  |
| Sec9dcf513abc_N424 | Sec9dcf513abc_N423 | start_tag | 101–101 | start_tag  |
| Sec9dcf513abc_N425 | Sec9dcf513abc_N424 | tag_name | 101–101 | div |
| Sec9dcf513abc_N426 | Sec9dcf513abc_N424 | attribute | 101–101 | attribute  |
| Sec9dcf513abc_N427 | Sec9dcf513abc_N426 | attribute_name | 101–101 | aria-live |
| Sec9dcf513abc_N428 | Sec9dcf513abc_N426 | quoted_attribute_value | 101–101 | quoted_attribute_value  |
| Sec9dcf513abc_N429 | Sec9dcf513abc_N428 | attribute_value | 101–101 | polite |
| Sec9dcf513abc_N430 | Sec9dcf513abc_N424 | attribute | 101–101 | attribute  |
| Sec9dcf513abc_N431 | Sec9dcf513abc_N430 | attribute_name | 101–101 | class |
| Sec9dcf513abc_N432 | Sec9dcf513abc_N430 | quoted_attribute_value | 101–101 | quoted_attribute_value  |
| Sec9dcf513abc_N433 | Sec9dcf513abc_N432 | attribute_value | 101–101 | sr-only |
| Sec9dcf513abc_N434 | Sec9dcf513abc_N424 | attribute | 101–101 | attribute  |
| Sec9dcf513abc_N435 | Sec9dcf513abc_N434 | attribute_name | 101–101 | id |
| Sec9dcf513abc_N436 | Sec9dcf513abc_N434 | quoted_attribute_value | 101–101 | quoted_attribute_value  |
| Sec9dcf513abc_N437 | Sec9dcf513abc_N436 | attribute_value | 101–101 | preview-status |
| Sec9dcf513abc_N438 | Sec9dcf513abc_N424 | attribute | 101–101 | attribute  |
| Sec9dcf513abc_N439 | Sec9dcf513abc_N438 | attribute_name | 101–101 | role |
| Sec9dcf513abc_N440 | Sec9dcf513abc_N438 | quoted_attribute_value | 101–101 | quoted_attribute_value  |
| Sec9dcf513abc_N441 | Sec9dcf513abc_N440 | attribute_value | 101–101 | status |
| Sec9dcf513abc_N442 | Sec9dcf513abc_N423 | text | 102–102 | Profile view active. Payments not connected in this preview. |
| Sec9dcf513abc_N443 | Sec9dcf513abc_N423 | end_tag | 103–103 | end_tag  |
| Sec9dcf513abc_N444 | Sec9dcf513abc_N443 | tag_name | 103–103 | div |
| Sec9dcf513abc_N445 | Sec9dcf513abc_N189 | comment | 104–104 | &lt;!-- MAIN EDITORIAL LAYOUT --&gt; |
| Sec9dcf513abc_N446 | Sec9dcf513abc_N189 | element | 105–559 | element  |
| Sec9dcf513abc_N447 | Sec9dcf513abc_N446 | start_tag | 105–105 | start_tag  |
| Sec9dcf513abc_N448 | Sec9dcf513abc_N447 | tag_name | 105–105 | main |
| Sec9dcf513abc_N449 | Sec9dcf513abc_N447 | attribute | 105–105 | attribute  |
| Sec9dcf513abc_N450 | Sec9dcf513abc_N449 | attribute_name | 105–105 | class |
| Sec9dcf513abc_N451 | Sec9dcf513abc_N449 | quoted_attribute_value | 105–105 | quoted_attribute_value  |
| Sec9dcf513abc_N452 | Sec9dcf513abc_N451 | attribute_value | 105–105 | flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 lg:py-10 |
| Sec9dcf513abc_N453 | Sec9dcf513abc_N446 | element | 106–558 | element  |
| Sec9dcf513abc_N454 | Sec9dcf513abc_N453 | start_tag | 106–106 | start_tag  |
| Sec9dcf513abc_N455 | Sec9dcf513abc_N454 | tag_name | 106–106 | div |
| Sec9dcf513abc_N456 | Sec9dcf513abc_N454 | attribute | 106–106 | attribute  |
| Sec9dcf513abc_N457 | Sec9dcf513abc_N456 | attribute_name | 106–106 | class |
| Sec9dcf513abc_N458 | Sec9dcf513abc_N456 | quoted_attribute_value | 106–106 | quoted_attribute_value  |
| Sec9dcf513abc_N459 | Sec9dcf513abc_N458 | attribute_value | 106–106 | grid grid-cols-1 lg:grid-cols-12 gap-8 items-start |
| Sec9dcf513abc_N460 | Sec9dcf513abc_N453 | comment | 107–107 | &lt;!-- LEFT SIDEBAR: ACCOUNT NAVIGATION (Desktop) / TOP ACCORDION (Mobile) --&gt; |
| Sec9dcf513abc_N461 | Sec9dcf513abc_N453 | element | 108–181 | element  |
| Sec9dcf513abc_N462 | Sec9dcf513abc_N461 | start_tag | 108–108 | start_tag  |
| Sec9dcf513abc_N463 | Sec9dcf513abc_N462 | tag_name | 108–108 | aside |
| Sec9dcf513abc_N464 | Sec9dcf513abc_N462 | attribute | 108–108 | attribute  |
| Sec9dcf513abc_N465 | Sec9dcf513abc_N464 | attribute_name | 108–108 | class |
| Sec9dcf513abc_N466 | Sec9dcf513abc_N464 | quoted_attribute_value | 108–108 | quoted_attribute_value  |
| Sec9dcf513abc_N467 | Sec9dcf513abc_N466 | attribute_value | 108–108 | lg:col-span-4 xl:col-span-3 space-y-6 |
| Sec9dcf513abc_N468 | Sec9dcf513abc_N461 | comment | 109–109 | &lt;!-- Companion Cameo Card --&gt; |
| Sec9dcf513abc_N469 | Sec9dcf513abc_N461 | element | 110–121 | element  |
| Sec9dcf513abc_N470 | Sec9dcf513abc_N469 | start_tag | 110–110 | start_tag  |
| Sec9dcf513abc_N471 | Sec9dcf513abc_N470 | tag_name | 110–110 | div |
| Sec9dcf513abc_N472 | Sec9dcf513abc_N470 | attribute | 110–110 | attribute  |
| Sec9dcf513abc_N473 | Sec9dcf513abc_N472 | attribute_name | 110–110 | class |
| Sec9dcf513abc_N474 | Sec9dcf513abc_N472 | quoted_attribute_value | 110–110 | quoted_attribute_value  |
| Sec9dcf513abc_N475 | Sec9dcf513abc_N474 | attribute_value | 110–110 | p-5 rounded-xl border border-hairline bg-raised-charcoal/80 flex items-center space-x-4 |
| Sec9dcf513abc_N476 | Sec9dcf513abc_N469 | element | 111–113 | element  |
| Sec9dcf513abc_N477 | Sec9dcf513abc_N476 | start_tag | 111–111 | start_tag  |
| Sec9dcf513abc_N478 | Sec9dcf513abc_N477 | tag_name | 111–111 | div |
| Sec9dcf513abc_N479 | Sec9dcf513abc_N477 | attribute | 111–111 | attribute  |
| Sec9dcf513abc_N480 | Sec9dcf513abc_N479 | attribute_name | 111–111 | class |
| Sec9dcf513abc_N481 | Sec9dcf513abc_N479 | quoted_attribute_value | 111–111 | quoted_attribute_value  |
| Sec9dcf513abc_N482 | Sec9dcf513abc_N481 | attribute_value | 111–111 | w-14 h-14 rounded-full border-2 border-celestial-brass/60 overflow-hidden flex-shrink-0 bg-surface-dim |
| Sec9dcf513abc_N483 | Sec9dcf513abc_N476 | element | 112–112 | element  |
| Sec9dcf513abc_N484 | Sec9dcf513abc_N483 | self_closing_tag | 112–112 | self_closing_tag  |
| Sec9dcf513abc_N485 | Sec9dcf513abc_N484 | tag_name | 112–112 | img |
| Sec9dcf513abc_N486 | Sec9dcf513abc_N484 | attribute | 112–112 | attribute  |
| Sec9dcf513abc_N487 | Sec9dcf513abc_N486 | attribute_name | 112–112 | alt |
| Sec9dcf513abc_N488 | Sec9dcf513abc_N486 | quoted_attribute_value | 112–112 | quoted_attribute_value  |
| Sec9dcf513abc_N489 | Sec9dcf513abc_N488 | attribute_value | 112–112 | Natally Mascot in Plum Velvet Turban |
| Sec9dcf513abc_N490 | Sec9dcf513abc_N484 | attribute | 112–112 | attribute  |
| Sec9dcf513abc_N491 | Sec9dcf513abc_N490 | attribute_name | 112–112 | class |
| Sec9dcf513abc_N492 | Sec9dcf513abc_N490 | quoted_attribute_value | 112–112 | quoted_attribute_value  |
| Sec9dcf513abc_N493 | Sec9dcf513abc_N492 | attribute_value | 112–112 | w-full h-full object-cover |
| Sec9dcf513abc_N494 | Sec9dcf513abc_N484 | attribute | 112–112 | attribute  |
| Sec9dcf513abc_N495 | Sec9dcf513abc_N494 | attribute_name | 112–112 | onerror |
| Sec9dcf513abc_N496 | Sec9dcf513abc_N494 | quoted_attribute_value | 112–112 | quoted_attribute_value  |
| Sec9dcf513abc_N497 | Sec9dcf513abc_N496 | attribute_value | 112–112 | this.src='https://lh3.googleusercontent.com/aida-public/AB6AXuCrfhL4lciCS2D4SfH-I-Aq0qL6NisgPYvi8x0pRtoqm0ZT-d8DZ3OiEaetjs5aI6RcGmyzIEtUDxgO7_ke3koF5-QzSocUK-zRvNfNbssqYzFQsKrwpdaw8gTTc1ps8FBv401bQfGhzP2rbE6JEcZieIy58sIGyoSB5Eco9eB1AdxjP5bHxO8HY-EZMKACzNBCGQh6blsU9a75CNgoqxX2h-uOp59BV_C7bbgi42rkaNBJBBZ2Z7wIRxEYVpgFod3LF91tPeOSRGM' |
| Sec9dcf513abc_N498 | Sec9dcf513abc_N484 | attribute | 112–112 | attribute  |
| Sec9dcf513abc_N499 | Sec9dcf513abc_N498 | attribute_name | 112–112 | src |
| Sec9dcf513abc_N500 | Sec9dcf513abc_N498 | quoted_attribute_value | 112–112 | quoted_attribute_value  |
| Sec9dcf513abc_N501 | Sec9dcf513abc_N500 | attribute_value | 112–112 | https://www.gstatic.com/labs-code/stitch/stitch-placeholder-300x300.svg |
| Sec9dcf513abc_N502 | Sec9dcf513abc_N476 | end_tag | 113–113 | end_tag  |
| Sec9dcf513abc_N503 | Sec9dcf513abc_N502 | tag_name | 113–113 | div |
| Sec9dcf513abc_N504 | Sec9dcf513abc_N469 | element | 114–120 | element  |
| Sec9dcf513abc_N505 | Sec9dcf513abc_N504 | start_tag | 114–114 | start_tag  |
| Sec9dcf513abc_N506 | Sec9dcf513abc_N505 | tag_name | 114–114 | div |
| Sec9dcf513abc_N507 | Sec9dcf513abc_N504 | element | 115–115 | element  |
| Sec9dcf513abc_N508 | Sec9dcf513abc_N507 | start_tag | 115–115 | start_tag  |
| Sec9dcf513abc_N509 | Sec9dcf513abc_N508 | tag_name | 115–115 | h2 |
| Sec9dcf513abc_N510 | Sec9dcf513abc_N508 | attribute | 115–115 | attribute  |
| Sec9dcf513abc_N511 | Sec9dcf513abc_N510 | attribute_name | 115–115 | class |
| Sec9dcf513abc_N512 | Sec9dcf513abc_N510 | quoted_attribute_value | 115–115 | quoted_attribute_value  |
| Sec9dcf513abc_N513 | Sec9dcf513abc_N512 | attribute_value | 115–115 | font-display font-medium text-starlight text-base |
| Sec9dcf513abc_N514 | Sec9dcf513abc_N507 | text | 115–115 | Observatory Atelier |
| Sec9dcf513abc_N515 | Sec9dcf513abc_N507 | end_tag | 115–115 | end_tag  |
| Sec9dcf513abc_N516 | Sec9dcf513abc_N515 | tag_name | 115–115 | h2 |
| Sec9dcf513abc_N517 | Sec9dcf513abc_N504 | element | 116–116 | element  |
| Sec9dcf513abc_N518 | Sec9dcf513abc_N517 | start_tag | 116–116 | start_tag  |
| Sec9dcf513abc_N519 | Sec9dcf513abc_N518 | tag_name | 116–116 | p |
| Sec9dcf513abc_N520 | Sec9dcf513abc_N518 | attribute | 116–116 | attribute  |
| Sec9dcf513abc_N521 | Sec9dcf513abc_N520 | attribute_name | 116–116 | class |
| Sec9dcf513abc_N522 | Sec9dcf513abc_N520 | quoted_attribute_value | 116–116 | quoted_attribute_value  |
| Sec9dcf513abc_N523 | Sec9dcf513abc_N522 | attribute_value | 116–116 | text-xs text-ash mt-0.5 |
| Sec9dcf513abc_N524 | Sec9dcf513abc_N517 | text | 116–116 | Continuous companion presence |
| Sec9dcf513abc_N525 | Sec9dcf513abc_N517 | end_tag | 116–116 | end_tag  |
| Sec9dcf513abc_N526 | Sec9dcf513abc_N525 | tag_name | 116–116 | p |
| Sec9dcf513abc_N527 | Sec9dcf513abc_N504 | element | 117–119 | element  |
| Sec9dcf513abc_N528 | Sec9dcf513abc_N527 | start_tag | 117–117 | start_tag  |
| Sec9dcf513abc_N529 | Sec9dcf513abc_N528 | tag_name | 117–117 | div |
| Sec9dcf513abc_N530 | Sec9dcf513abc_N528 | attribute | 117–117 | attribute  |
| Sec9dcf513abc_N531 | Sec9dcf513abc_N530 | attribute_name | 117–117 | class |
| Sec9dcf513abc_N532 | Sec9dcf513abc_N530 | quoted_attribute_value | 117–117 | quoted_attribute_value  |
| Sec9dcf513abc_N533 | Sec9dcf513abc_N532 | attribute_value | 117–117 | mt-2 inline-flex items-center text-[11px] font-mono text-celestial-brass bg-celestial-brass/10 px-2 py-0.5 rounded border border-celestial-brass/20 |
| Sec9dcf513abc_N534 | Sec9dcf513abc_N527 | text | 118–118 | Verified server-authoritative |
| Sec9dcf513abc_N535 | Sec9dcf513abc_N527 | end_tag | 119–119 | end_tag  |
| Sec9dcf513abc_N536 | Sec9dcf513abc_N535 | tag_name | 119–119 | div |
| Sec9dcf513abc_N537 | Sec9dcf513abc_N504 | end_tag | 120–120 | end_tag  |
| Sec9dcf513abc_N538 | Sec9dcf513abc_N537 | tag_name | 120–120 | div |
| Sec9dcf513abc_N539 | Sec9dcf513abc_N469 | end_tag | 121–121 | end_tag  |
| Sec9dcf513abc_N540 | Sec9dcf513abc_N539 | tag_name | 121–121 | div |
| Sec9dcf513abc_N541 | Sec9dcf513abc_N461 | comment | 122–122 | &lt;!-- Semantic Navigation Bar --&gt; |
| Sec9dcf513abc_N542 | Sec9dcf513abc_N461 | element | 123–173 | element  |
| Sec9dcf513abc_N543 | Sec9dcf513abc_N542 | start_tag | 123–123 | start_tag  |
| Sec9dcf513abc_N544 | Sec9dcf513abc_N543 | tag_name | 123–123 | nav |
| Sec9dcf513abc_N545 | Sec9dcf513abc_N543 | attribute | 123–123 | attribute  |
| Sec9dcf513abc_N546 | Sec9dcf513abc_N545 | attribute_name | 123–123 | aria-label |
| Sec9dcf513abc_N547 | Sec9dcf513abc_N545 | quoted_attribute_value | 123–123 | quoted_attribute_value  |
| Sec9dcf513abc_N548 | Sec9dcf513abc_N547 | attribute_value | 123–123 | Account management |
| Sec9dcf513abc_N549 | Sec9dcf513abc_N543 | attribute | 123–123 | attribute  |
| Sec9dcf513abc_N550 | Sec9dcf513abc_N549 | attribute_name | 123–123 | class |
| Sec9dcf513abc_N551 | Sec9dcf513abc_N549 | quoted_attribute_value | 123–123 | quoted_attribute_value  |
| Sec9dcf513abc_N552 | Sec9dcf513abc_N551 | attribute_value | 123–123 | p-3 rounded-xl border border-hairline bg-surface-dim space-y-1 |
| Sec9dcf513abc_N553 | Sec9dcf513abc_N542 | element | 124–130 | element  |
| Sec9dcf513abc_N554 | Sec9dcf513abc_N553 | start_tag | 124–124 | start_tag  |
| Sec9dcf513abc_N555 | Sec9dcf513abc_N554 | tag_name | 124–124 | button |
| Sec9dcf513abc_N556 | Sec9dcf513abc_N554 | attribute | 124–124 | attribute  |
| Sec9dcf513abc_N557 | Sec9dcf513abc_N556 | attribute_name | 124–124 | class |
| Sec9dcf513abc_N558 | Sec9dcf513abc_N556 | quoted_attribute_value | 124–124 | quoted_attribute_value  |
| Sec9dcf513abc_N559 | Sec9dcf513abc_N558 | attribute_value | 124–124 | nav-tab w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm text-left font-medium transition-colors bg-raised-charcoal text-celestial-brass border border-hairline/80 |
| Sec9dcf513abc_N560 | Sec9dcf513abc_N554 | attribute | 124–124 | attribute  |
| Sec9dcf513abc_N561 | Sec9dcf513abc_N560 | attribute_name | 124–124 | id |
| Sec9dcf513abc_N562 | Sec9dcf513abc_N560 | quoted_attribute_value | 124–124 | quoted_attribute_value  |
| Sec9dcf513abc_N563 | Sec9dcf513abc_N562 | attribute_value | 124–124 | view-profile |
| Sec9dcf513abc_N564 | Sec9dcf513abc_N554 | attribute | 124–124 | attribute  |
| Sec9dcf513abc_N565 | Sec9dcf513abc_N564 | attribute_name | 124–124 | onclick |
| Sec9dcf513abc_N566 | Sec9dcf513abc_N564 | quoted_attribute_value | 124–124 | quoted_attribute_value  |
| Sec9dcf513abc_N567 | Sec9dcf513abc_N566 | attribute_value | 124–124 | switchView('profile') |
| Sec9dcf513abc_N568 | Sec9dcf513abc_N553 | element | 125–128 | element  |
| Sec9dcf513abc_N569 | Sec9dcf513abc_N568 | start_tag | 125–125 | start_tag  |
| Sec9dcf513abc_N570 | Sec9dcf513abc_N569 | tag_name | 125–125 | span |
| Sec9dcf513abc_N571 | Sec9dcf513abc_N569 | attribute | 125–125 | attribute  |
| Sec9dcf513abc_N572 | Sec9dcf513abc_N571 | attribute_name | 125–125 | class |
| Sec9dcf513abc_N573 | Sec9dcf513abc_N571 | quoted_attribute_value | 125–125 | quoted_attribute_value  |
| Sec9dcf513abc_N574 | Sec9dcf513abc_N573 | attribute_value | 125–125 | flex items-center space-x-3 |
| Sec9dcf513abc_N575 | Sec9dcf513abc_N568 | element | 126–126 | element  |
| Sec9dcf513abc_N576 | Sec9dcf513abc_N575 | start_tag | 126–126 | start_tag  |
| Sec9dcf513abc_N577 | Sec9dcf513abc_N576 | tag_name | 126–126 | svg |
| Sec9dcf513abc_N578 | Sec9dcf513abc_N576 | attribute | 126–126 | attribute  |
| Sec9dcf513abc_N579 | Sec9dcf513abc_N578 | attribute_name | 126–126 | class |
| Sec9dcf513abc_N580 | Sec9dcf513abc_N578 | quoted_attribute_value | 126–126 | quoted_attribute_value  |
| Sec9dcf513abc_N581 | Sec9dcf513abc_N580 | attribute_value | 126–126 | w-4 h-4 opacity-80 |
| Sec9dcf513abc_N582 | Sec9dcf513abc_N576 | attribute | 126–126 | attribute  |
| Sec9dcf513abc_N583 | Sec9dcf513abc_N582 | attribute_name | 126–126 | fill |
| Sec9dcf513abc_N584 | Sec9dcf513abc_N582 | quoted_attribute_value | 126–126 | quoted_attribute_value  |
| Sec9dcf513abc_N585 | Sec9dcf513abc_N584 | attribute_value | 126–126 | none |
| Sec9dcf513abc_N586 | Sec9dcf513abc_N576 | attribute | 126–126 | attribute  |
| Sec9dcf513abc_N587 | Sec9dcf513abc_N586 | attribute_name | 126–126 | stroke |
| Sec9dcf513abc_N588 | Sec9dcf513abc_N586 | quoted_attribute_value | 126–126 | quoted_attribute_value  |
| Sec9dcf513abc_N589 | Sec9dcf513abc_N588 | attribute_value | 126–126 | currentColor |
| Sec9dcf513abc_N590 | Sec9dcf513abc_N576 | attribute | 126–126 | attribute  |
| Sec9dcf513abc_N591 | Sec9dcf513abc_N590 | attribute_name | 126–126 | viewbox |
| Sec9dcf513abc_N592 | Sec9dcf513abc_N590 | quoted_attribute_value | 126–126 | quoted_attribute_value  |
| Sec9dcf513abc_N593 | Sec9dcf513abc_N592 | attribute_value | 126–126 | 0 0 24 24 |
| Sec9dcf513abc_N594 | Sec9dcf513abc_N575 | element | 126–126 | element  |
| Sec9dcf513abc_N595 | Sec9dcf513abc_N594 | start_tag | 126–126 | start_tag  |
| Sec9dcf513abc_N596 | Sec9dcf513abc_N595 | tag_name | 126–126 | path |
| Sec9dcf513abc_N597 | Sec9dcf513abc_N595 | attribute | 126–126 | attribute  |
| Sec9dcf513abc_N598 | Sec9dcf513abc_N597 | attribute_name | 126–126 | d |
| Sec9dcf513abc_N599 | Sec9dcf513abc_N597 | quoted_attribute_value | 126–126 | quoted_attribute_value  |
| Sec9dcf513abc_N600 | Sec9dcf513abc_N599 | attribute_value | 126–126 | M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z |
| Sec9dcf513abc_N601 | Sec9dcf513abc_N595 | attribute | 126–126 | attribute  |
| Sec9dcf513abc_N602 | Sec9dcf513abc_N601 | attribute_name | 126–126 | stroke-linecap |
| Sec9dcf513abc_N603 | Sec9dcf513abc_N601 | quoted_attribute_value | 126–126 | quoted_attribute_value  |
| Sec9dcf513abc_N604 | Sec9dcf513abc_N603 | attribute_value | 126–126 | round |
| Sec9dcf513abc_N605 | Sec9dcf513abc_N595 | attribute | 126–126 | attribute  |
| Sec9dcf513abc_N606 | Sec9dcf513abc_N605 | attribute_name | 126–126 | stroke-linejoin |
| Sec9dcf513abc_N607 | Sec9dcf513abc_N605 | quoted_attribute_value | 126–126 | quoted_attribute_value  |
| Sec9dcf513abc_N608 | Sec9dcf513abc_N607 | attribute_value | 126–126 | round |
| Sec9dcf513abc_N609 | Sec9dcf513abc_N595 | attribute | 126–126 | attribute  |
| Sec9dcf513abc_N610 | Sec9dcf513abc_N609 | attribute_name | 126–126 | stroke-width |
| Sec9dcf513abc_N611 | Sec9dcf513abc_N609 | quoted_attribute_value | 126–126 | quoted_attribute_value  |
| Sec9dcf513abc_N612 | Sec9dcf513abc_N611 | attribute_value | 126–126 | 2 |
| Sec9dcf513abc_N613 | Sec9dcf513abc_N594 | end_tag | 126–126 | end_tag  |
| Sec9dcf513abc_N614 | Sec9dcf513abc_N613 | tag_name | 126–126 | path |
| Sec9dcf513abc_N615 | Sec9dcf513abc_N575 | end_tag | 126–126 | end_tag  |
| Sec9dcf513abc_N616 | Sec9dcf513abc_N615 | tag_name | 126–126 | svg |
| Sec9dcf513abc_N617 | Sec9dcf513abc_N568 | element | 127–127 | element  |
| Sec9dcf513abc_N618 | Sec9dcf513abc_N617 | start_tag | 127–127 | start_tag  |
| Sec9dcf513abc_N619 | Sec9dcf513abc_N618 | tag_name | 127–127 | span |
| Sec9dcf513abc_N620 | Sec9dcf513abc_N617 | text | 127–127 | Account Profile |
| Sec9dcf513abc_N621 | Sec9dcf513abc_N617 | end_tag | 127–127 | end_tag  |
| Sec9dcf513abc_N622 | Sec9dcf513abc_N621 | tag_name | 127–127 | span |
| Sec9dcf513abc_N623 | Sec9dcf513abc_N568 | end_tag | 128–128 | end_tag  |
| Sec9dcf513abc_N624 | Sec9dcf513abc_N623 | tag_name | 128–128 | span |
| Sec9dcf513abc_N625 | Sec9dcf513abc_N553 | element | 129–129 | element  |
| Sec9dcf513abc_N626 | Sec9dcf513abc_N625 | start_tag | 129–129 | start_tag  |
| Sec9dcf513abc_N627 | Sec9dcf513abc_N626 | tag_name | 129–129 | span |
| Sec9dcf513abc_N628 | Sec9dcf513abc_N626 | attribute | 129–129 | attribute  |
| Sec9dcf513abc_N629 | Sec9dcf513abc_N628 | attribute_name | 129–129 | class |
| Sec9dcf513abc_N630 | Sec9dcf513abc_N628 | quoted_attribute_value | 129–129 | quoted_attribute_value  |
| Sec9dcf513abc_N631 | Sec9dcf513abc_N630 | attribute_value | 129–129 | text-xs font-mono text-ash |
| Sec9dcf513abc_N632 | Sec9dcf513abc_N625 | text | 129–129 | → |
| Sec9dcf513abc_N633 | Sec9dcf513abc_N625 | end_tag | 129–129 | end_tag  |
| Sec9dcf513abc_N634 | Sec9dcf513abc_N633 | tag_name | 129–129 | span |
| Sec9dcf513abc_N635 | Sec9dcf513abc_N553 | end_tag | 130–130 | end_tag  |
| Sec9dcf513abc_N636 | Sec9dcf513abc_N635 | tag_name | 130–130 | button |
| Sec9dcf513abc_N637 | Sec9dcf513abc_N542 | element | 131–137 | element  |
| Sec9dcf513abc_N638 | Sec9dcf513abc_N637 | start_tag | 131–131 | start_tag  |
| Sec9dcf513abc_N639 | Sec9dcf513abc_N638 | tag_name | 131–131 | button |
| Sec9dcf513abc_N640 | Sec9dcf513abc_N638 | attribute | 131–131 | attribute  |
| Sec9dcf513abc_N641 | Sec9dcf513abc_N640 | attribute_name | 131–131 | class |
| Sec9dcf513abc_N642 | Sec9dcf513abc_N640 | quoted_attribute_value | 131–131 | quoted_attribute_value  |
| Sec9dcf513abc_N643 | Sec9dcf513abc_N642 | attribute_value | 131–131 | nav-tab w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm text-left font-medium transition-colors text-ash hover:text-starlight hover:bg-raised-charcoal/50 |
| Sec9dcf513abc_N644 | Sec9dcf513abc_N638 | attribute | 131–131 | attribute  |
| Sec9dcf513abc_N645 | Sec9dcf513abc_N644 | attribute_name | 131–131 | id |
| Sec9dcf513abc_N646 | Sec9dcf513abc_N644 | quoted_attribute_value | 131–131 | quoted_attribute_value  |
| Sec9dcf513abc_N647 | Sec9dcf513abc_N646 | attribute_value | 131–131 | view-balance |
| Sec9dcf513abc_N648 | Sec9dcf513abc_N638 | attribute | 131–131 | attribute  |
| Sec9dcf513abc_N649 | Sec9dcf513abc_N648 | attribute_name | 131–131 | onclick |
| Sec9dcf513abc_N650 | Sec9dcf513abc_N648 | quoted_attribute_value | 131–131 | quoted_attribute_value  |
| Sec9dcf513abc_N651 | Sec9dcf513abc_N650 | attribute_value | 131–131 | switchView('balance') |
| Sec9dcf513abc_N652 | Sec9dcf513abc_N637 | element | 132–135 | element  |
| Sec9dcf513abc_N653 | Sec9dcf513abc_N652 | start_tag | 132–132 | start_tag  |
| Sec9dcf513abc_N654 | Sec9dcf513abc_N653 | tag_name | 132–132 | span |
| Sec9dcf513abc_N655 | Sec9dcf513abc_N653 | attribute | 132–132 | attribute  |
| Sec9dcf513abc_N656 | Sec9dcf513abc_N655 | attribute_name | 132–132 | class |
| Sec9dcf513abc_N657 | Sec9dcf513abc_N655 | quoted_attribute_value | 132–132 | quoted_attribute_value  |
| Sec9dcf513abc_N658 | Sec9dcf513abc_N657 | attribute_value | 132–132 | flex items-center space-x-3 |
| Sec9dcf513abc_N659 | Sec9dcf513abc_N652 | element | 133–133 | element  |
| Sec9dcf513abc_N660 | Sec9dcf513abc_N659 | start_tag | 133–133 | start_tag  |
| Sec9dcf513abc_N661 | Sec9dcf513abc_N660 | tag_name | 133–133 | svg |
| Sec9dcf513abc_N662 | Sec9dcf513abc_N660 | attribute | 133–133 | attribute  |
| Sec9dcf513abc_N663 | Sec9dcf513abc_N662 | attribute_name | 133–133 | class |
| Sec9dcf513abc_N664 | Sec9dcf513abc_N662 | quoted_attribute_value | 133–133 | quoted_attribute_value  |
| Sec9dcf513abc_N665 | Sec9dcf513abc_N664 | attribute_value | 133–133 | w-4 h-4 opacity-80 |
| Sec9dcf513abc_N666 | Sec9dcf513abc_N660 | attribute | 133–133 | attribute  |
| Sec9dcf513abc_N667 | Sec9dcf513abc_N666 | attribute_name | 133–133 | fill |
| Sec9dcf513abc_N668 | Sec9dcf513abc_N666 | quoted_attribute_value | 133–133 | quoted_attribute_value  |
| Sec9dcf513abc_N669 | Sec9dcf513abc_N668 | attribute_value | 133–133 | none |
| Sec9dcf513abc_N670 | Sec9dcf513abc_N660 | attribute | 133–133 | attribute  |
| Sec9dcf513abc_N671 | Sec9dcf513abc_N670 | attribute_name | 133–133 | stroke |
| Sec9dcf513abc_N672 | Sec9dcf513abc_N670 | quoted_attribute_value | 133–133 | quoted_attribute_value  |
| Sec9dcf513abc_N673 | Sec9dcf513abc_N672 | attribute_value | 133–133 | currentColor |
| Sec9dcf513abc_N674 | Sec9dcf513abc_N660 | attribute | 133–133 | attribute  |
| Sec9dcf513abc_N675 | Sec9dcf513abc_N674 | attribute_name | 133–133 | viewbox |
| Sec9dcf513abc_N676 | Sec9dcf513abc_N674 | quoted_attribute_value | 133–133 | quoted_attribute_value  |
| Sec9dcf513abc_N677 | Sec9dcf513abc_N676 | attribute_value | 133–133 | 0 0 24 24 |
| Sec9dcf513abc_N678 | Sec9dcf513abc_N659 | element | 133–133 | element  |
| Sec9dcf513abc_N679 | Sec9dcf513abc_N678 | start_tag | 133–133 | start_tag  |
| Sec9dcf513abc_N680 | Sec9dcf513abc_N679 | tag_name | 133–133 | path |
| Sec9dcf513abc_N681 | Sec9dcf513abc_N679 | attribute | 133–133 | attribute  |
| Sec9dcf513abc_N682 | Sec9dcf513abc_N681 | attribute_name | 133–133 | d |
| Sec9dcf513abc_N683 | Sec9dcf513abc_N681 | quoted_attribute_value | 133–133 | quoted_attribute_value  |
| Sec9dcf513abc_N684 | Sec9dcf513abc_N683 | attribute_value | 133–133 | M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z |
| Sec9dcf513abc_N685 | Sec9dcf513abc_N679 | attribute | 133–133 | attribute  |
| Sec9dcf513abc_N686 | Sec9dcf513abc_N685 | attribute_name | 133–133 | stroke-linecap |
| Sec9dcf513abc_N687 | Sec9dcf513abc_N685 | quoted_attribute_value | 133–133 | quoted_attribute_value  |
| Sec9dcf513abc_N688 | Sec9dcf513abc_N687 | attribute_value | 133–133 | round |
| Sec9dcf513abc_N689 | Sec9dcf513abc_N679 | attribute | 133–133 | attribute  |
| Sec9dcf513abc_N690 | Sec9dcf513abc_N689 | attribute_name | 133–133 | stroke-linejoin |
| Sec9dcf513abc_N691 | Sec9dcf513abc_N689 | quoted_attribute_value | 133–133 | quoted_attribute_value  |
| Sec9dcf513abc_N692 | Sec9dcf513abc_N691 | attribute_value | 133–133 | round |
| Sec9dcf513abc_N693 | Sec9dcf513abc_N679 | attribute | 133–133 | attribute  |
| Sec9dcf513abc_N694 | Sec9dcf513abc_N693 | attribute_name | 133–133 | stroke-width |
| Sec9dcf513abc_N695 | Sec9dcf513abc_N693 | quoted_attribute_value | 133–133 | quoted_attribute_value  |
| Sec9dcf513abc_N696 | Sec9dcf513abc_N695 | attribute_value | 133–133 | 2 |
| Sec9dcf513abc_N697 | Sec9dcf513abc_N678 | end_tag | 133–133 | end_tag  |
| Sec9dcf513abc_N698 | Sec9dcf513abc_N697 | tag_name | 133–133 | path |
| Sec9dcf513abc_N699 | Sec9dcf513abc_N659 | end_tag | 133–133 | end_tag  |
| Sec9dcf513abc_N700 | Sec9dcf513abc_N699 | tag_name | 133–133 | svg |
| Sec9dcf513abc_N701 | Sec9dcf513abc_N652 | element | 134–134 | element  |
| Sec9dcf513abc_N702 | Sec9dcf513abc_N701 | start_tag | 134–134 | start_tag  |
| Sec9dcf513abc_N703 | Sec9dcf513abc_N702 | tag_name | 134–134 | span |
| Sec9dcf513abc_N704 | Sec9dcf513abc_N701 | text | 134–134 | Balance |
| Sec9dcf513abc_N705 | Sec9dcf513abc_N701 | entity | 134–134 | &amp;amp; |
| Sec9dcf513abc_N706 | Sec9dcf513abc_N701 | text | 134–134 | Usage |
| Sec9dcf513abc_N707 | Sec9dcf513abc_N701 | end_tag | 134–134 | end_tag  |
| Sec9dcf513abc_N708 | Sec9dcf513abc_N707 | tag_name | 134–134 | span |
| Sec9dcf513abc_N709 | Sec9dcf513abc_N652 | end_tag | 135–135 | end_tag  |
| Sec9dcf513abc_N710 | Sec9dcf513abc_N709 | tag_name | 135–135 | span |
| Sec9dcf513abc_N711 | Sec9dcf513abc_N637 | element | 136–136 | element  |
| Sec9dcf513abc_N712 | Sec9dcf513abc_N711 | start_tag | 136–136 | start_tag  |
| Sec9dcf513abc_N713 | Sec9dcf513abc_N712 | tag_name | 136–136 | span |
| Sec9dcf513abc_N714 | Sec9dcf513abc_N712 | attribute | 136–136 | attribute  |
| Sec9dcf513abc_N715 | Sec9dcf513abc_N714 | attribute_name | 136–136 | class |
| Sec9dcf513abc_N716 | Sec9dcf513abc_N714 | quoted_attribute_value | 136–136 | quoted_attribute_value  |
| Sec9dcf513abc_N717 | Sec9dcf513abc_N716 | attribute_value | 136–136 | text-xs font-mono text-ash |
| Sec9dcf513abc_N718 | Sec9dcf513abc_N711 | text | 136–136 | → |
| Sec9dcf513abc_N719 | Sec9dcf513abc_N711 | end_tag | 136–136 | end_tag  |
| Sec9dcf513abc_N720 | Sec9dcf513abc_N719 | tag_name | 136–136 | span |
| Sec9dcf513abc_N721 | Sec9dcf513abc_N637 | end_tag | 137–137 | end_tag  |
| Sec9dcf513abc_N722 | Sec9dcf513abc_N721 | tag_name | 137–137 | button |
| Sec9dcf513abc_N723 | Sec9dcf513abc_N542 | element | 138–144 | element  |
| Sec9dcf513abc_N724 | Sec9dcf513abc_N723 | start_tag | 138–138 | start_tag  |
| Sec9dcf513abc_N725 | Sec9dcf513abc_N724 | tag_name | 138–138 | button |
| Sec9dcf513abc_N726 | Sec9dcf513abc_N724 | attribute | 138–138 | attribute  |
| Sec9dcf513abc_N727 | Sec9dcf513abc_N726 | attribute_name | 138–138 | class |
| Sec9dcf513abc_N728 | Sec9dcf513abc_N726 | quoted_attribute_value | 138–138 | quoted_attribute_value  |
| Sec9dcf513abc_N729 | Sec9dcf513abc_N728 | attribute_value | 138–138 | nav-tab w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm text-left font-medium transition-colors text-ash hover:text-starlight hover:bg-raised-charcoal/50 |
| Sec9dcf513abc_N730 | Sec9dcf513abc_N724 | attribute | 138–138 | attribute  |
| Sec9dcf513abc_N731 | Sec9dcf513abc_N730 | attribute_name | 138–138 | id |
| Sec9dcf513abc_N732 | Sec9dcf513abc_N730 | quoted_attribute_value | 138–138 | quoted_attribute_value  |
| Sec9dcf513abc_N733 | Sec9dcf513abc_N732 | attribute_value | 138–138 | view-topup |
| Sec9dcf513abc_N734 | Sec9dcf513abc_N724 | attribute | 138–138 | attribute  |
| Sec9dcf513abc_N735 | Sec9dcf513abc_N734 | attribute_name | 138–138 | onclick |
| Sec9dcf513abc_N736 | Sec9dcf513abc_N734 | quoted_attribute_value | 138–138 | quoted_attribute_value  |
| Sec9dcf513abc_N737 | Sec9dcf513abc_N736 | attribute_value | 138–138 | switchView('topup') |
| Sec9dcf513abc_N738 | Sec9dcf513abc_N723 | element | 139–142 | element  |
| Sec9dcf513abc_N739 | Sec9dcf513abc_N738 | start_tag | 139–139 | start_tag  |
| Sec9dcf513abc_N740 | Sec9dcf513abc_N739 | tag_name | 139–139 | span |
| Sec9dcf513abc_N741 | Sec9dcf513abc_N739 | attribute | 139–139 | attribute  |
| Sec9dcf513abc_N742 | Sec9dcf513abc_N741 | attribute_name | 139–139 | class |
| Sec9dcf513abc_N743 | Sec9dcf513abc_N741 | quoted_attribute_value | 139–139 | quoted_attribute_value  |
| Sec9dcf513abc_N744 | Sec9dcf513abc_N743 | attribute_value | 139–139 | flex items-center space-x-3 |
| Sec9dcf513abc_N745 | Sec9dcf513abc_N738 | element | 140–140 | element  |
| Sec9dcf513abc_N746 | Sec9dcf513abc_N745 | start_tag | 140–140 | start_tag  |
| Sec9dcf513abc_N747 | Sec9dcf513abc_N746 | tag_name | 140–140 | svg |
| Sec9dcf513abc_N748 | Sec9dcf513abc_N746 | attribute | 140–140 | attribute  |
| Sec9dcf513abc_N749 | Sec9dcf513abc_N748 | attribute_name | 140–140 | class |
| Sec9dcf513abc_N750 | Sec9dcf513abc_N748 | quoted_attribute_value | 140–140 | quoted_attribute_value  |
| Sec9dcf513abc_N751 | Sec9dcf513abc_N750 | attribute_value | 140–140 | w-4 h-4 opacity-80 |
| Sec9dcf513abc_N752 | Sec9dcf513abc_N746 | attribute | 140–140 | attribute  |
| Sec9dcf513abc_N753 | Sec9dcf513abc_N752 | attribute_name | 140–140 | fill |
| Sec9dcf513abc_N754 | Sec9dcf513abc_N752 | quoted_attribute_value | 140–140 | quoted_attribute_value  |
| Sec9dcf513abc_N755 | Sec9dcf513abc_N754 | attribute_value | 140–140 | none |
| Sec9dcf513abc_N756 | Sec9dcf513abc_N746 | attribute | 140–140 | attribute  |
| Sec9dcf513abc_N757 | Sec9dcf513abc_N756 | attribute_name | 140–140 | stroke |
| Sec9dcf513abc_N758 | Sec9dcf513abc_N756 | quoted_attribute_value | 140–140 | quoted_attribute_value  |
| Sec9dcf513abc_N759 | Sec9dcf513abc_N758 | attribute_value | 140–140 | currentColor |
| Sec9dcf513abc_N760 | Sec9dcf513abc_N746 | attribute | 140–140 | attribute  |
| Sec9dcf513abc_N761 | Sec9dcf513abc_N760 | attribute_name | 140–140 | viewbox |
| Sec9dcf513abc_N762 | Sec9dcf513abc_N760 | quoted_attribute_value | 140–140 | quoted_attribute_value  |
| Sec9dcf513abc_N763 | Sec9dcf513abc_N762 | attribute_value | 140–140 | 0 0 24 24 |
| Sec9dcf513abc_N764 | Sec9dcf513abc_N745 | element | 140–140 | element  |
| Sec9dcf513abc_N765 | Sec9dcf513abc_N764 | start_tag | 140–140 | start_tag  |
| Sec9dcf513abc_N766 | Sec9dcf513abc_N765 | tag_name | 140–140 | path |
| Sec9dcf513abc_N767 | Sec9dcf513abc_N765 | attribute | 140–140 | attribute  |
| Sec9dcf513abc_N768 | Sec9dcf513abc_N767 | attribute_name | 140–140 | d |
| Sec9dcf513abc_N769 | Sec9dcf513abc_N767 | quoted_attribute_value | 140–140 | quoted_attribute_value  |
| Sec9dcf513abc_N770 | Sec9dcf513abc_N769 | attribute_value | 140–140 | M12 6v6m0 0v6m0-6h6m-6 0H6 |
| Sec9dcf513abc_N771 | Sec9dcf513abc_N765 | attribute | 140–140 | attribute  |
| Sec9dcf513abc_N772 | Sec9dcf513abc_N771 | attribute_name | 140–140 | stroke-linecap |
| Sec9dcf513abc_N773 | Sec9dcf513abc_N771 | quoted_attribute_value | 140–140 | quoted_attribute_value  |
| Sec9dcf513abc_N774 | Sec9dcf513abc_N773 | attribute_value | 140–140 | round |
| Sec9dcf513abc_N775 | Sec9dcf513abc_N765 | attribute | 140–140 | attribute  |
| Sec9dcf513abc_N776 | Sec9dcf513abc_N775 | attribute_name | 140–140 | stroke-linejoin |
| Sec9dcf513abc_N777 | Sec9dcf513abc_N775 | quoted_attribute_value | 140–140 | quoted_attribute_value  |
| Sec9dcf513abc_N778 | Sec9dcf513abc_N777 | attribute_value | 140–140 | round |
| Sec9dcf513abc_N779 | Sec9dcf513abc_N765 | attribute | 140–140 | attribute  |
| Sec9dcf513abc_N780 | Sec9dcf513abc_N779 | attribute_name | 140–140 | stroke-width |
| Sec9dcf513abc_N781 | Sec9dcf513abc_N779 | quoted_attribute_value | 140–140 | quoted_attribute_value  |
| Sec9dcf513abc_N782 | Sec9dcf513abc_N781 | attribute_value | 140–140 | 2 |
| Sec9dcf513abc_N783 | Sec9dcf513abc_N764 | end_tag | 140–140 | end_tag  |
| Sec9dcf513abc_N784 | Sec9dcf513abc_N783 | tag_name | 140–140 | path |
| Sec9dcf513abc_N785 | Sec9dcf513abc_N745 | end_tag | 140–140 | end_tag  |
| Sec9dcf513abc_N786 | Sec9dcf513abc_N785 | tag_name | 140–140 | svg |
| Sec9dcf513abc_N787 | Sec9dcf513abc_N738 | element | 141–141 | element  |
| Sec9dcf513abc_N788 | Sec9dcf513abc_N787 | start_tag | 141–141 | start_tag  |
| Sec9dcf513abc_N789 | Sec9dcf513abc_N788 | tag_name | 141–141 | span |
| Sec9dcf513abc_N790 | Sec9dcf513abc_N787 | text | 141–141 | Top Up Credits |
| Sec9dcf513abc_N791 | Sec9dcf513abc_N787 | end_tag | 141–141 | end_tag  |
| Sec9dcf513abc_N792 | Sec9dcf513abc_N791 | tag_name | 141–141 | span |
| Sec9dcf513abc_N793 | Sec9dcf513abc_N738 | end_tag | 142–142 | end_tag  |
| Sec9dcf513abc_N794 | Sec9dcf513abc_N793 | tag_name | 142–142 | span |
| Sec9dcf513abc_N795 | Sec9dcf513abc_N723 | element | 143–143 | element  |
| Sec9dcf513abc_N796 | Sec9dcf513abc_N795 | start_tag | 143–143 | start_tag  |
| Sec9dcf513abc_N797 | Sec9dcf513abc_N796 | tag_name | 143–143 | span |
| Sec9dcf513abc_N798 | Sec9dcf513abc_N796 | attribute | 143–143 | attribute  |
| Sec9dcf513abc_N799 | Sec9dcf513abc_N798 | attribute_name | 143–143 | class |
| Sec9dcf513abc_N800 | Sec9dcf513abc_N798 | quoted_attribute_value | 143–143 | quoted_attribute_value  |
| Sec9dcf513abc_N801 | Sec9dcf513abc_N800 | attribute_value | 143–143 | text-xs font-mono text-ash |
| Sec9dcf513abc_N802 | Sec9dcf513abc_N795 | text | 143–143 | → |
| Sec9dcf513abc_N803 | Sec9dcf513abc_N795 | end_tag | 143–143 | end_tag  |
| Sec9dcf513abc_N804 | Sec9dcf513abc_N803 | tag_name | 143–143 | span |
| Sec9dcf513abc_N805 | Sec9dcf513abc_N723 | end_tag | 144–144 | end_tag  |
| Sec9dcf513abc_N806 | Sec9dcf513abc_N805 | tag_name | 144–144 | button |
| Sec9dcf513abc_N807 | Sec9dcf513abc_N542 | element | 145–151 | element  |
| Sec9dcf513abc_N808 | Sec9dcf513abc_N807 | start_tag | 145–145 | start_tag  |
| Sec9dcf513abc_N809 | Sec9dcf513abc_N808 | tag_name | 145–145 | button |
| Sec9dcf513abc_N810 | Sec9dcf513abc_N808 | attribute | 145–145 | attribute  |
| Sec9dcf513abc_N811 | Sec9dcf513abc_N810 | attribute_name | 145–145 | class |
| Sec9dcf513abc_N812 | Sec9dcf513abc_N810 | quoted_attribute_value | 145–145 | quoted_attribute_value  |
| Sec9dcf513abc_N813 | Sec9dcf513abc_N812 | attribute_value | 145–145 | nav-tab w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm text-left font-medium transition-colors text-ash hover:text-starlight hover:bg-raised-charcoal/50 |
| Sec9dcf513abc_N814 | Sec9dcf513abc_N808 | attribute | 145–145 | attribute  |
| Sec9dcf513abc_N815 | Sec9dcf513abc_N814 | attribute_name | 145–145 | id |
| Sec9dcf513abc_N816 | Sec9dcf513abc_N814 | quoted_attribute_value | 145–145 | quoted_attribute_value  |
| Sec9dcf513abc_N817 | Sec9dcf513abc_N816 | attribute_value | 145–145 | view-offers |
| Sec9dcf513abc_N818 | Sec9dcf513abc_N808 | attribute | 145–145 | attribute  |
| Sec9dcf513abc_N819 | Sec9dcf513abc_N818 | attribute_name | 145–145 | onclick |
| Sec9dcf513abc_N820 | Sec9dcf513abc_N818 | quoted_attribute_value | 145–145 | quoted_attribute_value  |
| Sec9dcf513abc_N821 | Sec9dcf513abc_N820 | attribute_value | 145–145 | switchView('offers') |
| Sec9dcf513abc_N822 | Sec9dcf513abc_N807 | element | 146–149 | element  |
| Sec9dcf513abc_N823 | Sec9dcf513abc_N822 | start_tag | 146–146 | start_tag  |
| Sec9dcf513abc_N824 | Sec9dcf513abc_N823 | tag_name | 146–146 | span |
| Sec9dcf513abc_N825 | Sec9dcf513abc_N823 | attribute | 146–146 | attribute  |
| Sec9dcf513abc_N826 | Sec9dcf513abc_N825 | attribute_name | 146–146 | class |
| Sec9dcf513abc_N827 | Sec9dcf513abc_N825 | quoted_attribute_value | 146–146 | quoted_attribute_value  |
| Sec9dcf513abc_N828 | Sec9dcf513abc_N827 | attribute_value | 146–146 | flex items-center space-x-3 |
| Sec9dcf513abc_N829 | Sec9dcf513abc_N822 | element | 147–147 | element  |
| Sec9dcf513abc_N830 | Sec9dcf513abc_N829 | start_tag | 147–147 | start_tag  |
| Sec9dcf513abc_N831 | Sec9dcf513abc_N830 | tag_name | 147–147 | svg |
| Sec9dcf513abc_N832 | Sec9dcf513abc_N830 | attribute | 147–147 | attribute  |
| Sec9dcf513abc_N833 | Sec9dcf513abc_N832 | attribute_name | 147–147 | class |
| Sec9dcf513abc_N834 | Sec9dcf513abc_N832 | quoted_attribute_value | 147–147 | quoted_attribute_value  |
| Sec9dcf513abc_N835 | Sec9dcf513abc_N834 | attribute_value | 147–147 | w-4 h-4 opacity-80 |
| Sec9dcf513abc_N836 | Sec9dcf513abc_N830 | attribute | 147–147 | attribute  |
| Sec9dcf513abc_N837 | Sec9dcf513abc_N836 | attribute_name | 147–147 | fill |
| Sec9dcf513abc_N838 | Sec9dcf513abc_N836 | quoted_attribute_value | 147–147 | quoted_attribute_value  |
| Sec9dcf513abc_N839 | Sec9dcf513abc_N838 | attribute_value | 147–147 | none |
| Sec9dcf513abc_N840 | Sec9dcf513abc_N830 | attribute | 147–147 | attribute  |
| Sec9dcf513abc_N841 | Sec9dcf513abc_N840 | attribute_name | 147–147 | stroke |
| Sec9dcf513abc_N842 | Sec9dcf513abc_N840 | quoted_attribute_value | 147–147 | quoted_attribute_value  |
| Sec9dcf513abc_N843 | Sec9dcf513abc_N842 | attribute_value | 147–147 | currentColor |
| Sec9dcf513abc_N844 | Sec9dcf513abc_N830 | attribute | 147–147 | attribute  |
| Sec9dcf513abc_N845 | Sec9dcf513abc_N844 | attribute_name | 147–147 | viewbox |
| Sec9dcf513abc_N846 | Sec9dcf513abc_N844 | quoted_attribute_value | 147–147 | quoted_attribute_value  |
| Sec9dcf513abc_N847 | Sec9dcf513abc_N846 | attribute_value | 147–147 | 0 0 24 24 |
| Sec9dcf513abc_N848 | Sec9dcf513abc_N829 | element | 147–147 | element  |
| Sec9dcf513abc_N849 | Sec9dcf513abc_N848 | start_tag | 147–147 | start_tag  |
| Sec9dcf513abc_N850 | Sec9dcf513abc_N849 | tag_name | 147–147 | path |
| Sec9dcf513abc_N851 | Sec9dcf513abc_N849 | attribute | 147–147 | attribute  |
| Sec9dcf513abc_N852 | Sec9dcf513abc_N851 | attribute_name | 147–147 | d |
| Sec9dcf513abc_N853 | Sec9dcf513abc_N851 | quoted_attribute_value | 147–147 | quoted_attribute_value  |
| Sec9dcf513abc_N854 | Sec9dcf513abc_N853 | attribute_value | 147–147 | M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253 |
| Sec9dcf513abc_N855 | Sec9dcf513abc_N849 | attribute | 147–147 | attribute  |
| Sec9dcf513abc_N856 | Sec9dcf513abc_N855 | attribute_name | 147–147 | stroke-linecap |
| Sec9dcf513abc_N857 | Sec9dcf513abc_N855 | quoted_attribute_value | 147–147 | quoted_attribute_value  |
| Sec9dcf513abc_N858 | Sec9dcf513abc_N857 | attribute_value | 147–147 | round |
| Sec9dcf513abc_N859 | Sec9dcf513abc_N849 | attribute | 147–147 | attribute  |
| Sec9dcf513abc_N860 | Sec9dcf513abc_N859 | attribute_name | 147–147 | stroke-linejoin |
| Sec9dcf513abc_N861 | Sec9dcf513abc_N859 | quoted_attribute_value | 147–147 | quoted_attribute_value  |
| Sec9dcf513abc_N862 | Sec9dcf513abc_N861 | attribute_value | 147–147 | round |
| Sec9dcf513abc_N863 | Sec9dcf513abc_N849 | attribute | 147–147 | attribute  |
| Sec9dcf513abc_N864 | Sec9dcf513abc_N863 | attribute_name | 147–147 | stroke-width |
| Sec9dcf513abc_N865 | Sec9dcf513abc_N863 | quoted_attribute_value | 147–147 | quoted_attribute_value  |
| Sec9dcf513abc_N866 | Sec9dcf513abc_N865 | attribute_value | 147–147 | 2 |
| Sec9dcf513abc_N867 | Sec9dcf513abc_N848 | end_tag | 147–147 | end_tag  |
| Sec9dcf513abc_N868 | Sec9dcf513abc_N867 | tag_name | 147–147 | path |
| Sec9dcf513abc_N869 | Sec9dcf513abc_N829 | end_tag | 147–147 | end_tag  |
| Sec9dcf513abc_N870 | Sec9dcf513abc_N869 | tag_name | 147–147 | svg |
| Sec9dcf513abc_N871 | Sec9dcf513abc_N822 | element | 148–148 | element  |
| Sec9dcf513abc_N872 | Sec9dcf513abc_N871 | start_tag | 148–148 | start_tag  |
| Sec9dcf513abc_N873 | Sec9dcf513abc_N872 | tag_name | 148–148 | span |
| Sec9dcf513abc_N874 | Sec9dcf513abc_N871 | text | 148–148 | Buy Natal Chart |
| Sec9dcf513abc_N875 | Sec9dcf513abc_N871 | end_tag | 148–148 | end_tag  |
| Sec9dcf513abc_N876 | Sec9dcf513abc_N875 | tag_name | 148–148 | span |
| Sec9dcf513abc_N877 | Sec9dcf513abc_N822 | end_tag | 149–149 | end_tag  |
| Sec9dcf513abc_N878 | Sec9dcf513abc_N877 | tag_name | 149–149 | span |
| Sec9dcf513abc_N879 | Sec9dcf513abc_N807 | element | 150–150 | element  |
| Sec9dcf513abc_N880 | Sec9dcf513abc_N879 | start_tag | 150–150 | start_tag  |
| Sec9dcf513abc_N881 | Sec9dcf513abc_N880 | tag_name | 150–150 | span |
| Sec9dcf513abc_N882 | Sec9dcf513abc_N880 | attribute | 150–150 | attribute  |
| Sec9dcf513abc_N883 | Sec9dcf513abc_N882 | attribute_name | 150–150 | class |
| Sec9dcf513abc_N884 | Sec9dcf513abc_N882 | quoted_attribute_value | 150–150 | quoted_attribute_value  |
| Sec9dcf513abc_N885 | Sec9dcf513abc_N884 | attribute_value | 150–150 | text-xs font-mono text-ash |
| Sec9dcf513abc_N886 | Sec9dcf513abc_N879 | text | 150–150 | → |
| Sec9dcf513abc_N887 | Sec9dcf513abc_N879 | end_tag | 150–150 | end_tag  |
| Sec9dcf513abc_N888 | Sec9dcf513abc_N887 | tag_name | 150–150 | span |
| Sec9dcf513abc_N889 | Sec9dcf513abc_N807 | end_tag | 151–151 | end_tag  |
| Sec9dcf513abc_N890 | Sec9dcf513abc_N889 | tag_name | 151–151 | button |
| Sec9dcf513abc_N891 | Sec9dcf513abc_N542 | element | 152–158 | element  |
| Sec9dcf513abc_N892 | Sec9dcf513abc_N891 | start_tag | 152–152 | start_tag  |
| Sec9dcf513abc_N893 | Sec9dcf513abc_N892 | tag_name | 152–152 | button |
| Sec9dcf513abc_N894 | Sec9dcf513abc_N892 | attribute | 152–152 | attribute  |
| Sec9dcf513abc_N895 | Sec9dcf513abc_N894 | attribute_name | 152–152 | class |
| Sec9dcf513abc_N896 | Sec9dcf513abc_N894 | quoted_attribute_value | 152–152 | quoted_attribute_value  |
| Sec9dcf513abc_N897 | Sec9dcf513abc_N896 | attribute_value | 152–152 | nav-tab w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm text-left font-medium transition-colors text-ash hover:text-starlight hover:bg-raised-charcoal/50 |
| Sec9dcf513abc_N898 | Sec9dcf513abc_N892 | attribute | 152–152 | attribute  |
| Sec9dcf513abc_N899 | Sec9dcf513abc_N898 | attribute_name | 152–152 | id |
| Sec9dcf513abc_N900 | Sec9dcf513abc_N898 | quoted_attribute_value | 152–152 | quoted_attribute_value  |
| Sec9dcf513abc_N901 | Sec9dcf513abc_N900 | attribute_value | 152–152 | view-alby |
| Sec9dcf513abc_N902 | Sec9dcf513abc_N892 | attribute | 152–152 | attribute  |
| Sec9dcf513abc_N903 | Sec9dcf513abc_N902 | attribute_name | 152–152 | onclick |
| Sec9dcf513abc_N904 | Sec9dcf513abc_N902 | quoted_attribute_value | 152–152 | quoted_attribute_value  |
| Sec9dcf513abc_N905 | Sec9dcf513abc_N904 | attribute_value | 152–152 | switchView('alby') |
| Sec9dcf513abc_N906 | Sec9dcf513abc_N891 | element | 153–156 | element  |
| Sec9dcf513abc_N907 | Sec9dcf513abc_N906 | start_tag | 153–153 | start_tag  |
| Sec9dcf513abc_N908 | Sec9dcf513abc_N907 | tag_name | 153–153 | span |
| Sec9dcf513abc_N909 | Sec9dcf513abc_N907 | attribute | 153–153 | attribute  |
| Sec9dcf513abc_N910 | Sec9dcf513abc_N909 | attribute_name | 153–153 | class |
| Sec9dcf513abc_N911 | Sec9dcf513abc_N909 | quoted_attribute_value | 153–153 | quoted_attribute_value  |
| Sec9dcf513abc_N912 | Sec9dcf513abc_N911 | attribute_value | 153–153 | flex items-center space-x-3 |
| Sec9dcf513abc_N913 | Sec9dcf513abc_N906 | element | 154–154 | element  |
| Sec9dcf513abc_N914 | Sec9dcf513abc_N913 | start_tag | 154–154 | start_tag  |
| Sec9dcf513abc_N915 | Sec9dcf513abc_N914 | tag_name | 154–154 | svg |
| Sec9dcf513abc_N916 | Sec9dcf513abc_N914 | attribute | 154–154 | attribute  |
| Sec9dcf513abc_N917 | Sec9dcf513abc_N916 | attribute_name | 154–154 | class |
| Sec9dcf513abc_N918 | Sec9dcf513abc_N916 | quoted_attribute_value | 154–154 | quoted_attribute_value  |
| Sec9dcf513abc_N919 | Sec9dcf513abc_N918 | attribute_value | 154–154 | w-4 h-4 opacity-80 text-celestial-brass |
| Sec9dcf513abc_N920 | Sec9dcf513abc_N914 | attribute | 154–154 | attribute  |
| Sec9dcf513abc_N921 | Sec9dcf513abc_N920 | attribute_name | 154–154 | fill |
| Sec9dcf513abc_N922 | Sec9dcf513abc_N920 | quoted_attribute_value | 154–154 | quoted_attribute_value  |
| Sec9dcf513abc_N923 | Sec9dcf513abc_N922 | attribute_value | 154–154 | none |
| Sec9dcf513abc_N924 | Sec9dcf513abc_N914 | attribute | 154–154 | attribute  |
| Sec9dcf513abc_N925 | Sec9dcf513abc_N924 | attribute_name | 154–154 | stroke |
| Sec9dcf513abc_N926 | Sec9dcf513abc_N924 | quoted_attribute_value | 154–154 | quoted_attribute_value  |
| Sec9dcf513abc_N927 | Sec9dcf513abc_N926 | attribute_value | 154–154 | currentColor |
| Sec9dcf513abc_N928 | Sec9dcf513abc_N914 | attribute | 154–154 | attribute  |
| Sec9dcf513abc_N929 | Sec9dcf513abc_N928 | attribute_name | 154–154 | viewbox |
| Sec9dcf513abc_N930 | Sec9dcf513abc_N928 | quoted_attribute_value | 154–154 | quoted_attribute_value  |
| Sec9dcf513abc_N931 | Sec9dcf513abc_N930 | attribute_value | 154–154 | 0 0 24 24 |
| Sec9dcf513abc_N932 | Sec9dcf513abc_N913 | element | 154–154 | element  |
| Sec9dcf513abc_N933 | Sec9dcf513abc_N932 | start_tag | 154–154 | start_tag  |
| Sec9dcf513abc_N934 | Sec9dcf513abc_N933 | tag_name | 154–154 | path |
| Sec9dcf513abc_N935 | Sec9dcf513abc_N933 | attribute | 154–154 | attribute  |
| Sec9dcf513abc_N936 | Sec9dcf513abc_N935 | attribute_name | 154–154 | d |
| Sec9dcf513abc_N937 | Sec9dcf513abc_N935 | quoted_attribute_value | 154–154 | quoted_attribute_value  |
| Sec9dcf513abc_N938 | Sec9dcf513abc_N937 | attribute_value | 154–154 | M13 10V3L4 14h7v7l9-11h-7z |
| Sec9dcf513abc_N939 | Sec9dcf513abc_N933 | attribute | 154–154 | attribute  |
| Sec9dcf513abc_N940 | Sec9dcf513abc_N939 | attribute_name | 154–154 | stroke-linecap |
| Sec9dcf513abc_N941 | Sec9dcf513abc_N939 | quoted_attribute_value | 154–154 | quoted_attribute_value  |
| Sec9dcf513abc_N942 | Sec9dcf513abc_N941 | attribute_value | 154–154 | round |
| Sec9dcf513abc_N943 | Sec9dcf513abc_N933 | attribute | 154–154 | attribute  |
| Sec9dcf513abc_N944 | Sec9dcf513abc_N943 | attribute_name | 154–154 | stroke-linejoin |
| Sec9dcf513abc_N945 | Sec9dcf513abc_N943 | quoted_attribute_value | 154–154 | quoted_attribute_value  |
| Sec9dcf513abc_N946 | Sec9dcf513abc_N945 | attribute_value | 154–154 | round |
| Sec9dcf513abc_N947 | Sec9dcf513abc_N933 | attribute | 154–154 | attribute  |
| Sec9dcf513abc_N948 | Sec9dcf513abc_N947 | attribute_name | 154–154 | stroke-width |
| Sec9dcf513abc_N949 | Sec9dcf513abc_N947 | quoted_attribute_value | 154–154 | quoted_attribute_value  |
| Sec9dcf513abc_N950 | Sec9dcf513abc_N949 | attribute_value | 154–154 | 2 |
| Sec9dcf513abc_N951 | Sec9dcf513abc_N932 | end_tag | 154–154 | end_tag  |
| Sec9dcf513abc_N952 | Sec9dcf513abc_N951 | tag_name | 154–154 | path |
| Sec9dcf513abc_N953 | Sec9dcf513abc_N913 | end_tag | 154–154 | end_tag  |
| Sec9dcf513abc_N954 | Sec9dcf513abc_N953 | tag_name | 154–154 | svg |
| Sec9dcf513abc_N955 | Sec9dcf513abc_N906 | element | 155–155 | element  |
| Sec9dcf513abc_N956 | Sec9dcf513abc_N955 | start_tag | 155–155 | start_tag  |
| Sec9dcf513abc_N957 | Sec9dcf513abc_N956 | tag_name | 155–155 | span |
| Sec9dcf513abc_N958 | Sec9dcf513abc_N955 | text | 155–155 | Alby Per-Turn Reading |
| Sec9dcf513abc_N959 | Sec9dcf513abc_N955 | end_tag | 155–155 | end_tag  |
| Sec9dcf513abc_N960 | Sec9dcf513abc_N959 | tag_name | 155–155 | span |
| Sec9dcf513abc_N961 | Sec9dcf513abc_N906 | end_tag | 156–156 | end_tag  |
| Sec9dcf513abc_N962 | Sec9dcf513abc_N961 | tag_name | 156–156 | span |
| Sec9dcf513abc_N963 | Sec9dcf513abc_N891 | element | 157–157 | element  |
| Sec9dcf513abc_N964 | Sec9dcf513abc_N963 | start_tag | 157–157 | start_tag  |
| Sec9dcf513abc_N965 | Sec9dcf513abc_N964 | tag_name | 157–157 | span |
| Sec9dcf513abc_N966 | Sec9dcf513abc_N964 | attribute | 157–157 | attribute  |
| Sec9dcf513abc_N967 | Sec9dcf513abc_N966 | attribute_name | 157–157 | class |
| Sec9dcf513abc_N968 | Sec9dcf513abc_N966 | quoted_attribute_value | 157–157 | quoted_attribute_value  |
| Sec9dcf513abc_N969 | Sec9dcf513abc_N968 | attribute_value | 157–157 | text-xs font-mono text-ash |
| Sec9dcf513abc_N970 | Sec9dcf513abc_N963 | text | 157–157 | → |
| Sec9dcf513abc_N971 | Sec9dcf513abc_N963 | end_tag | 157–157 | end_tag  |
| Sec9dcf513abc_N972 | Sec9dcf513abc_N971 | tag_name | 157–157 | span |
| Sec9dcf513abc_N973 | Sec9dcf513abc_N891 | end_tag | 158–158 | end_tag  |
| Sec9dcf513abc_N974 | Sec9dcf513abc_N973 | tag_name | 158–158 | button |
| Sec9dcf513abc_N975 | Sec9dcf513abc_N542 | element | 159–165 | element  |
| Sec9dcf513abc_N976 | Sec9dcf513abc_N975 | start_tag | 159–159 | start_tag  |
| Sec9dcf513abc_N977 | Sec9dcf513abc_N976 | tag_name | 159–159 | button |
| Sec9dcf513abc_N978 | Sec9dcf513abc_N976 | attribute | 159–159 | attribute  |
| Sec9dcf513abc_N979 | Sec9dcf513abc_N978 | attribute_name | 159–159 | class |
| Sec9dcf513abc_N980 | Sec9dcf513abc_N978 | quoted_attribute_value | 159–159 | quoted_attribute_value  |
| Sec9dcf513abc_N981 | Sec9dcf513abc_N980 | attribute_value | 159–159 | nav-tab w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm text-left font-medium transition-colors text-ash hover:text-starlight hover:bg-raised-charcoal/50 |
| Sec9dcf513abc_N982 | Sec9dcf513abc_N976 | attribute | 159–159 | attribute  |
| Sec9dcf513abc_N983 | Sec9dcf513abc_N982 | attribute_name | 159–159 | id |
| Sec9dcf513abc_N984 | Sec9dcf513abc_N982 | quoted_attribute_value | 159–159 | quoted_attribute_value  |
| Sec9dcf513abc_N985 | Sec9dcf513abc_N984 | attribute_value | 159–159 | view-billing |
| Sec9dcf513abc_N986 | Sec9dcf513abc_N976 | attribute | 159–159 | attribute  |
| Sec9dcf513abc_N987 | Sec9dcf513abc_N986 | attribute_name | 159–159 | onclick |
| Sec9dcf513abc_N988 | Sec9dcf513abc_N986 | quoted_attribute_value | 159–159 | quoted_attribute_value  |
| Sec9dcf513abc_N989 | Sec9dcf513abc_N988 | attribute_value | 159–159 | switchView('billing') |
| Sec9dcf513abc_N990 | Sec9dcf513abc_N975 | element | 160–163 | element  |
| Sec9dcf513abc_N991 | Sec9dcf513abc_N990 | start_tag | 160–160 | start_tag  |
| Sec9dcf513abc_N992 | Sec9dcf513abc_N991 | tag_name | 160–160 | span |
| Sec9dcf513abc_N993 | Sec9dcf513abc_N991 | attribute | 160–160 | attribute  |
| Sec9dcf513abc_N994 | Sec9dcf513abc_N993 | attribute_name | 160–160 | class |
| Sec9dcf513abc_N995 | Sec9dcf513abc_N993 | quoted_attribute_value | 160–160 | quoted_attribute_value  |
| Sec9dcf513abc_N996 | Sec9dcf513abc_N995 | attribute_value | 160–160 | flex items-center space-x-3 |
| Sec9dcf513abc_N997 | Sec9dcf513abc_N990 | element | 161–161 | element  |
| Sec9dcf513abc_N998 | Sec9dcf513abc_N997 | start_tag | 161–161 | start_tag  |
| Sec9dcf513abc_N999 | Sec9dcf513abc_N998 | tag_name | 161–161 | svg |
| Sec9dcf513abc_N1000 | Sec9dcf513abc_N998 | attribute | 161–161 | attribute  |
| Sec9dcf513abc_N1001 | Sec9dcf513abc_N1000 | attribute_name | 161–161 | class |
| Sec9dcf513abc_N1002 | Sec9dcf513abc_N1000 | quoted_attribute_value | 161–161 | quoted_attribute_value  |
| Sec9dcf513abc_N1003 | Sec9dcf513abc_N1002 | attribute_value | 161–161 | w-4 h-4 opacity-80 |
| Sec9dcf513abc_N1004 | Sec9dcf513abc_N998 | attribute | 161–161 | attribute  |
| Sec9dcf513abc_N1005 | Sec9dcf513abc_N1004 | attribute_name | 161–161 | fill |
| Sec9dcf513abc_N1006 | Sec9dcf513abc_N1004 | quoted_attribute_value | 161–161 | quoted_attribute_value  |
| Sec9dcf513abc_N1007 | Sec9dcf513abc_N1006 | attribute_value | 161–161 | none |
| Sec9dcf513abc_N1008 | Sec9dcf513abc_N998 | attribute | 161–161 | attribute  |
| Sec9dcf513abc_N1009 | Sec9dcf513abc_N1008 | attribute_name | 161–161 | stroke |
| Sec9dcf513abc_N1010 | Sec9dcf513abc_N1008 | quoted_attribute_value | 161–161 | quoted_attribute_value  |
| Sec9dcf513abc_N1011 | Sec9dcf513abc_N1010 | attribute_value | 161–161 | currentColor |
| Sec9dcf513abc_N1012 | Sec9dcf513abc_N998 | attribute | 161–161 | attribute  |
| Sec9dcf513abc_N1013 | Sec9dcf513abc_N1012 | attribute_name | 161–161 | viewbox |
| Sec9dcf513abc_N1014 | Sec9dcf513abc_N1012 | quoted_attribute_value | 161–161 | quoted_attribute_value  |
| Sec9dcf513abc_N1015 | Sec9dcf513abc_N1014 | attribute_value | 161–161 | 0 0 24 24 |
| Sec9dcf513abc_N1016 | Sec9dcf513abc_N997 | element | 161–161 | element  |
| Sec9dcf513abc_N1017 | Sec9dcf513abc_N1016 | start_tag | 161–161 | start_tag  |
| Sec9dcf513abc_N1018 | Sec9dcf513abc_N1017 | tag_name | 161–161 | path |
| Sec9dcf513abc_N1019 | Sec9dcf513abc_N1017 | attribute | 161–161 | attribute  |
| Sec9dcf513abc_N1020 | Sec9dcf513abc_N1019 | attribute_name | 161–161 | d |
| Sec9dcf513abc_N1021 | Sec9dcf513abc_N1019 | quoted_attribute_value | 161–161 | quoted_attribute_value  |
| Sec9dcf513abc_N1022 | Sec9dcf513abc_N1021 | attribute_value | 161–161 | M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z |
| Sec9dcf513abc_N1023 | Sec9dcf513abc_N1017 | attribute | 161–161 | attribute  |
| Sec9dcf513abc_N1024 | Sec9dcf513abc_N1023 | attribute_name | 161–161 | stroke-linecap |
| Sec9dcf513abc_N1025 | Sec9dcf513abc_N1023 | quoted_attribute_value | 161–161 | quoted_attribute_value  |
| Sec9dcf513abc_N1026 | Sec9dcf513abc_N1025 | attribute_value | 161–161 | round |
| Sec9dcf513abc_N1027 | Sec9dcf513abc_N1017 | attribute | 161–161 | attribute  |
| Sec9dcf513abc_N1028 | Sec9dcf513abc_N1027 | attribute_name | 161–161 | stroke-linejoin |
| Sec9dcf513abc_N1029 | Sec9dcf513abc_N1027 | quoted_attribute_value | 161–161 | quoted_attribute_value  |
| Sec9dcf513abc_N1030 | Sec9dcf513abc_N1029 | attribute_value | 161–161 | round |
| Sec9dcf513abc_N1031 | Sec9dcf513abc_N1017 | attribute | 161–161 | attribute  |
| Sec9dcf513abc_N1032 | Sec9dcf513abc_N1031 | attribute_name | 161–161 | stroke-width |
| Sec9dcf513abc_N1033 | Sec9dcf513abc_N1031 | quoted_attribute_value | 161–161 | quoted_attribute_value  |
| Sec9dcf513abc_N1034 | Sec9dcf513abc_N1033 | attribute_value | 161–161 | 2 |
| Sec9dcf513abc_N1035 | Sec9dcf513abc_N1016 | end_tag | 161–161 | end_tag  |
| Sec9dcf513abc_N1036 | Sec9dcf513abc_N1035 | tag_name | 161–161 | path |
| Sec9dcf513abc_N1037 | Sec9dcf513abc_N997 | end_tag | 161–161 | end_tag  |
| Sec9dcf513abc_N1038 | Sec9dcf513abc_N1037 | tag_name | 161–161 | svg |
| Sec9dcf513abc_N1039 | Sec9dcf513abc_N990 | element | 162–162 | element  |
| Sec9dcf513abc_N1040 | Sec9dcf513abc_N1039 | start_tag | 162–162 | start_tag  |
| Sec9dcf513abc_N1041 | Sec9dcf513abc_N1040 | tag_name | 162–162 | span |
| Sec9dcf513abc_N1042 | Sec9dcf513abc_N1039 | text | 162–162 | Billing Account |
| Sec9dcf513abc_N1043 | Sec9dcf513abc_N1039 | entity | 162–162 | &amp;amp; |
| Sec9dcf513abc_N1044 | Sec9dcf513abc_N1039 | text | 162–162 | Receipts |
| Sec9dcf513abc_N1045 | Sec9dcf513abc_N1039 | end_tag | 162–162 | end_tag  |
| Sec9dcf513abc_N1046 | Sec9dcf513abc_N1045 | tag_name | 162–162 | span |
| Sec9dcf513abc_N1047 | Sec9dcf513abc_N990 | end_tag | 163–163 | end_tag  |
| Sec9dcf513abc_N1048 | Sec9dcf513abc_N1047 | tag_name | 163–163 | span |
| Sec9dcf513abc_N1049 | Sec9dcf513abc_N975 | element | 164–164 | element  |
| Sec9dcf513abc_N1050 | Sec9dcf513abc_N1049 | start_tag | 164–164 | start_tag  |
| Sec9dcf513abc_N1051 | Sec9dcf513abc_N1050 | tag_name | 164–164 | span |
| Sec9dcf513abc_N1052 | Sec9dcf513abc_N1050 | attribute | 164–164 | attribute  |
| Sec9dcf513abc_N1053 | Sec9dcf513abc_N1052 | attribute_name | 164–164 | class |
| Sec9dcf513abc_N1054 | Sec9dcf513abc_N1052 | quoted_attribute_value | 164–164 | quoted_attribute_value  |
| Sec9dcf513abc_N1055 | Sec9dcf513abc_N1054 | attribute_value | 164–164 | text-xs font-mono text-ash |
| Sec9dcf513abc_N1056 | Sec9dcf513abc_N1049 | text | 164–164 | → |
| Sec9dcf513abc_N1057 | Sec9dcf513abc_N1049 | end_tag | 164–164 | end_tag  |
| Sec9dcf513abc_N1058 | Sec9dcf513abc_N1057 | tag_name | 164–164 | span |
| Sec9dcf513abc_N1059 | Sec9dcf513abc_N975 | end_tag | 165–165 | end_tag  |
| Sec9dcf513abc_N1060 | Sec9dcf513abc_N1059 | tag_name | 165–165 | button |
| Sec9dcf513abc_N1061 | Sec9dcf513abc_N542 | element | 166–172 | element  |
| Sec9dcf513abc_N1062 | Sec9dcf513abc_N1061 | start_tag | 166–166 | start_tag  |
| Sec9dcf513abc_N1063 | Sec9dcf513abc_N1062 | tag_name | 166–166 | button |
| Sec9dcf513abc_N1064 | Sec9dcf513abc_N1062 | attribute | 166–166 | attribute  |
| Sec9dcf513abc_N1065 | Sec9dcf513abc_N1064 | attribute_name | 166–166 | class |
| Sec9dcf513abc_N1066 | Sec9dcf513abc_N1064 | quoted_attribute_value | 166–166 | quoted_attribute_value  |
| Sec9dcf513abc_N1067 | Sec9dcf513abc_N1066 | attribute_value | 166–166 | nav-tab w-full flex items-center justify-between px-3.5 py-2.5 rounded-lg text-sm text-left font-medium transition-colors text-ash hover:text-starlight hover:bg-raised-charcoal/50 |
| Sec9dcf513abc_N1068 | Sec9dcf513abc_N1062 | attribute | 166–166 | attribute  |
| Sec9dcf513abc_N1069 | Sec9dcf513abc_N1068 | attribute_name | 166–166 | id |
| Sec9dcf513abc_N1070 | Sec9dcf513abc_N1068 | quoted_attribute_value | 166–166 | quoted_attribute_value  |
| Sec9dcf513abc_N1071 | Sec9dcf513abc_N1070 | attribute_value | 166–166 | view-conversation |
| Sec9dcf513abc_N1072 | Sec9dcf513abc_N1062 | attribute | 166–166 | attribute  |
| Sec9dcf513abc_N1073 | Sec9dcf513abc_N1072 | attribute_name | 166–166 | onclick |
| Sec9dcf513abc_N1074 | Sec9dcf513abc_N1072 | quoted_attribute_value | 166–166 | quoted_attribute_value  |
| Sec9dcf513abc_N1075 | Sec9dcf513abc_N1074 | attribute_value | 166–166 | switchView('conversation') |
| Sec9dcf513abc_N1076 | Sec9dcf513abc_N1061 | element | 167–170 | element  |
| Sec9dcf513abc_N1077 | Sec9dcf513abc_N1076 | start_tag | 167–167 | start_tag  |
| Sec9dcf513abc_N1078 | Sec9dcf513abc_N1077 | tag_name | 167–167 | span |
| Sec9dcf513abc_N1079 | Sec9dcf513abc_N1077 | attribute | 167–167 | attribute  |
| Sec9dcf513abc_N1080 | Sec9dcf513abc_N1079 | attribute_name | 167–167 | class |
| Sec9dcf513abc_N1081 | Sec9dcf513abc_N1079 | quoted_attribute_value | 167–167 | quoted_attribute_value  |
| Sec9dcf513abc_N1082 | Sec9dcf513abc_N1081 | attribute_value | 167–167 | flex items-center space-x-3 |
| Sec9dcf513abc_N1083 | Sec9dcf513abc_N1076 | element | 168–168 | element  |
| Sec9dcf513abc_N1084 | Sec9dcf513abc_N1083 | start_tag | 168–168 | start_tag  |
| Sec9dcf513abc_N1085 | Sec9dcf513abc_N1084 | tag_name | 168–168 | svg |
| Sec9dcf513abc_N1086 | Sec9dcf513abc_N1084 | attribute | 168–168 | attribute  |
| Sec9dcf513abc_N1087 | Sec9dcf513abc_N1086 | attribute_name | 168–168 | class |
| Sec9dcf513abc_N1088 | Sec9dcf513abc_N1086 | quoted_attribute_value | 168–168 | quoted_attribute_value  |
| Sec9dcf513abc_N1089 | Sec9dcf513abc_N1088 | attribute_value | 168–168 | w-4 h-4 opacity-80 |
| Sec9dcf513abc_N1090 | Sec9dcf513abc_N1084 | attribute | 168–168 | attribute  |
| Sec9dcf513abc_N1091 | Sec9dcf513abc_N1090 | attribute_name | 168–168 | fill |
| Sec9dcf513abc_N1092 | Sec9dcf513abc_N1090 | quoted_attribute_value | 168–168 | quoted_attribute_value  |
| Sec9dcf513abc_N1093 | Sec9dcf513abc_N1092 | attribute_value | 168–168 | none |
| Sec9dcf513abc_N1094 | Sec9dcf513abc_N1084 | attribute | 168–168 | attribute  |
| Sec9dcf513abc_N1095 | Sec9dcf513abc_N1094 | attribute_name | 168–168 | stroke |
| Sec9dcf513abc_N1096 | Sec9dcf513abc_N1094 | quoted_attribute_value | 168–168 | quoted_attribute_value  |
| Sec9dcf513abc_N1097 | Sec9dcf513abc_N1096 | attribute_value | 168–168 | currentColor |
| Sec9dcf513abc_N1098 | Sec9dcf513abc_N1084 | attribute | 168–168 | attribute  |
| Sec9dcf513abc_N1099 | Sec9dcf513abc_N1098 | attribute_name | 168–168 | viewbox |
| Sec9dcf513abc_N1100 | Sec9dcf513abc_N1098 | quoted_attribute_value | 168–168 | quoted_attribute_value  |
| Sec9dcf513abc_N1101 | Sec9dcf513abc_N1100 | attribute_value | 168–168 | 0 0 24 24 |
| Sec9dcf513abc_N1102 | Sec9dcf513abc_N1083 | element | 168–168 | element  |
| Sec9dcf513abc_N1103 | Sec9dcf513abc_N1102 | start_tag | 168–168 | start_tag  |
| Sec9dcf513abc_N1104 | Sec9dcf513abc_N1103 | tag_name | 168–168 | path |
| Sec9dcf513abc_N1105 | Sec9dcf513abc_N1103 | attribute | 168–168 | attribute  |
| Sec9dcf513abc_N1106 | Sec9dcf513abc_N1105 | attribute_name | 168–168 | d |
| Sec9dcf513abc_N1107 | Sec9dcf513abc_N1105 | quoted_attribute_value | 168–168 | quoted_attribute_value  |
| Sec9dcf513abc_N1108 | Sec9dcf513abc_N1107 | attribute_value | 168–168 | M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z |
| Sec9dcf513abc_N1109 | Sec9dcf513abc_N1103 | attribute | 168–168 | attribute  |
| Sec9dcf513abc_N1110 | Sec9dcf513abc_N1109 | attribute_name | 168–168 | stroke-linecap |
| Sec9dcf513abc_N1111 | Sec9dcf513abc_N1109 | quoted_attribute_value | 168–168 | quoted_attribute_value  |
| Sec9dcf513abc_N1112 | Sec9dcf513abc_N1111 | attribute_value | 168–168 | round |
| Sec9dcf513abc_N1113 | Sec9dcf513abc_N1103 | attribute | 168–168 | attribute  |
| Sec9dcf513abc_N1114 | Sec9dcf513abc_N1113 | attribute_name | 168–168 | stroke-linejoin |
| Sec9dcf513abc_N1115 | Sec9dcf513abc_N1113 | quoted_attribute_value | 168–168 | quoted_attribute_value  |
| Sec9dcf513abc_N1116 | Sec9dcf513abc_N1115 | attribute_value | 168–168 | round |
| Sec9dcf513abc_N1117 | Sec9dcf513abc_N1103 | attribute | 168–168 | attribute  |
| Sec9dcf513abc_N1118 | Sec9dcf513abc_N1117 | attribute_name | 168–168 | stroke-width |
| Sec9dcf513abc_N1119 | Sec9dcf513abc_N1117 | quoted_attribute_value | 168–168 | quoted_attribute_value  |
| Sec9dcf513abc_N1120 | Sec9dcf513abc_N1119 | attribute_value | 168–168 | 2 |
| Sec9dcf513abc_N1121 | Sec9dcf513abc_N1102 | end_tag | 168–168 | end_tag  |
| Sec9dcf513abc_N1122 | Sec9dcf513abc_N1121 | tag_name | 168–168 | path |
| Sec9dcf513abc_N1123 | Sec9dcf513abc_N1083 | end_tag | 168–168 | end_tag  |
| Sec9dcf513abc_N1124 | Sec9dcf513abc_N1123 | tag_name | 168–168 | svg |
| Sec9dcf513abc_N1125 | Sec9dcf513abc_N1076 | element | 169–169 | element  |
| Sec9dcf513abc_N1126 | Sec9dcf513abc_N1125 | start_tag | 169–169 | start_tag  |
| Sec9dcf513abc_N1127 | Sec9dcf513abc_N1126 | tag_name | 169–169 | span |
| Sec9dcf513abc_N1128 | Sec9dcf513abc_N1125 | text | 169–169 | Atelier Conversation |
| Sec9dcf513abc_N1129 | Sec9dcf513abc_N1125 | end_tag | 169–169 | end_tag  |
| Sec9dcf513abc_N1130 | Sec9dcf513abc_N1129 | tag_name | 169–169 | span |
| Sec9dcf513abc_N1131 | Sec9dcf513abc_N1076 | end_tag | 170–170 | end_tag  |
| Sec9dcf513abc_N1132 | Sec9dcf513abc_N1131 | tag_name | 170–170 | span |
| Sec9dcf513abc_N1133 | Sec9dcf513abc_N1061 | element | 171–171 | element  |
| Sec9dcf513abc_N1134 | Sec9dcf513abc_N1133 | start_tag | 171–171 | start_tag  |
| Sec9dcf513abc_N1135 | Sec9dcf513abc_N1134 | tag_name | 171–171 | span |
| Sec9dcf513abc_N1136 | Sec9dcf513abc_N1134 | attribute | 171–171 | attribute  |
| Sec9dcf513abc_N1137 | Sec9dcf513abc_N1136 | attribute_name | 171–171 | class |
| Sec9dcf513abc_N1138 | Sec9dcf513abc_N1136 | quoted_attribute_value | 171–171 | quoted_attribute_value  |
| Sec9dcf513abc_N1139 | Sec9dcf513abc_N1138 | attribute_value | 171–171 | text-xs font-mono text-ash |
| Sec9dcf513abc_N1140 | Sec9dcf513abc_N1133 | text | 171–171 | → |
| Sec9dcf513abc_N1141 | Sec9dcf513abc_N1133 | end_tag | 171–171 | end_tag  |
| Sec9dcf513abc_N1142 | Sec9dcf513abc_N1141 | tag_name | 171–171 | span |
| Sec9dcf513abc_N1143 | Sec9dcf513abc_N1061 | end_tag | 172–172 | end_tag  |
| Sec9dcf513abc_N1144 | Sec9dcf513abc_N1143 | tag_name | 172–172 | button |
| Sec9dcf513abc_N1145 | Sec9dcf513abc_N542 | end_tag | 173–173 | end_tag  |
| Sec9dcf513abc_N1146 | Sec9dcf513abc_N1145 | tag_name | 173–173 | nav |
| Sec9dcf513abc_N1147 | Sec9dcf513abc_N461 | comment | 174–174 | &lt;!-- Technical Architecture Disclaimer --&gt; |
| Sec9dcf513abc_N1148 | Sec9dcf513abc_N461 | element | 175–180 | element  |
| Sec9dcf513abc_N1149 | Sec9dcf513abc_N1148 | start_tag | 175–175 | start_tag  |
| Sec9dcf513abc_N1150 | Sec9dcf513abc_N1149 | tag_name | 175–175 | div |
| Sec9dcf513abc_N1151 | Sec9dcf513abc_N1149 | attribute | 175–175 | attribute  |
| Sec9dcf513abc_N1152 | Sec9dcf513abc_N1151 | attribute_name | 175–175 | class |
| Sec9dcf513abc_N1153 | Sec9dcf513abc_N1151 | quoted_attribute_value | 175–175 | quoted_attribute_value  |
| Sec9dcf513abc_N1154 | Sec9dcf513abc_N1153 | attribute_value | 175–175 | p-4 rounded-xl border border-hairline/60 bg-surface-dim text-xs text-ash space-y-2 |
| Sec9dcf513abc_N1155 | Sec9dcf513abc_N1148 | element | 176–176 | element  |
| Sec9dcf513abc_N1156 | Sec9dcf513abc_N1155 | start_tag | 176–176 | start_tag  |
| Sec9dcf513abc_N1157 | Sec9dcf513abc_N1156 | tag_name | 176–176 | div |
| Sec9dcf513abc_N1158 | Sec9dcf513abc_N1156 | attribute | 176–176 | attribute  |
| Sec9dcf513abc_N1159 | Sec9dcf513abc_N1158 | attribute_name | 176–176 | class |
| Sec9dcf513abc_N1160 | Sec9dcf513abc_N1158 | quoted_attribute_value | 176–176 | quoted_attribute_value  |
| Sec9dcf513abc_N1161 | Sec9dcf513abc_N1160 | attribute_value | 176–176 | font-mono text-[11px] text-celestial-brass uppercase font-semibold |
| Sec9dcf513abc_N1162 | Sec9dcf513abc_N1155 | text | 176–176 | Operator Directive · 21 Oct 2026 |
| Sec9dcf513abc_N1163 | Sec9dcf513abc_N1155 | end_tag | 176–176 | end_tag  |
| Sec9dcf513abc_N1164 | Sec9dcf513abc_N1163 | tag_name | 176–176 | div |
| Sec9dcf513abc_N1165 | Sec9dcf513abc_N1148 | element | 177–179 | element  |
| Sec9dcf513abc_N1166 | Sec9dcf513abc_N1165 | start_tag | 177–177 | start_tag  |
| Sec9dcf513abc_N1167 | Sec9dcf513abc_N1166 | tag_name | 177–177 | p |
| Sec9dcf513abc_N1168 | Sec9dcf513abc_N1166 | attribute | 177–177 | attribute  |
| Sec9dcf513abc_N1169 | Sec9dcf513abc_N1168 | attribute_name | 177–177 | class |
| Sec9dcf513abc_N1170 | Sec9dcf513abc_N1168 | quoted_attribute_value | 177–177 | quoted_attribute_value  |
| Sec9dcf513abc_N1171 | Sec9dcf513abc_N1170 | attribute_value | 177–177 | leading-relaxed |
| Sec9dcf513abc_N1172 | Sec9dcf513abc_N1165 | text | 178–178 | WooCommerce buildout deferred. First launch isolated with |
| Sec9dcf513abc_N1173 | Sec9dcf513abc_N1165 | element | 178–178 | element  |
| Sec9dcf513abc_N1174 | Sec9dcf513abc_N1173 | start_tag | 178–178 | start_tag  |
| Sec9dcf513abc_N1175 | Sec9dcf513abc_N1174 | tag_name | 178–178 | strong |
| Sec9dcf513abc_N1176 | Sec9dcf513abc_N1173 | text | 178–178 | RevenueCat |
| Sec9dcf513abc_N1177 | Sec9dcf513abc_N1173 | end_tag | 178–178 | end_tag  |
| Sec9dcf513abc_N1178 | Sec9dcf513abc_N1177 | tag_name | 178–178 | strong |
| Sec9dcf513abc_N1179 | Sec9dcf513abc_N1165 | text | 178–178 | (PDF/SPA purchases) and |
| Sec9dcf513abc_N1180 | Sec9dcf513abc_N1165 | element | 178–178 | element  |
| Sec9dcf513abc_N1181 | Sec9dcf513abc_N1180 | start_tag | 178–178 | start_tag  |
| Sec9dcf513abc_N1182 | Sec9dcf513abc_N1181 | tag_name | 178–178 | strong |
| Sec9dcf513abc_N1183 | Sec9dcf513abc_N1180 | text | 178–178 | Alby |
| Sec9dcf513abc_N1184 | Sec9dcf513abc_N1180 | end_tag | 178–178 | end_tag  |
| Sec9dcf513abc_N1185 | Sec9dcf513abc_N1184 | tag_name | 178–178 | strong |
| Sec9dcf513abc_N1186 | Sec9dcf513abc_N1165 | text | 178–178 | (metered turns). No funds transfer or real settlement in this prototype. |
| Sec9dcf513abc_N1187 | Sec9dcf513abc_N1165 | end_tag | 179–179 | end_tag  |
| Sec9dcf513abc_N1188 | Sec9dcf513abc_N1187 | tag_name | 179–179 | p |
| Sec9dcf513abc_N1189 | Sec9dcf513abc_N1148 | end_tag | 180–180 | end_tag  |
| Sec9dcf513abc_N1190 | Sec9dcf513abc_N1189 | tag_name | 180–180 | div |
| Sec9dcf513abc_N1191 | Sec9dcf513abc_N461 | end_tag | 181–181 | end_tag  |
| Sec9dcf513abc_N1192 | Sec9dcf513abc_N1191 | tag_name | 181–181 | aside |
| Sec9dcf513abc_N1193 | Sec9dcf513abc_N453 | comment | 182–182 | &lt;!-- RIGHT / MAIN CONTENT AREA --&gt; |
| Sec9dcf513abc_N1194 | Sec9dcf513abc_N453 | element | 183–557 | element  |
| Sec9dcf513abc_N1195 | Sec9dcf513abc_N1194 | start_tag | 183–183 | start_tag  |
| Sec9dcf513abc_N1196 | Sec9dcf513abc_N1195 | tag_name | 183–183 | section |
| Sec9dcf513abc_N1197 | Sec9dcf513abc_N1195 | attribute | 183–183 | attribute  |
| Sec9dcf513abc_N1198 | Sec9dcf513abc_N1197 | attribute_name | 183–183 | class |
| Sec9dcf513abc_N1199 | Sec9dcf513abc_N1197 | quoted_attribute_value | 183–183 | quoted_attribute_value  |
| Sec9dcf513abc_N1200 | Sec9dcf513abc_N1199 | attribute_value | 183–183 | lg:col-span-8 xl:col-span-9 bg-raised-charcoal border border-hairline rounded-2xl p-6 sm:p-8 relative min-h-[580px] |
| Sec9dcf513abc_N1201 | Sec9dcf513abc_N1194 | comment | 184–184 | &lt;!-- SECTION 1: PROFILE (Default Active) --&gt; |
| Sec9dcf513abc_N1202 | Sec9dcf513abc_N1194 | element | 185–265 | element  |
| Sec9dcf513abc_N1203 | Sec9dcf513abc_N1202 | start_tag | 185–185 | start_tag  |
| Sec9dcf513abc_N1204 | Sec9dcf513abc_N1203 | tag_name | 185–185 | div |
| Sec9dcf513abc_N1205 | Sec9dcf513abc_N1203 | attribute | 185–185 | attribute  |
| Sec9dcf513abc_N1206 | Sec9dcf513abc_N1205 | attribute_name | 185–185 | class |
| Sec9dcf513abc_N1207 | Sec9dcf513abc_N1205 | quoted_attribute_value | 185–185 | quoted_attribute_value  |
| Sec9dcf513abc_N1208 | Sec9dcf513abc_N1207 | attribute_value | 185–185 | view-section active space-y-6 |
| Sec9dcf513abc_N1209 | Sec9dcf513abc_N1203 | attribute | 185–185 | attribute  |
| Sec9dcf513abc_N1210 | Sec9dcf513abc_N1209 | attribute_name | 185–185 | data-view |
| Sec9dcf513abc_N1211 | Sec9dcf513abc_N1209 | quoted_attribute_value | 185–185 | quoted_attribute_value  |
| Sec9dcf513abc_N1212 | Sec9dcf513abc_N1211 | attribute_value | 185–185 | profile |
| Sec9dcf513abc_N1213 | Sec9dcf513abc_N1203 | attribute | 185–185 | attribute  |
| Sec9dcf513abc_N1214 | Sec9dcf513abc_N1213 | attribute_name | 185–185 | id |
| Sec9dcf513abc_N1215 | Sec9dcf513abc_N1213 | quoted_attribute_value | 185–185 | quoted_attribute_value  |
| Sec9dcf513abc_N1216 | Sec9dcf513abc_N1215 | attribute_value | 185–185 | section-profile |
| Sec9dcf513abc_N1217 | Sec9dcf513abc_N1202 | element | 186–194 | element  |
| Sec9dcf513abc_N1218 | Sec9dcf513abc_N1217 | start_tag | 186–186 | start_tag  |
| Sec9dcf513abc_N1219 | Sec9dcf513abc_N1218 | tag_name | 186–186 | div |
| Sec9dcf513abc_N1220 | Sec9dcf513abc_N1218 | attribute | 186–186 | attribute  |
| Sec9dcf513abc_N1221 | Sec9dcf513abc_N1220 | attribute_name | 186–186 | class |
| Sec9dcf513abc_N1222 | Sec9dcf513abc_N1220 | quoted_attribute_value | 186–186 | quoted_attribute_value  |
| Sec9dcf513abc_N1223 | Sec9dcf513abc_N1222 | attribute_value | 186–186 | border-b border-hairline/80 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 |
| Sec9dcf513abc_N1224 | Sec9dcf513abc_N1217 | element | 187–190 | element  |
| Sec9dcf513abc_N1225 | Sec9dcf513abc_N1224 | start_tag | 187–187 | start_tag  |
| Sec9dcf513abc_N1226 | Sec9dcf513abc_N1225 | tag_name | 187–187 | div |
| Sec9dcf513abc_N1227 | Sec9dcf513abc_N1224 | element | 188–188 | element  |
| Sec9dcf513abc_N1228 | Sec9dcf513abc_N1227 | start_tag | 188–188 | start_tag  |
| Sec9dcf513abc_N1229 | Sec9dcf513abc_N1228 | tag_name | 188–188 | span |
| Sec9dcf513abc_N1230 | Sec9dcf513abc_N1228 | attribute | 188–188 | attribute  |
| Sec9dcf513abc_N1231 | Sec9dcf513abc_N1230 | attribute_name | 188–188 | class |
| Sec9dcf513abc_N1232 | Sec9dcf513abc_N1230 | quoted_attribute_value | 188–188 | quoted_attribute_value  |
| Sec9dcf513abc_N1233 | Sec9dcf513abc_N1232 | attribute_value | 188–188 | text-xs font-mono text-celestial-brass uppercase tracking-wider |
| Sec9dcf513abc_N1234 | Sec9dcf513abc_N1227 | text | 188–188 | Account Overview |
| Sec9dcf513abc_N1235 | Sec9dcf513abc_N1227 | end_tag | 188–188 | end_tag  |
| Sec9dcf513abc_N1236 | Sec9dcf513abc_N1235 | tag_name | 188–188 | span |
| Sec9dcf513abc_N1237 | Sec9dcf513abc_N1224 | element | 189–189 | element  |
| Sec9dcf513abc_N1238 | Sec9dcf513abc_N1237 | start_tag | 189–189 | start_tag  |
| Sec9dcf513abc_N1239 | Sec9dcf513abc_N1238 | tag_name | 189–189 | h1 |
| Sec9dcf513abc_N1240 | Sec9dcf513abc_N1238 | attribute | 189–189 | attribute  |
| Sec9dcf513abc_N1241 | Sec9dcf513abc_N1240 | attribute_name | 189–189 | class |
| Sec9dcf513abc_N1242 | Sec9dcf513abc_N1240 | quoted_attribute_value | 189–189 | quoted_attribute_value  |
| Sec9dcf513abc_N1243 | Sec9dcf513abc_N1242 | attribute_value | 189–189 | font-display text-2xl sm:text-3xl font-normal text-starlight mt-1 |
| Sec9dcf513abc_N1244 | Sec9dcf513abc_N1237 | text | 189–189 | Profile |
| Sec9dcf513abc_N1245 | Sec9dcf513abc_N1237 | entity | 189–189 | &amp;amp; |
| Sec9dcf513abc_N1246 | Sec9dcf513abc_N1237 | text | 189–189 | Reading Access |
| Sec9dcf513abc_N1247 | Sec9dcf513abc_N1237 | end_tag | 189–189 | end_tag  |
| Sec9dcf513abc_N1248 | Sec9dcf513abc_N1247 | tag_name | 189–189 | h1 |
| Sec9dcf513abc_N1249 | Sec9dcf513abc_N1224 | end_tag | 190–190 | end_tag  |
| Sec9dcf513abc_N1250 | Sec9dcf513abc_N1249 | tag_name | 190–190 | div |
| Sec9dcf513abc_N1251 | Sec9dcf513abc_N1217 | element | 191–193 | element  |
| Sec9dcf513abc_N1252 | Sec9dcf513abc_N1251 | start_tag | 191–191 | start_tag  |
| Sec9dcf513abc_N1253 | Sec9dcf513abc_N1252 | tag_name | 191–191 | div |
| Sec9dcf513abc_N1254 | Sec9dcf513abc_N1252 | attribute | 191–191 | attribute  |
| Sec9dcf513abc_N1255 | Sec9dcf513abc_N1254 | attribute_name | 191–191 | class |
| Sec9dcf513abc_N1256 | Sec9dcf513abc_N1254 | quoted_attribute_value | 191–191 | quoted_attribute_value  |
| Sec9dcf513abc_N1257 | Sec9dcf513abc_N1256 | attribute_value | 191–191 | inline-flex items-center px-3 py-1 rounded bg-surface-dim border border-hairline text-xs font-mono text-ash |
| Sec9dcf513abc_N1258 | Sec9dcf513abc_N1251 | text | 192–192 | User: |
| Sec9dcf513abc_N1259 | Sec9dcf513abc_N1251 | element | 192–192 | element  |
| Sec9dcf513abc_N1260 | Sec9dcf513abc_N1259 | start_tag | 192–192 | start_tag  |
| Sec9dcf513abc_N1261 | Sec9dcf513abc_N1260 | tag_name | 192–192 | strong |
| Sec9dcf513abc_N1262 | Sec9dcf513abc_N1260 | attribute | 192–192 | attribute  |
| Sec9dcf513abc_N1263 | Sec9dcf513abc_N1262 | attribute_name | 192–192 | class |
| Sec9dcf513abc_N1264 | Sec9dcf513abc_N1262 | quoted_attribute_value | 192–192 | quoted_attribute_value  |
| Sec9dcf513abc_N1265 | Sec9dcf513abc_N1264 | attribute_value | 192–192 | text-starlight ml-1 font-normal |
| Sec9dcf513abc_N1266 | Sec9dcf513abc_N1259 | text | 192–192 | Reading preview |
| Sec9dcf513abc_N1267 | Sec9dcf513abc_N1259 | end_tag | 192–192 | end_tag  |
| Sec9dcf513abc_N1268 | Sec9dcf513abc_N1267 | tag_name | 192–192 | strong |
| Sec9dcf513abc_N1269 | Sec9dcf513abc_N1251 | end_tag | 193–193 | end_tag  |
| Sec9dcf513abc_N1270 | Sec9dcf513abc_N1269 | tag_name | 193–193 | div |
| Sec9dcf513abc_N1271 | Sec9dcf513abc_N1217 | end_tag | 194–194 | end_tag  |
| Sec9dcf513abc_N1272 | Sec9dcf513abc_N1271 | tag_name | 194–194 | div |
| Sec9dcf513abc_N1273 | Sec9dcf513abc_N1202 | comment | 195–195 | &lt;!-- Account Identity Summary --&gt; |
| Sec9dcf513abc_N1274 | Sec9dcf513abc_N1202 | element | 196–212 | element  |
| Sec9dcf513abc_N1275 | Sec9dcf513abc_N1274 | start_tag | 196–196 | start_tag  |
| Sec9dcf513abc_N1276 | Sec9dcf513abc_N1275 | tag_name | 196–196 | div |
| Sec9dcf513abc_N1277 | Sec9dcf513abc_N1275 | attribute | 196–196 | attribute  |
| Sec9dcf513abc_N1278 | Sec9dcf513abc_N1277 | attribute_name | 196–196 | class |
| Sec9dcf513abc_N1279 | Sec9dcf513abc_N1277 | quoted_attribute_value | 196–196 | quoted_attribute_value  |
| Sec9dcf513abc_N1280 | Sec9dcf513abc_N1279 | attribute_value | 196–196 | grid grid-cols-1 sm:grid-cols-3 gap-4 |
| Sec9dcf513abc_N1281 | Sec9dcf513abc_N1274 | element | 197–201 | element  |
| Sec9dcf513abc_N1282 | Sec9dcf513abc_N1281 | start_tag | 197–197 | start_tag  |
| Sec9dcf513abc_N1283 | Sec9dcf513abc_N1282 | tag_name | 197–197 | div |
| Sec9dcf513abc_N1284 | Sec9dcf513abc_N1282 | attribute | 197–197 | attribute  |
| Sec9dcf513abc_N1285 | Sec9dcf513abc_N1284 | attribute_name | 197–197 | class |
| Sec9dcf513abc_N1286 | Sec9dcf513abc_N1284 | quoted_attribute_value | 197–197 | quoted_attribute_value  |
| Sec9dcf513abc_N1287 | Sec9dcf513abc_N1286 | attribute_value | 197–197 | p-4 rounded-xl bg-surface-dim border border-hairline |
| Sec9dcf513abc_N1288 | Sec9dcf513abc_N1281 | element | 198–198 | element  |
| Sec9dcf513abc_N1289 | Sec9dcf513abc_N1288 | start_tag | 198–198 | start_tag  |
| Sec9dcf513abc_N1290 | Sec9dcf513abc_N1289 | tag_name | 198–198 | span |
| Sec9dcf513abc_N1291 | Sec9dcf513abc_N1289 | attribute | 198–198 | attribute  |
| Sec9dcf513abc_N1292 | Sec9dcf513abc_N1291 | attribute_name | 198–198 | class |
| Sec9dcf513abc_N1293 | Sec9dcf513abc_N1291 | quoted_attribute_value | 198–198 | quoted_attribute_value  |
| Sec9dcf513abc_N1294 | Sec9dcf513abc_N1293 | attribute_value | 198–198 | text-xs font-mono text-ash block |
| Sec9dcf513abc_N1295 | Sec9dcf513abc_N1288 | text | 198–198 | Signed-in Identity |
| Sec9dcf513abc_N1296 | Sec9dcf513abc_N1288 | end_tag | 198–198 | end_tag  |
| Sec9dcf513abc_N1297 | Sec9dcf513abc_N1296 | tag_name | 198–198 | span |
| Sec9dcf513abc_N1298 | Sec9dcf513abc_N1281 | element | 199–199 | element  |
| Sec9dcf513abc_N1299 | Sec9dcf513abc_N1298 | start_tag | 199–199 | start_tag  |
| Sec9dcf513abc_N1300 | Sec9dcf513abc_N1299 | tag_name | 199–199 | span |
| Sec9dcf513abc_N1301 | Sec9dcf513abc_N1299 | attribute | 199–199 | attribute  |
| Sec9dcf513abc_N1302 | Sec9dcf513abc_N1301 | attribute_name | 199–199 | class |
| Sec9dcf513abc_N1303 | Sec9dcf513abc_N1301 | quoted_attribute_value | 199–199 | quoted_attribute_value  |
| Sec9dcf513abc_N1304 | Sec9dcf513abc_N1303 | attribute_value | 199–199 | text-base font-semibold text-starlight mt-1 block |
| Sec9dcf513abc_N1305 | Sec9dcf513abc_N1298 | text | 199–199 | Reading preview |
| Sec9dcf513abc_N1306 | Sec9dcf513abc_N1298 | end_tag | 199–199 | end_tag  |
| Sec9dcf513abc_N1307 | Sec9dcf513abc_N1306 | tag_name | 199–199 | span |
| Sec9dcf513abc_N1308 | Sec9dcf513abc_N1281 | element | 200–200 | element  |
| Sec9dcf513abc_N1309 | Sec9dcf513abc_N1308 | start_tag | 200–200 | start_tag  |
| Sec9dcf513abc_N1310 | Sec9dcf513abc_N1309 | tag_name | 200–200 | span |
| Sec9dcf513abc_N1311 | Sec9dcf513abc_N1309 | attribute | 200–200 | attribute  |
| Sec9dcf513abc_N1312 | Sec9dcf513abc_N1311 | attribute_name | 200–200 | class |
| Sec9dcf513abc_N1313 | Sec9dcf513abc_N1311 | quoted_attribute_value | 200–200 | quoted_attribute_value  |
| Sec9dcf513abc_N1314 | Sec9dcf513abc_N1313 | attribute_value | 200–200 | text-xs text-ash mt-1 block font-mono |
| Sec9dcf513abc_N1315 | Sec9dcf513abc_N1308 | text | 200–200 | auth: isolated-session |
| Sec9dcf513abc_N1316 | Sec9dcf513abc_N1308 | end_tag | 200–200 | end_tag  |
| Sec9dcf513abc_N1317 | Sec9dcf513abc_N1316 | tag_name | 200–200 | span |
| Sec9dcf513abc_N1318 | Sec9dcf513abc_N1281 | end_tag | 201–201 | end_tag  |
| Sec9dcf513abc_N1319 | Sec9dcf513abc_N1318 | tag_name | 201–201 | div |
| Sec9dcf513abc_N1320 | Sec9dcf513abc_N1274 | element | 202–206 | element  |
| Sec9dcf513abc_N1321 | Sec9dcf513abc_N1320 | start_tag | 202–202 | start_tag  |
| Sec9dcf513abc_N1322 | Sec9dcf513abc_N1321 | tag_name | 202–202 | div |
| Sec9dcf513abc_N1323 | Sec9dcf513abc_N1321 | attribute | 202–202 | attribute  |
| Sec9dcf513abc_N1324 | Sec9dcf513abc_N1323 | attribute_name | 202–202 | class |
| Sec9dcf513abc_N1325 | Sec9dcf513abc_N1323 | quoted_attribute_value | 202–202 | quoted_attribute_value  |
| Sec9dcf513abc_N1326 | Sec9dcf513abc_N1325 | attribute_value | 202–202 | p-4 rounded-xl bg-surface-dim border border-hairline |
| Sec9dcf513abc_N1327 | Sec9dcf513abc_N1320 | element | 203–203 | element  |
| Sec9dcf513abc_N1328 | Sec9dcf513abc_N1327 | start_tag | 203–203 | start_tag  |
| Sec9dcf513abc_N1329 | Sec9dcf513abc_N1328 | tag_name | 203–203 | span |
| Sec9dcf513abc_N1330 | Sec9dcf513abc_N1328 | attribute | 203–203 | attribute  |
| Sec9dcf513abc_N1331 | Sec9dcf513abc_N1330 | attribute_name | 203–203 | class |
| Sec9dcf513abc_N1332 | Sec9dcf513abc_N1330 | quoted_attribute_value | 203–203 | quoted_attribute_value  |
| Sec9dcf513abc_N1333 | Sec9dcf513abc_N1332 | attribute_value | 203–203 | text-xs font-mono text-ash block |
| Sec9dcf513abc_N1334 | Sec9dcf513abc_N1327 | text | 203–203 | Natal Reading Status |
| Sec9dcf513abc_N1335 | Sec9dcf513abc_N1327 | end_tag | 203–203 | end_tag  |
| Sec9dcf513abc_N1336 | Sec9dcf513abc_N1335 | tag_name | 203–203 | span |
| Sec9dcf513abc_N1337 | Sec9dcf513abc_N1320 | element | 204–204 | element  |
| Sec9dcf513abc_N1338 | Sec9dcf513abc_N1337 | start_tag | 204–204 | start_tag  |
| Sec9dcf513abc_N1339 | Sec9dcf513abc_N1338 | tag_name | 204–204 | span |
| Sec9dcf513abc_N1340 | Sec9dcf513abc_N1338 | attribute | 204–204 | attribute  |
| Sec9dcf513abc_N1341 | Sec9dcf513abc_N1340 | attribute_name | 204–204 | class |
| Sec9dcf513abc_N1342 | Sec9dcf513abc_N1340 | quoted_attribute_value | 204–204 | quoted_attribute_value  |
| Sec9dcf513abc_N1343 | Sec9dcf513abc_N1342 | attribute_value | 204–204 | text-base font-semibold text-celestial-brass mt-1 block |
| Sec9dcf513abc_N1344 | Sec9dcf513abc_N1337 | text | 204–204 | Unpurchased |
| Sec9dcf513abc_N1345 | Sec9dcf513abc_N1337 | end_tag | 204–204 | end_tag  |
| Sec9dcf513abc_N1346 | Sec9dcf513abc_N1345 | tag_name | 204–204 | span |
| Sec9dcf513abc_N1347 | Sec9dcf513abc_N1320 | element | 205–205 | element  |
| Sec9dcf513abc_N1348 | Sec9dcf513abc_N1347 | start_tag | 205–205 | start_tag  |
| Sec9dcf513abc_N1349 | Sec9dcf513abc_N1348 | tag_name | 205–205 | span |
| Sec9dcf513abc_N1350 | Sec9dcf513abc_N1348 | attribute | 205–205 | attribute  |
| Sec9dcf513abc_N1351 | Sec9dcf513abc_N1350 | attribute_name | 205–205 | class |
| Sec9dcf513abc_N1352 | Sec9dcf513abc_N1350 | quoted_attribute_value | 205–205 | quoted_attribute_value  |
| Sec9dcf513abc_N1353 | Sec9dcf513abc_N1352 | attribute_value | 205–205 | text-xs text-ash mt-1 block |
| Sec9dcf513abc_N1354 | Sec9dcf513abc_N1347 | text | 205–205 | PDF |
| Sec9dcf513abc_N1355 | Sec9dcf513abc_N1347 | entity | 205–205 | &amp;amp; |
| Sec9dcf513abc_N1356 | Sec9dcf513abc_N1347 | text | 205–205 | SPA not yet unlocked |
| Sec9dcf513abc_N1357 | Sec9dcf513abc_N1347 | end_tag | 205–205 | end_tag  |
| Sec9dcf513abc_N1358 | Sec9dcf513abc_N1357 | tag_name | 205–205 | span |
| Sec9dcf513abc_N1359 | Sec9dcf513abc_N1320 | end_tag | 206–206 | end_tag  |
| Sec9dcf513abc_N1360 | Sec9dcf513abc_N1359 | tag_name | 206–206 | div |
| Sec9dcf513abc_N1361 | Sec9dcf513abc_N1274 | element | 207–211 | element  |
| Sec9dcf513abc_N1362 | Sec9dcf513abc_N1361 | start_tag | 207–207 | start_tag  |
| Sec9dcf513abc_N1363 | Sec9dcf513abc_N1362 | tag_name | 207–207 | div |
| Sec9dcf513abc_N1364 | Sec9dcf513abc_N1362 | attribute | 207–207 | attribute  |
| Sec9dcf513abc_N1365 | Sec9dcf513abc_N1364 | attribute_name | 207–207 | class |
| Sec9dcf513abc_N1366 | Sec9dcf513abc_N1364 | quoted_attribute_value | 207–207 | quoted_attribute_value  |
| Sec9dcf513abc_N1367 | Sec9dcf513abc_N1366 | attribute_value | 207–207 | p-4 rounded-xl bg-surface-dim border border-hairline |
| Sec9dcf513abc_N1368 | Sec9dcf513abc_N1361 | element | 208–208 | element  |
| Sec9dcf513abc_N1369 | Sec9dcf513abc_N1368 | start_tag | 208–208 | start_tag  |
| Sec9dcf513abc_N1370 | Sec9dcf513abc_N1369 | tag_name | 208–208 | span |
| Sec9dcf513abc_N1371 | Sec9dcf513abc_N1369 | attribute | 208–208 | attribute  |
| Sec9dcf513abc_N1372 | Sec9dcf513abc_N1371 | attribute_name | 208–208 | class |
| Sec9dcf513abc_N1373 | Sec9dcf513abc_N1371 | quoted_attribute_value | 208–208 | quoted_attribute_value  |
| Sec9dcf513abc_N1374 | Sec9dcf513abc_N1373 | attribute_value | 208–208 | text-xs font-mono text-ash block |
| Sec9dcf513abc_N1375 | Sec9dcf513abc_N1368 | text | 208–208 | USD Credit Balance |
| Sec9dcf513abc_N1376 | Sec9dcf513abc_N1368 | end_tag | 208–208 | end_tag  |
| Sec9dcf513abc_N1377 | Sec9dcf513abc_N1376 | tag_name | 208–208 | span |
| Sec9dcf513abc_N1378 | Sec9dcf513abc_N1361 | element | 209–209 | element  |
| Sec9dcf513abc_N1379 | Sec9dcf513abc_N1378 | start_tag | 209–209 | start_tag  |
| Sec9dcf513abc_N1380 | Sec9dcf513abc_N1379 | tag_name | 209–209 | span |
| Sec9dcf513abc_N1381 | Sec9dcf513abc_N1379 | attribute | 209–209 | attribute  |
| Sec9dcf513abc_N1382 | Sec9dcf513abc_N1381 | attribute_name | 209–209 | class |
| Sec9dcf513abc_N1383 | Sec9dcf513abc_N1381 | quoted_attribute_value | 209–209 | quoted_attribute_value  |
| Sec9dcf513abc_N1384 | Sec9dcf513abc_N1383 | attribute_value | 209–209 | text-base font-semibold text-starlight mt-1 block font-mono |
| Sec9dcf513abc_N1385 | Sec9dcf513abc_N1378 | text | 209–209 | Unavailable |
| Sec9dcf513abc_N1386 | Sec9dcf513abc_N1378 | end_tag | 209–209 | end_tag  |
| Sec9dcf513abc_N1387 | Sec9dcf513abc_N1386 | tag_name | 209–209 | span |
| Sec9dcf513abc_N1388 | Sec9dcf513abc_N1361 | element | 210–210 | element  |
| Sec9dcf513abc_N1389 | Sec9dcf513abc_N1388 | start_tag | 210–210 | start_tag  |
| Sec9dcf513abc_N1390 | Sec9dcf513abc_N1389 | tag_name | 210–210 | span |
| Sec9dcf513abc_N1391 | Sec9dcf513abc_N1389 | attribute | 210–210 | attribute  |
| Sec9dcf513abc_N1392 | Sec9dcf513abc_N1391 | attribute_name | 210–210 | class |
| Sec9dcf513abc_N1393 | Sec9dcf513abc_N1391 | quoted_attribute_value | 210–210 | quoted_attribute_value  |
| Sec9dcf513abc_N1394 | Sec9dcf513abc_N1393 | attribute_value | 210–210 | text-xs text-ash mt-1 block |
| Sec9dcf513abc_N1395 | Sec9dcf513abc_N1388 | text | 210–210 | Awaiting verified account |
| Sec9dcf513abc_N1396 | Sec9dcf513abc_N1388 | end_tag | 210–210 | end_tag  |
| Sec9dcf513abc_N1397 | Sec9dcf513abc_N1396 | tag_name | 210–210 | span |
| Sec9dcf513abc_N1398 | Sec9dcf513abc_N1361 | end_tag | 211–211 | end_tag  |
| Sec9dcf513abc_N1399 | Sec9dcf513abc_N1398 | tag_name | 211–211 | div |
| Sec9dcf513abc_N1400 | Sec9dcf513abc_N1274 | end_tag | 212–212 | end_tag  |
| Sec9dcf513abc_N1401 | Sec9dcf513abc_N1400 | tag_name | 212–212 | div |
| Sec9dcf513abc_N1402 | Sec9dcf513abc_N1202 | comment | 213–213 | &lt;!-- Quick Actions Grid --&gt; |
| Sec9dcf513abc_N1403 | Sec9dcf513abc_N1202 | element | 214–256 | element  |
| Sec9dcf513abc_N1404 | Sec9dcf513abc_N1403 | start_tag | 214–214 | start_tag  |
| Sec9dcf513abc_N1405 | Sec9dcf513abc_N1404 | tag_name | 214–214 | div |
| Sec9dcf513abc_N1406 | Sec9dcf513abc_N1404 | attribute | 214–214 | attribute  |
| Sec9dcf513abc_N1407 | Sec9dcf513abc_N1406 | attribute_name | 214–214 | class |
| Sec9dcf513abc_N1408 | Sec9dcf513abc_N1406 | quoted_attribute_value | 214–214 | quoted_attribute_value  |
| Sec9dcf513abc_N1409 | Sec9dcf513abc_N1408 | attribute_value | 214–214 | space-y-4 pt-2 |
| Sec9dcf513abc_N1410 | Sec9dcf513abc_N1403 | element | 215–215 | element  |
| Sec9dcf513abc_N1411 | Sec9dcf513abc_N1410 | start_tag | 215–215 | start_tag  |
| Sec9dcf513abc_N1412 | Sec9dcf513abc_N1411 | tag_name | 215–215 | h2 |
| Sec9dcf513abc_N1413 | Sec9dcf513abc_N1411 | attribute | 215–215 | attribute  |
| Sec9dcf513abc_N1414 | Sec9dcf513abc_N1413 | attribute_name | 215–215 | class |
| Sec9dcf513abc_N1415 | Sec9dcf513abc_N1413 | quoted_attribute_value | 215–215 | quoted_attribute_value  |
| Sec9dcf513abc_N1416 | Sec9dcf513abc_N1415 | attribute_value | 215–215 | text-sm font-mono uppercase tracking-wider text-ash |
| Sec9dcf513abc_N1417 | Sec9dcf513abc_N1410 | text | 215–215 | Available Actions |
| Sec9dcf513abc_N1418 | Sec9dcf513abc_N1410 | end_tag | 215–215 | end_tag  |
| Sec9dcf513abc_N1419 | Sec9dcf513abc_N1418 | tag_name | 215–215 | h2 |
| Sec9dcf513abc_N1420 | Sec9dcf513abc_N1403 | element | 216–255 | element  |
| Sec9dcf513abc_N1421 | Sec9dcf513abc_N1420 | start_tag | 216–216 | start_tag  |
| Sec9dcf513abc_N1422 | Sec9dcf513abc_N1421 | tag_name | 216–216 | div |
| Sec9dcf513abc_N1423 | Sec9dcf513abc_N1421 | attribute | 216–216 | attribute  |
| Sec9dcf513abc_N1424 | Sec9dcf513abc_N1423 | attribute_name | 216–216 | class |
| Sec9dcf513abc_N1425 | Sec9dcf513abc_N1423 | quoted_attribute_value | 216–216 | quoted_attribute_value  |
| Sec9dcf513abc_N1426 | Sec9dcf513abc_N1425 | attribute_value | 216–216 | grid grid-cols-1 md:grid-cols-2 gap-4 |
| Sec9dcf513abc_N1427 | Sec9dcf513abc_N1420 | comment | 217–217 | &lt;!-- Buy Natal Chart Action --&gt; |
| Sec9dcf513abc_N1428 | Sec9dcf513abc_N1420 | element | 218–233 | element  |
| Sec9dcf513abc_N1429 | Sec9dcf513abc_N1428 | start_tag | 218–218 | start_tag  |
| Sec9dcf513abc_N1430 | Sec9dcf513abc_N1429 | tag_name | 218–218 | div |
| Sec9dcf513abc_N1431 | Sec9dcf513abc_N1429 | attribute | 218–218 | attribute  |
| Sec9dcf513abc_N1432 | Sec9dcf513abc_N1431 | attribute_name | 218–218 | class |
| Sec9dcf513abc_N1433 | Sec9dcf513abc_N1431 | quoted_attribute_value | 218–218 | quoted_attribute_value  |
| Sec9dcf513abc_N1434 | Sec9dcf513abc_N1433 | attribute_value | 218–218 | p-5 rounded-xl border border-celestial-brass/40 bg-surface-dim/80 hover:border-celestial-brass transition-colors flex flex-col justify-between space-y-4 |
| Sec9dcf513abc_N1435 | Sec9dcf513abc_N1428 | element | 219–228 | element  |
| Sec9dcf513abc_N1436 | Sec9dcf513abc_N1435 | start_tag | 219–219 | start_tag  |
| Sec9dcf513abc_N1437 | Sec9dcf513abc_N1436 | tag_name | 219–219 | div |
| Sec9dcf513abc_N1438 | Sec9dcf513abc_N1435 | element | 220–223 | element  |
| Sec9dcf513abc_N1439 | Sec9dcf513abc_N1438 | start_tag | 220–220 | start_tag  |
| Sec9dcf513abc_N1440 | Sec9dcf513abc_N1439 | tag_name | 220–220 | div |
| Sec9dcf513abc_N1441 | Sec9dcf513abc_N1439 | attribute | 220–220 | attribute  |
| Sec9dcf513abc_N1442 | Sec9dcf513abc_N1441 | attribute_name | 220–220 | class |
| Sec9dcf513abc_N1443 | Sec9dcf513abc_N1441 | quoted_attribute_value | 220–220 | quoted_attribute_value  |
| Sec9dcf513abc_N1444 | Sec9dcf513abc_N1443 | attribute_value | 220–220 | flex items-center justify-between |
| Sec9dcf513abc_N1445 | Sec9dcf513abc_N1438 | element | 221–221 | element  |
| Sec9dcf513abc_N1446 | Sec9dcf513abc_N1445 | start_tag | 221–221 | start_tag  |
| Sec9dcf513abc_N1447 | Sec9dcf513abc_N1446 | tag_name | 221–221 | span |
| Sec9dcf513abc_N1448 | Sec9dcf513abc_N1446 | attribute | 221–221 | attribute  |
| Sec9dcf513abc_N1449 | Sec9dcf513abc_N1448 | attribute_name | 221–221 | class |
| Sec9dcf513abc_N1450 | Sec9dcf513abc_N1448 | quoted_attribute_value | 221–221 | quoted_attribute_value  |
| Sec9dcf513abc_N1451 | Sec9dcf513abc_N1450 | attribute_value | 221–221 | text-xs font-mono text-celestial-brass font-semibold |
| Sec9dcf513abc_N1452 | Sec9dcf513abc_N1445 | text | 221–221 | Flagship Deliverable |
| Sec9dcf513abc_N1453 | Sec9dcf513abc_N1445 | end_tag | 221–221 | end_tag  |
| Sec9dcf513abc_N1454 | Sec9dcf513abc_N1453 | tag_name | 221–221 | span |
| Sec9dcf513abc_N1455 | Sec9dcf513abc_N1438 | element | 222–222 | element  |
| Sec9dcf513abc_N1456 | Sec9dcf513abc_N1455 | start_tag | 222–222 | start_tag  |
| Sec9dcf513abc_N1457 | Sec9dcf513abc_N1456 | tag_name | 222–222 | span |
| Sec9dcf513abc_N1458 | Sec9dcf513abc_N1456 | attribute | 222–222 | attribute  |
| Sec9dcf513abc_N1459 | Sec9dcf513abc_N1458 | attribute_name | 222–222 | class |
| Sec9dcf513abc_N1460 | Sec9dcf513abc_N1458 | quoted_attribute_value | 222–222 | quoted_attribute_value  |
| Sec9dcf513abc_N1461 | Sec9dcf513abc_N1460 | attribute_value | 222–222 | text-[11px] font-mono bg-celestial-brass/10 text-celestial-brass px-2 py-0.5 rounded |
| Sec9dcf513abc_N1462 | Sec9dcf513abc_N1455 | text | 222–222 | Site-Centric |
| Sec9dcf513abc_N1463 | Sec9dcf513abc_N1455 | end_tag | 222–222 | end_tag  |
| Sec9dcf513abc_N1464 | Sec9dcf513abc_N1463 | tag_name | 222–222 | span |
| Sec9dcf513abc_N1465 | Sec9dcf513abc_N1438 | end_tag | 223–223 | end_tag  |
| Sec9dcf513abc_N1466 | Sec9dcf513abc_N1465 | tag_name | 223–223 | div |
| Sec9dcf513abc_N1467 | Sec9dcf513abc_N1435 | element | 224–224 | element  |
| Sec9dcf513abc_N1468 | Sec9dcf513abc_N1467 | start_tag | 224–224 | start_tag  |
| Sec9dcf513abc_N1469 | Sec9dcf513abc_N1468 | tag_name | 224–224 | h3 |
| Sec9dcf513abc_N1470 | Sec9dcf513abc_N1468 | attribute | 224–224 | attribute  |
| Sec9dcf513abc_N1471 | Sec9dcf513abc_N1470 | attribute_name | 224–224 | class |
| Sec9dcf513abc_N1472 | Sec9dcf513abc_N1470 | quoted_attribute_value | 224–224 | quoted_attribute_value  |
| Sec9dcf513abc_N1473 | Sec9dcf513abc_N1472 | attribute_value | 224–224 | font-display text-lg text-starlight mt-2 |
| Sec9dcf513abc_N1474 | Sec9dcf513abc_N1467 | text | 224–224 | Buy natal chart (PDF + SPA) |
| Sec9dcf513abc_N1475 | Sec9dcf513abc_N1467 | end_tag | 224–224 | end_tag  |
| Sec9dcf513abc_N1476 | Sec9dcf513abc_N1475 | tag_name | 224–224 | h3 |
| Sec9dcf513abc_N1477 | Sec9dcf513abc_N1435 | element | 225–227 | element  |
| Sec9dcf513abc_N1478 | Sec9dcf513abc_N1477 | start_tag | 225–225 | start_tag  |
| Sec9dcf513abc_N1479 | Sec9dcf513abc_N1478 | tag_name | 225–225 | p |
| Sec9dcf513abc_N1480 | Sec9dcf513abc_N1478 | attribute | 225–225 | attribute  |
| Sec9dcf513abc_N1481 | Sec9dcf513abc_N1480 | attribute_name | 225–225 | class |
| Sec9dcf513abc_N1482 | Sec9dcf513abc_N1480 | quoted_attribute_value | 225–225 | quoted_attribute_value  |
| Sec9dcf513abc_N1483 | Sec9dcf513abc_N1482 | attribute_value | 225–225 | text-xs text-ash mt-1 leading-relaxed |
| Sec9dcf513abc_N1484 | Sec9dcf513abc_N1477 | text | 226–226 | High-resolution 300 DPI folio plus interactive conversational reading. Hosted via RevenueCat channel. |
| Sec9dcf513abc_N1485 | Sec9dcf513abc_N1477 | end_tag | 227–227 | end_tag  |
| Sec9dcf513abc_N1486 | Sec9dcf513abc_N1485 | tag_name | 227–227 | p |
| Sec9dcf513abc_N1487 | Sec9dcf513abc_N1435 | end_tag | 228–228 | end_tag  |
| Sec9dcf513abc_N1488 | Sec9dcf513abc_N1487 | tag_name | 228–228 | div |
| Sec9dcf513abc_N1489 | Sec9dcf513abc_N1428 | element | 229–232 | element  |
| Sec9dcf513abc_N1490 | Sec9dcf513abc_N1489 | start_tag | 229–229 | start_tag  |
| Sec9dcf513abc_N1491 | Sec9dcf513abc_N1490 | tag_name | 229–229 | button |
| Sec9dcf513abc_N1492 | Sec9dcf513abc_N1490 | attribute | 229–229 | attribute  |
| Sec9dcf513abc_N1493 | Sec9dcf513abc_N1492 | attribute_name | 229–229 | class |
| Sec9dcf513abc_N1494 | Sec9dcf513abc_N1492 | quoted_attribute_value | 229–229 | quoted_attribute_value  |
| Sec9dcf513abc_N1495 | Sec9dcf513abc_N1494 | attribute_value | 229–229 | w-full py-2.5 px-4 rounded-lg bg-celestial-brass text-observatory font-semibold text-sm hover:bg-celestial-brass-hover transition-colors flex items-center justify-center space-x-2 |
| Sec9dcf513abc_N1496 | Sec9dcf513abc_N1490 | attribute | 229–229 | attribute  |
| Sec9dcf513abc_N1497 | Sec9dcf513abc_N1496 | attribute_name | 229–229 | onclick |
| Sec9dcf513abc_N1498 | Sec9dcf513abc_N1496 | quoted_attribute_value | 229–229 | quoted_attribute_value  |
| Sec9dcf513abc_N1499 | Sec9dcf513abc_N1498 | attribute_value | 229–229 | switchView('offers') |
| Sec9dcf513abc_N1500 | Sec9dcf513abc_N1489 | element | 230–230 | element  |
| Sec9dcf513abc_N1501 | Sec9dcf513abc_N1500 | start_tag | 230–230 | start_tag  |
| Sec9dcf513abc_N1502 | Sec9dcf513abc_N1501 | tag_name | 230–230 | span |
| Sec9dcf513abc_N1503 | Sec9dcf513abc_N1500 | text | 230–230 | Review chart packages |
| Sec9dcf513abc_N1504 | Sec9dcf513abc_N1500 | end_tag | 230–230 | end_tag  |
| Sec9dcf513abc_N1505 | Sec9dcf513abc_N1504 | tag_name | 230–230 | span |
| Sec9dcf513abc_N1506 | Sec9dcf513abc_N1489 | element | 231–231 | element  |
| Sec9dcf513abc_N1507 | Sec9dcf513abc_N1506 | start_tag | 231–231 | start_tag  |
| Sec9dcf513abc_N1508 | Sec9dcf513abc_N1507 | tag_name | 231–231 | span |
| Sec9dcf513abc_N1509 | Sec9dcf513abc_N1506 | text | 231–231 | → |
| Sec9dcf513abc_N1510 | Sec9dcf513abc_N1506 | end_tag | 231–231 | end_tag  |
| Sec9dcf513abc_N1511 | Sec9dcf513abc_N1510 | tag_name | 231–231 | span |
| Sec9dcf513abc_N1512 | Sec9dcf513abc_N1489 | end_tag | 232–232 | end_tag  |
| Sec9dcf513abc_N1513 | Sec9dcf513abc_N1512 | tag_name | 232–232 | button |
| Sec9dcf513abc_N1514 | Sec9dcf513abc_N1428 | end_tag | 233–233 | end_tag  |
| Sec9dcf513abc_N1515 | Sec9dcf513abc_N1514 | tag_name | 233–233 | div |
| Sec9dcf513abc_N1516 | Sec9dcf513abc_N1420 | comment | 234–234 | &lt;!-- Top Up &amp; Metered Conversation --&gt; |
| Sec9dcf513abc_N1517 | Sec9dcf513abc_N1420 | element | 235–254 | element  |
| Sec9dcf513abc_N1518 | Sec9dcf513abc_N1517 | start_tag | 235–235 | start_tag  |
| Sec9dcf513abc_N1519 | Sec9dcf513abc_N1518 | tag_name | 235–235 | div |
| Sec9dcf513abc_N1520 | Sec9dcf513abc_N1518 | attribute | 235–235 | attribute  |
| Sec9dcf513abc_N1521 | Sec9dcf513abc_N1520 | attribute_name | 235–235 | class |
| Sec9dcf513abc_N1522 | Sec9dcf513abc_N1520 | quoted_attribute_value | 235–235 | quoted_attribute_value  |
| Sec9dcf513abc_N1523 | Sec9dcf513abc_N1522 | attribute_value | 235–235 | p-5 rounded-xl border border-hairline bg-surface-dim/80 hover:border-hairline/80 transition-colors flex flex-col justify-between space-y-4 |
| Sec9dcf513abc_N1524 | Sec9dcf513abc_N1517 | element | 236–245 | element  |
| Sec9dcf513abc_N1525 | Sec9dcf513abc_N1524 | start_tag | 236–236 | start_tag  |
| Sec9dcf513abc_N1526 | Sec9dcf513abc_N1525 | tag_name | 236–236 | div |
| Sec9dcf513abc_N1527 | Sec9dcf513abc_N1524 | element | 237–240 | element  |
| Sec9dcf513abc_N1528 | Sec9dcf513abc_N1527 | start_tag | 237–237 | start_tag  |
| Sec9dcf513abc_N1529 | Sec9dcf513abc_N1528 | tag_name | 237–237 | div |
| Sec9dcf513abc_N1530 | Sec9dcf513abc_N1528 | attribute | 237–237 | attribute  |
| Sec9dcf513abc_N1531 | Sec9dcf513abc_N1530 | attribute_name | 237–237 | class |
| Sec9dcf513abc_N1532 | Sec9dcf513abc_N1530 | quoted_attribute_value | 237–237 | quoted_attribute_value  |
| Sec9dcf513abc_N1533 | Sec9dcf513abc_N1532 | attribute_value | 237–237 | flex items-center justify-between |
| Sec9dcf513abc_N1534 | Sec9dcf513abc_N1527 | element | 238–238 | element  |
| Sec9dcf513abc_N1535 | Sec9dcf513abc_N1534 | start_tag | 238–238 | start_tag  |
| Sec9dcf513abc_N1536 | Sec9dcf513abc_N1535 | tag_name | 238–238 | span |
| Sec9dcf513abc_N1537 | Sec9dcf513abc_N1535 | attribute | 238–238 | attribute  |
| Sec9dcf513abc_N1538 | Sec9dcf513abc_N1537 | attribute_name | 238–238 | class |
| Sec9dcf513abc_N1539 | Sec9dcf513abc_N1537 | quoted_attribute_value | 238–238 | quoted_attribute_value  |
| Sec9dcf513abc_N1540 | Sec9dcf513abc_N1539 | attribute_value | 238–238 | text-xs font-mono text-ash font-semibold |
| Sec9dcf513abc_N1541 | Sec9dcf513abc_N1534 | text | 238–238 | Conversational Metering |
| Sec9dcf513abc_N1542 | Sec9dcf513abc_N1534 | end_tag | 238–238 | end_tag  |
| Sec9dcf513abc_N1543 | Sec9dcf513abc_N1542 | tag_name | 238–238 | span |
| Sec9dcf513abc_N1544 | Sec9dcf513abc_N1527 | element | 239–239 | element  |
| Sec9dcf513abc_N1545 | Sec9dcf513abc_N1544 | start_tag | 239–239 | start_tag  |
| Sec9dcf513abc_N1546 | Sec9dcf513abc_N1545 | tag_name | 239–239 | span |
| Sec9dcf513abc_N1547 | Sec9dcf513abc_N1545 | attribute | 239–239 | attribute  |
| Sec9dcf513abc_N1548 | Sec9dcf513abc_N1547 | attribute_name | 239–239 | class |
| Sec9dcf513abc_N1549 | Sec9dcf513abc_N1547 | quoted_attribute_value | 239–239 | quoted_attribute_value  |
| Sec9dcf513abc_N1550 | Sec9dcf513abc_N1549 | attribute_value | 239–239 | text-[11px] font-mono bg-raised-charcoal text-ash px-2 py-0.5 rounded |
| Sec9dcf513abc_N1551 | Sec9dcf513abc_N1544 | text | 239–239 | Alby / Sats |
| Sec9dcf513abc_N1552 | Sec9dcf513abc_N1544 | end_tag | 239–239 | end_tag  |
| Sec9dcf513abc_N1553 | Sec9dcf513abc_N1552 | tag_name | 239–239 | span |
| Sec9dcf513abc_N1554 | Sec9dcf513abc_N1527 | end_tag | 240–240 | end_tag  |
| Sec9dcf513abc_N1555 | Sec9dcf513abc_N1554 | tag_name | 240–240 | div |
| Sec9dcf513abc_N1556 | Sec9dcf513abc_N1524 | element | 241–241 | element  |
| Sec9dcf513abc_N1557 | Sec9dcf513abc_N1556 | start_tag | 241–241 | start_tag  |
| Sec9dcf513abc_N1558 | Sec9dcf513abc_N1557 | tag_name | 241–241 | h3 |
| Sec9dcf513abc_N1559 | Sec9dcf513abc_N1557 | attribute | 241–241 | attribute  |
| Sec9dcf513abc_N1560 | Sec9dcf513abc_N1559 | attribute_name | 241–241 | class |
| Sec9dcf513abc_N1561 | Sec9dcf513abc_N1559 | quoted_attribute_value | 241–241 | quoted_attribute_value  |
| Sec9dcf513abc_N1562 | Sec9dcf513abc_N1561 | attribute_value | 241–241 | font-display text-lg text-starlight mt-2 |
| Sec9dcf513abc_N1563 | Sec9dcf513abc_N1556 | text | 241–241 | Per-turn atelier dialogue |
| Sec9dcf513abc_N1564 | Sec9dcf513abc_N1556 | end_tag | 241–241 | end_tag  |
| Sec9dcf513abc_N1565 | Sec9dcf513abc_N1564 | tag_name | 241–241 | h3 |
| Sec9dcf513abc_N1566 | Sec9dcf513abc_N1524 | element | 242–244 | element  |
| Sec9dcf513abc_N1567 | Sec9dcf513abc_N1566 | start_tag | 242–242 | start_tag  |
| Sec9dcf513abc_N1568 | Sec9dcf513abc_N1567 | tag_name | 242–242 | p |
| Sec9dcf513abc_N1569 | Sec9dcf513abc_N1567 | attribute | 242–242 | attribute  |
| Sec9dcf513abc_N1570 | Sec9dcf513abc_N1569 | attribute_name | 242–242 | class |
| Sec9dcf513abc_N1571 | Sec9dcf513abc_N1569 | quoted_attribute_value | 242–242 | quoted_attribute_value  |
| Sec9dcf513abc_N1572 | Sec9dcf513abc_N1571 | attribute_value | 242–242 | text-xs text-ash mt-1 leading-relaxed |
| Sec9dcf513abc_N1573 | Sec9dcf513abc_N1566 | text | 243–243 | Discrete planetary consultation turns settled via Alby. Ownership of PDF/SPA does not imply unlimited hosted turns. |
| Sec9dcf513abc_N1574 | Sec9dcf513abc_N1566 | end_tag | 244–244 | end_tag  |
| Sec9dcf513abc_N1575 | Sec9dcf513abc_N1574 | tag_name | 244–244 | p |
| Sec9dcf513abc_N1576 | Sec9dcf513abc_N1524 | end_tag | 245–245 | end_tag  |
| Sec9dcf513abc_N1577 | Sec9dcf513abc_N1576 | tag_name | 245–245 | div |
| Sec9dcf513abc_N1578 | Sec9dcf513abc_N1517 | element | 246–253 | element  |
| Sec9dcf513abc_N1579 | Sec9dcf513abc_N1578 | start_tag | 246–246 | start_tag  |
| Sec9dcf513abc_N1580 | Sec9dcf513abc_N1579 | tag_name | 246–246 | div |
| Sec9dcf513abc_N1581 | Sec9dcf513abc_N1579 | attribute | 246–246 | attribute  |
| Sec9dcf513abc_N1582 | Sec9dcf513abc_N1581 | attribute_name | 246–246 | class |
| Sec9dcf513abc_N1583 | Sec9dcf513abc_N1581 | quoted_attribute_value | 246–246 | quoted_attribute_value  |
| Sec9dcf513abc_N1584 | Sec9dcf513abc_N1583 | attribute_value | 246–246 | flex items-center space-x-2 |
| Sec9dcf513abc_N1585 | Sec9dcf513abc_N1578 | element | 247–249 | element  |
| Sec9dcf513abc_N1586 | Sec9dcf513abc_N1585 | start_tag | 247–247 | start_tag  |
| Sec9dcf513abc_N1587 | Sec9dcf513abc_N1586 | tag_name | 247–247 | button |
| Sec9dcf513abc_N1588 | Sec9dcf513abc_N1586 | attribute | 247–247 | attribute  |
| Sec9dcf513abc_N1589 | Sec9dcf513abc_N1588 | attribute_name | 247–247 | class |
| Sec9dcf513abc_N1590 | Sec9dcf513abc_N1588 | quoted_attribute_value | 247–247 | quoted_attribute_value  |
| Sec9dcf513abc_N1591 | Sec9dcf513abc_N1590 | attribute_value | 247–247 | flex-1 py-2.5 px-3 rounded-lg border border-hairline text-starlight font-medium text-xs hover:bg-raised-charcoal transition-colors |
| Sec9dcf513abc_N1592 | Sec9dcf513abc_N1586 | attribute | 247–247 | attribute  |
| Sec9dcf513abc_N1593 | Sec9dcf513abc_N1592 | attribute_name | 247–247 | onclick |
| Sec9dcf513abc_N1594 | Sec9dcf513abc_N1592 | quoted_attribute_value | 247–247 | quoted_attribute_value  |
| Sec9dcf513abc_N1595 | Sec9dcf513abc_N1594 | attribute_value | 247–247 | switchView('topup') |
| Sec9dcf513abc_N1596 | Sec9dcf513abc_N1585 | text | 248–248 | Top up balance |
| Sec9dcf513abc_N1597 | Sec9dcf513abc_N1585 | end_tag | 249–249 | end_tag  |
| Sec9dcf513abc_N1598 | Sec9dcf513abc_N1597 | tag_name | 249–249 | button |
| Sec9dcf513abc_N1599 | Sec9dcf513abc_N1578 | element | 250–252 | element  |
| Sec9dcf513abc_N1600 | Sec9dcf513abc_N1599 | start_tag | 250–250 | start_tag  |
| Sec9dcf513abc_N1601 | Sec9dcf513abc_N1600 | tag_name | 250–250 | button |
| Sec9dcf513abc_N1602 | Sec9dcf513abc_N1600 | attribute | 250–250 | attribute  |
| Sec9dcf513abc_N1603 | Sec9dcf513abc_N1602 | attribute_name | 250–250 | class |
| Sec9dcf513abc_N1604 | Sec9dcf513abc_N1602 | quoted_attribute_value | 250–250 | quoted_attribute_value  |
| Sec9dcf513abc_N1605 | Sec9dcf513abc_N1604 | attribute_value | 250–250 | flex-1 py-2.5 px-3 rounded-lg border border-celestial-brass/50 text-celestial-brass font-medium text-xs hover:bg-celestial-brass/10 transition-colors |
| Sec9dcf513abc_N1606 | Sec9dcf513abc_N1600 | attribute | 250–250 | attribute  |
| Sec9dcf513abc_N1607 | Sec9dcf513abc_N1606 | attribute_name | 250–250 | onclick |
| Sec9dcf513abc_N1608 | Sec9dcf513abc_N1606 | quoted_attribute_value | 250–250 | quoted_attribute_value  |
| Sec9dcf513abc_N1609 | Sec9dcf513abc_N1608 | attribute_value | 250–250 | switchView('alby') |
| Sec9dcf513abc_N1610 | Sec9dcf513abc_N1599 | text | 251–251 | Quote Alby turn |
| Sec9dcf513abc_N1611 | Sec9dcf513abc_N1599 | end_tag | 252–252 | end_tag  |
| Sec9dcf513abc_N1612 | Sec9dcf513abc_N1611 | tag_name | 252–252 | button |
| Sec9dcf513abc_N1613 | Sec9dcf513abc_N1578 | end_tag | 253–253 | end_tag  |
| Sec9dcf513abc_N1614 | Sec9dcf513abc_N1613 | tag_name | 253–253 | div |
| Sec9dcf513abc_N1615 | Sec9dcf513abc_N1517 | end_tag | 254–254 | end_tag  |
| Sec9dcf513abc_N1616 | Sec9dcf513abc_N1615 | tag_name | 254–254 | div |
| Sec9dcf513abc_N1617 | Sec9dcf513abc_N1420 | end_tag | 255–255 | end_tag  |
| Sec9dcf513abc_N1618 | Sec9dcf513abc_N1617 | tag_name | 255–255 | div |
| Sec9dcf513abc_N1619 | Sec9dcf513abc_N1403 | end_tag | 256–256 | end_tag  |
| Sec9dcf513abc_N1620 | Sec9dcf513abc_N1619 | tag_name | 256–256 | div |
| Sec9dcf513abc_N1621 | Sec9dcf513abc_N1202 | comment | 257–257 | &lt;!-- Expand Billing Account Link --&gt; |
| Sec9dcf513abc_N1622 | Sec9dcf513abc_N1202 | element | 258–264 | element  |
| Sec9dcf513abc_N1623 | Sec9dcf513abc_N1622 | start_tag | 258–258 | start_tag  |
| Sec9dcf513abc_N1624 | Sec9dcf513abc_N1623 | tag_name | 258–258 | div |
| Sec9dcf513abc_N1625 | Sec9dcf513abc_N1623 | attribute | 258–258 | attribute  |
| Sec9dcf513abc_N1626 | Sec9dcf513abc_N1625 | attribute_name | 258–258 | class |
| Sec9dcf513abc_N1627 | Sec9dcf513abc_N1625 | quoted_attribute_value | 258–258 | quoted_attribute_value  |
| Sec9dcf513abc_N1628 | Sec9dcf513abc_N1627 | attribute_value | 258–258 | pt-4 border-t border-hairline/60 flex flex-col sm:flex-row items-start sm:items-center justify-between text-xs text-ash gap-2 |
| Sec9dcf513abc_N1629 | Sec9dcf513abc_N1622 | element | 259–259 | element  |
| Sec9dcf513abc_N1630 | Sec9dcf513abc_N1629 | start_tag | 259–259 | start_tag  |
| Sec9dcf513abc_N1631 | Sec9dcf513abc_N1630 | tag_name | 259–259 | span |
| Sec9dcf513abc_N1632 | Sec9dcf513abc_N1629 | text | 259–259 | Need past receipts, invoice proofs, or order restoration? |
| Sec9dcf513abc_N1633 | Sec9dcf513abc_N1629 | end_tag | 259–259 | end_tag  |
| Sec9dcf513abc_N1634 | Sec9dcf513abc_N1633 | tag_name | 259–259 | span |
| Sec9dcf513abc_N1635 | Sec9dcf513abc_N1622 | element | 260–263 | element  |
| Sec9dcf513abc_N1636 | Sec9dcf513abc_N1635 | start_tag | 260–260 | start_tag  |
| Sec9dcf513abc_N1637 | Sec9dcf513abc_N1636 | tag_name | 260–260 | button |
| Sec9dcf513abc_N1638 | Sec9dcf513abc_N1636 | attribute | 260–260 | attribute  |
| Sec9dcf513abc_N1639 | Sec9dcf513abc_N1638 | attribute_name | 260–260 | class |
| Sec9dcf513abc_N1640 | Sec9dcf513abc_N1638 | quoted_attribute_value | 260–260 | quoted_attribute_value  |
| Sec9dcf513abc_N1641 | Sec9dcf513abc_N1640 | attribute_value | 260–260 | text-celestial-brass hover:underline underline-offset-4 flex items-center space-x-1 font-mono |
| Sec9dcf513abc_N1642 | Sec9dcf513abc_N1636 | attribute | 260–260 | attribute  |
| Sec9dcf513abc_N1643 | Sec9dcf513abc_N1642 | attribute_name | 260–260 | onclick |
| Sec9dcf513abc_N1644 | Sec9dcf513abc_N1642 | quoted_attribute_value | 260–260 | quoted_attribute_value  |
| Sec9dcf513abc_N1645 | Sec9dcf513abc_N1644 | attribute_value | 260–260 | switchView('billing') |
| Sec9dcf513abc_N1646 | Sec9dcf513abc_N1635 | element | 261–261 | element  |
| Sec9dcf513abc_N1647 | Sec9dcf513abc_N1646 | start_tag | 261–261 | start_tag  |
| Sec9dcf513abc_N1648 | Sec9dcf513abc_N1647 | tag_name | 261–261 | span |
| Sec9dcf513abc_N1649 | Sec9dcf513abc_N1646 | text | 261–261 | Expand billing account management |
| Sec9dcf513abc_N1650 | Sec9dcf513abc_N1646 | end_tag | 261–261 | end_tag  |
| Sec9dcf513abc_N1651 | Sec9dcf513abc_N1650 | tag_name | 261–261 | span |
| Sec9dcf513abc_N1652 | Sec9dcf513abc_N1635 | element | 262–262 | element  |
| Sec9dcf513abc_N1653 | Sec9dcf513abc_N1652 | start_tag | 262–262 | start_tag  |
| Sec9dcf513abc_N1654 | Sec9dcf513abc_N1653 | tag_name | 262–262 | span |
| Sec9dcf513abc_N1655 | Sec9dcf513abc_N1652 | text | 262–262 | → |
| Sec9dcf513abc_N1656 | Sec9dcf513abc_N1652 | end_tag | 262–262 | end_tag  |
| Sec9dcf513abc_N1657 | Sec9dcf513abc_N1656 | tag_name | 262–262 | span |
| Sec9dcf513abc_N1658 | Sec9dcf513abc_N1635 | end_tag | 263–263 | end_tag  |
| Sec9dcf513abc_N1659 | Sec9dcf513abc_N1658 | tag_name | 263–263 | button |
| Sec9dcf513abc_N1660 | Sec9dcf513abc_N1622 | end_tag | 264–264 | end_tag  |
| Sec9dcf513abc_N1661 | Sec9dcf513abc_N1660 | tag_name | 264–264 | div |
| Sec9dcf513abc_N1662 | Sec9dcf513abc_N1202 | end_tag | 265–265 | end_tag  |
| Sec9dcf513abc_N1663 | Sec9dcf513abc_N1662 | tag_name | 265–265 | div |
| Sec9dcf513abc_N1664 | Sec9dcf513abc_N1194 | comment | 266–266 | &lt;!-- SECTION 2: BALANCE &amp; USAGE --&gt; |
| Sec9dcf513abc_N1665 | Sec9dcf513abc_N1194 | element | 267–302 | element  |
| Sec9dcf513abc_N1666 | Sec9dcf513abc_N1665 | start_tag | 267–267 | start_tag  |
| Sec9dcf513abc_N1667 | Sec9dcf513abc_N1666 | tag_name | 267–267 | div |
| Sec9dcf513abc_N1668 | Sec9dcf513abc_N1666 | attribute | 267–267 | attribute  |
| Sec9dcf513abc_N1669 | Sec9dcf513abc_N1668 | attribute_name | 267–267 | class |
| Sec9dcf513abc_N1670 | Sec9dcf513abc_N1668 | quoted_attribute_value | 267–267 | quoted_attribute_value  |
| Sec9dcf513abc_N1671 | Sec9dcf513abc_N1670 | attribute_value | 267–267 | view-section space-y-6 |
| Sec9dcf513abc_N1672 | Sec9dcf513abc_N1666 | attribute | 267–267 | attribute  |
| Sec9dcf513abc_N1673 | Sec9dcf513abc_N1672 | attribute_name | 267–267 | data-view |
| Sec9dcf513abc_N1674 | Sec9dcf513abc_N1672 | quoted_attribute_value | 267–267 | quoted_attribute_value  |
| Sec9dcf513abc_N1675 | Sec9dcf513abc_N1674 | attribute_value | 267–267 | balance |
| Sec9dcf513abc_N1676 | Sec9dcf513abc_N1666 | attribute | 267–267 | attribute  |
| Sec9dcf513abc_N1677 | Sec9dcf513abc_N1676 | attribute_name | 267–267 | id |
| Sec9dcf513abc_N1678 | Sec9dcf513abc_N1676 | quoted_attribute_value | 267–267 | quoted_attribute_value  |
| Sec9dcf513abc_N1679 | Sec9dcf513abc_N1678 | attribute_value | 267–267 | section-balance |
| Sec9dcf513abc_N1680 | Sec9dcf513abc_N1665 | element | 268–274 | element  |
| Sec9dcf513abc_N1681 | Sec9dcf513abc_N1680 | start_tag | 268–268 | start_tag  |
| Sec9dcf513abc_N1682 | Sec9dcf513abc_N1681 | tag_name | 268–268 | div |
| Sec9dcf513abc_N1683 | Sec9dcf513abc_N1681 | attribute | 268–268 | attribute  |
| Sec9dcf513abc_N1684 | Sec9dcf513abc_N1683 | attribute_name | 268–268 | class |
| Sec9dcf513abc_N1685 | Sec9dcf513abc_N1683 | quoted_attribute_value | 268–268 | quoted_attribute_value  |
| Sec9dcf513abc_N1686 | Sec9dcf513abc_N1685 | attribute_value | 268–268 | border-b border-hairline/80 pb-4 flex items-center justify-between |
| Sec9dcf513abc_N1687 | Sec9dcf513abc_N1680 | element | 269–272 | element  |
| Sec9dcf513abc_N1688 | Sec9dcf513abc_N1687 | start_tag | 269–269 | start_tag  |
| Sec9dcf513abc_N1689 | Sec9dcf513abc_N1688 | tag_name | 269–269 | div |
| Sec9dcf513abc_N1690 | Sec9dcf513abc_N1687 | element | 270–270 | element  |
| Sec9dcf513abc_N1691 | Sec9dcf513abc_N1690 | start_tag | 270–270 | start_tag  |
| Sec9dcf513abc_N1692 | Sec9dcf513abc_N1691 | tag_name | 270–270 | span |
| Sec9dcf513abc_N1693 | Sec9dcf513abc_N1691 | attribute | 270–270 | attribute  |
| Sec9dcf513abc_N1694 | Sec9dcf513abc_N1693 | attribute_name | 270–270 | class |
| Sec9dcf513abc_N1695 | Sec9dcf513abc_N1693 | quoted_attribute_value | 270–270 | quoted_attribute_value  |
| Sec9dcf513abc_N1696 | Sec9dcf513abc_N1695 | attribute_value | 270–270 | text-xs font-mono text-celestial-brass uppercase tracking-wider |
| Sec9dcf513abc_N1697 | Sec9dcf513abc_N1690 | text | 270–270 | Account Ledger |
| Sec9dcf513abc_N1698 | Sec9dcf513abc_N1690 | end_tag | 270–270 | end_tag  |
| Sec9dcf513abc_N1699 | Sec9dcf513abc_N1698 | tag_name | 270–270 | span |
| Sec9dcf513abc_N1700 | Sec9dcf513abc_N1687 | element | 271–271 | element  |
| Sec9dcf513abc_N1701 | Sec9dcf513abc_N1700 | start_tag | 271–271 | start_tag  |
| Sec9dcf513abc_N1702 | Sec9dcf513abc_N1701 | tag_name | 271–271 | h1 |
| Sec9dcf513abc_N1703 | Sec9dcf513abc_N1701 | attribute | 271–271 | attribute  |
| Sec9dcf513abc_N1704 | Sec9dcf513abc_N1703 | attribute_name | 271–271 | class |
| Sec9dcf513abc_N1705 | Sec9dcf513abc_N1703 | quoted_attribute_value | 271–271 | quoted_attribute_value  |
| Sec9dcf513abc_N1706 | Sec9dcf513abc_N1705 | attribute_value | 271–271 | font-display text-2xl font-normal text-starlight mt-1 |
| Sec9dcf513abc_N1707 | Sec9dcf513abc_N1700 | text | 271–271 | Reading-Credit Balance |
| Sec9dcf513abc_N1708 | Sec9dcf513abc_N1700 | end_tag | 271–271 | end_tag  |
| Sec9dcf513abc_N1709 | Sec9dcf513abc_N1708 | tag_name | 271–271 | h1 |
| Sec9dcf513abc_N1710 | Sec9dcf513abc_N1687 | end_tag | 272–272 | end_tag  |
| Sec9dcf513abc_N1711 | Sec9dcf513abc_N1710 | tag_name | 272–272 | div |
| Sec9dcf513abc_N1712 | Sec9dcf513abc_N1680 | element | 273–273 | element  |
| Sec9dcf513abc_N1713 | Sec9dcf513abc_N1712 | start_tag | 273–273 | start_tag  |
| Sec9dcf513abc_N1714 | Sec9dcf513abc_N1713 | tag_name | 273–273 | button |
| Sec9dcf513abc_N1715 | Sec9dcf513abc_N1713 | attribute | 273–273 | attribute  |
| Sec9dcf513abc_N1716 | Sec9dcf513abc_N1715 | attribute_name | 273–273 | class |
| Sec9dcf513abc_N1717 | Sec9dcf513abc_N1715 | quoted_attribute_value | 273–273 | quoted_attribute_value  |
| Sec9dcf513abc_N1718 | Sec9dcf513abc_N1717 | attribute_value | 273–273 | text-xs font-mono text-ash hover:text-starlight |
| Sec9dcf513abc_N1719 | Sec9dcf513abc_N1713 | attribute | 273–273 | attribute  |
| Sec9dcf513abc_N1720 | Sec9dcf513abc_N1719 | attribute_name | 273–273 | onclick |
| Sec9dcf513abc_N1721 | Sec9dcf513abc_N1719 | quoted_attribute_value | 273–273 | quoted_attribute_value  |
| Sec9dcf513abc_N1722 | Sec9dcf513abc_N1721 | attribute_value | 273–273 | switchView('profile') |
| Sec9dcf513abc_N1723 | Sec9dcf513abc_N1712 | text | 273–273 | ← Return to Profile |
| Sec9dcf513abc_N1724 | Sec9dcf513abc_N1712 | end_tag | 273–273 | end_tag  |
| Sec9dcf513abc_N1725 | Sec9dcf513abc_N1724 | tag_name | 273–273 | button |
| Sec9dcf513abc_N1726 | Sec9dcf513abc_N1680 | end_tag | 274–274 | end_tag  |
| Sec9dcf513abc_N1727 | Sec9dcf513abc_N1726 | tag_name | 274–274 | div |
| Sec9dcf513abc_N1728 | Sec9dcf513abc_N1665 | comment | 275–275 | &lt;!-- Truthful Balance Status Box --&gt; |
| Sec9dcf513abc_N1729 | Sec9dcf513abc_N1665 | element | 276–291 | element  |
| Sec9dcf513abc_N1730 | Sec9dcf513abc_N1729 | start_tag | 276–276 | start_tag  |
| Sec9dcf513abc_N1731 | Sec9dcf513abc_N1730 | tag_name | 276–276 | div |
| Sec9dcf513abc_N1732 | Sec9dcf513abc_N1730 | attribute | 276–276 | attribute  |
| Sec9dcf513abc_N1733 | Sec9dcf513abc_N1732 | attribute_name | 276–276 | class |
| Sec9dcf513abc_N1734 | Sec9dcf513abc_N1732 | quoted_attribute_value | 276–276 | quoted_attribute_value  |
| Sec9dcf513abc_N1735 | Sec9dcf513abc_N1734 | attribute_value | 276–276 | p-6 rounded-xl border border-hairline bg-surface-dim space-y-4 |
| Sec9dcf513abc_N1736 | Sec9dcf513abc_N1729 | element | 277–287 | element  |
| Sec9dcf513abc_N1737 | Sec9dcf513abc_N1736 | start_tag | 277–277 | start_tag  |
| Sec9dcf513abc_N1738 | Sec9dcf513abc_N1737 | tag_name | 277–277 | div |
| Sec9dcf513abc_N1739 | Sec9dcf513abc_N1737 | attribute | 277–277 | attribute  |
| Sec9dcf513abc_N1740 | Sec9dcf513abc_N1739 | attribute_name | 277–277 | class |
| Sec9dcf513abc_N1741 | Sec9dcf513abc_N1739 | quoted_attribute_value | 277–277 | quoted_attribute_value  |
| Sec9dcf513abc_N1742 | Sec9dcf513abc_N1741 | attribute_value | 277–277 | flex flex-col sm:flex-row sm:items-center justify-between gap-4 |
| Sec9dcf513abc_N1743 | Sec9dcf513abc_N1736 | element | 278–283 | element  |
| Sec9dcf513abc_N1744 | Sec9dcf513abc_N1743 | start_tag | 278–278 | start_tag  |
| Sec9dcf513abc_N1745 | Sec9dcf513abc_N1744 | tag_name | 278–278 | div |
| Sec9dcf513abc_N1746 | Sec9dcf513abc_N1743 | element | 279–279 | element  |
| Sec9dcf513abc_N1747 | Sec9dcf513abc_N1746 | start_tag | 279–279 | start_tag  |
| Sec9dcf513abc_N1748 | Sec9dcf513abc_N1747 | tag_name | 279–279 | span |
| Sec9dcf513abc_N1749 | Sec9dcf513abc_N1747 | attribute | 279–279 | attribute  |
| Sec9dcf513abc_N1750 | Sec9dcf513abc_N1749 | attribute_name | 279–279 | class |
| Sec9dcf513abc_N1751 | Sec9dcf513abc_N1749 | quoted_attribute_value | 279–279 | quoted_attribute_value  |
| Sec9dcf513abc_N1752 | Sec9dcf513abc_N1751 | attribute_value | 279–279 | text-xs font-mono text-ash |
| Sec9dcf513abc_N1753 | Sec9dcf513abc_N1746 | text | 279–279 | USD Reading-Credit Balance |
| Sec9dcf513abc_N1754 | Sec9dcf513abc_N1746 | end_tag | 279–279 | end_tag  |
| Sec9dcf513abc_N1755 | Sec9dcf513abc_N1754 | tag_name | 279–279 | span |
| Sec9dcf513abc_N1756 | Sec9dcf513abc_N1743 | element | 280–282 | element  |
| Sec9dcf513abc_N1757 | Sec9dcf513abc_N1756 | start_tag | 280–280 | start_tag  |
| Sec9dcf513abc_N1758 | Sec9dcf513abc_N1757 | tag_name | 280–280 | div |
| Sec9dcf513abc_N1759 | Sec9dcf513abc_N1757 | attribute | 280–280 | attribute  |
| Sec9dcf513abc_N1760 | Sec9dcf513abc_N1759 | attribute_name | 280–280 | class |
| Sec9dcf513abc_N1761 | Sec9dcf513abc_N1759 | quoted_attribute_value | 280–280 | quoted_attribute_value  |
| Sec9dcf513abc_N1762 | Sec9dcf513abc_N1761 | attribute_value | 280–280 | text-3xl font-display text-starlight mt-1 font-medium tracking-tight |
| Sec9dcf513abc_N1763 | Sec9dcf513abc_N1756 | text | 281–281 | $0.00 |
| Sec9dcf513abc_N1764 | Sec9dcf513abc_N1756 | element | 281–281 | element  |
| Sec9dcf513abc_N1765 | Sec9dcf513abc_N1764 | start_tag | 281–281 | start_tag  |
| Sec9dcf513abc_N1766 | Sec9dcf513abc_N1765 | tag_name | 281–281 | span |
| Sec9dcf513abc_N1767 | Sec9dcf513abc_N1765 | attribute | 281–281 | attribute  |
| Sec9dcf513abc_N1768 | Sec9dcf513abc_N1767 | attribute_name | 281–281 | class |
| Sec9dcf513abc_N1769 | Sec9dcf513abc_N1767 | quoted_attribute_value | 281–281 | quoted_attribute_value  |
| Sec9dcf513abc_N1770 | Sec9dcf513abc_N1769 | attribute_value | 281–281 | text-xs font-mono text-ash font-normal tracking-normal |
| Sec9dcf513abc_N1771 | Sec9dcf513abc_N1764 | text | 281–281 | (Unavailable until verified) |
| Sec9dcf513abc_N1772 | Sec9dcf513abc_N1764 | end_tag | 281–281 | end_tag  |
| Sec9dcf513abc_N1773 | Sec9dcf513abc_N1772 | tag_name | 281–281 | span |
| Sec9dcf513abc_N1774 | Sec9dcf513abc_N1756 | end_tag | 282–282 | end_tag  |
| Sec9dcf513abc_N1775 | Sec9dcf513abc_N1774 | tag_name | 282–282 | div |
| Sec9dcf513abc_N1776 | Sec9dcf513abc_N1743 | end_tag | 283–283 | end_tag  |
| Sec9dcf513abc_N1777 | Sec9dcf513abc_N1776 | tag_name | 283–283 | div |
| Sec9dcf513abc_N1778 | Sec9dcf513abc_N1736 | element | 284–286 | element  |
| Sec9dcf513abc_N1779 | Sec9dcf513abc_N1778 | start_tag | 284–284 | start_tag  |
| Sec9dcf513abc_N1780 | Sec9dcf513abc_N1779 | tag_name | 284–284 | button |
| Sec9dcf513abc_N1781 | Sec9dcf513abc_N1779 | attribute | 284–284 | attribute  |
| Sec9dcf513abc_N1782 | Sec9dcf513abc_N1781 | attribute_name | 284–284 | class |
| Sec9dcf513abc_N1783 | Sec9dcf513abc_N1781 | quoted_attribute_value | 284–284 | quoted_attribute_value  |
| Sec9dcf513abc_N1784 | Sec9dcf513abc_N1783 | attribute_value | 284–284 | px-4 py-2 rounded-lg bg-celestial-brass text-observatory font-semibold text-sm hover:bg-celestial-brass-hover transition-colors |
| Sec9dcf513abc_N1785 | Sec9dcf513abc_N1779 | attribute | 284–284 | attribute  |
| Sec9dcf513abc_N1786 | Sec9dcf513abc_N1785 | attribute_name | 284–284 | onclick |
| Sec9dcf513abc_N1787 | Sec9dcf513abc_N1785 | quoted_attribute_value | 284–284 | quoted_attribute_value  |
| Sec9dcf513abc_N1788 | Sec9dcf513abc_N1787 | attribute_value | 284–284 | switchView('topup') |
| Sec9dcf513abc_N1789 | Sec9dcf513abc_N1778 | text | 285–285 | Request top-up quote |
| Sec9dcf513abc_N1790 | Sec9dcf513abc_N1778 | end_tag | 286–286 | end_tag  |
| Sec9dcf513abc_N1791 | Sec9dcf513abc_N1790 | tag_name | 286–286 | button |
| Sec9dcf513abc_N1792 | Sec9dcf513abc_N1736 | end_tag | 287–287 | end_tag  |
| Sec9dcf513abc_N1793 | Sec9dcf513abc_N1792 | tag_name | 287–287 | div |
| Sec9dcf513abc_N1794 | Sec9dcf513abc_N1729 | element | 288–290 | element  |
| Sec9dcf513abc_N1795 | Sec9dcf513abc_N1794 | start_tag | 288–288 | start_tag  |
| Sec9dcf513abc_N1796 | Sec9dcf513abc_N1795 | tag_name | 288–288 | p |
| Sec9dcf513abc_N1797 | Sec9dcf513abc_N1795 | attribute | 288–288 | attribute  |
| Sec9dcf513abc_N1798 | Sec9dcf513abc_N1797 | attribute_name | 288–288 | class |
| Sec9dcf513abc_N1799 | Sec9dcf513abc_N1797 | quoted_attribute_value | 288–288 | quoted_attribute_value  |
| Sec9dcf513abc_N1800 | Sec9dcf513abc_N1799 | attribute_value | 288–288 | text-xs text-ash leading-relaxed border-t border-hairline/60 pt-3 |
| Sec9dcf513abc_N1801 | Sec9dcf513abc_N1794 | text | 289–289 | USD reading credits are strictly separate from Bitcoin Lightning / Alby satoshi turn quotes, and separate from provider treasury accounts. Settlement is server-authoritative. |
| Sec9dcf513abc_N1802 | Sec9dcf513abc_N1794 | end_tag | 290–290 | end_tag  |
| Sec9dcf513abc_N1803 | Sec9dcf513abc_N1802 | tag_name | 290–290 | p |
| Sec9dcf513abc_N1804 | Sec9dcf513abc_N1729 | end_tag | 291–291 | end_tag  |
| Sec9dcf513abc_N1805 | Sec9dcf513abc_N1804 | tag_name | 291–291 | div |
| Sec9dcf513abc_N1806 | Sec9dcf513abc_N1665 | comment | 292–292 | &lt;!-- Empty Usage State --&gt; |
| Sec9dcf513abc_N1807 | Sec9dcf513abc_N1665 | element | 293–301 | element  |
| Sec9dcf513abc_N1808 | Sec9dcf513abc_N1807 | start_tag | 293–293 | start_tag  |
| Sec9dcf513abc_N1809 | Sec9dcf513abc_N1808 | tag_name | 293–293 | div |
| Sec9dcf513abc_N1810 | Sec9dcf513abc_N1808 | attribute | 293–293 | attribute  |
| Sec9dcf513abc_N1811 | Sec9dcf513abc_N1810 | attribute_name | 293–293 | class |
| Sec9dcf513abc_N1812 | Sec9dcf513abc_N1810 | quoted_attribute_value | 293–293 | quoted_attribute_value  |
| Sec9dcf513abc_N1813 | Sec9dcf513abc_N1812 | attribute_value | 293–293 | p-8 rounded-xl border border-dashed border-hairline bg-surface-dim/40 text-center space-y-3 |
| Sec9dcf513abc_N1814 | Sec9dcf513abc_N1807 | element | 294–296 | element  |
| Sec9dcf513abc_N1815 | Sec9dcf513abc_N1814 | start_tag | 294–294 | start_tag  |
| Sec9dcf513abc_N1816 | Sec9dcf513abc_N1815 | tag_name | 294–294 | div |
| Sec9dcf513abc_N1817 | Sec9dcf513abc_N1815 | attribute | 294–294 | attribute  |
| Sec9dcf513abc_N1818 | Sec9dcf513abc_N1817 | attribute_name | 294–294 | class |
| Sec9dcf513abc_N1819 | Sec9dcf513abc_N1817 | quoted_attribute_value | 294–294 | quoted_attribute_value  |
| Sec9dcf513abc_N1820 | Sec9dcf513abc_N1819 | attribute_value | 294–294 | w-10 h-10 rounded-full border border-hairline mx-auto flex items-center justify-center text-ash font-mono |
| Sec9dcf513abc_N1821 | Sec9dcf513abc_N1814 | text | 295–295 | ∅ |
| Sec9dcf513abc_N1822 | Sec9dcf513abc_N1814 | end_tag | 296–296 | end_tag  |
| Sec9dcf513abc_N1823 | Sec9dcf513abc_N1822 | tag_name | 296–296 | div |
| Sec9dcf513abc_N1824 | Sec9dcf513abc_N1807 | element | 297–297 | element  |
| Sec9dcf513abc_N1825 | Sec9dcf513abc_N1824 | start_tag | 297–297 | start_tag  |
| Sec9dcf513abc_N1826 | Sec9dcf513abc_N1825 | tag_name | 297–297 | h2 |
| Sec9dcf513abc_N1827 | Sec9dcf513abc_N1825 | attribute | 297–297 | attribute  |
| Sec9dcf513abc_N1828 | Sec9dcf513abc_N1827 | attribute_name | 297–297 | class |
| Sec9dcf513abc_N1829 | Sec9dcf513abc_N1827 | quoted_attribute_value | 297–297 | quoted_attribute_value  |
| Sec9dcf513abc_N1830 | Sec9dcf513abc_N1829 | attribute_value | 297–297 | font-display text-lg text-starlight |
| Sec9dcf513abc_N1831 | Sec9dcf513abc_N1824 | text | 297–297 | No recorded credit usage |
| Sec9dcf513abc_N1832 | Sec9dcf513abc_N1824 | end_tag | 297–297 | end_tag  |
| Sec9dcf513abc_N1833 | Sec9dcf513abc_N1832 | tag_name | 297–297 | h2 |
| Sec9dcf513abc_N1834 | Sec9dcf513abc_N1807 | element | 298–300 | element  |
| Sec9dcf513abc_N1835 | Sec9dcf513abc_N1834 | start_tag | 298–298 | start_tag  |
| Sec9dcf513abc_N1836 | Sec9dcf513abc_N1835 | tag_name | 298–298 | p |
| Sec9dcf513abc_N1837 | Sec9dcf513abc_N1835 | attribute | 298–298 | attribute  |
| Sec9dcf513abc_N1838 | Sec9dcf513abc_N1837 | attribute_name | 298–298 | class |
| Sec9dcf513abc_N1839 | Sec9dcf513abc_N1837 | quoted_attribute_value | 298–298 | quoted_attribute_value  |
| Sec9dcf513abc_N1840 | Sec9dcf513abc_N1839 | attribute_value | 298–298 | text-xs text-ash max-w-md mx-auto leading-relaxed |
| Sec9dcf513abc_N1841 | Sec9dcf513abc_N1834 | text | 299–299 | Usage and itemized deductions will appear here once an authenticated account is provisioned with prepaid balances. No simulated deductions or mock receipts are manufactured in this design preview. |
| Sec9dcf513abc_N1842 | Sec9dcf513abc_N1834 | end_tag | 300–300 | end_tag  |
| Sec9dcf513abc_N1843 | Sec9dcf513abc_N1842 | tag_name | 300–300 | p |
| Sec9dcf513abc_N1844 | Sec9dcf513abc_N1807 | end_tag | 301–301 | end_tag  |
| Sec9dcf513abc_N1845 | Sec9dcf513abc_N1844 | tag_name | 301–301 | div |
| Sec9dcf513abc_N1846 | Sec9dcf513abc_N1665 | end_tag | 302–302 | end_tag  |
| Sec9dcf513abc_N1847 | Sec9dcf513abc_N1846 | tag_name | 302–302 | div |
| Sec9dcf513abc_N1848 | Sec9dcf513abc_N1194 | comment | 303–303 | &lt;!-- SECTION 3: TOP UP --&gt; |
| Sec9dcf513abc_N1849 | Sec9dcf513abc_N1194 | element | 304–349 | element  |
| Sec9dcf513abc_N1850 | Sec9dcf513abc_N1849 | start_tag | 304–304 | start_tag  |
| Sec9dcf513abc_N1851 | Sec9dcf513abc_N1850 | tag_name | 304–304 | div |
| Sec9dcf513abc_N1852 | Sec9dcf513abc_N1850 | attribute | 304–304 | attribute  |
| Sec9dcf513abc_N1853 | Sec9dcf513abc_N1852 | attribute_name | 304–304 | class |
| Sec9dcf513abc_N1854 | Sec9dcf513abc_N1852 | quoted_attribute_value | 304–304 | quoted_attribute_value  |
| Sec9dcf513abc_N1855 | Sec9dcf513abc_N1854 | attribute_value | 304–304 | view-section space-y-6 |
| Sec9dcf513abc_N1856 | Sec9dcf513abc_N1850 | attribute | 304–304 | attribute  |
| Sec9dcf513abc_N1857 | Sec9dcf513abc_N1856 | attribute_name | 304–304 | data-view |
| Sec9dcf513abc_N1858 | Sec9dcf513abc_N1856 | quoted_attribute_value | 304–304 | quoted_attribute_value  |
| Sec9dcf513abc_N1859 | Sec9dcf513abc_N1858 | attribute_value | 304–304 | topup |
| Sec9dcf513abc_N1860 | Sec9dcf513abc_N1850 | attribute | 304–304 | attribute  |
| Sec9dcf513abc_N1861 | Sec9dcf513abc_N1860 | attribute_name | 304–304 | id |
| Sec9dcf513abc_N1862 | Sec9dcf513abc_N1860 | quoted_attribute_value | 304–304 | quoted_attribute_value  |
| Sec9dcf513abc_N1863 | Sec9dcf513abc_N1862 | attribute_value | 304–304 | section-topup |
| Sec9dcf513abc_N1864 | Sec9dcf513abc_N1849 | element | 305–311 | element  |
| Sec9dcf513abc_N1865 | Sec9dcf513abc_N1864 | start_tag | 305–305 | start_tag  |
| Sec9dcf513abc_N1866 | Sec9dcf513abc_N1865 | tag_name | 305–305 | div |
| Sec9dcf513abc_N1867 | Sec9dcf513abc_N1865 | attribute | 305–305 | attribute  |
| Sec9dcf513abc_N1868 | Sec9dcf513abc_N1867 | attribute_name | 305–305 | class |
| Sec9dcf513abc_N1869 | Sec9dcf513abc_N1867 | quoted_attribute_value | 305–305 | quoted_attribute_value  |
| Sec9dcf513abc_N1870 | Sec9dcf513abc_N1869 | attribute_value | 305–305 | border-b border-hairline/80 pb-4 flex items-center justify-between |
| Sec9dcf513abc_N1871 | Sec9dcf513abc_N1864 | element | 306–309 | element  |
| Sec9dcf513abc_N1872 | Sec9dcf513abc_N1871 | start_tag | 306–306 | start_tag  |
| Sec9dcf513abc_N1873 | Sec9dcf513abc_N1872 | tag_name | 306–306 | div |
| Sec9dcf513abc_N1874 | Sec9dcf513abc_N1871 | element | 307–307 | element  |
| Sec9dcf513abc_N1875 | Sec9dcf513abc_N1874 | start_tag | 307–307 | start_tag  |
| Sec9dcf513abc_N1876 | Sec9dcf513abc_N1875 | tag_name | 307–307 | span |
| Sec9dcf513abc_N1877 | Sec9dcf513abc_N1875 | attribute | 307–307 | attribute  |
| Sec9dcf513abc_N1878 | Sec9dcf513abc_N1877 | attribute_name | 307–307 | class |
| Sec9dcf513abc_N1879 | Sec9dcf513abc_N1877 | quoted_attribute_value | 307–307 | quoted_attribute_value  |
| Sec9dcf513abc_N1880 | Sec9dcf513abc_N1879 | attribute_value | 307–307 | text-xs font-mono text-celestial-brass uppercase tracking-wider |
| Sec9dcf513abc_N1881 | Sec9dcf513abc_N1874 | text | 307–307 | Prepaid Recharge |
| Sec9dcf513abc_N1882 | Sec9dcf513abc_N1874 | end_tag | 307–307 | end_tag  |
| Sec9dcf513abc_N1883 | Sec9dcf513abc_N1882 | tag_name | 307–307 | span |
| Sec9dcf513abc_N1884 | Sec9dcf513abc_N1871 | element | 308–308 | element  |
| Sec9dcf513abc_N1885 | Sec9dcf513abc_N1884 | start_tag | 308–308 | start_tag  |
| Sec9dcf513abc_N1886 | Sec9dcf513abc_N1885 | tag_name | 308–308 | h1 |
| Sec9dcf513abc_N1887 | Sec9dcf513abc_N1885 | attribute | 308–308 | attribute  |
| Sec9dcf513abc_N1888 | Sec9dcf513abc_N1887 | attribute_name | 308–308 | class |
| Sec9dcf513abc_N1889 | Sec9dcf513abc_N1887 | quoted_attribute_value | 308–308 | quoted_attribute_value  |
| Sec9dcf513abc_N1890 | Sec9dcf513abc_N1889 | attribute_value | 308–308 | font-display text-2xl font-normal text-starlight mt-1 |
| Sec9dcf513abc_N1891 | Sec9dcf513abc_N1884 | text | 308–308 | Top Up Reading Credits |
| Sec9dcf513abc_N1892 | Sec9dcf513abc_N1884 | end_tag | 308–308 | end_tag  |
| Sec9dcf513abc_N1893 | Sec9dcf513abc_N1892 | tag_name | 308–308 | h1 |
| Sec9dcf513abc_N1894 | Sec9dcf513abc_N1871 | end_tag | 309–309 | end_tag  |
| Sec9dcf513abc_N1895 | Sec9dcf513abc_N1894 | tag_name | 309–309 | div |
| Sec9dcf513abc_N1896 | Sec9dcf513abc_N1864 | element | 310–310 | element  |
| Sec9dcf513abc_N1897 | Sec9dcf513abc_N1896 | start_tag | 310–310 | start_tag  |
| Sec9dcf513abc_N1898 | Sec9dcf513abc_N1897 | tag_name | 310–310 | button |
| Sec9dcf513abc_N1899 | Sec9dcf513abc_N1897 | attribute | 310–310 | attribute  |
| Sec9dcf513abc_N1900 | Sec9dcf513abc_N1899 | attribute_name | 310–310 | class |
| Sec9dcf513abc_N1901 | Sec9dcf513abc_N1899 | quoted_attribute_value | 310–310 | quoted_attribute_value  |
| Sec9dcf513abc_N1902 | Sec9dcf513abc_N1901 | attribute_value | 310–310 | text-xs font-mono text-ash hover:text-starlight |
| Sec9dcf513abc_N1903 | Sec9dcf513abc_N1897 | attribute | 310–310 | attribute  |
| Sec9dcf513abc_N1904 | Sec9dcf513abc_N1903 | attribute_name | 310–310 | onclick |
| Sec9dcf513abc_N1905 | Sec9dcf513abc_N1903 | quoted_attribute_value | 310–310 | quoted_attribute_value  |
| Sec9dcf513abc_N1906 | Sec9dcf513abc_N1905 | attribute_value | 310–310 | switchView('profile') |
| Sec9dcf513abc_N1907 | Sec9dcf513abc_N1896 | text | 310–310 | ← Return to Profile |
| Sec9dcf513abc_N1908 | Sec9dcf513abc_N1896 | end_tag | 310–310 | end_tag  |
| Sec9dcf513abc_N1909 | Sec9dcf513abc_N1908 | tag_name | 310–310 | button |
| Sec9dcf513abc_N1910 | Sec9dcf513abc_N1864 | end_tag | 311–311 | end_tag  |
| Sec9dcf513abc_N1911 | Sec9dcf513abc_N1910 | tag_name | 311–311 | div |
| Sec9dcf513abc_N1912 | Sec9dcf513abc_N1849 | comment | 312–312 | &lt;!-- Top-Up Form --&gt; |
| Sec9dcf513abc_N1913 | Sec9dcf513abc_N1849 | element | 313–348 | element  |
| Sec9dcf513abc_N1914 | Sec9dcf513abc_N1913 | start_tag | 313–313 | start_tag  |
| Sec9dcf513abc_N1915 | Sec9dcf513abc_N1914 | tag_name | 313–313 | div |
| Sec9dcf513abc_N1916 | Sec9dcf513abc_N1914 | attribute | 313–313 | attribute  |
| Sec9dcf513abc_N1917 | Sec9dcf513abc_N1916 | attribute_name | 313–313 | class |
| Sec9dcf513abc_N1918 | Sec9dcf513abc_N1916 | quoted_attribute_value | 313–313 | quoted_attribute_value  |
| Sec9dcf513abc_N1919 | Sec9dcf513abc_N1918 | attribute_value | 313–313 | p-6 rounded-xl border border-hairline bg-surface-dim space-y-5 |
| Sec9dcf513abc_N1920 | Sec9dcf513abc_N1913 | element | 314–325 | element  |
| Sec9dcf513abc_N1921 | Sec9dcf513abc_N1920 | start_tag | 314–314 | start_tag  |
| Sec9dcf513abc_N1922 | Sec9dcf513abc_N1921 | tag_name | 314–314 | div |
| Sec9dcf513abc_N1923 | Sec9dcf513abc_N1920 | element | 315–317 | element  |
| Sec9dcf513abc_N1924 | Sec9dcf513abc_N1923 | start_tag | 315–315 | start_tag  |
| Sec9dcf513abc_N1925 | Sec9dcf513abc_N1924 | tag_name | 315–315 | label |
| Sec9dcf513abc_N1926 | Sec9dcf513abc_N1924 | attribute | 315–315 | attribute  |
| Sec9dcf513abc_N1927 | Sec9dcf513abc_N1926 | attribute_name | 315–315 | class |
| Sec9dcf513abc_N1928 | Sec9dcf513abc_N1926 | quoted_attribute_value | 315–315 | quoted_attribute_value  |
| Sec9dcf513abc_N1929 | Sec9dcf513abc_N1928 | attribute_value | 315–315 | block text-xs font-mono uppercase text-ash tracking-wider mb-2 |
| Sec9dcf513abc_N1930 | Sec9dcf513abc_N1924 | attribute | 315–315 | attribute  |
| Sec9dcf513abc_N1931 | Sec9dcf513abc_N1930 | attribute_name | 315–315 | for |
| Sec9dcf513abc_N1932 | Sec9dcf513abc_N1930 | quoted_attribute_value | 315–315 | quoted_attribute_value  |
| Sec9dcf513abc_N1933 | Sec9dcf513abc_N1932 | attribute_value | 315–315 | topup-amount |
| Sec9dcf513abc_N1934 | Sec9dcf513abc_N1923 | text | 316–316 | Prepaid credit tier to quote |
| Sec9dcf513abc_N1935 | Sec9dcf513abc_N1923 | end_tag | 317–317 | end_tag  |
| Sec9dcf513abc_N1936 | Sec9dcf513abc_N1935 | tag_name | 317–317 | label |
| Sec9dcf513abc_N1937 | Sec9dcf513abc_N1920 | element | 318–321 | element  |
| Sec9dcf513abc_N1938 | Sec9dcf513abc_N1937 | start_tag | 318–318 | start_tag  |
| Sec9dcf513abc_N1939 | Sec9dcf513abc_N1938 | tag_name | 318–318 | div |
| Sec9dcf513abc_N1940 | Sec9dcf513abc_N1938 | attribute | 318–318 | attribute  |
| Sec9dcf513abc_N1941 | Sec9dcf513abc_N1940 | attribute_name | 318–318 | class |
| Sec9dcf513abc_N1942 | Sec9dcf513abc_N1940 | quoted_attribute_value | 318–318 | quoted_attribute_value  |
| Sec9dcf513abc_N1943 | Sec9dcf513abc_N1942 | attribute_value | 318–318 | relative max-w-xs |
| Sec9dcf513abc_N1944 | Sec9dcf513abc_N1937 | element | 319–319 | element  |
| Sec9dcf513abc_N1945 | Sec9dcf513abc_N1944 | start_tag | 319–319 | start_tag  |
| Sec9dcf513abc_N1946 | Sec9dcf513abc_N1945 | tag_name | 319–319 | span |
| Sec9dcf513abc_N1947 | Sec9dcf513abc_N1945 | attribute | 319–319 | attribute  |
| Sec9dcf513abc_N1948 | Sec9dcf513abc_N1947 | attribute_name | 319–319 | class |
| Sec9dcf513abc_N1949 | Sec9dcf513abc_N1947 | quoted_attribute_value | 319–319 | quoted_attribute_value  |
| Sec9dcf513abc_N1950 | Sec9dcf513abc_N1949 | attribute_value | 319–319 | absolute inset-y-0 left-0 pl-3 flex items-center text-ash font-mono text-sm |
| Sec9dcf513abc_N1951 | Sec9dcf513abc_N1944 | text | 319–319 | $ |
| Sec9dcf513abc_N1952 | Sec9dcf513abc_N1944 | end_tag | 319–319 | end_tag  |
| Sec9dcf513abc_N1953 | Sec9dcf513abc_N1952 | tag_name | 319–319 | span |
| Sec9dcf513abc_N1954 | Sec9dcf513abc_N1937 | element | 320–320 | element  |
| Sec9dcf513abc_N1955 | Sec9dcf513abc_N1954 | self_closing_tag | 320–320 | self_closing_tag  |
| Sec9dcf513abc_N1956 | Sec9dcf513abc_N1955 | tag_name | 320–320 | input |
| Sec9dcf513abc_N1957 | Sec9dcf513abc_N1955 | attribute | 320–320 | attribute  |
| Sec9dcf513abc_N1958 | Sec9dcf513abc_N1957 | attribute_name | 320–320 | class |
| Sec9dcf513abc_N1959 | Sec9dcf513abc_N1957 | quoted_attribute_value | 320–320 | quoted_attribute_value  |
| Sec9dcf513abc_N1960 | Sec9dcf513abc_N1959 | attribute_value | 320–320 | w-full pl-8 pr-3 py-2 rounded-lg bg-raised-charcoal border border-hairline text-sm text-starlight font-mono focus:border-celestial-brass cursor-not-allowed |
| Sec9dcf513abc_N1961 | Sec9dcf513abc_N1955 | attribute | 320–320 | attribute  |
| Sec9dcf513abc_N1962 | Sec9dcf513abc_N1961 | attribute_name | 320–320 | id |
| Sec9dcf513abc_N1963 | Sec9dcf513abc_N1961 | quoted_attribute_value | 320–320 | quoted_attribute_value  |
| Sec9dcf513abc_N1964 | Sec9dcf513abc_N1963 | attribute_value | 320–320 | topup-amount |
| Sec9dcf513abc_N1965 | Sec9dcf513abc_N1955 | attribute | 320–320 | attribute  |
| Sec9dcf513abc_N1966 | Sec9dcf513abc_N1965 | attribute_name | 320–320 | name |
| Sec9dcf513abc_N1967 | Sec9dcf513abc_N1965 | quoted_attribute_value | 320–320 | quoted_attribute_value  |
| Sec9dcf513abc_N1968 | Sec9dcf513abc_N1967 | attribute_value | 320–320 | topup-amount |
| Sec9dcf513abc_N1969 | Sec9dcf513abc_N1955 | attribute | 320–320 | attribute  |
| Sec9dcf513abc_N1970 | Sec9dcf513abc_N1969 | attribute_name | 320–320 | placeholder |
| Sec9dcf513abc_N1971 | Sec9dcf513abc_N1969 | quoted_attribute_value | 320–320 | quoted_attribute_value  |
| Sec9dcf513abc_N1972 | Sec9dcf513abc_N1971 | attribute_value | 320–320 | Price shown in quote |
| Sec9dcf513abc_N1973 | Sec9dcf513abc_N1955 | attribute | 320–320 | attribute  |
| Sec9dcf513abc_N1974 | Sec9dcf513abc_N1973 | attribute_name | 320–320 | readonly |
| Sec9dcf513abc_N1975 | Sec9dcf513abc_N1973 | quoted_attribute_value | 320–320 | "" |
| Sec9dcf513abc_N1976 | Sec9dcf513abc_N1955 | attribute | 320–320 | attribute  |
| Sec9dcf513abc_N1977 | Sec9dcf513abc_N1976 | attribute_name | 320–320 | type |
| Sec9dcf513abc_N1978 | Sec9dcf513abc_N1976 | quoted_attribute_value | 320–320 | quoted_attribute_value  |
| Sec9dcf513abc_N1979 | Sec9dcf513abc_N1978 | attribute_value | 320–320 | text |
| Sec9dcf513abc_N1980 | Sec9dcf513abc_N1955 | attribute | 320–320 | attribute  |
| Sec9dcf513abc_N1981 | Sec9dcf513abc_N1980 | attribute_name | 320–320 | value |
| Sec9dcf513abc_N1982 | Sec9dcf513abc_N1980 | quoted_attribute_value | 320–320 | quoted_attribute_value  |
| Sec9dcf513abc_N1983 | Sec9dcf513abc_N1982 | attribute_value | 320–320 | Price shown in server quote |
| Sec9dcf513abc_N1984 | Sec9dcf513abc_N1937 | end_tag | 321–321 | end_tag  |
| Sec9dcf513abc_N1985 | Sec9dcf513abc_N1984 | tag_name | 321–321 | div |
| Sec9dcf513abc_N1986 | Sec9dcf513abc_N1920 | element | 322–324 | element  |
| Sec9dcf513abc_N1987 | Sec9dcf513abc_N1986 | start_tag | 322–322 | start_tag  |
| Sec9dcf513abc_N1988 | Sec9dcf513abc_N1987 | tag_name | 322–322 | p |
| Sec9dcf513abc_N1989 | Sec9dcf513abc_N1987 | attribute | 322–322 | attribute  |
| Sec9dcf513abc_N1990 | Sec9dcf513abc_N1989 | attribute_name | 322–322 | class |
| Sec9dcf513abc_N1991 | Sec9dcf513abc_N1989 | quoted_attribute_value | 322–322 | quoted_attribute_value  |
| Sec9dcf513abc_N1992 | Sec9dcf513abc_N1991 | attribute_value | 322–322 | text-xs text-ash mt-1.5 font-mono |
| Sec9dcf513abc_N1993 | Sec9dcf513abc_N1986 | text | 323–323 | Actual amount, fees, and currency network parameters are calculated server-authoritatively at quote issuance. |
| Sec9dcf513abc_N1994 | Sec9dcf513abc_N1986 | end_tag | 324–324 | end_tag  |
| Sec9dcf513abc_N1995 | Sec9dcf513abc_N1994 | tag_name | 324–324 | p |
| Sec9dcf513abc_N1996 | Sec9dcf513abc_N1920 | end_tag | 325–325 | end_tag  |
| Sec9dcf513abc_N1997 | Sec9dcf513abc_N1996 | tag_name | 325–325 | div |
| Sec9dcf513abc_N1998 | Sec9dcf513abc_N1913 | element | 326–339 | element  |
| Sec9dcf513abc_N1999 | Sec9dcf513abc_N1998 | start_tag | 326–326 | start_tag  |
| Sec9dcf513abc_N2000 | Sec9dcf513abc_N1999 | tag_name | 326–326 | div |
| Sec9dcf513abc_N2001 | Sec9dcf513abc_N1999 | attribute | 326–326 | attribute  |
| Sec9dcf513abc_N2002 | Sec9dcf513abc_N2001 | attribute_name | 326–326 | class |
| Sec9dcf513abc_N2003 | Sec9dcf513abc_N2001 | quoted_attribute_value | 326–326 | quoted_attribute_value  |
| Sec9dcf513abc_N2004 | Sec9dcf513abc_N2003 | attribute_value | 326–326 | grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs |
| Sec9dcf513abc_N2005 | Sec9dcf513abc_N1998 | element | 327–330 | element  |
| Sec9dcf513abc_N2006 | Sec9dcf513abc_N2005 | start_tag | 327–327 | start_tag  |
| Sec9dcf513abc_N2007 | Sec9dcf513abc_N2006 | tag_name | 327–327 | div |
| Sec9dcf513abc_N2008 | Sec9dcf513abc_N2006 | attribute | 327–327 | attribute  |
| Sec9dcf513abc_N2009 | Sec9dcf513abc_N2008 | attribute_name | 327–327 | class |
| Sec9dcf513abc_N2010 | Sec9dcf513abc_N2008 | quoted_attribute_value | 327–327 | quoted_attribute_value  |
| Sec9dcf513abc_N2011 | Sec9dcf513abc_N2010 | attribute_value | 327–327 | p-3 rounded-lg border border-hairline/60 bg-raised-charcoal |
| Sec9dcf513abc_N2012 | Sec9dcf513abc_N2005 | element | 328–328 | element  |
| Sec9dcf513abc_N2013 | Sec9dcf513abc_N2012 | start_tag | 328–328 | start_tag  |
| Sec9dcf513abc_N2014 | Sec9dcf513abc_N2013 | tag_name | 328–328 | span |
| Sec9dcf513abc_N2015 | Sec9dcf513abc_N2013 | attribute | 328–328 | attribute  |
| Sec9dcf513abc_N2016 | Sec9dcf513abc_N2015 | attribute_name | 328–328 | class |
| Sec9dcf513abc_N2017 | Sec9dcf513abc_N2015 | quoted_attribute_value | 328–328 | quoted_attribute_value  |
| Sec9dcf513abc_N2018 | Sec9dcf513abc_N2017 | attribute_value | 328–328 | font-mono text-ash block text-[11px] |
| Sec9dcf513abc_N2019 | Sec9dcf513abc_N2012 | text | 328–328 | Payment State |
| Sec9dcf513abc_N2020 | Sec9dcf513abc_N2012 | end_tag | 328–328 | end_tag  |
| Sec9dcf513abc_N2021 | Sec9dcf513abc_N2020 | tag_name | 328–328 | span |
| Sec9dcf513abc_N2022 | Sec9dcf513abc_N2005 | element | 329–329 | element  |
| Sec9dcf513abc_N2023 | Sec9dcf513abc_N2022 | start_tag | 329–329 | start_tag  |
| Sec9dcf513abc_N2024 | Sec9dcf513abc_N2023 | tag_name | 329–329 | span |
| Sec9dcf513abc_N2025 | Sec9dcf513abc_N2023 | attribute | 329–329 | attribute  |
| Sec9dcf513abc_N2026 | Sec9dcf513abc_N2025 | attribute_name | 329–329 | class |
| Sec9dcf513abc_N2027 | Sec9dcf513abc_N2025 | quoted_attribute_value | 329–329 | quoted_attribute_value  |
| Sec9dcf513abc_N2028 | Sec9dcf513abc_N2027 | attribute_value | 329–329 | text-starlight font-medium mt-0.5 block |
| Sec9dcf513abc_N2029 | Sec9dcf513abc_N2022 | text | 329–329 | Awaiting Quote |
| Sec9dcf513abc_N2030 | Sec9dcf513abc_N2022 | end_tag | 329–329 | end_tag  |
| Sec9dcf513abc_N2031 | Sec9dcf513abc_N2030 | tag_name | 329–329 | span |
| Sec9dcf513abc_N2032 | Sec9dcf513abc_N2005 | end_tag | 330–330 | end_tag  |
| Sec9dcf513abc_N2033 | Sec9dcf513abc_N2032 | tag_name | 330–330 | div |
| Sec9dcf513abc_N2034 | Sec9dcf513abc_N1998 | element | 331–334 | element  |
| Sec9dcf513abc_N2035 | Sec9dcf513abc_N2034 | start_tag | 331–331 | start_tag  |
| Sec9dcf513abc_N2036 | Sec9dcf513abc_N2035 | tag_name | 331–331 | div |
| Sec9dcf513abc_N2037 | Sec9dcf513abc_N2035 | attribute | 331–331 | attribute  |
| Sec9dcf513abc_N2038 | Sec9dcf513abc_N2037 | attribute_name | 331–331 | class |
| Sec9dcf513abc_N2039 | Sec9dcf513abc_N2037 | quoted_attribute_value | 331–331 | quoted_attribute_value  |
| Sec9dcf513abc_N2040 | Sec9dcf513abc_N2039 | attribute_value | 331–331 | p-3 rounded-lg border border-hairline/60 bg-raised-charcoal |
| Sec9dcf513abc_N2041 | Sec9dcf513abc_N2034 | element | 332–332 | element  |
| Sec9dcf513abc_N2042 | Sec9dcf513abc_N2041 | start_tag | 332–332 | start_tag  |
| Sec9dcf513abc_N2043 | Sec9dcf513abc_N2042 | tag_name | 332–332 | span |
| Sec9dcf513abc_N2044 | Sec9dcf513abc_N2042 | attribute | 332–332 | attribute  |
| Sec9dcf513abc_N2045 | Sec9dcf513abc_N2044 | attribute_name | 332–332 | class |
| Sec9dcf513abc_N2046 | Sec9dcf513abc_N2044 | quoted_attribute_value | 332–332 | quoted_attribute_value  |
| Sec9dcf513abc_N2047 | Sec9dcf513abc_N2046 | attribute_value | 332–332 | font-mono text-ash block text-[11px] |
| Sec9dcf513abc_N2048 | Sec9dcf513abc_N2041 | text | 332–332 | Quote Expiry |
| Sec9dcf513abc_N2049 | Sec9dcf513abc_N2041 | end_tag | 332–332 | end_tag  |
| Sec9dcf513abc_N2050 | Sec9dcf513abc_N2049 | tag_name | 332–332 | span |
| Sec9dcf513abc_N2051 | Sec9dcf513abc_N2034 | element | 333–333 | element  |
| Sec9dcf513abc_N2052 | Sec9dcf513abc_N2051 | start_tag | 333–333 | start_tag  |
| Sec9dcf513abc_N2053 | Sec9dcf513abc_N2052 | tag_name | 333–333 | span |
| Sec9dcf513abc_N2054 | Sec9dcf513abc_N2052 | attribute | 333–333 | attribute  |
| Sec9dcf513abc_N2055 | Sec9dcf513abc_N2054 | attribute_name | 333–333 | class |
| Sec9dcf513abc_N2056 | Sec9dcf513abc_N2054 | quoted_attribute_value | 333–333 | quoted_attribute_value  |
| Sec9dcf513abc_N2057 | Sec9dcf513abc_N2056 | attribute_value | 333–333 | text-starlight font-medium mt-0.5 block |
| Sec9dcf513abc_N2058 | Sec9dcf513abc_N2051 | text | 333–333 | Determined on request |
| Sec9dcf513abc_N2059 | Sec9dcf513abc_N2051 | end_tag | 333–333 | end_tag  |
| Sec9dcf513abc_N2060 | Sec9dcf513abc_N2059 | tag_name | 333–333 | span |
| Sec9dcf513abc_N2061 | Sec9dcf513abc_N2034 | end_tag | 334–334 | end_tag  |
| Sec9dcf513abc_N2062 | Sec9dcf513abc_N2061 | tag_name | 334–334 | div |
| Sec9dcf513abc_N2063 | Sec9dcf513abc_N1998 | element | 335–338 | element  |
| Sec9dcf513abc_N2064 | Sec9dcf513abc_N2063 | start_tag | 335–335 | start_tag  |
| Sec9dcf513abc_N2065 | Sec9dcf513abc_N2064 | tag_name | 335–335 | div |
| Sec9dcf513abc_N2066 | Sec9dcf513abc_N2064 | attribute | 335–335 | attribute  |
| Sec9dcf513abc_N2067 | Sec9dcf513abc_N2066 | attribute_name | 335–335 | class |
| Sec9dcf513abc_N2068 | Sec9dcf513abc_N2066 | quoted_attribute_value | 335–335 | quoted_attribute_value  |
| Sec9dcf513abc_N2069 | Sec9dcf513abc_N2068 | attribute_value | 335–335 | p-3 rounded-lg border border-hairline/60 bg-raised-charcoal |
| Sec9dcf513abc_N2070 | Sec9dcf513abc_N2063 | element | 336–336 | element  |
| Sec9dcf513abc_N2071 | Sec9dcf513abc_N2070 | start_tag | 336–336 | start_tag  |
| Sec9dcf513abc_N2072 | Sec9dcf513abc_N2071 | tag_name | 336–336 | span |
| Sec9dcf513abc_N2073 | Sec9dcf513abc_N2071 | attribute | 336–336 | attribute  |
| Sec9dcf513abc_N2074 | Sec9dcf513abc_N2073 | attribute_name | 336–336 | class |
| Sec9dcf513abc_N2075 | Sec9dcf513abc_N2073 | quoted_attribute_value | 336–336 | quoted_attribute_value  |
| Sec9dcf513abc_N2076 | Sec9dcf513abc_N2075 | attribute_value | 336–336 | font-mono text-ash block text-[11px] |
| Sec9dcf513abc_N2077 | Sec9dcf513abc_N2070 | text | 336–336 | Settlement |
| Sec9dcf513abc_N2078 | Sec9dcf513abc_N2070 | end_tag | 336–336 | end_tag  |
| Sec9dcf513abc_N2079 | Sec9dcf513abc_N2078 | tag_name | 336–336 | span |
| Sec9dcf513abc_N2080 | Sec9dcf513abc_N2063 | element | 337–337 | element  |
| Sec9dcf513abc_N2081 | Sec9dcf513abc_N2080 | start_tag | 337–337 | start_tag  |
| Sec9dcf513abc_N2082 | Sec9dcf513abc_N2081 | tag_name | 337–337 | span |
| Sec9dcf513abc_N2083 | Sec9dcf513abc_N2081 | attribute | 337–337 | attribute  |
| Sec9dcf513abc_N2084 | Sec9dcf513abc_N2083 | attribute_name | 337–337 | class |
| Sec9dcf513abc_N2085 | Sec9dcf513abc_N2083 | quoted_attribute_value | 337–337 | quoted_attribute_value  |
| Sec9dcf513abc_N2086 | Sec9dcf513abc_N2085 | attribute_value | 337–337 | text-celestial-brass font-medium mt-0.5 block |
| Sec9dcf513abc_N2087 | Sec9dcf513abc_N2080 | text | 337–337 | Zero simulation |
| Sec9dcf513abc_N2088 | Sec9dcf513abc_N2080 | end_tag | 337–337 | end_tag  |
| Sec9dcf513abc_N2089 | Sec9dcf513abc_N2088 | tag_name | 337–337 | span |
| Sec9dcf513abc_N2090 | Sec9dcf513abc_N2063 | end_tag | 338–338 | end_tag  |
| Sec9dcf513abc_N2091 | Sec9dcf513abc_N2090 | tag_name | 338–338 | div |
| Sec9dcf513abc_N2092 | Sec9dcf513abc_N1998 | end_tag | 339–339 | end_tag  |
| Sec9dcf513abc_N2093 | Sec9dcf513abc_N2092 | tag_name | 339–339 | div |
| Sec9dcf513abc_N2094 | Sec9dcf513abc_N1913 | element | 340–344 | element  |
| Sec9dcf513abc_N2095 | Sec9dcf513abc_N2094 | start_tag | 340–340 | start_tag  |
| Sec9dcf513abc_N2096 | Sec9dcf513abc_N2095 | tag_name | 340–340 | div |
| Sec9dcf513abc_N2097 | Sec9dcf513abc_N2095 | attribute | 340–340 | attribute  |
| Sec9dcf513abc_N2098 | Sec9dcf513abc_N2097 | attribute_name | 340–340 | class |
| Sec9dcf513abc_N2099 | Sec9dcf513abc_N2097 | quoted_attribute_value | 340–340 | quoted_attribute_value  |
| Sec9dcf513abc_N2100 | Sec9dcf513abc_N2099 | attribute_value | 340–340 | pt-2 |
| Sec9dcf513abc_N2101 | Sec9dcf513abc_N2094 | element | 341–343 | element  |
| Sec9dcf513abc_N2102 | Sec9dcf513abc_N2101 | start_tag | 341–341 | start_tag  |
| Sec9dcf513abc_N2103 | Sec9dcf513abc_N2102 | tag_name | 341–341 | button |
| Sec9dcf513abc_N2104 | Sec9dcf513abc_N2102 | attribute | 341–341 | attribute  |
| Sec9dcf513abc_N2105 | Sec9dcf513abc_N2104 | attribute_name | 341–341 | class |
| Sec9dcf513abc_N2106 | Sec9dcf513abc_N2104 | quoted_attribute_value | 341–341 | quoted_attribute_value  |
| Sec9dcf513abc_N2107 | Sec9dcf513abc_N2106 | attribute_value | 341–341 | py-3 px-6 rounded-lg bg-celestial-brass text-observatory font-semibold text-sm hover:bg-celestial-brass-hover transition-colors |
| Sec9dcf513abc_N2108 | Sec9dcf513abc_N2102 | attribute | 341–341 | attribute  |
| Sec9dcf513abc_N2109 | Sec9dcf513abc_N2108 | attribute_name | 341–341 | id |
| Sec9dcf513abc_N2110 | Sec9dcf513abc_N2108 | quoted_attribute_value | 341–341 | quoted_attribute_value  |
| Sec9dcf513abc_N2111 | Sec9dcf513abc_N2110 | attribute_value | 341–341 | request-topup |
| Sec9dcf513abc_N2112 | Sec9dcf513abc_N2102 | attribute | 341–341 | attribute  |
| Sec9dcf513abc_N2113 | Sec9dcf513abc_N2112 | attribute_name | 341–341 | onclick |
| Sec9dcf513abc_N2114 | Sec9dcf513abc_N2112 | quoted_attribute_value | 341–341 | quoted_attribute_value  |
| Sec9dcf513abc_N2115 | Sec9dcf513abc_N2114 | attribute_value | 341–341 | simulateQuoteNotice('Top-up quote requested. Server-authoritative calculation will determine final fees; design screens do not simulate real settlement.') |
| Sec9dcf513abc_N2116 | Sec9dcf513abc_N2101 | text | 342–342 | Request server quote |
| Sec9dcf513abc_N2117 | Sec9dcf513abc_N2101 | end_tag | 343–343 | end_tag  |
| Sec9dcf513abc_N2118 | Sec9dcf513abc_N2117 | tag_name | 343–343 | button |
| Sec9dcf513abc_N2119 | Sec9dcf513abc_N2094 | end_tag | 344–344 | end_tag  |
| Sec9dcf513abc_N2120 | Sec9dcf513abc_N2119 | tag_name | 344–344 | div |
| Sec9dcf513abc_N2121 | Sec9dcf513abc_N1913 | element | 345–347 | element  |
| Sec9dcf513abc_N2122 | Sec9dcf513abc_N2121 | start_tag | 345–345 | start_tag  |
| Sec9dcf513abc_N2123 | Sec9dcf513abc_N2122 | tag_name | 345–345 | div |
| Sec9dcf513abc_N2124 | Sec9dcf513abc_N2122 | attribute | 345–345 | attribute  |
| Sec9dcf513abc_N2125 | Sec9dcf513abc_N2124 | attribute_name | 345–345 | class |
| Sec9dcf513abc_N2126 | Sec9dcf513abc_N2124 | quoted_attribute_value | 345–345 | quoted_attribute_value  |
| Sec9dcf513abc_N2127 | Sec9dcf513abc_N2126 | attribute_value | 345–345 | border-t border-hairline/60 pt-3 text-xs text-ash space-y-1 |
| Sec9dcf513abc_N2128 | Sec9dcf513abc_N2121 | element | 346–346 | element  |
| Sec9dcf513abc_N2129 | Sec9dcf513abc_N2128 | start_tag | 346–346 | start_tag  |
| Sec9dcf513abc_N2130 | Sec9dcf513abc_N2129 | tag_name | 346–346 | p |
| Sec9dcf513abc_N2131 | Sec9dcf513abc_N2128 | element | 346–346 | element  |
| Sec9dcf513abc_N2132 | Sec9dcf513abc_N2131 | start_tag | 346–346 | start_tag  |
| Sec9dcf513abc_N2133 | Sec9dcf513abc_N2132 | tag_name | 346–346 | strong |
| Sec9dcf513abc_N2134 | Sec9dcf513abc_N2131 | text | 346–346 | Recovery notice: |
| Sec9dcf513abc_N2135 | Sec9dcf513abc_N2131 | end_tag | 346–346 | end_tag  |
| Sec9dcf513abc_N2136 | Sec9dcf513abc_N2135 | tag_name | 346–346 | strong |
| Sec9dcf513abc_N2137 | Sec9dcf513abc_N2128 | text | 346–346 | If a payment is interrupted or expires, orders can be resumed rather than settled twice. |
| Sec9dcf513abc_N2138 | Sec9dcf513abc_N2128 | end_tag | 346–346 | end_tag  |
| Sec9dcf513abc_N2139 | Sec9dcf513abc_N2138 | tag_name | 346–346 | p |
| Sec9dcf513abc_N2140 | Sec9dcf513abc_N2121 | end_tag | 347–347 | end_tag  |
| Sec9dcf513abc_N2141 | Sec9dcf513abc_N2140 | tag_name | 347–347 | div |
| Sec9dcf513abc_N2142 | Sec9dcf513abc_N1913 | end_tag | 348–348 | end_tag  |
| Sec9dcf513abc_N2143 | Sec9dcf513abc_N2142 | tag_name | 348–348 | div |
| Sec9dcf513abc_N2144 | Sec9dcf513abc_N1849 | end_tag | 349–349 | end_tag  |
| Sec9dcf513abc_N2145 | Sec9dcf513abc_N2144 | tag_name | 349–349 | div |
| Sec9dcf513abc_N2146 | Sec9dcf513abc_N1194 | comment | 350–350 | &lt;!-- SECTION 4: BUY NATAL CHART OFFERS --&gt; |
| Sec9dcf513abc_N2147 | Sec9dcf513abc_N1194 | element | 351–425 | element  |
| Sec9dcf513abc_N2148 | Sec9dcf513abc_N2147 | start_tag | 351–351 | start_tag  |
| Sec9dcf513abc_N2149 | Sec9dcf513abc_N2148 | tag_name | 351–351 | div |
| Sec9dcf513abc_N2150 | Sec9dcf513abc_N2148 | attribute | 351–351 | attribute  |
| Sec9dcf513abc_N2151 | Sec9dcf513abc_N2150 | attribute_name | 351–351 | class |
| Sec9dcf513abc_N2152 | Sec9dcf513abc_N2150 | quoted_attribute_value | 351–351 | quoted_attribute_value  |
| Sec9dcf513abc_N2153 | Sec9dcf513abc_N2152 | attribute_value | 351–351 | view-section space-y-6 |
| Sec9dcf513abc_N2154 | Sec9dcf513abc_N2148 | attribute | 351–351 | attribute  |
| Sec9dcf513abc_N2155 | Sec9dcf513abc_N2154 | attribute_name | 351–351 | data-view |
| Sec9dcf513abc_N2156 | Sec9dcf513abc_N2154 | quoted_attribute_value | 351–351 | quoted_attribute_value  |
| Sec9dcf513abc_N2157 | Sec9dcf513abc_N2156 | attribute_value | 351–351 | offers |
| Sec9dcf513abc_N2158 | Sec9dcf513abc_N2148 | attribute | 351–351 | attribute  |
| Sec9dcf513abc_N2159 | Sec9dcf513abc_N2158 | attribute_name | 351–351 | id |
| Sec9dcf513abc_N2160 | Sec9dcf513abc_N2158 | quoted_attribute_value | 351–351 | quoted_attribute_value  |
| Sec9dcf513abc_N2161 | Sec9dcf513abc_N2160 | attribute_value | 351–351 | section-offers |
| Sec9dcf513abc_N2162 | Sec9dcf513abc_N2147 | element | 352–358 | element  |
| Sec9dcf513abc_N2163 | Sec9dcf513abc_N2162 | start_tag | 352–352 | start_tag  |
| Sec9dcf513abc_N2164 | Sec9dcf513abc_N2163 | tag_name | 352–352 | div |
| Sec9dcf513abc_N2165 | Sec9dcf513abc_N2163 | attribute | 352–352 | attribute  |
| Sec9dcf513abc_N2166 | Sec9dcf513abc_N2165 | attribute_name | 352–352 | class |
| Sec9dcf513abc_N2167 | Sec9dcf513abc_N2165 | quoted_attribute_value | 352–352 | quoted_attribute_value  |
| Sec9dcf513abc_N2168 | Sec9dcf513abc_N2167 | attribute_value | 352–352 | border-b border-hairline/80 pb-4 flex items-center justify-between |
| Sec9dcf513abc_N2169 | Sec9dcf513abc_N2162 | element | 353–356 | element  |
| Sec9dcf513abc_N2170 | Sec9dcf513abc_N2169 | start_tag | 353–353 | start_tag  |
| Sec9dcf513abc_N2171 | Sec9dcf513abc_N2170 | tag_name | 353–353 | div |
| Sec9dcf513abc_N2172 | Sec9dcf513abc_N2169 | element | 354–354 | element  |
| Sec9dcf513abc_N2173 | Sec9dcf513abc_N2172 | start_tag | 354–354 | start_tag  |
| Sec9dcf513abc_N2174 | Sec9dcf513abc_N2173 | tag_name | 354–354 | span |
| Sec9dcf513abc_N2175 | Sec9dcf513abc_N2173 | attribute | 354–354 | attribute  |
| Sec9dcf513abc_N2176 | Sec9dcf513abc_N2175 | attribute_name | 354–354 | class |
| Sec9dcf513abc_N2177 | Sec9dcf513abc_N2175 | quoted_attribute_value | 354–354 | quoted_attribute_value  |
| Sec9dcf513abc_N2178 | Sec9dcf513abc_N2177 | attribute_value | 354–354 | text-xs font-mono text-celestial-brass uppercase tracking-wider |
| Sec9dcf513abc_N2179 | Sec9dcf513abc_N2172 | text | 354–354 | Offer Selection |
| Sec9dcf513abc_N2180 | Sec9dcf513abc_N2172 | end_tag | 354–354 | end_tag  |
| Sec9dcf513abc_N2181 | Sec9dcf513abc_N2180 | tag_name | 354–354 | span |
| Sec9dcf513abc_N2182 | Sec9dcf513abc_N2169 | element | 355–355 | element  |
| Sec9dcf513abc_N2183 | Sec9dcf513abc_N2182 | start_tag | 355–355 | start_tag  |
| Sec9dcf513abc_N2184 | Sec9dcf513abc_N2183 | tag_name | 355–355 | h1 |
| Sec9dcf513abc_N2185 | Sec9dcf513abc_N2183 | attribute | 355–355 | attribute  |
| Sec9dcf513abc_N2186 | Sec9dcf513abc_N2185 | attribute_name | 355–355 | class |
| Sec9dcf513abc_N2187 | Sec9dcf513abc_N2185 | quoted_attribute_value | 355–355 | quoted_attribute_value  |
| Sec9dcf513abc_N2188 | Sec9dcf513abc_N2187 | attribute_value | 355–355 | font-display text-2xl font-normal text-starlight mt-1 |
| Sec9dcf513abc_N2189 | Sec9dcf513abc_N2182 | text | 355–355 | Natal Chart Packages |
| Sec9dcf513abc_N2190 | Sec9dcf513abc_N2182 | end_tag | 355–355 | end_tag  |
| Sec9dcf513abc_N2191 | Sec9dcf513abc_N2190 | tag_name | 355–355 | h1 |
| Sec9dcf513abc_N2192 | Sec9dcf513abc_N2169 | end_tag | 356–356 | end_tag  |
| Sec9dcf513abc_N2193 | Sec9dcf513abc_N2192 | tag_name | 356–356 | div |
| Sec9dcf513abc_N2194 | Sec9dcf513abc_N2162 | element | 357–357 | element  |
| Sec9dcf513abc_N2195 | Sec9dcf513abc_N2194 | start_tag | 357–357 | start_tag  |
| Sec9dcf513abc_N2196 | Sec9dcf513abc_N2195 | tag_name | 357–357 | button |
| Sec9dcf513abc_N2197 | Sec9dcf513abc_N2195 | attribute | 357–357 | attribute  |
| Sec9dcf513abc_N2198 | Sec9dcf513abc_N2197 | attribute_name | 357–357 | class |
| Sec9dcf513abc_N2199 | Sec9dcf513abc_N2197 | quoted_attribute_value | 357–357 | quoted_attribute_value  |
| Sec9dcf513abc_N2200 | Sec9dcf513abc_N2199 | attribute_value | 357–357 | text-xs font-mono text-ash hover:text-starlight |
| Sec9dcf513abc_N2201 | Sec9dcf513abc_N2195 | attribute | 357–357 | attribute  |
| Sec9dcf513abc_N2202 | Sec9dcf513abc_N2201 | attribute_name | 357–357 | onclick |
| Sec9dcf513abc_N2203 | Sec9dcf513abc_N2201 | quoted_attribute_value | 357–357 | quoted_attribute_value  |
| Sec9dcf513abc_N2204 | Sec9dcf513abc_N2203 | attribute_value | 357–357 | switchView('profile') |
| Sec9dcf513abc_N2205 | Sec9dcf513abc_N2194 | text | 357–357 | ← Return to Profile |
| Sec9dcf513abc_N2206 | Sec9dcf513abc_N2194 | end_tag | 357–357 | end_tag  |
| Sec9dcf513abc_N2207 | Sec9dcf513abc_N2206 | tag_name | 357–357 | button |
| Sec9dcf513abc_N2208 | Sec9dcf513abc_N2162 | end_tag | 358–358 | end_tag  |
| Sec9dcf513abc_N2209 | Sec9dcf513abc_N2208 | tag_name | 358–358 | div |
| Sec9dcf513abc_N2210 | Sec9dcf513abc_N2147 | element | 359–361 | element  |
| Sec9dcf513abc_N2211 | Sec9dcf513abc_N2210 | start_tag | 359–359 | start_tag  |
| Sec9dcf513abc_N2212 | Sec9dcf513abc_N2211 | tag_name | 359–359 | p |
| Sec9dcf513abc_N2213 | Sec9dcf513abc_N2211 | attribute | 359–359 | attribute  |
| Sec9dcf513abc_N2214 | Sec9dcf513abc_N2213 | attribute_name | 359–359 | class |
| Sec9dcf513abc_N2215 | Sec9dcf513abc_N2213 | quoted_attribute_value | 359–359 | quoted_attribute_value  |
| Sec9dcf513abc_N2216 | Sec9dcf513abc_N2215 | attribute_value | 359–359 | text-xs text-ash leading-relaxed |
| Sec9dcf513abc_N2217 | Sec9dcf513abc_N2210 | text | 360–360 | RevenueCat site-centric purchases. Choose an archival folio or interactive experience. Explicit note: metered conversational readings remain separate from static deliverables. |
| Sec9dcf513abc_N2218 | Sec9dcf513abc_N2210 | end_tag | 361–361 | end_tag  |
| Sec9dcf513abc_N2219 | Sec9dcf513abc_N2218 | tag_name | 361–361 | p |
| Sec9dcf513abc_N2220 | Sec9dcf513abc_N2147 | comment | 362–362 | &lt;!-- Radio Selector List --&gt; |
| Sec9dcf513abc_N2221 | Sec9dcf513abc_N2147 | element | 363–415 | element  |
| Sec9dcf513abc_N2222 | Sec9dcf513abc_N2221 | start_tag | 363–363 | start_tag  |
| Sec9dcf513abc_N2223 | Sec9dcf513abc_N2222 | tag_name | 363–363 | div |
| Sec9dcf513abc_N2224 | Sec9dcf513abc_N2222 | attribute | 363–363 | attribute  |
| Sec9dcf513abc_N2225 | Sec9dcf513abc_N2224 | attribute_name | 363–363 | class |
| Sec9dcf513abc_N2226 | Sec9dcf513abc_N2224 | quoted_attribute_value | 363–363 | quoted_attribute_value  |
| Sec9dcf513abc_N2227 | Sec9dcf513abc_N2226 | attribute_value | 363–363 | space-y-4 |
| Sec9dcf513abc_N2228 | Sec9dcf513abc_N2221 | comment | 364–364 | &lt;!-- Tier 1: PDF Only --&gt; |
| Sec9dcf513abc_N2229 | Sec9dcf513abc_N2221 | element | 365–379 | element  |
| Sec9dcf513abc_N2230 | Sec9dcf513abc_N2229 | start_tag | 365–365 | start_tag  |
| Sec9dcf513abc_N2231 | Sec9dcf513abc_N2230 | tag_name | 365–365 | label |
| Sec9dcf513abc_N2232 | Sec9dcf513abc_N2230 | attribute | 365–365 | attribute  |
| Sec9dcf513abc_N2233 | Sec9dcf513abc_N2232 | attribute_name | 365–365 | class |
| Sec9dcf513abc_N2234 | Sec9dcf513abc_N2232 | quoted_attribute_value | 365–365 | quoted_attribute_value  |
| Sec9dcf513abc_N2235 | Sec9dcf513abc_N2234 | attribute_value | 365–365 | p-5 rounded-xl border border-hairline bg-surface-dim block cursor-pointer hover:border-hairline/80 transition-colors |
| Sec9dcf513abc_N2236 | Sec9dcf513abc_N2229 | element | 366–375 | element  |
| Sec9dcf513abc_N2237 | Sec9dcf513abc_N2236 | start_tag | 366–366 | start_tag  |
| Sec9dcf513abc_N2238 | Sec9dcf513abc_N2237 | tag_name | 366–366 | div |
| Sec9dcf513abc_N2239 | Sec9dcf513abc_N2237 | attribute | 366–366 | attribute  |
| Sec9dcf513abc_N2240 | Sec9dcf513abc_N2239 | attribute_name | 366–366 | class |
| Sec9dcf513abc_N2241 | Sec9dcf513abc_N2239 | quoted_attribute_value | 366–366 | quoted_attribute_value  |
| Sec9dcf513abc_N2242 | Sec9dcf513abc_N2241 | attribute_value | 366–366 | flex items-start justify-between |
| Sec9dcf513abc_N2243 | Sec9dcf513abc_N2236 | element | 367–373 | element  |
| Sec9dcf513abc_N2244 | Sec9dcf513abc_N2243 | start_tag | 367–367 | start_tag  |
| Sec9dcf513abc_N2245 | Sec9dcf513abc_N2244 | tag_name | 367–367 | div |
| Sec9dcf513abc_N2246 | Sec9dcf513abc_N2244 | attribute | 367–367 | attribute  |
| Sec9dcf513abc_N2247 | Sec9dcf513abc_N2246 | attribute_name | 367–367 | class |
| Sec9dcf513abc_N2248 | Sec9dcf513abc_N2246 | quoted_attribute_value | 367–367 | quoted_attribute_value  |
| Sec9dcf513abc_N2249 | Sec9dcf513abc_N2248 | attribute_value | 367–367 | flex items-center space-x-3 |
| Sec9dcf513abc_N2250 | Sec9dcf513abc_N2243 | element | 368–368 | element  |
| Sec9dcf513abc_N2251 | Sec9dcf513abc_N2250 | self_closing_tag | 368–368 | self_closing_tag  |
| Sec9dcf513abc_N2252 | Sec9dcf513abc_N2251 | tag_name | 368–368 | input |
| Sec9dcf513abc_N2253 | Sec9dcf513abc_N2251 | attribute | 368–368 | attribute  |
| Sec9dcf513abc_N2254 | Sec9dcf513abc_N2253 | attribute_name | 368–368 | class |
| Sec9dcf513abc_N2255 | Sec9dcf513abc_N2253 | quoted_attribute_value | 368–368 | quoted_attribute_value  |
| Sec9dcf513abc_N2256 | Sec9dcf513abc_N2255 | attribute_value | 368–368 | accent-celestial-brass w-4 h-4 |
| Sec9dcf513abc_N2257 | Sec9dcf513abc_N2251 | attribute | 368–368 | attribute  |
| Sec9dcf513abc_N2258 | Sec9dcf513abc_N2257 | attribute_name | 368–368 | name |
| Sec9dcf513abc_N2259 | Sec9dcf513abc_N2257 | quoted_attribute_value | 368–368 | quoted_attribute_value  |
| Sec9dcf513abc_N2260 | Sec9dcf513abc_N2259 | attribute_value | 368–368 | offer |
| Sec9dcf513abc_N2261 | Sec9dcf513abc_N2251 | attribute | 368–368 | attribute  |
| Sec9dcf513abc_N2262 | Sec9dcf513abc_N2261 | attribute_name | 368–368 | type |
| Sec9dcf513abc_N2263 | Sec9dcf513abc_N2261 | quoted_attribute_value | 368–368 | quoted_attribute_value  |
| Sec9dcf513abc_N2264 | Sec9dcf513abc_N2263 | attribute_value | 368–368 | radio |
| Sec9dcf513abc_N2265 | Sec9dcf513abc_N2251 | attribute | 368–368 | attribute  |
| Sec9dcf513abc_N2266 | Sec9dcf513abc_N2265 | attribute_name | 368–368 | value |
| Sec9dcf513abc_N2267 | Sec9dcf513abc_N2265 | quoted_attribute_value | 368–368 | quoted_attribute_value  |
| Sec9dcf513abc_N2268 | Sec9dcf513abc_N2267 | attribute_value | 368–368 | pdf-only |
| Sec9dcf513abc_N2269 | Sec9dcf513abc_N2243 | element | 369–372 | element  |
| Sec9dcf513abc_N2270 | Sec9dcf513abc_N2269 | start_tag | 369–369 | start_tag  |
| Sec9dcf513abc_N2271 | Sec9dcf513abc_N2270 | tag_name | 369–369 | div |
| Sec9dcf513abc_N2272 | Sec9dcf513abc_N2269 | element | 370–370 | element  |
| Sec9dcf513abc_N2273 | Sec9dcf513abc_N2272 | start_tag | 370–370 | start_tag  |
| Sec9dcf513abc_N2274 | Sec9dcf513abc_N2273 | tag_name | 370–370 | span |
| Sec9dcf513abc_N2275 | Sec9dcf513abc_N2273 | attribute | 370–370 | attribute  |
| Sec9dcf513abc_N2276 | Sec9dcf513abc_N2275 | attribute_name | 370–370 | class |
| Sec9dcf513abc_N2277 | Sec9dcf513abc_N2275 | quoted_attribute_value | 370–370 | quoted_attribute_value  |
| Sec9dcf513abc_N2278 | Sec9dcf513abc_N2277 | attribute_value | 370–370 | font-display text-base text-starlight font-medium |
| Sec9dcf513abc_N2279 | Sec9dcf513abc_N2272 | text | 370–370 | Natal chart — PDF only |
| Sec9dcf513abc_N2280 | Sec9dcf513abc_N2272 | end_tag | 370–370 | end_tag  |
| Sec9dcf513abc_N2281 | Sec9dcf513abc_N2280 | tag_name | 370–370 | span |
| Sec9dcf513abc_N2282 | Sec9dcf513abc_N2269 | element | 371–371 | element  |
| Sec9dcf513abc_N2283 | Sec9dcf513abc_N2282 | start_tag | 371–371 | start_tag  |
| Sec9dcf513abc_N2284 | Sec9dcf513abc_N2283 | tag_name | 371–371 | span |
| Sec9dcf513abc_N2285 | Sec9dcf513abc_N2283 | attribute | 371–371 | attribute  |
| Sec9dcf513abc_N2286 | Sec9dcf513abc_N2285 | attribute_name | 371–371 | class |
| Sec9dcf513abc_N2287 | Sec9dcf513abc_N2285 | quoted_attribute_value | 371–371 | quoted_attribute_value  |
| Sec9dcf513abc_N2288 | Sec9dcf513abc_N2287 | attribute_value | 371–371 | text-xs font-mono text-ash block mt-0.5 |
| Sec9dcf513abc_N2289 | Sec9dcf513abc_N2282 | text | 371–371 | Static archival illuminated folio |
| Sec9dcf513abc_N2290 | Sec9dcf513abc_N2282 | end_tag | 371–371 | end_tag  |
| Sec9dcf513abc_N2291 | Sec9dcf513abc_N2290 | tag_name | 371–371 | span |
| Sec9dcf513abc_N2292 | Sec9dcf513abc_N2269 | end_tag | 372–372 | end_tag  |
| Sec9dcf513abc_N2293 | Sec9dcf513abc_N2292 | tag_name | 372–372 | div |
| Sec9dcf513abc_N2294 | Sec9dcf513abc_N2243 | end_tag | 373–373 | end_tag  |
| Sec9dcf513abc_N2295 | Sec9dcf513abc_N2294 | tag_name | 373–373 | div |
| Sec9dcf513abc_N2296 | Sec9dcf513abc_N2236 | element | 374–374 | element  |
| Sec9dcf513abc_N2297 | Sec9dcf513abc_N2296 | start_tag | 374–374 | start_tag  |
| Sec9dcf513abc_N2298 | Sec9dcf513abc_N2297 | tag_name | 374–374 | span |
| Sec9dcf513abc_N2299 | Sec9dcf513abc_N2297 | attribute | 374–374 | attribute  |
| Sec9dcf513abc_N2300 | Sec9dcf513abc_N2299 | attribute_name | 374–374 | class |
| Sec9dcf513abc_N2301 | Sec9dcf513abc_N2299 | quoted_attribute_value | 374–374 | quoted_attribute_value  |
| Sec9dcf513abc_N2302 | Sec9dcf513abc_N2301 | attribute_value | 374–374 | text-xs font-mono text-celestial-brass |
| Sec9dcf513abc_N2303 | Sec9dcf513abc_N2296 | text | 374–374 | Price shown in checkout |
| Sec9dcf513abc_N2304 | Sec9dcf513abc_N2296 | end_tag | 374–374 | end_tag  |
| Sec9dcf513abc_N2305 | Sec9dcf513abc_N2304 | tag_name | 374–374 | span |
| Sec9dcf513abc_N2306 | Sec9dcf513abc_N2236 | end_tag | 375–375 | end_tag  |
| Sec9dcf513abc_N2307 | Sec9dcf513abc_N2306 | tag_name | 375–375 | div |
| Sec9dcf513abc_N2308 | Sec9dcf513abc_N2229 | element | 376–378 | element  |
| Sec9dcf513abc_N2309 | Sec9dcf513abc_N2308 | start_tag | 376–376 | start_tag  |
| Sec9dcf513abc_N2310 | Sec9dcf513abc_N2309 | tag_name | 376–376 | p |
| Sec9dcf513abc_N2311 | Sec9dcf513abc_N2309 | attribute | 376–376 | attribute  |
| Sec9dcf513abc_N2312 | Sec9dcf513abc_N2311 | attribute_name | 376–376 | class |
| Sec9dcf513abc_N2313 | Sec9dcf513abc_N2311 | quoted_attribute_value | 376–376 | quoted_attribute_value  |
| Sec9dcf513abc_N2314 | Sec9dcf513abc_N2313 | attribute_value | 376–376 | text-xs text-ash mt-3 pl-7 leading-relaxed |
| Sec9dcf513abc_N2315 | Sec9dcf513abc_N2308 | text | 377–377 | A downloadable natal reading/folio formatted for 300 DPI high-density printing. Does not include browser SPA access or conversational companion hosting. |
| Sec9dcf513abc_N2316 | Sec9dcf513abc_N2308 | end_tag | 378–378 | end_tag  |
| Sec9dcf513abc_N2317 | Sec9dcf513abc_N2316 | tag_name | 378–378 | p |
| Sec9dcf513abc_N2318 | Sec9dcf513abc_N2229 | end_tag | 379–379 | end_tag  |
| Sec9dcf513abc_N2319 | Sec9dcf513abc_N2318 | tag_name | 379–379 | label |
| Sec9dcf513abc_N2320 | Sec9dcf513abc_N2221 | comment | 380–380 | &lt;!-- Tier 2: PDF + SPA (Featured) --&gt; |
| Sec9dcf513abc_N2321 | Sec9dcf513abc_N2221 | element | 381–398 | element  |
| Sec9dcf513abc_N2322 | Sec9dcf513abc_N2321 | start_tag | 381–381 | start_tag  |
| Sec9dcf513abc_N2323 | Sec9dcf513abc_N2322 | tag_name | 381–381 | label |
| Sec9dcf513abc_N2324 | Sec9dcf513abc_N2322 | attribute | 381–381 | attribute  |
| Sec9dcf513abc_N2325 | Sec9dcf513abc_N2324 | attribute_name | 381–381 | class |
| Sec9dcf513abc_N2326 | Sec9dcf513abc_N2324 | quoted_attribute_value | 381–381 | quoted_attribute_value  |
| Sec9dcf513abc_N2327 | Sec9dcf513abc_N2326 | attribute_value | 381–381 | p-5 rounded-xl border-2 border-celestial-brass bg-surface-dim/90 block cursor-pointer relative shadow-lg shadow-black/40 |
| Sec9dcf513abc_N2328 | Sec9dcf513abc_N2321 | element | 382–384 | element  |
| Sec9dcf513abc_N2329 | Sec9dcf513abc_N2328 | start_tag | 382–382 | start_tag  |
| Sec9dcf513abc_N2330 | Sec9dcf513abc_N2329 | tag_name | 382–382 | div |
| Sec9dcf513abc_N2331 | Sec9dcf513abc_N2329 | attribute | 382–382 | attribute  |
| Sec9dcf513abc_N2332 | Sec9dcf513abc_N2331 | attribute_name | 382–382 | class |
| Sec9dcf513abc_N2333 | Sec9dcf513abc_N2331 | quoted_attribute_value | 382–382 | quoted_attribute_value  |
| Sec9dcf513abc_N2334 | Sec9dcf513abc_N2333 | attribute_value | 382–382 | absolute -top-3 right-4 px-2 py-0.5 rounded bg-celestial-brass text-observatory font-mono text-[10px] font-bold tracking-wider uppercase |
| Sec9dcf513abc_N2335 | Sec9dcf513abc_N2328 | text | 383–383 | Recommended Deliverable |
| Sec9dcf513abc_N2336 | Sec9dcf513abc_N2328 | end_tag | 384–384 | end_tag  |
| Sec9dcf513abc_N2337 | Sec9dcf513abc_N2336 | tag_name | 384–384 | div |
| Sec9dcf513abc_N2338 | Sec9dcf513abc_N2321 | element | 385–394 | element  |
| Sec9dcf513abc_N2339 | Sec9dcf513abc_N2338 | start_tag | 385–385 | start_tag  |
| Sec9dcf513abc_N2340 | Sec9dcf513abc_N2339 | tag_name | 385–385 | div |
| Sec9dcf513abc_N2341 | Sec9dcf513abc_N2339 | attribute | 385–385 | attribute  |
| Sec9dcf513abc_N2342 | Sec9dcf513abc_N2341 | attribute_name | 385–385 | class |
| Sec9dcf513abc_N2343 | Sec9dcf513abc_N2341 | quoted_attribute_value | 385–385 | quoted_attribute_value  |
| Sec9dcf513abc_N2344 | Sec9dcf513abc_N2343 | attribute_value | 385–385 | flex items-start justify-between |
| Sec9dcf513abc_N2345 | Sec9dcf513abc_N2338 | element | 386–392 | element  |
| Sec9dcf513abc_N2346 | Sec9dcf513abc_N2345 | start_tag | 386–386 | start_tag  |
| Sec9dcf513abc_N2347 | Sec9dcf513abc_N2346 | tag_name | 386–386 | div |
| Sec9dcf513abc_N2348 | Sec9dcf513abc_N2346 | attribute | 386–386 | attribute  |
| Sec9dcf513abc_N2349 | Sec9dcf513abc_N2348 | attribute_name | 386–386 | class |
| Sec9dcf513abc_N2350 | Sec9dcf513abc_N2348 | quoted_attribute_value | 386–386 | quoted_attribute_value  |
| Sec9dcf513abc_N2351 | Sec9dcf513abc_N2350 | attribute_value | 386–386 | flex items-center space-x-3 |
| Sec9dcf513abc_N2352 | Sec9dcf513abc_N2345 | element | 387–387 | element  |
| Sec9dcf513abc_N2353 | Sec9dcf513abc_N2352 | self_closing_tag | 387–387 | self_closing_tag  |
| Sec9dcf513abc_N2354 | Sec9dcf513abc_N2353 | tag_name | 387–387 | input |
| Sec9dcf513abc_N2355 | Sec9dcf513abc_N2353 | attribute | 387–387 | attribute  |
| Sec9dcf513abc_N2356 | Sec9dcf513abc_N2355 | attribute_name | 387–387 | checked |
| Sec9dcf513abc_N2357 | Sec9dcf513abc_N2355 | quoted_attribute_value | 387–387 | "" |
| Sec9dcf513abc_N2358 | Sec9dcf513abc_N2353 | attribute | 387–387 | attribute  |
| Sec9dcf513abc_N2359 | Sec9dcf513abc_N2358 | attribute_name | 387–387 | class |
| Sec9dcf513abc_N2360 | Sec9dcf513abc_N2358 | quoted_attribute_value | 387–387 | quoted_attribute_value  |
| Sec9dcf513abc_N2361 | Sec9dcf513abc_N2360 | attribute_value | 387–387 | accent-celestial-brass w-4 h-4 |
| Sec9dcf513abc_N2362 | Sec9dcf513abc_N2353 | attribute | 387–387 | attribute  |
| Sec9dcf513abc_N2363 | Sec9dcf513abc_N2362 | attribute_name | 387–387 | name |
| Sec9dcf513abc_N2364 | Sec9dcf513abc_N2362 | quoted_attribute_value | 387–387 | quoted_attribute_value  |
| Sec9dcf513abc_N2365 | Sec9dcf513abc_N2364 | attribute_value | 387–387 | offer |
| Sec9dcf513abc_N2366 | Sec9dcf513abc_N2353 | attribute | 387–387 | attribute  |
| Sec9dcf513abc_N2367 | Sec9dcf513abc_N2366 | attribute_name | 387–387 | type |
| Sec9dcf513abc_N2368 | Sec9dcf513abc_N2366 | quoted_attribute_value | 387–387 | quoted_attribute_value  |
| Sec9dcf513abc_N2369 | Sec9dcf513abc_N2368 | attribute_value | 387–387 | radio |
| Sec9dcf513abc_N2370 | Sec9dcf513abc_N2353 | attribute | 387–387 | attribute  |
| Sec9dcf513abc_N2371 | Sec9dcf513abc_N2370 | attribute_name | 387–387 | value |
| Sec9dcf513abc_N2372 | Sec9dcf513abc_N2370 | quoted_attribute_value | 387–387 | quoted_attribute_value  |
| Sec9dcf513abc_N2373 | Sec9dcf513abc_N2372 | attribute_value | 387–387 | pdf-spa |
| Sec9dcf513abc_N2374 | Sec9dcf513abc_N2345 | element | 388–391 | element  |
| Sec9dcf513abc_N2375 | Sec9dcf513abc_N2374 | start_tag | 388–388 | start_tag  |
| Sec9dcf513abc_N2376 | Sec9dcf513abc_N2375 | tag_name | 388–388 | div |
| Sec9dcf513abc_N2377 | Sec9dcf513abc_N2374 | element | 389–389 | element  |
| Sec9dcf513abc_N2378 | Sec9dcf513abc_N2377 | start_tag | 389–389 | start_tag  |
| Sec9dcf513abc_N2379 | Sec9dcf513abc_N2378 | tag_name | 389–389 | span |
| Sec9dcf513abc_N2380 | Sec9dcf513abc_N2378 | attribute | 389–389 | attribute  |
| Sec9dcf513abc_N2381 | Sec9dcf513abc_N2380 | attribute_name | 389–389 | class |
| Sec9dcf513abc_N2382 | Sec9dcf513abc_N2380 | quoted_attribute_value | 389–389 | quoted_attribute_value  |
| Sec9dcf513abc_N2383 | Sec9dcf513abc_N2382 | attribute_value | 389–389 | font-display text-base text-starlight font-medium |
| Sec9dcf513abc_N2384 | Sec9dcf513abc_N2377 | text | 389–389 | Natal chart — PDF + SPA |
| Sec9dcf513abc_N2385 | Sec9dcf513abc_N2377 | end_tag | 389–389 | end_tag  |
| Sec9dcf513abc_N2386 | Sec9dcf513abc_N2385 | tag_name | 389–389 | span |
| Sec9dcf513abc_N2387 | Sec9dcf513abc_N2374 | element | 390–390 | element  |
| Sec9dcf513abc_N2388 | Sec9dcf513abc_N2387 | start_tag | 390–390 | start_tag  |
| Sec9dcf513abc_N2389 | Sec9dcf513abc_N2388 | tag_name | 390–390 | span |
| Sec9dcf513abc_N2390 | Sec9dcf513abc_N2388 | attribute | 390–390 | attribute  |
| Sec9dcf513abc_N2391 | Sec9dcf513abc_N2390 | attribute_name | 390–390 | class |
| Sec9dcf513abc_N2392 | Sec9dcf513abc_N2390 | quoted_attribute_value | 390–390 | quoted_attribute_value  |
| Sec9dcf513abc_N2393 | Sec9dcf513abc_N2392 | attribute_value | 390–390 | text-xs font-mono text-celestial-brass block mt-0.5 |
| Sec9dcf513abc_N2394 | Sec9dcf513abc_N2387 | text | 390–390 | Includes interactive conversational reading |
| Sec9dcf513abc_N2395 | Sec9dcf513abc_N2387 | end_tag | 390–390 | end_tag  |
| Sec9dcf513abc_N2396 | Sec9dcf513abc_N2395 | tag_name | 390–390 | span |
| Sec9dcf513abc_N2397 | Sec9dcf513abc_N2374 | end_tag | 391–391 | end_tag  |
| Sec9dcf513abc_N2398 | Sec9dcf513abc_N2397 | tag_name | 391–391 | div |
| Sec9dcf513abc_N2399 | Sec9dcf513abc_N2345 | end_tag | 392–392 | end_tag  |
| Sec9dcf513abc_N2400 | Sec9dcf513abc_N2399 | tag_name | 392–392 | div |
| Sec9dcf513abc_N2401 | Sec9dcf513abc_N2338 | element | 393–393 | element  |
| Sec9dcf513abc_N2402 | Sec9dcf513abc_N2401 | start_tag | 393–393 | start_tag  |
| Sec9dcf513abc_N2403 | Sec9dcf513abc_N2402 | tag_name | 393–393 | span |
| Sec9dcf513abc_N2404 | Sec9dcf513abc_N2402 | attribute | 393–393 | attribute  |
| Sec9dcf513abc_N2405 | Sec9dcf513abc_N2404 | attribute_name | 393–393 | class |
| Sec9dcf513abc_N2406 | Sec9dcf513abc_N2404 | quoted_attribute_value | 393–393 | quoted_attribute_value  |
| Sec9dcf513abc_N2407 | Sec9dcf513abc_N2406 | attribute_value | 393–393 | text-xs font-mono text-celestial-brass |
| Sec9dcf513abc_N2408 | Sec9dcf513abc_N2401 | text | 393–393 | Price shown in checkout |
| Sec9dcf513abc_N2409 | Sec9dcf513abc_N2401 | end_tag | 393–393 | end_tag  |
| Sec9dcf513abc_N2410 | Sec9dcf513abc_N2409 | tag_name | 393–393 | span |
| Sec9dcf513abc_N2411 | Sec9dcf513abc_N2338 | end_tag | 394–394 | end_tag  |
| Sec9dcf513abc_N2412 | Sec9dcf513abc_N2411 | tag_name | 394–394 | div |
| Sec9dcf513abc_N2413 | Sec9dcf513abc_N2321 | element | 395–397 | element  |
| Sec9dcf513abc_N2414 | Sec9dcf513abc_N2413 | start_tag | 395–395 | start_tag  |
| Sec9dcf513abc_N2415 | Sec9dcf513abc_N2414 | tag_name | 395–395 | p |
| Sec9dcf513abc_N2416 | Sec9dcf513abc_N2414 | attribute | 395–395 | attribute  |
| Sec9dcf513abc_N2417 | Sec9dcf513abc_N2416 | attribute_name | 395–395 | class |
| Sec9dcf513abc_N2418 | Sec9dcf513abc_N2416 | quoted_attribute_value | 395–395 | quoted_attribute_value  |
| Sec9dcf513abc_N2419 | Sec9dcf513abc_N2418 | attribute_value | 395–395 | text-xs text-ash mt-3 pl-7 leading-relaxed |
| Sec9dcf513abc_N2420 | Sec9dcf513abc_N2413 | text | 396–396 | The complete 300 DPI archival PDF plus standalone interactive chart web app. Explorable orbital degrees, aspect highlights, and dedicated conversational reading entry. |
| Sec9dcf513abc_N2421 | Sec9dcf513abc_N2413 | end_tag | 397–397 | end_tag  |
| Sec9dcf513abc_N2422 | Sec9dcf513abc_N2421 | tag_name | 397–397 | p |
| Sec9dcf513abc_N2423 | Sec9dcf513abc_N2321 | end_tag | 398–398 | end_tag  |
| Sec9dcf513abc_N2424 | Sec9dcf513abc_N2423 | tag_name | 398–398 | label |
| Sec9dcf513abc_N2425 | Sec9dcf513abc_N2221 | comment | 399–399 | &lt;!-- Tier 3: Bring Natally Home (Upsell) --&gt; |
| Sec9dcf513abc_N2426 | Sec9dcf513abc_N2221 | element | 400–414 | element  |
| Sec9dcf513abc_N2427 | Sec9dcf513abc_N2426 | start_tag | 400–400 | start_tag  |
| Sec9dcf513abc_N2428 | Sec9dcf513abc_N2427 | tag_name | 400–400 | label |
| Sec9dcf513abc_N2429 | Sec9dcf513abc_N2427 | attribute | 400–400 | attribute  |
| Sec9dcf513abc_N2430 | Sec9dcf513abc_N2429 | attribute_name | 400–400 | class |
| Sec9dcf513abc_N2431 | Sec9dcf513abc_N2429 | quoted_attribute_value | 400–400 | quoted_attribute_value  |
| Sec9dcf513abc_N2432 | Sec9dcf513abc_N2431 | attribute_value | 400–400 | p-5 rounded-xl border border-hairline bg-surface-dim block cursor-pointer hover:border-hairline/80 transition-colors |
| Sec9dcf513abc_N2433 | Sec9dcf513abc_N2426 | element | 401–410 | element  |
| Sec9dcf513abc_N2434 | Sec9dcf513abc_N2433 | start_tag | 401–401 | start_tag  |
| Sec9dcf513abc_N2435 | Sec9dcf513abc_N2434 | tag_name | 401–401 | div |
| Sec9dcf513abc_N2436 | Sec9dcf513abc_N2434 | attribute | 401–401 | attribute  |
| Sec9dcf513abc_N2437 | Sec9dcf513abc_N2436 | attribute_name | 401–401 | class |
| Sec9dcf513abc_N2438 | Sec9dcf513abc_N2436 | quoted_attribute_value | 401–401 | quoted_attribute_value  |
| Sec9dcf513abc_N2439 | Sec9dcf513abc_N2438 | attribute_value | 401–401 | flex items-start justify-between |
| Sec9dcf513abc_N2440 | Sec9dcf513abc_N2433 | element | 402–408 | element  |
| Sec9dcf513abc_N2441 | Sec9dcf513abc_N2440 | start_tag | 402–402 | start_tag  |
| Sec9dcf513abc_N2442 | Sec9dcf513abc_N2441 | tag_name | 402–402 | div |
| Sec9dcf513abc_N2443 | Sec9dcf513abc_N2441 | attribute | 402–402 | attribute  |
| Sec9dcf513abc_N2444 | Sec9dcf513abc_N2443 | attribute_name | 402–402 | class |
| Sec9dcf513abc_N2445 | Sec9dcf513abc_N2443 | quoted_attribute_value | 402–402 | quoted_attribute_value  |
| Sec9dcf513abc_N2446 | Sec9dcf513abc_N2445 | attribute_value | 402–402 | flex items-center space-x-3 |
| Sec9dcf513abc_N2447 | Sec9dcf513abc_N2440 | element | 403–403 | element  |
| Sec9dcf513abc_N2448 | Sec9dcf513abc_N2447 | self_closing_tag | 403–403 | self_closing_tag  |
| Sec9dcf513abc_N2449 | Sec9dcf513abc_N2448 | tag_name | 403–403 | input |
| Sec9dcf513abc_N2450 | Sec9dcf513abc_N2448 | attribute | 403–403 | attribute  |
| Sec9dcf513abc_N2451 | Sec9dcf513abc_N2450 | attribute_name | 403–403 | class |
| Sec9dcf513abc_N2452 | Sec9dcf513abc_N2450 | quoted_attribute_value | 403–403 | quoted_attribute_value  |
| Sec9dcf513abc_N2453 | Sec9dcf513abc_N2452 | attribute_value | 403–403 | accent-celestial-brass w-4 h-4 |
| Sec9dcf513abc_N2454 | Sec9dcf513abc_N2448 | attribute | 403–403 | attribute  |
| Sec9dcf513abc_N2455 | Sec9dcf513abc_N2454 | attribute_name | 403–403 | name |
| Sec9dcf513abc_N2456 | Sec9dcf513abc_N2454 | quoted_attribute_value | 403–403 | quoted_attribute_value  |
| Sec9dcf513abc_N2457 | Sec9dcf513abc_N2456 | attribute_value | 403–403 | offer |
| Sec9dcf513abc_N2458 | Sec9dcf513abc_N2448 | attribute | 403–403 | attribute  |
| Sec9dcf513abc_N2459 | Sec9dcf513abc_N2458 | attribute_name | 403–403 | type |
| Sec9dcf513abc_N2460 | Sec9dcf513abc_N2458 | quoted_attribute_value | 403–403 | quoted_attribute_value  |
| Sec9dcf513abc_N2461 | Sec9dcf513abc_N2460 | attribute_value | 403–403 | radio |
| Sec9dcf513abc_N2462 | Sec9dcf513abc_N2448 | attribute | 403–403 | attribute  |
| Sec9dcf513abc_N2463 | Sec9dcf513abc_N2462 | attribute_name | 403–403 | value |
| Sec9dcf513abc_N2464 | Sec9dcf513abc_N2462 | quoted_attribute_value | 403–403 | quoted_attribute_value  |
| Sec9dcf513abc_N2465 | Sec9dcf513abc_N2464 | attribute_value | 403–403 | home |
| Sec9dcf513abc_N2466 | Sec9dcf513abc_N2440 | element | 404–407 | element  |
| Sec9dcf513abc_N2467 | Sec9dcf513abc_N2466 | start_tag | 404–404 | start_tag  |
| Sec9dcf513abc_N2468 | Sec9dcf513abc_N2467 | tag_name | 404–404 | div |
| Sec9dcf513abc_N2469 | Sec9dcf513abc_N2466 | element | 405–405 | element  |
| Sec9dcf513abc_N2470 | Sec9dcf513abc_N2469 | start_tag | 405–405 | start_tag  |
| Sec9dcf513abc_N2471 | Sec9dcf513abc_N2470 | tag_name | 405–405 | span |
| Sec9dcf513abc_N2472 | Sec9dcf513abc_N2470 | attribute | 405–405 | attribute  |
| Sec9dcf513abc_N2473 | Sec9dcf513abc_N2472 | attribute_name | 405–405 | class |
| Sec9dcf513abc_N2474 | Sec9dcf513abc_N2472 | quoted_attribute_value | 405–405 | quoted_attribute_value  |
| Sec9dcf513abc_N2475 | Sec9dcf513abc_N2474 | attribute_value | 405–405 | font-display text-base text-starlight font-medium |
| Sec9dcf513abc_N2476 | Sec9dcf513abc_N2469 | text | 405–405 | Bring Natally home |
| Sec9dcf513abc_N2477 | Sec9dcf513abc_N2469 | end_tag | 405–405 | end_tag  |
| Sec9dcf513abc_N2478 | Sec9dcf513abc_N2477 | tag_name | 405–405 | span |
| Sec9dcf513abc_N2479 | Sec9dcf513abc_N2466 | element | 406–406 | element  |
| Sec9dcf513abc_N2480 | Sec9dcf513abc_N2479 | start_tag | 406–406 | start_tag  |
| Sec9dcf513abc_N2481 | Sec9dcf513abc_N2480 | tag_name | 406–406 | span |
| Sec9dcf513abc_N2482 | Sec9dcf513abc_N2480 | attribute | 406–406 | attribute  |
| Sec9dcf513abc_N2483 | Sec9dcf513abc_N2482 | attribute_name | 406–406 | class |
| Sec9dcf513abc_N2484 | Sec9dcf513abc_N2482 | quoted_attribute_value | 406–406 | quoted_attribute_value  |
| Sec9dcf513abc_N2485 | Sec9dcf513abc_N2484 | attribute_value | 406–406 | text-xs font-mono text-ash block mt-0.5 |
| Sec9dcf513abc_N2486 | Sec9dcf513abc_N2479 | text | 406–406 | Personal Natally SPA experience |
| Sec9dcf513abc_N2487 | Sec9dcf513abc_N2479 | end_tag | 406–406 | end_tag  |
| Sec9dcf513abc_N2488 | Sec9dcf513abc_N2487 | tag_name | 406–406 | span |
| Sec9dcf513abc_N2489 | Sec9dcf513abc_N2466 | end_tag | 407–407 | end_tag  |
| Sec9dcf513abc_N2490 | Sec9dcf513abc_N2489 | tag_name | 407–407 | div |
| Sec9dcf513abc_N2491 | Sec9dcf513abc_N2440 | end_tag | 408–408 | end_tag  |
| Sec9dcf513abc_N2492 | Sec9dcf513abc_N2491 | tag_name | 408–408 | div |
| Sec9dcf513abc_N2493 | Sec9dcf513abc_N2433 | element | 409–409 | element  |
| Sec9dcf513abc_N2494 | Sec9dcf513abc_N2493 | start_tag | 409–409 | start_tag  |
| Sec9dcf513abc_N2495 | Sec9dcf513abc_N2494 | tag_name | 409–409 | span |
| Sec9dcf513abc_N2496 | Sec9dcf513abc_N2494 | attribute | 409–409 | attribute  |
| Sec9dcf513abc_N2497 | Sec9dcf513abc_N2496 | attribute_name | 409–409 | class |
| Sec9dcf513abc_N2498 | Sec9dcf513abc_N2496 | quoted_attribute_value | 409–409 | quoted_attribute_value  |
| Sec9dcf513abc_N2499 | Sec9dcf513abc_N2498 | attribute_value | 409–409 | text-xs font-mono text-celestial-brass |
| Sec9dcf513abc_N2500 | Sec9dcf513abc_N2493 | text | 409–409 | Price shown in checkout |
| Sec9dcf513abc_N2501 | Sec9dcf513abc_N2493 | end_tag | 409–409 | end_tag  |
| Sec9dcf513abc_N2502 | Sec9dcf513abc_N2501 | tag_name | 409–409 | span |
| Sec9dcf513abc_N2503 | Sec9dcf513abc_N2433 | end_tag | 410–410 | end_tag  |
| Sec9dcf513abc_N2504 | Sec9dcf513abc_N2503 | tag_name | 410–410 | div |
| Sec9dcf513abc_N2505 | Sec9dcf513abc_N2426 | element | 411–413 | element  |
| Sec9dcf513abc_N2506 | Sec9dcf513abc_N2505 | start_tag | 411–411 | start_tag  |
| Sec9dcf513abc_N2507 | Sec9dcf513abc_N2506 | tag_name | 411–411 | p |
| Sec9dcf513abc_N2508 | Sec9dcf513abc_N2506 | attribute | 411–411 | attribute  |
| Sec9dcf513abc_N2509 | Sec9dcf513abc_N2508 | attribute_name | 411–411 | class |
| Sec9dcf513abc_N2510 | Sec9dcf513abc_N2508 | quoted_attribute_value | 411–411 | quoted_attribute_value  |
| Sec9dcf513abc_N2511 | Sec9dcf513abc_N2510 | attribute_value | 411–411 | text-xs text-ash mt-3 pl-7 leading-relaxed |
| Sec9dcf513abc_N2512 | Sec9dcf513abc_N2505 | text | 412–412 | Attuned standalone client environment for quiet ongoing reflection. Does not imply unlimited server inference, permanent hosting, or fixed turn allowance. |
| Sec9dcf513abc_N2513 | Sec9dcf513abc_N2505 | end_tag | 413–413 | end_tag  |
| Sec9dcf513abc_N2514 | Sec9dcf513abc_N2513 | tag_name | 413–413 | p |
| Sec9dcf513abc_N2515 | Sec9dcf513abc_N2426 | end_tag | 414–414 | end_tag  |
| Sec9dcf513abc_N2516 | Sec9dcf513abc_N2515 | tag_name | 414–414 | label |
| Sec9dcf513abc_N2517 | Sec9dcf513abc_N2221 | end_tag | 415–415 | end_tag  |
| Sec9dcf513abc_N2518 | Sec9dcf513abc_N2517 | tag_name | 415–415 | div |
| Sec9dcf513abc_N2519 | Sec9dcf513abc_N2147 | comment | 416–416 | &lt;!-- Checkout &amp; Recovery Controls --&gt; |
| Sec9dcf513abc_N2520 | Sec9dcf513abc_N2147 | element | 417–424 | element  |
| Sec9dcf513abc_N2521 | Sec9dcf513abc_N2520 | start_tag | 417–417 | start_tag  |
| Sec9dcf513abc_N2522 | Sec9dcf513abc_N2521 | tag_name | 417–417 | div |
| Sec9dcf513abc_N2523 | Sec9dcf513abc_N2521 | attribute | 417–417 | attribute  |
| Sec9dcf513abc_N2524 | Sec9dcf513abc_N2523 | attribute_name | 417–417 | class |
| Sec9dcf513abc_N2525 | Sec9dcf513abc_N2523 | quoted_attribute_value | 417–417 | quoted_attribute_value  |
| Sec9dcf513abc_N2526 | Sec9dcf513abc_N2525 | attribute_value | 417–417 | pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 |
| Sec9dcf513abc_N2527 | Sec9dcf513abc_N2520 | element | 418–420 | element  |
| Sec9dcf513abc_N2528 | Sec9dcf513abc_N2527 | start_tag | 418–418 | start_tag  |
| Sec9dcf513abc_N2529 | Sec9dcf513abc_N2528 | tag_name | 418–418 | button |
| Sec9dcf513abc_N2530 | Sec9dcf513abc_N2528 | attribute | 418–418 | attribute  |
| Sec9dcf513abc_N2531 | Sec9dcf513abc_N2530 | attribute_name | 418–418 | class |
| Sec9dcf513abc_N2532 | Sec9dcf513abc_N2530 | quoted_attribute_value | 418–418 | quoted_attribute_value  |
| Sec9dcf513abc_N2533 | Sec9dcf513abc_N2532 | attribute_value | 418–418 | w-full sm:w-auto py-3 px-8 rounded-lg bg-celestial-brass text-observatory font-semibold text-sm hover:bg-celestial-brass-hover transition-colors |
| Sec9dcf513abc_N2534 | Sec9dcf513abc_N2528 | attribute | 418–418 | attribute  |
| Sec9dcf513abc_N2535 | Sec9dcf513abc_N2534 | attribute_name | 418–418 | id |
| Sec9dcf513abc_N2536 | Sec9dcf513abc_N2534 | quoted_attribute_value | 418–418 | quoted_attribute_value  |
| Sec9dcf513abc_N2537 | Sec9dcf513abc_N2536 | attribute_value | 418–418 | buy-reading |
| Sec9dcf513abc_N2538 | Sec9dcf513abc_N2528 | attribute | 418–418 | attribute  |
| Sec9dcf513abc_N2539 | Sec9dcf513abc_N2538 | attribute_name | 418–418 | onclick |
| Sec9dcf513abc_N2540 | Sec9dcf513abc_N2538 | quoted_attribute_value | 418–418 | quoted_attribute_value  |
| Sec9dcf513abc_N2541 | Sec9dcf513abc_N2540 | attribute_value | 418–418 | simulateQuoteNotice('Proceeding to checkout preview. Live settlement and RevenueCat billing account creation are server-authoritative; no payment is taken.') |
| Sec9dcf513abc_N2542 | Sec9dcf513abc_N2527 | text | 419–419 | Continue to secure checkout → |
| Sec9dcf513abc_N2543 | Sec9dcf513abc_N2527 | end_tag | 420–420 | end_tag  |
| Sec9dcf513abc_N2544 | Sec9dcf513abc_N2543 | tag_name | 420–420 | button |
| Sec9dcf513abc_N2545 | Sec9dcf513abc_N2520 | element | 421–423 | element  |
| Sec9dcf513abc_N2546 | Sec9dcf513abc_N2545 | start_tag | 421–421 | start_tag  |
| Sec9dcf513abc_N2547 | Sec9dcf513abc_N2546 | tag_name | 421–421 | button |
| Sec9dcf513abc_N2548 | Sec9dcf513abc_N2546 | attribute | 421–421 | attribute  |
| Sec9dcf513abc_N2549 | Sec9dcf513abc_N2548 | attribute_name | 421–421 | class |
| Sec9dcf513abc_N2550 | Sec9dcf513abc_N2548 | quoted_attribute_value | 421–421 | quoted_attribute_value  |
| Sec9dcf513abc_N2551 | Sec9dcf513abc_N2550 | attribute_value | 421–421 | text-xs font-mono text-ash hover:text-celestial-brass underline underline-offset-4 |
| Sec9dcf513abc_N2552 | Sec9dcf513abc_N2546 | attribute | 421–421 | attribute  |
| Sec9dcf513abc_N2553 | Sec9dcf513abc_N2552 | attribute_name | 421–421 | id |
| Sec9dcf513abc_N2554 | Sec9dcf513abc_N2552 | quoted_attribute_value | 421–421 | quoted_attribute_value  |
| Sec9dcf513abc_N2555 | Sec9dcf513abc_N2554 | attribute_value | 421–421 | restore-purchases |
| Sec9dcf513abc_N2556 | Sec9dcf513abc_N2546 | attribute | 421–421 | attribute  |
| Sec9dcf513abc_N2557 | Sec9dcf513abc_N2556 | attribute_name | 421–421 | onclick |
| Sec9dcf513abc_N2558 | Sec9dcf513abc_N2556 | quoted_attribute_value | 421–421 | quoted_attribute_value  |
| Sec9dcf513abc_N2559 | Sec9dcf513abc_N2558 | attribute_value | 421–421 | simulateQuoteNotice('Querying purchase receipts via RevenueCat API stub. No historical entitlement restored in this unauthenticated design branch.') |
| Sec9dcf513abc_N2560 | Sec9dcf513abc_N2545 | text | 422–422 | Restore existing purchases |
| Sec9dcf513abc_N2561 | Sec9dcf513abc_N2545 | end_tag | 423–423 | end_tag  |
| Sec9dcf513abc_N2562 | Sec9dcf513abc_N2561 | tag_name | 423–423 | button |
| Sec9dcf513abc_N2563 | Sec9dcf513abc_N2520 | end_tag | 424–424 | end_tag  |
| Sec9dcf513abc_N2564 | Sec9dcf513abc_N2563 | tag_name | 424–424 | div |
| Sec9dcf513abc_N2565 | Sec9dcf513abc_N2147 | end_tag | 425–425 | end_tag  |
| Sec9dcf513abc_N2566 | Sec9dcf513abc_N2565 | tag_name | 425–425 | div |
| Sec9dcf513abc_N2567 | Sec9dcf513abc_N1194 | comment | 426–426 | &lt;!-- SECTION 5: BILLING &amp; RECEIPTS --&gt; |
| Sec9dcf513abc_N2568 | Sec9dcf513abc_N1194 | element | 427–464 | element  |
| Sec9dcf513abc_N2569 | Sec9dcf513abc_N2568 | start_tag | 427–427 | start_tag  |
| Sec9dcf513abc_N2570 | Sec9dcf513abc_N2569 | tag_name | 427–427 | div |
| Sec9dcf513abc_N2571 | Sec9dcf513abc_N2569 | attribute | 427–427 | attribute  |
| Sec9dcf513abc_N2572 | Sec9dcf513abc_N2571 | attribute_name | 427–427 | class |
| Sec9dcf513abc_N2573 | Sec9dcf513abc_N2571 | quoted_attribute_value | 427–427 | quoted_attribute_value  |
| Sec9dcf513abc_N2574 | Sec9dcf513abc_N2573 | attribute_value | 427–427 | view-section space-y-6 |
| Sec9dcf513abc_N2575 | Sec9dcf513abc_N2569 | attribute | 427–427 | attribute  |
| Sec9dcf513abc_N2576 | Sec9dcf513abc_N2575 | attribute_name | 427–427 | data-view |
| Sec9dcf513abc_N2577 | Sec9dcf513abc_N2575 | quoted_attribute_value | 427–427 | quoted_attribute_value  |
| Sec9dcf513abc_N2578 | Sec9dcf513abc_N2577 | attribute_value | 427–427 | billing |
| Sec9dcf513abc_N2579 | Sec9dcf513abc_N2569 | attribute | 427–427 | attribute  |
| Sec9dcf513abc_N2580 | Sec9dcf513abc_N2579 | attribute_name | 427–427 | id |
| Sec9dcf513abc_N2581 | Sec9dcf513abc_N2579 | quoted_attribute_value | 427–427 | quoted_attribute_value  |
| Sec9dcf513abc_N2582 | Sec9dcf513abc_N2581 | attribute_value | 427–427 | section-billing |
| Sec9dcf513abc_N2583 | Sec9dcf513abc_N2568 | element | 428–434 | element  |
| Sec9dcf513abc_N2584 | Sec9dcf513abc_N2583 | start_tag | 428–428 | start_tag  |
| Sec9dcf513abc_N2585 | Sec9dcf513abc_N2584 | tag_name | 428–428 | div |
| Sec9dcf513abc_N2586 | Sec9dcf513abc_N2584 | attribute | 428–428 | attribute  |
| Sec9dcf513abc_N2587 | Sec9dcf513abc_N2586 | attribute_name | 428–428 | class |
| Sec9dcf513abc_N2588 | Sec9dcf513abc_N2586 | quoted_attribute_value | 428–428 | quoted_attribute_value  |
| Sec9dcf513abc_N2589 | Sec9dcf513abc_N2588 | attribute_value | 428–428 | border-b border-hairline/80 pb-4 flex items-center justify-between |
| Sec9dcf513abc_N2590 | Sec9dcf513abc_N2583 | element | 429–432 | element  |
| Sec9dcf513abc_N2591 | Sec9dcf513abc_N2590 | start_tag | 429–429 | start_tag  |
| Sec9dcf513abc_N2592 | Sec9dcf513abc_N2591 | tag_name | 429–429 | div |
| Sec9dcf513abc_N2593 | Sec9dcf513abc_N2590 | element | 430–430 | element  |
| Sec9dcf513abc_N2594 | Sec9dcf513abc_N2593 | start_tag | 430–430 | start_tag  |
| Sec9dcf513abc_N2595 | Sec9dcf513abc_N2594 | tag_name | 430–430 | span |
| Sec9dcf513abc_N2596 | Sec9dcf513abc_N2594 | attribute | 430–430 | attribute  |
| Sec9dcf513abc_N2597 | Sec9dcf513abc_N2596 | attribute_name | 430–430 | class |
| Sec9dcf513abc_N2598 | Sec9dcf513abc_N2596 | quoted_attribute_value | 430–430 | quoted_attribute_value  |
| Sec9dcf513abc_N2599 | Sec9dcf513abc_N2598 | attribute_value | 430–430 | text-xs font-mono text-celestial-brass uppercase tracking-wider |
| Sec9dcf513abc_N2600 | Sec9dcf513abc_N2593 | text | 430–430 | Account Records |
| Sec9dcf513abc_N2601 | Sec9dcf513abc_N2593 | end_tag | 430–430 | end_tag  |
| Sec9dcf513abc_N2602 | Sec9dcf513abc_N2601 | tag_name | 430–430 | span |
| Sec9dcf513abc_N2603 | Sec9dcf513abc_N2590 | element | 431–431 | element  |
| Sec9dcf513abc_N2604 | Sec9dcf513abc_N2603 | start_tag | 431–431 | start_tag  |
| Sec9dcf513abc_N2605 | Sec9dcf513abc_N2604 | tag_name | 431–431 | h1 |
| Sec9dcf513abc_N2606 | Sec9dcf513abc_N2604 | attribute | 431–431 | attribute  |
| Sec9dcf513abc_N2607 | Sec9dcf513abc_N2606 | attribute_name | 431–431 | class |
| Sec9dcf513abc_N2608 | Sec9dcf513abc_N2606 | quoted_attribute_value | 431–431 | quoted_attribute_value  |
| Sec9dcf513abc_N2609 | Sec9dcf513abc_N2608 | attribute_value | 431–431 | font-display text-2xl font-normal text-starlight mt-1 |
| Sec9dcf513abc_N2610 | Sec9dcf513abc_N2603 | text | 431–431 | Billing |
| Sec9dcf513abc_N2611 | Sec9dcf513abc_N2603 | entity | 431–431 | &amp;amp; |
| Sec9dcf513abc_N2612 | Sec9dcf513abc_N2603 | text | 431–431 | Receipts |
| Sec9dcf513abc_N2613 | Sec9dcf513abc_N2603 | end_tag | 431–431 | end_tag  |
| Sec9dcf513abc_N2614 | Sec9dcf513abc_N2613 | tag_name | 431–431 | h1 |
| Sec9dcf513abc_N2615 | Sec9dcf513abc_N2590 | end_tag | 432–432 | end_tag  |
| Sec9dcf513abc_N2616 | Sec9dcf513abc_N2615 | tag_name | 432–432 | div |
| Sec9dcf513abc_N2617 | Sec9dcf513abc_N2583 | element | 433–433 | element  |
| Sec9dcf513abc_N2618 | Sec9dcf513abc_N2617 | start_tag | 433–433 | start_tag  |
| Sec9dcf513abc_N2619 | Sec9dcf513abc_N2618 | tag_name | 433–433 | button |
| Sec9dcf513abc_N2620 | Sec9dcf513abc_N2618 | attribute | 433–433 | attribute  |
| Sec9dcf513abc_N2621 | Sec9dcf513abc_N2620 | attribute_name | 433–433 | class |
| Sec9dcf513abc_N2622 | Sec9dcf513abc_N2620 | quoted_attribute_value | 433–433 | quoted_attribute_value  |
| Sec9dcf513abc_N2623 | Sec9dcf513abc_N2622 | attribute_value | 433–433 | text-xs font-mono text-ash hover:text-starlight |
| Sec9dcf513abc_N2624 | Sec9dcf513abc_N2618 | attribute | 433–433 | attribute  |
| Sec9dcf513abc_N2625 | Sec9dcf513abc_N2624 | attribute_name | 433–433 | onclick |
| Sec9dcf513abc_N2626 | Sec9dcf513abc_N2624 | quoted_attribute_value | 433–433 | quoted_attribute_value  |
| Sec9dcf513abc_N2627 | Sec9dcf513abc_N2626 | attribute_value | 433–433 | switchView('profile') |
| Sec9dcf513abc_N2628 | Sec9dcf513abc_N2617 | text | 433–433 | ← Return to Profile |
| Sec9dcf513abc_N2629 | Sec9dcf513abc_N2617 | end_tag | 433–433 | end_tag  |
| Sec9dcf513abc_N2630 | Sec9dcf513abc_N2629 | tag_name | 433–433 | button |
| Sec9dcf513abc_N2631 | Sec9dcf513abc_N2583 | end_tag | 434–434 | end_tag  |
| Sec9dcf513abc_N2632 | Sec9dcf513abc_N2631 | tag_name | 434–434 | div |
| Sec9dcf513abc_N2633 | Sec9dcf513abc_N2568 | comment | 435–435 | &lt;!-- Billing Portal Integration Card --&gt; |
| Sec9dcf513abc_N2634 | Sec9dcf513abc_N2568 | element | 436–446 | element  |
| Sec9dcf513abc_N2635 | Sec9dcf513abc_N2634 | start_tag | 436–436 | start_tag  |
| Sec9dcf513abc_N2636 | Sec9dcf513abc_N2635 | tag_name | 436–436 | div |
| Sec9dcf513abc_N2637 | Sec9dcf513abc_N2635 | attribute | 436–436 | attribute  |
| Sec9dcf513abc_N2638 | Sec9dcf513abc_N2637 | attribute_name | 436–436 | class |
| Sec9dcf513abc_N2639 | Sec9dcf513abc_N2637 | quoted_attribute_value | 436–436 | quoted_attribute_value  |
| Sec9dcf513abc_N2640 | Sec9dcf513abc_N2639 | attribute_value | 436–436 | p-6 rounded-xl border border-hairline bg-surface-dim space-y-4 |
| Sec9dcf513abc_N2641 | Sec9dcf513abc_N2634 | element | 437–445 | element  |
| Sec9dcf513abc_N2642 | Sec9dcf513abc_N2641 | start_tag | 437–437 | start_tag  |
| Sec9dcf513abc_N2643 | Sec9dcf513abc_N2642 | tag_name | 437–437 | div |
| Sec9dcf513abc_N2644 | Sec9dcf513abc_N2642 | attribute | 437–437 | attribute  |
| Sec9dcf513abc_N2645 | Sec9dcf513abc_N2644 | attribute_name | 437–437 | class |
| Sec9dcf513abc_N2646 | Sec9dcf513abc_N2644 | quoted_attribute_value | 437–437 | quoted_attribute_value  |
| Sec9dcf513abc_N2647 | Sec9dcf513abc_N2646 | attribute_value | 437–437 | flex flex-col sm:flex-row sm:items-center justify-between gap-3 |
| Sec9dcf513abc_N2648 | Sec9dcf513abc_N2641 | element | 438–441 | element  |
| Sec9dcf513abc_N2649 | Sec9dcf513abc_N2648 | start_tag | 438–438 | start_tag  |
| Sec9dcf513abc_N2650 | Sec9dcf513abc_N2649 | tag_name | 438–438 | div |
| Sec9dcf513abc_N2651 | Sec9dcf513abc_N2648 | element | 439–439 | element  |
| Sec9dcf513abc_N2652 | Sec9dcf513abc_N2651 | start_tag | 439–439 | start_tag  |
| Sec9dcf513abc_N2653 | Sec9dcf513abc_N2652 | tag_name | 439–439 | h2 |
| Sec9dcf513abc_N2654 | Sec9dcf513abc_N2652 | attribute | 439–439 | attribute  |
| Sec9dcf513abc_N2655 | Sec9dcf513abc_N2654 | attribute_name | 439–439 | class |
| Sec9dcf513abc_N2656 | Sec9dcf513abc_N2654 | quoted_attribute_value | 439–439 | quoted_attribute_value  |
| Sec9dcf513abc_N2657 | Sec9dcf513abc_N2656 | attribute_value | 439–439 | font-display text-lg text-starlight |
| Sec9dcf513abc_N2658 | Sec9dcf513abc_N2651 | text | 439–439 | Customer Billing Portal |
| Sec9dcf513abc_N2659 | Sec9dcf513abc_N2651 | end_tag | 439–439 | end_tag  |
| Sec9dcf513abc_N2660 | Sec9dcf513abc_N2659 | tag_name | 439–439 | h2 |
| Sec9dcf513abc_N2661 | Sec9dcf513abc_N2648 | element | 440–440 | element  |
| Sec9dcf513abc_N2662 | Sec9dcf513abc_N2661 | start_tag | 440–440 | start_tag  |
| Sec9dcf513abc_N2663 | Sec9dcf513abc_N2662 | tag_name | 440–440 | p |
| Sec9dcf513abc_N2664 | Sec9dcf513abc_N2662 | attribute | 440–440 | attribute  |
| Sec9dcf513abc_N2665 | Sec9dcf513abc_N2664 | attribute_name | 440–440 | class |
| Sec9dcf513abc_N2666 | Sec9dcf513abc_N2664 | quoted_attribute_value | 440–440 | quoted_attribute_value  |
| Sec9dcf513abc_N2667 | Sec9dcf513abc_N2666 | attribute_value | 440–440 | text-xs text-ash mt-0.5 |
| Sec9dcf513abc_N2668 | Sec9dcf513abc_N2661 | text | 440–440 | Manage payment methods, vat details, and download formal tax receipts. |
| Sec9dcf513abc_N2669 | Sec9dcf513abc_N2661 | end_tag | 440–440 | end_tag  |
| Sec9dcf513abc_N2670 | Sec9dcf513abc_N2669 | tag_name | 440–440 | p |
| Sec9dcf513abc_N2671 | Sec9dcf513abc_N2648 | end_tag | 441–441 | end_tag  |
| Sec9dcf513abc_N2672 | Sec9dcf513abc_N2671 | tag_name | 441–441 | div |
| Sec9dcf513abc_N2673 | Sec9dcf513abc_N2641 | element | 442–444 | element  |
| Sec9dcf513abc_N2674 | Sec9dcf513abc_N2673 | start_tag | 442–442 | start_tag  |
| Sec9dcf513abc_N2675 | Sec9dcf513abc_N2674 | tag_name | 442–442 | button |
| Sec9dcf513abc_N2676 | Sec9dcf513abc_N2674 | attribute | 442–442 | attribute  |
| Sec9dcf513abc_N2677 | Sec9dcf513abc_N2676 | attribute_name | 442–442 | class |
| Sec9dcf513abc_N2678 | Sec9dcf513abc_N2676 | quoted_attribute_value | 442–442 | quoted_attribute_value  |
| Sec9dcf513abc_N2679 | Sec9dcf513abc_N2678 | attribute_value | 442–442 | py-2 px-4 rounded-lg border border-celestial-brass text-celestial-brass text-xs font-mono hover:bg-celestial-brass/10 transition-colors |
| Sec9dcf513abc_N2680 | Sec9dcf513abc_N2674 | attribute | 442–442 | attribute  |
| Sec9dcf513abc_N2681 | Sec9dcf513abc_N2680 | attribute_name | 442–442 | id |
| Sec9dcf513abc_N2682 | Sec9dcf513abc_N2680 | quoted_attribute_value | 442–442 | quoted_attribute_value  |
| Sec9dcf513abc_N2683 | Sec9dcf513abc_N2682 | attribute_value | 442–442 | open-billing-portal |
| Sec9dcf513abc_N2684 | Sec9dcf513abc_N2674 | attribute | 442–442 | attribute  |
| Sec9dcf513abc_N2685 | Sec9dcf513abc_N2684 | attribute_name | 442–442 | onclick |
| Sec9dcf513abc_N2686 | Sec9dcf513abc_N2684 | quoted_attribute_value | 442–442 | quoted_attribute_value  |
| Sec9dcf513abc_N2687 | Sec9dcf513abc_N2686 | attribute_value | 442–442 | simulateQuoteNotice('Customer billing portal would open authenticated RevenueCat management link. Payments are not connected on this preview branch.') |
| Sec9dcf513abc_N2688 | Sec9dcf513abc_N2673 | text | 443–443 | Launch billing portal → |
| Sec9dcf513abc_N2689 | Sec9dcf513abc_N2673 | end_tag | 444–444 | end_tag  |
| Sec9dcf513abc_N2690 | Sec9dcf513abc_N2689 | tag_name | 444–444 | button |
| Sec9dcf513abc_N2691 | Sec9dcf513abc_N2641 | end_tag | 445–445 | end_tag  |
| Sec9dcf513abc_N2692 | Sec9dcf513abc_N2691 | tag_name | 445–445 | div |
| Sec9dcf513abc_N2693 | Sec9dcf513abc_N2634 | end_tag | 446–446 | end_tag  |
| Sec9dcf513abc_N2694 | Sec9dcf513abc_N2693 | tag_name | 446–446 | div |
| Sec9dcf513abc_N2695 | Sec9dcf513abc_N2568 | comment | 447–447 | &lt;!-- Empty Receipts List --&gt; |
| Sec9dcf513abc_N2696 | Sec9dcf513abc_N2568 | element | 448–456 | element  |
| Sec9dcf513abc_N2697 | Sec9dcf513abc_N2696 | start_tag | 448–448 | start_tag  |
| Sec9dcf513abc_N2698 | Sec9dcf513abc_N2697 | tag_name | 448–448 | div |
| Sec9dcf513abc_N2699 | Sec9dcf513abc_N2697 | attribute | 448–448 | attribute  |
| Sec9dcf513abc_N2700 | Sec9dcf513abc_N2699 | attribute_name | 448–448 | class |
| Sec9dcf513abc_N2701 | Sec9dcf513abc_N2699 | quoted_attribute_value | 448–448 | quoted_attribute_value  |
| Sec9dcf513abc_N2702 | Sec9dcf513abc_N2701 | attribute_value | 448–448 | space-y-3 |
| Sec9dcf513abc_N2703 | Sec9dcf513abc_N2696 | element | 449–449 | element  |
| Sec9dcf513abc_N2704 | Sec9dcf513abc_N2703 | start_tag | 449–449 | start_tag  |
| Sec9dcf513abc_N2705 | Sec9dcf513abc_N2704 | tag_name | 449–449 | h3 |
| Sec9dcf513abc_N2706 | Sec9dcf513abc_N2704 | attribute | 449–449 | attribute  |
| Sec9dcf513abc_N2707 | Sec9dcf513abc_N2706 | attribute_name | 449–449 | class |
| Sec9dcf513abc_N2708 | Sec9dcf513abc_N2706 | quoted_attribute_value | 449–449 | quoted_attribute_value  |
| Sec9dcf513abc_N2709 | Sec9dcf513abc_N2708 | attribute_value | 449–449 | text-xs font-mono uppercase text-ash tracking-wider |
| Sec9dcf513abc_N2710 | Sec9dcf513abc_N2703 | text | 449–449 | Purchase History |
| Sec9dcf513abc_N2711 | Sec9dcf513abc_N2703 | entity | 449–449 | &amp;amp; |
| Sec9dcf513abc_N2712 | Sec9dcf513abc_N2703 | text | 449–449 | Settlement Proofs |
| Sec9dcf513abc_N2713 | Sec9dcf513abc_N2703 | end_tag | 449–449 | end_tag  |
| Sec9dcf513abc_N2714 | Sec9dcf513abc_N2713 | tag_name | 449–449 | h3 |
| Sec9dcf513abc_N2715 | Sec9dcf513abc_N2696 | element | 450–455 | element  |
| Sec9dcf513abc_N2716 | Sec9dcf513abc_N2715 | start_tag | 450–450 | start_tag  |
| Sec9dcf513abc_N2717 | Sec9dcf513abc_N2716 | tag_name | 450–450 | div |
| Sec9dcf513abc_N2718 | Sec9dcf513abc_N2716 | attribute | 450–450 | attribute  |
| Sec9dcf513abc_N2719 | Sec9dcf513abc_N2718 | attribute_name | 450–450 | class |
| Sec9dcf513abc_N2720 | Sec9dcf513abc_N2718 | quoted_attribute_value | 450–450 | quoted_attribute_value  |
| Sec9dcf513abc_N2721 | Sec9dcf513abc_N2720 | attribute_value | 450–450 | p-8 rounded-xl border border-hairline bg-surface-dim/40 text-center space-y-2 |
| Sec9dcf513abc_N2722 | Sec9dcf513abc_N2715 | element | 451–451 | element  |
| Sec9dcf513abc_N2723 | Sec9dcf513abc_N2722 | start_tag | 451–451 | start_tag  |
| Sec9dcf513abc_N2724 | Sec9dcf513abc_N2723 | tag_name | 451–451 | span |
| Sec9dcf513abc_N2725 | Sec9dcf513abc_N2723 | attribute | 451–451 | attribute  |
| Sec9dcf513abc_N2726 | Sec9dcf513abc_N2725 | attribute_name | 451–451 | class |
| Sec9dcf513abc_N2727 | Sec9dcf513abc_N2725 | quoted_attribute_value | 451–451 | quoted_attribute_value  |
| Sec9dcf513abc_N2728 | Sec9dcf513abc_N2727 | attribute_value | 451–451 | font-mono text-ash text-xs |
| Sec9dcf513abc_N2729 | Sec9dcf513abc_N2722 | text | 451–451 | No active orders or receipts on this unconfigured preview. |
| Sec9dcf513abc_N2730 | Sec9dcf513abc_N2722 | end_tag | 451–451 | end_tag  |
| Sec9dcf513abc_N2731 | Sec9dcf513abc_N2730 | tag_name | 451–451 | span |
| Sec9dcf513abc_N2732 | Sec9dcf513abc_N2715 | element | 452–454 | element  |
| Sec9dcf513abc_N2733 | Sec9dcf513abc_N2732 | start_tag | 452–452 | start_tag  |
| Sec9dcf513abc_N2734 | Sec9dcf513abc_N2733 | tag_name | 452–452 | p |
| Sec9dcf513abc_N2735 | Sec9dcf513abc_N2733 | attribute | 452–452 | attribute  |
| Sec9dcf513abc_N2736 | Sec9dcf513abc_N2735 | attribute_name | 452–452 | class |
| Sec9dcf513abc_N2737 | Sec9dcf513abc_N2735 | quoted_attribute_value | 452–452 | quoted_attribute_value  |
| Sec9dcf513abc_N2738 | Sec9dcf513abc_N2737 | attribute_value | 452–452 | text-[11px] text-ash/80 max-w-sm mx-auto |
| Sec9dcf513abc_N2739 | Sec9dcf513abc_N2732 | text | 453–453 | Orders remain server-authoritative; design screens never state that payment is confirmed without live confirmation. |
| Sec9dcf513abc_N2740 | Sec9dcf513abc_N2732 | end_tag | 454–454 | end_tag  |
| Sec9dcf513abc_N2741 | Sec9dcf513abc_N2740 | tag_name | 454–454 | p |
| Sec9dcf513abc_N2742 | Sec9dcf513abc_N2715 | end_tag | 455–455 | end_tag  |
| Sec9dcf513abc_N2743 | Sec9dcf513abc_N2742 | tag_name | 455–455 | div |
| Sec9dcf513abc_N2744 | Sec9dcf513abc_N2696 | end_tag | 456–456 | end_tag  |
| Sec9dcf513abc_N2745 | Sec9dcf513abc_N2744 | tag_name | 456–456 | div |
| Sec9dcf513abc_N2746 | Sec9dcf513abc_N2568 | comment | 457–457 | &lt;!-- Refund &amp; Recovery Guidance --&gt; |
| Sec9dcf513abc_N2747 | Sec9dcf513abc_N2568 | element | 458–463 | element  |
| Sec9dcf513abc_N2748 | Sec9dcf513abc_N2747 | start_tag | 458–458 | start_tag  |
| Sec9dcf513abc_N2749 | Sec9dcf513abc_N2748 | tag_name | 458–458 | div |
| Sec9dcf513abc_N2750 | Sec9dcf513abc_N2748 | attribute | 458–458 | attribute  |
| Sec9dcf513abc_N2751 | Sec9dcf513abc_N2750 | attribute_name | 458–458 | class |
| Sec9dcf513abc_N2752 | Sec9dcf513abc_N2750 | quoted_attribute_value | 458–458 | quoted_attribute_value  |
| Sec9dcf513abc_N2753 | Sec9dcf513abc_N2752 | attribute_value | 458–458 | p-4 rounded-xl border border-hairline/60 bg-surface-dim text-xs text-ash space-y-1.5 |
| Sec9dcf513abc_N2754 | Sec9dcf513abc_N2747 | element | 459–459 | element  |
| Sec9dcf513abc_N2755 | Sec9dcf513abc_N2754 | start_tag | 459–459 | start_tag  |
| Sec9dcf513abc_N2756 | Sec9dcf513abc_N2755 | tag_name | 459–459 | span |
| Sec9dcf513abc_N2757 | Sec9dcf513abc_N2755 | attribute | 459–459 | attribute  |
| Sec9dcf513abc_N2758 | Sec9dcf513abc_N2757 | attribute_name | 459–459 | class |
| Sec9dcf513abc_N2759 | Sec9dcf513abc_N2757 | quoted_attribute_value | 459–459 | quoted_attribute_value  |
| Sec9dcf513abc_N2760 | Sec9dcf513abc_N2759 | attribute_value | 459–459 | font-mono text-starlight font-semibold block |
| Sec9dcf513abc_N2761 | Sec9dcf513abc_N2754 | text | 459–459 | Order Recovery |
| Sec9dcf513abc_N2762 | Sec9dcf513abc_N2754 | entity | 459–459 | &amp;amp; |
| Sec9dcf513abc_N2763 | Sec9dcf513abc_N2754 | text | 459–459 | Dispute Policy |
| Sec9dcf513abc_N2764 | Sec9dcf513abc_N2754 | end_tag | 459–459 | end_tag  |
| Sec9dcf513abc_N2765 | Sec9dcf513abc_N2764 | tag_name | 459–459 | span |
| Sec9dcf513abc_N2766 | Sec9dcf513abc_N2747 | element | 460–462 | element  |
| Sec9dcf513abc_N2767 | Sec9dcf513abc_N2766 | start_tag | 460–460 | start_tag  |
| Sec9dcf513abc_N2768 | Sec9dcf513abc_N2767 | tag_name | 460–460 | p |
| Sec9dcf513abc_N2769 | Sec9dcf513abc_N2767 | attribute | 460–460 | attribute  |
| Sec9dcf513abc_N2770 | Sec9dcf513abc_N2769 | attribute_name | 460–460 | class |
| Sec9dcf513abc_N2771 | Sec9dcf513abc_N2769 | quoted_attribute_value | 460–460 | quoted_attribute_value  |
| Sec9dcf513abc_N2772 | Sec9dcf513abc_N2771 | attribute_value | 460–460 | leading-relaxed |
| Sec9dcf513abc_N2773 | Sec9dcf513abc_N2766 | text | 461–461 | If an order was settled but files were not downloaded, do not pay again. Use order recovery with your reference identifier to resume access. Refund management is deferred to the billing administrator. |
| Sec9dcf513abc_N2774 | Sec9dcf513abc_N2766 | end_tag | 462–462 | end_tag  |
| Sec9dcf513abc_N2775 | Sec9dcf513abc_N2774 | tag_name | 462–462 | p |
| Sec9dcf513abc_N2776 | Sec9dcf513abc_N2747 | end_tag | 463–463 | end_tag  |
| Sec9dcf513abc_N2777 | Sec9dcf513abc_N2776 | tag_name | 463–463 | div |
| Sec9dcf513abc_N2778 | Sec9dcf513abc_N2568 | end_tag | 464–464 | end_tag  |
| Sec9dcf513abc_N2779 | Sec9dcf513abc_N2778 | tag_name | 464–464 | div |
| Sec9dcf513abc_N2780 | Sec9dcf513abc_N1194 | comment | 465–465 | &lt;!-- SECTION 6: ALBY MARKETPLACE (Per-Turn Reading) --&gt; |
| Sec9dcf513abc_N2781 | Sec9dcf513abc_N1194 | element | 466–520 | element  |
| Sec9dcf513abc_N2782 | Sec9dcf513abc_N2781 | start_tag | 466–466 | start_tag  |
| Sec9dcf513abc_N2783 | Sec9dcf513abc_N2782 | tag_name | 466–466 | div |
| Sec9dcf513abc_N2784 | Sec9dcf513abc_N2782 | attribute | 466–466 | attribute  |
| Sec9dcf513abc_N2785 | Sec9dcf513abc_N2784 | attribute_name | 466–466 | class |
| Sec9dcf513abc_N2786 | Sec9dcf513abc_N2784 | quoted_attribute_value | 466–466 | quoted_attribute_value  |
| Sec9dcf513abc_N2787 | Sec9dcf513abc_N2786 | attribute_value | 466–466 | view-section space-y-6 |
| Sec9dcf513abc_N2788 | Sec9dcf513abc_N2782 | attribute | 466–466 | attribute  |
| Sec9dcf513abc_N2789 | Sec9dcf513abc_N2788 | attribute_name | 466–466 | data-view |
| Sec9dcf513abc_N2790 | Sec9dcf513abc_N2788 | quoted_attribute_value | 466–466 | quoted_attribute_value  |
| Sec9dcf513abc_N2791 | Sec9dcf513abc_N2790 | attribute_value | 466–466 | alby |
| Sec9dcf513abc_N2792 | Sec9dcf513abc_N2782 | attribute | 466–466 | attribute  |
| Sec9dcf513abc_N2793 | Sec9dcf513abc_N2792 | attribute_name | 466–466 | id |
| Sec9dcf513abc_N2794 | Sec9dcf513abc_N2792 | quoted_attribute_value | 466–466 | quoted_attribute_value  |
| Sec9dcf513abc_N2795 | Sec9dcf513abc_N2794 | attribute_value | 466–466 | section-alby |
| Sec9dcf513abc_N2796 | Sec9dcf513abc_N2781 | element | 467–473 | element  |
| Sec9dcf513abc_N2797 | Sec9dcf513abc_N2796 | start_tag | 467–467 | start_tag  |
| Sec9dcf513abc_N2798 | Sec9dcf513abc_N2797 | tag_name | 467–467 | div |
| Sec9dcf513abc_N2799 | Sec9dcf513abc_N2797 | attribute | 467–467 | attribute  |
| Sec9dcf513abc_N2800 | Sec9dcf513abc_N2799 | attribute_name | 467–467 | class |
| Sec9dcf513abc_N2801 | Sec9dcf513abc_N2799 | quoted_attribute_value | 467–467 | quoted_attribute_value  |
| Sec9dcf513abc_N2802 | Sec9dcf513abc_N2801 | attribute_value | 467–467 | border-b border-hairline/80 pb-4 flex items-center justify-between |
| Sec9dcf513abc_N2803 | Sec9dcf513abc_N2796 | element | 468–471 | element  |
| Sec9dcf513abc_N2804 | Sec9dcf513abc_N2803 | start_tag | 468–468 | start_tag  |
| Sec9dcf513abc_N2805 | Sec9dcf513abc_N2804 | tag_name | 468–468 | div |
| Sec9dcf513abc_N2806 | Sec9dcf513abc_N2803 | element | 469–469 | element  |
| Sec9dcf513abc_N2807 | Sec9dcf513abc_N2806 | start_tag | 469–469 | start_tag  |
| Sec9dcf513abc_N2808 | Sec9dcf513abc_N2807 | tag_name | 469–469 | span |
| Sec9dcf513abc_N2809 | Sec9dcf513abc_N2807 | attribute | 469–469 | attribute  |
| Sec9dcf513abc_N2810 | Sec9dcf513abc_N2809 | attribute_name | 469–469 | class |
| Sec9dcf513abc_N2811 | Sec9dcf513abc_N2809 | quoted_attribute_value | 469–469 | quoted_attribute_value  |
| Sec9dcf513abc_N2812 | Sec9dcf513abc_N2811 | attribute_value | 469–469 | text-xs font-mono text-celestial-brass uppercase tracking-wider |
| Sec9dcf513abc_N2813 | Sec9dcf513abc_N2806 | text | 469–469 | Alby Channel |
| Sec9dcf513abc_N2814 | Sec9dcf513abc_N2806 | end_tag | 469–469 | end_tag  |
| Sec9dcf513abc_N2815 | Sec9dcf513abc_N2814 | tag_name | 469–469 | span |
| Sec9dcf513abc_N2816 | Sec9dcf513abc_N2803 | element | 470–470 | element  |
| Sec9dcf513abc_N2817 | Sec9dcf513abc_N2816 | start_tag | 470–470 | start_tag  |
| Sec9dcf513abc_N2818 | Sec9dcf513abc_N2817 | tag_name | 470–470 | h1 |
| Sec9dcf513abc_N2819 | Sec9dcf513abc_N2817 | attribute | 470–470 | attribute  |
| Sec9dcf513abc_N2820 | Sec9dcf513abc_N2819 | attribute_name | 470–470 | class |
| Sec9dcf513abc_N2821 | Sec9dcf513abc_N2819 | quoted_attribute_value | 470–470 | quoted_attribute_value  |
| Sec9dcf513abc_N2822 | Sec9dcf513abc_N2821 | attribute_value | 470–470 | font-display text-2xl font-normal text-starlight mt-1 |
| Sec9dcf513abc_N2823 | Sec9dcf513abc_N2816 | text | 470–470 | Per-Turn Metered Reading |
| Sec9dcf513abc_N2824 | Sec9dcf513abc_N2816 | end_tag | 470–470 | end_tag  |
| Sec9dcf513abc_N2825 | Sec9dcf513abc_N2824 | tag_name | 470–470 | h1 |
| Sec9dcf513abc_N2826 | Sec9dcf513abc_N2803 | end_tag | 471–471 | end_tag  |
| Sec9dcf513abc_N2827 | Sec9dcf513abc_N2826 | tag_name | 471–471 | div |
| Sec9dcf513abc_N2828 | Sec9dcf513abc_N2796 | element | 472–472 | element  |
| Sec9dcf513abc_N2829 | Sec9dcf513abc_N2828 | start_tag | 472–472 | start_tag  |
| Sec9dcf513abc_N2830 | Sec9dcf513abc_N2829 | tag_name | 472–472 | button |
| Sec9dcf513abc_N2831 | Sec9dcf513abc_N2829 | attribute | 472–472 | attribute  |
| Sec9dcf513abc_N2832 | Sec9dcf513abc_N2831 | attribute_name | 472–472 | class |
| Sec9dcf513abc_N2833 | Sec9dcf513abc_N2831 | quoted_attribute_value | 472–472 | quoted_attribute_value  |
| Sec9dcf513abc_N2834 | Sec9dcf513abc_N2833 | attribute_value | 472–472 | text-xs font-mono text-ash hover:text-starlight |
| Sec9dcf513abc_N2835 | Sec9dcf513abc_N2829 | attribute | 472–472 | attribute  |
| Sec9dcf513abc_N2836 | Sec9dcf513abc_N2835 | attribute_name | 472–472 | onclick |
| Sec9dcf513abc_N2837 | Sec9dcf513abc_N2835 | quoted_attribute_value | 472–472 | quoted_attribute_value  |
| Sec9dcf513abc_N2838 | Sec9dcf513abc_N2837 | attribute_value | 472–472 | switchView('profile') |
| Sec9dcf513abc_N2839 | Sec9dcf513abc_N2828 | text | 472–472 | ← Return to Profile |
| Sec9dcf513abc_N2840 | Sec9dcf513abc_N2828 | end_tag | 472–472 | end_tag  |
| Sec9dcf513abc_N2841 | Sec9dcf513abc_N2840 | tag_name | 472–472 | button |
| Sec9dcf513abc_N2842 | Sec9dcf513abc_N2796 | end_tag | 473–473 | end_tag  |
| Sec9dcf513abc_N2843 | Sec9dcf513abc_N2842 | tag_name | 473–473 | div |
| Sec9dcf513abc_N2844 | Sec9dcf513abc_N2781 | element | 474–479 | element  |
| Sec9dcf513abc_N2845 | Sec9dcf513abc_N2844 | start_tag | 474–474 | start_tag  |
| Sec9dcf513abc_N2846 | Sec9dcf513abc_N2845 | tag_name | 474–474 | div |
| Sec9dcf513abc_N2847 | Sec9dcf513abc_N2845 | attribute | 474–474 | attribute  |
| Sec9dcf513abc_N2848 | Sec9dcf513abc_N2847 | attribute_name | 474–474 | class |
| Sec9dcf513abc_N2849 | Sec9dcf513abc_N2847 | quoted_attribute_value | 474–474 | quoted_attribute_value  |
| Sec9dcf513abc_N2850 | Sec9dcf513abc_N2849 | attribute_value | 474–474 | p-4 rounded-xl border border-celestial-brass/30 bg-celestial-brass/5 text-xs text-ash space-y-1 |
| Sec9dcf513abc_N2851 | Sec9dcf513abc_N2844 | element | 475–475 | element  |
| Sec9dcf513abc_N2852 | Sec9dcf513abc_N2851 | start_tag | 475–475 | start_tag  |
| Sec9dcf513abc_N2853 | Sec9dcf513abc_N2852 | tag_name | 475–475 | span |
| Sec9dcf513abc_N2854 | Sec9dcf513abc_N2852 | attribute | 475–475 | attribute  |
| Sec9dcf513abc_N2855 | Sec9dcf513abc_N2854 | attribute_name | 475–475 | class |
| Sec9dcf513abc_N2856 | Sec9dcf513abc_N2854 | quoted_attribute_value | 475–475 | quoted_attribute_value  |
| Sec9dcf513abc_N2857 | Sec9dcf513abc_N2856 | attribute_value | 475–475 | font-mono text-celestial-brass font-semibold |
| Sec9dcf513abc_N2858 | Sec9dcf513abc_N2851 | text | 475–475 | Distribution Boundary: Alby Marketplace |
| Sec9dcf513abc_N2859 | Sec9dcf513abc_N2851 | end_tag | 475–475 | end_tag  |
| Sec9dcf513abc_N2860 | Sec9dcf513abc_N2859 | tag_name | 475–475 | span |
| Sec9dcf513abc_N2861 | Sec9dcf513abc_N2844 | element | 476–478 | element  |
| Sec9dcf513abc_N2862 | Sec9dcf513abc_N2861 | start_tag | 476–476 | start_tag  |
| Sec9dcf513abc_N2863 | Sec9dcf513abc_N2862 | tag_name | 476–476 | p |
| Sec9dcf513abc_N2864 | Sec9dcf513abc_N2862 | attribute | 476–476 | attribute  |
| Sec9dcf513abc_N2865 | Sec9dcf513abc_N2864 | attribute_name | 476–476 | class |
| Sec9dcf513abc_N2866 | Sec9dcf513abc_N2864 | quoted_attribute_value | 476–476 | quoted_attribute_value  |
| Sec9dcf513abc_N2867 | Sec9dcf513abc_N2866 | attribute_value | 476–476 | leading-relaxed |
| Sec9dcf513abc_N2868 | Sec9dcf513abc_N2861 | text | 477–477 | Alby is a payment channel for per-turn astrological dialogue settled in Bitcoin satoshis. Alby is not a PDF storefront and does not grant unlimited conversation tokens. |
| Sec9dcf513abc_N2869 | Sec9dcf513abc_N2861 | end_tag | 478–478 | end_tag  |
| Sec9dcf513abc_N2870 | Sec9dcf513abc_N2869 | tag_name | 478–478 | p |
| Sec9dcf513abc_N2871 | Sec9dcf513abc_N2844 | end_tag | 479–479 | end_tag  |
| Sec9dcf513abc_N2872 | Sec9dcf513abc_N2871 | tag_name | 479–479 | div |
| Sec9dcf513abc_N2873 | Sec9dcf513abc_N2781 | comment | 480–480 | &lt;!-- Turn Composer --&gt; |
| Sec9dcf513abc_N2874 | Sec9dcf513abc_N2781 | element | 481–519 | element  |
| Sec9dcf513abc_N2875 | Sec9dcf513abc_N2874 | start_tag | 481–481 | start_tag  |
| Sec9dcf513abc_N2876 | Sec9dcf513abc_N2875 | tag_name | 481–481 | div |
| Sec9dcf513abc_N2877 | Sec9dcf513abc_N2875 | attribute | 481–481 | attribute  |
| Sec9dcf513abc_N2878 | Sec9dcf513abc_N2877 | attribute_name | 481–481 | class |
| Sec9dcf513abc_N2879 | Sec9dcf513abc_N2877 | quoted_attribute_value | 481–481 | quoted_attribute_value  |
| Sec9dcf513abc_N2880 | Sec9dcf513abc_N2879 | attribute_value | 481–481 | space-y-4 |
| Sec9dcf513abc_N2881 | Sec9dcf513abc_N2874 | element | 482–487 | element  |
| Sec9dcf513abc_N2882 | Sec9dcf513abc_N2881 | start_tag | 482–482 | start_tag  |
| Sec9dcf513abc_N2883 | Sec9dcf513abc_N2882 | tag_name | 482–482 | div |
| Sec9dcf513abc_N2884 | Sec9dcf513abc_N2881 | element | 483–485 | element  |
| Sec9dcf513abc_N2885 | Sec9dcf513abc_N2884 | start_tag | 483–483 | start_tag  |
| Sec9dcf513abc_N2886 | Sec9dcf513abc_N2885 | tag_name | 483–483 | label |
| Sec9dcf513abc_N2887 | Sec9dcf513abc_N2885 | attribute | 483–483 | attribute  |
| Sec9dcf513abc_N2888 | Sec9dcf513abc_N2887 | attribute_name | 483–483 | class |
| Sec9dcf513abc_N2889 | Sec9dcf513abc_N2887 | quoted_attribute_value | 483–483 | quoted_attribute_value  |
| Sec9dcf513abc_N2890 | Sec9dcf513abc_N2889 | attribute_value | 483–483 | block text-xs font-mono uppercase text-ash tracking-wider mb-2 |
| Sec9dcf513abc_N2891 | Sec9dcf513abc_N2885 | attribute | 483–483 | attribute  |
| Sec9dcf513abc_N2892 | Sec9dcf513abc_N2891 | attribute_name | 483–483 | for |
| Sec9dcf513abc_N2893 | Sec9dcf513abc_N2891 | quoted_attribute_value | 483–483 | quoted_attribute_value  |
| Sec9dcf513abc_N2894 | Sec9dcf513abc_N2893 | attribute_value | 483–483 | reading-question |
| Sec9dcf513abc_N2895 | Sec9dcf513abc_N2884 | text | 484–484 | Your astrological query for Natally |
| Sec9dcf513abc_N2896 | Sec9dcf513abc_N2884 | end_tag | 485–485 | end_tag  |
| Sec9dcf513abc_N2897 | Sec9dcf513abc_N2896 | tag_name | 485–485 | label |
| Sec9dcf513abc_N2898 | Sec9dcf513abc_N2881 | element | 486–486 | element  |
| Sec9dcf513abc_N2899 | Sec9dcf513abc_N2898 | start_tag | 486–486 | start_tag  |
| Sec9dcf513abc_N2900 | Sec9dcf513abc_N2899 | tag_name | 486–486 | textarea |
| Sec9dcf513abc_N2901 | Sec9dcf513abc_N2899 | attribute | 486–486 | attribute  |
| Sec9dcf513abc_N2902 | Sec9dcf513abc_N2901 | attribute_name | 486–486 | class |
| Sec9dcf513abc_N2903 | Sec9dcf513abc_N2901 | quoted_attribute_value | 486–486 | quoted_attribute_value  |
| Sec9dcf513abc_N2904 | Sec9dcf513abc_N2903 | attribute_value | 486–486 | w-full p-3.5 rounded-xl bg-surface-dim border border-hairline text-sm text-starlight font-body placeholder:text-ash/50 focus:border-celestial-brass |
| Sec9dcf513abc_N2905 | Sec9dcf513abc_N2899 | attribute | 486–486 | attribute  |
| Sec9dcf513abc_N2906 | Sec9dcf513abc_N2905 | attribute_name | 486–486 | id |
| Sec9dcf513abc_N2907 | Sec9dcf513abc_N2905 | quoted_attribute_value | 486–486 | quoted_attribute_value  |
| Sec9dcf513abc_N2908 | Sec9dcf513abc_N2907 | attribute_value | 486–486 | reading-question |
| Sec9dcf513abc_N2909 | Sec9dcf513abc_N2899 | attribute | 486–486 | attribute  |
| Sec9dcf513abc_N2910 | Sec9dcf513abc_N2909 | attribute_name | 486–486 | placeholder |
| Sec9dcf513abc_N2911 | Sec9dcf513abc_N2909 | quoted_attribute_value | 486–486 | quoted_attribute_value  |
| Sec9dcf513abc_N2912 | Sec9dcf513abc_N2911 | attribute_value | 486–486 | E.g., Inquire into upcoming Venus-Saturn transits or Placidus midheaven placements... |
| Sec9dcf513abc_N2913 | Sec9dcf513abc_N2899 | attribute | 486–486 | attribute  |
| Sec9dcf513abc_N2914 | Sec9dcf513abc_N2913 | attribute_name | 486–486 | rows |
| Sec9dcf513abc_N2915 | Sec9dcf513abc_N2913 | quoted_attribute_value | 486–486 | quoted_attribute_value  |
| Sec9dcf513abc_N2916 | Sec9dcf513abc_N2915 | attribute_value | 486–486 | 3 |
| Sec9dcf513abc_N2917 | Sec9dcf513abc_N2898 | end_tag | 486–486 | end_tag  |
| Sec9dcf513abc_N2918 | Sec9dcf513abc_N2917 | tag_name | 486–486 | textarea |
| Sec9dcf513abc_N2919 | Sec9dcf513abc_N2881 | end_tag | 487–487 | end_tag  |
| Sec9dcf513abc_N2920 | Sec9dcf513abc_N2919 | tag_name | 487–487 | div |
| Sec9dcf513abc_N2921 | Sec9dcf513abc_N2874 | comment | 488–488 | &lt;!-- Quote &amp; Authorization Manifest --&gt; |
| Sec9dcf513abc_N2922 | Sec9dcf513abc_N2874 | element | 489–502 | element  |
| Sec9dcf513abc_N2923 | Sec9dcf513abc_N2922 | start_tag | 489–489 | start_tag  |
| Sec9dcf513abc_N2924 | Sec9dcf513abc_N2923 | tag_name | 489–489 | div |
| Sec9dcf513abc_N2925 | Sec9dcf513abc_N2923 | attribute | 489–489 | attribute  |
| Sec9dcf513abc_N2926 | Sec9dcf513abc_N2925 | attribute_name | 489–489 | class |
| Sec9dcf513abc_N2927 | Sec9dcf513abc_N2925 | quoted_attribute_value | 489–489 | quoted_attribute_value  |
| Sec9dcf513abc_N2928 | Sec9dcf513abc_N2927 | attribute_value | 489–489 | p-4 rounded-xl border border-hairline bg-surface-dim grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs |
| Sec9dcf513abc_N2929 | Sec9dcf513abc_N2922 | element | 490–493 | element  |
| Sec9dcf513abc_N2930 | Sec9dcf513abc_N2929 | start_tag | 490–490 | start_tag  |
| Sec9dcf513abc_N2931 | Sec9dcf513abc_N2930 | tag_name | 490–490 | div |
| Sec9dcf513abc_N2932 | Sec9dcf513abc_N2929 | element | 491–491 | element  |
| Sec9dcf513abc_N2933 | Sec9dcf513abc_N2932 | start_tag | 491–491 | start_tag  |
| Sec9dcf513abc_N2934 | Sec9dcf513abc_N2933 | tag_name | 491–491 | span |
| Sec9dcf513abc_N2935 | Sec9dcf513abc_N2933 | attribute | 491–491 | attribute  |
| Sec9dcf513abc_N2936 | Sec9dcf513abc_N2935 | attribute_name | 491–491 | class |
| Sec9dcf513abc_N2937 | Sec9dcf513abc_N2935 | quoted_attribute_value | 491–491 | quoted_attribute_value  |
| Sec9dcf513abc_N2938 | Sec9dcf513abc_N2937 | attribute_value | 491–491 | font-mono text-ash block text-[11px] |
| Sec9dcf513abc_N2939 | Sec9dcf513abc_N2932 | text | 491–491 | Turn Rate |
| Sec9dcf513abc_N2940 | Sec9dcf513abc_N2932 | end_tag | 491–491 | end_tag  |
| Sec9dcf513abc_N2941 | Sec9dcf513abc_N2940 | tag_name | 491–491 | span |
| Sec9dcf513abc_N2942 | Sec9dcf513abc_N2929 | element | 492–492 | element  |
| Sec9dcf513abc_N2943 | Sec9dcf513abc_N2942 | start_tag | 492–492 | start_tag  |
| Sec9dcf513abc_N2944 | Sec9dcf513abc_N2943 | tag_name | 492–492 | span |
| Sec9dcf513abc_N2945 | Sec9dcf513abc_N2943 | attribute | 492–492 | attribute  |
| Sec9dcf513abc_N2946 | Sec9dcf513abc_N2945 | attribute_name | 492–492 | class |
| Sec9dcf513abc_N2947 | Sec9dcf513abc_N2945 | quoted_attribute_value | 492–492 | quoted_attribute_value  |
| Sec9dcf513abc_N2948 | Sec9dcf513abc_N2947 | attribute_value | 492–492 | text-celestial-brass font-mono font-medium block mt-0.5 |
| Sec9dcf513abc_N2949 | Sec9dcf513abc_N2942 | text | 492–492 | Quote on request |
| Sec9dcf513abc_N2950 | Sec9dcf513abc_N2942 | end_tag | 492–492 | end_tag  |
| Sec9dcf513abc_N2951 | Sec9dcf513abc_N2950 | tag_name | 492–492 | span |
| Sec9dcf513abc_N2952 | Sec9dcf513abc_N2929 | end_tag | 493–493 | end_tag  |
| Sec9dcf513abc_N2953 | Sec9dcf513abc_N2952 | tag_name | 493–493 | div |
| Sec9dcf513abc_N2954 | Sec9dcf513abc_N2922 | element | 494–497 | element  |
| Sec9dcf513abc_N2955 | Sec9dcf513abc_N2954 | start_tag | 494–494 | start_tag  |
| Sec9dcf513abc_N2956 | Sec9dcf513abc_N2955 | tag_name | 494–494 | div |
| Sec9dcf513abc_N2957 | Sec9dcf513abc_N2954 | element | 495–495 | element  |
| Sec9dcf513abc_N2958 | Sec9dcf513abc_N2957 | start_tag | 495–495 | start_tag  |
| Sec9dcf513abc_N2959 | Sec9dcf513abc_N2958 | tag_name | 495–495 | span |
| Sec9dcf513abc_N2960 | Sec9dcf513abc_N2958 | attribute | 495–495 | attribute  |
| Sec9dcf513abc_N2961 | Sec9dcf513abc_N2960 | attribute_name | 495–495 | class |
| Sec9dcf513abc_N2962 | Sec9dcf513abc_N2960 | quoted_attribute_value | 495–495 | quoted_attribute_value  |
| Sec9dcf513abc_N2963 | Sec9dcf513abc_N2962 | attribute_value | 495–495 | font-mono text-ash block text-[11px] |
| Sec9dcf513abc_N2964 | Sec9dcf513abc_N2957 | text | 495–495 | Invoice Expiry |
| Sec9dcf513abc_N2965 | Sec9dcf513abc_N2957 | end_tag | 495–495 | end_tag  |
| Sec9dcf513abc_N2966 | Sec9dcf513abc_N2965 | tag_name | 495–495 | span |
| Sec9dcf513abc_N2967 | Sec9dcf513abc_N2954 | element | 496–496 | element  |
| Sec9dcf513abc_N2968 | Sec9dcf513abc_N2967 | start_tag | 496–496 | start_tag  |
| Sec9dcf513abc_N2969 | Sec9dcf513abc_N2968 | tag_name | 496–496 | span |
| Sec9dcf513abc_N2970 | Sec9dcf513abc_N2968 | attribute | 496–496 | attribute  |
| Sec9dcf513abc_N2971 | Sec9dcf513abc_N2970 | attribute_name | 496–496 | class |
| Sec9dcf513abc_N2972 | Sec9dcf513abc_N2970 | quoted_attribute_value | 496–496 | quoted_attribute_value  |
| Sec9dcf513abc_N2973 | Sec9dcf513abc_N2972 | attribute_value | 496–496 | text-starlight font-mono block mt-0.5 |
| Sec9dcf513abc_N2974 | Sec9dcf513abc_N2967 | text | 496–496 | 15 min window |
| Sec9dcf513abc_N2975 | Sec9dcf513abc_N2967 | end_tag | 496–496 | end_tag  |
| Sec9dcf513abc_N2976 | Sec9dcf513abc_N2975 | tag_name | 496–496 | span |
| Sec9dcf513abc_N2977 | Sec9dcf513abc_N2954 | end_tag | 497–497 | end_tag  |
| Sec9dcf513abc_N2978 | Sec9dcf513abc_N2977 | tag_name | 497–497 | div |
| Sec9dcf513abc_N2979 | Sec9dcf513abc_N2922 | element | 498–501 | element  |
| Sec9dcf513abc_N2980 | Sec9dcf513abc_N2979 | start_tag | 498–498 | start_tag  |
| Sec9dcf513abc_N2981 | Sec9dcf513abc_N2980 | tag_name | 498–498 | div |
| Sec9dcf513abc_N2982 | Sec9dcf513abc_N2979 | element | 499–499 | element  |
| Sec9dcf513abc_N2983 | Sec9dcf513abc_N2982 | start_tag | 499–499 | start_tag  |
| Sec9dcf513abc_N2984 | Sec9dcf513abc_N2983 | tag_name | 499–499 | span |
| Sec9dcf513abc_N2985 | Sec9dcf513abc_N2983 | attribute | 499–499 | attribute  |
| Sec9dcf513abc_N2986 | Sec9dcf513abc_N2985 | attribute_name | 499–499 | class |
| Sec9dcf513abc_N2987 | Sec9dcf513abc_N2985 | quoted_attribute_value | 499–499 | quoted_attribute_value  |
| Sec9dcf513abc_N2988 | Sec9dcf513abc_N2987 | attribute_value | 499–499 | font-mono text-ash block text-[11px] |
| Sec9dcf513abc_N2989 | Sec9dcf513abc_N2982 | text | 499–499 | Settlement |
| Sec9dcf513abc_N2990 | Sec9dcf513abc_N2982 | end_tag | 499–499 | end_tag  |
| Sec9dcf513abc_N2991 | Sec9dcf513abc_N2990 | tag_name | 499–499 | span |
| Sec9dcf513abc_N2992 | Sec9dcf513abc_N2979 | element | 500–500 | element  |
| Sec9dcf513abc_N2993 | Sec9dcf513abc_N2992 | start_tag | 500–500 | start_tag  |
| Sec9dcf513abc_N2994 | Sec9dcf513abc_N2993 | tag_name | 500–500 | span |
| Sec9dcf513abc_N2995 | Sec9dcf513abc_N2993 | attribute | 500–500 | attribute  |
| Sec9dcf513abc_N2996 | Sec9dcf513abc_N2995 | attribute_name | 500–500 | class |
| Sec9dcf513abc_N2997 | Sec9dcf513abc_N2995 | quoted_attribute_value | 500–500 | quoted_attribute_value  |
| Sec9dcf513abc_N2998 | Sec9dcf513abc_N2997 | attribute_value | 500–500 | text-starlight block mt-0.5 |
| Sec9dcf513abc_N2999 | Sec9dcf513abc_N2992 | text | 500–500 | Bitcoin Lightning (L402) |
| Sec9dcf513abc_N3000 | Sec9dcf513abc_N2992 | end_tag | 500–500 | end_tag  |
| Sec9dcf513abc_N3001 | Sec9dcf513abc_N3000 | tag_name | 500–500 | span |
| Sec9dcf513abc_N3002 | Sec9dcf513abc_N2979 | end_tag | 501–501 | end_tag  |
| Sec9dcf513abc_N3003 | Sec9dcf513abc_N3002 | tag_name | 501–501 | div |
| Sec9dcf513abc_N3004 | Sec9dcf513abc_N2922 | end_tag | 502–502 | end_tag  |
| Sec9dcf513abc_N3005 | Sec9dcf513abc_N3004 | tag_name | 502–502 | div |
| Sec9dcf513abc_N3006 | Sec9dcf513abc_N2874 | comment | 503–503 | &lt;!-- Action Buttons --&gt; |
| Sec9dcf513abc_N3007 | Sec9dcf513abc_N2874 | element | 504–514 | element  |
| Sec9dcf513abc_N3008 | Sec9dcf513abc_N3007 | start_tag | 504–504 | start_tag  |
| Sec9dcf513abc_N3009 | Sec9dcf513abc_N3008 | tag_name | 504–504 | div |
| Sec9dcf513abc_N3010 | Sec9dcf513abc_N3008 | attribute | 504–504 | attribute  |
| Sec9dcf513abc_N3011 | Sec9dcf513abc_N3010 | attribute_name | 504–504 | class |
| Sec9dcf513abc_N3012 | Sec9dcf513abc_N3010 | quoted_attribute_value | 504–504 | quoted_attribute_value  |
| Sec9dcf513abc_N3013 | Sec9dcf513abc_N3012 | attribute_value | 504–504 | flex flex-wrap items-center gap-3 pt-2 |
| Sec9dcf513abc_N3014 | Sec9dcf513abc_N3007 | element | 505–507 | element  |
| Sec9dcf513abc_N3015 | Sec9dcf513abc_N3014 | start_tag | 505–505 | start_tag  |
| Sec9dcf513abc_N3016 | Sec9dcf513abc_N3015 | tag_name | 505–505 | button |
| Sec9dcf513abc_N3017 | Sec9dcf513abc_N3015 | attribute | 505–505 | attribute  |
| Sec9dcf513abc_N3018 | Sec9dcf513abc_N3017 | attribute_name | 505–505 | class |
| Sec9dcf513abc_N3019 | Sec9dcf513abc_N3017 | quoted_attribute_value | 505–505 | quoted_attribute_value  |
| Sec9dcf513abc_N3020 | Sec9dcf513abc_N3019 | attribute_value | 505–505 | py-2.5 px-5 rounded-lg bg-celestial-brass text-observatory font-semibold text-sm hover:bg-celestial-brass-hover transition-colors |
| Sec9dcf513abc_N3021 | Sec9dcf513abc_N3015 | attribute | 505–505 | attribute  |
| Sec9dcf513abc_N3022 | Sec9dcf513abc_N3021 | attribute_name | 505–505 | id |
| Sec9dcf513abc_N3023 | Sec9dcf513abc_N3021 | quoted_attribute_value | 505–505 | quoted_attribute_value  |
| Sec9dcf513abc_N3024 | Sec9dcf513abc_N3023 | attribute_value | 505–505 | quote-turn |
| Sec9dcf513abc_N3025 | Sec9dcf513abc_N3015 | attribute | 505–505 | attribute  |
| Sec9dcf513abc_N3026 | Sec9dcf513abc_N3025 | attribute_name | 505–505 | onclick |
| Sec9dcf513abc_N3027 | Sec9dcf513abc_N3025 | quoted_attribute_value | 505–505 | quoted_attribute_value  |
| Sec9dcf513abc_N3028 | Sec9dcf513abc_N3027 | attribute_value | 505–505 | simulateQuoteNotice('Alby Lightning quote requested for 1 reading turn. Real sats amount and hash challenge will be returned by server.') |
| Sec9dcf513abc_N3029 | Sec9dcf513abc_N3014 | text | 506–506 | Quote 1 Turn |
| Sec9dcf513abc_N3030 | Sec9dcf513abc_N3014 | end_tag | 507–507 | end_tag  |
| Sec9dcf513abc_N3031 | Sec9dcf513abc_N3030 | tag_name | 507–507 | button |
| Sec9dcf513abc_N3032 | Sec9dcf513abc_N3007 | element | 508–510 | element  |
| Sec9dcf513abc_N3033 | Sec9dcf513abc_N3032 | start_tag | 508–508 | start_tag  |
| Sec9dcf513abc_N3034 | Sec9dcf513abc_N3033 | tag_name | 508–508 | button |
| Sec9dcf513abc_N3035 | Sec9dcf513abc_N3033 | attribute | 508–508 | attribute  |
| Sec9dcf513abc_N3036 | Sec9dcf513abc_N3035 | attribute_name | 508–508 | class |
| Sec9dcf513abc_N3037 | Sec9dcf513abc_N3035 | quoted_attribute_value | 508–508 | quoted_attribute_value  |
| Sec9dcf513abc_N3038 | Sec9dcf513abc_N3037 | attribute_value | 508–508 | py-2.5 px-5 rounded-lg border border-hairline text-starlight font-medium text-sm hover:bg-surface-dim transition-colors |
| Sec9dcf513abc_N3039 | Sec9dcf513abc_N3033 | attribute | 508–508 | attribute  |
| Sec9dcf513abc_N3040 | Sec9dcf513abc_N3039 | attribute_name | 508–508 | id |
| Sec9dcf513abc_N3041 | Sec9dcf513abc_N3039 | quoted_attribute_value | 508–508 | quoted_attribute_value  |
| Sec9dcf513abc_N3042 | Sec9dcf513abc_N3041 | attribute_value | 508–508 | pay-turn |
| Sec9dcf513abc_N3043 | Sec9dcf513abc_N3033 | attribute | 508–508 | attribute  |
| Sec9dcf513abc_N3044 | Sec9dcf513abc_N3043 | attribute_name | 508–508 | onclick |
| Sec9dcf513abc_N3045 | Sec9dcf513abc_N3043 | quoted_attribute_value | 508–508 | quoted_attribute_value  |
| Sec9dcf513abc_N3046 | Sec9dcf513abc_N3045 | attribute_value | 508–508 | simulateQuoteNotice('Prompting WebLN / Alby extension authorization. Prototype mode: no satoshis transmitted.') |
| Sec9dcf513abc_N3047 | Sec9dcf513abc_N3032 | text | 509–509 | Pay Turn (WebLN) |
| Sec9dcf513abc_N3048 | Sec9dcf513abc_N3032 | end_tag | 510–510 | end_tag  |
| Sec9dcf513abc_N3049 | Sec9dcf513abc_N3048 | tag_name | 510–510 | button |
| Sec9dcf513abc_N3050 | Sec9dcf513abc_N3007 | element | 511–513 | element  |
| Sec9dcf513abc_N3051 | Sec9dcf513abc_N3050 | start_tag | 511–511 | start_tag  |
| Sec9dcf513abc_N3052 | Sec9dcf513abc_N3051 | tag_name | 511–511 | button |
| Sec9dcf513abc_N3053 | Sec9dcf513abc_N3051 | attribute | 511–511 | attribute  |
| Sec9dcf513abc_N3054 | Sec9dcf513abc_N3053 | attribute_name | 511–511 | class |
| Sec9dcf513abc_N3055 | Sec9dcf513abc_N3053 | quoted_attribute_value | 511–511 | quoted_attribute_value  |
| Sec9dcf513abc_N3056 | Sec9dcf513abc_N3055 | attribute_value | 511–511 | py-2.5 px-5 rounded-lg border border-hairline/60 text-ash hover:text-starlight text-xs font-mono transition-colors |
| Sec9dcf513abc_N3057 | Sec9dcf513abc_N3051 | attribute | 511–511 | attribute  |
| Sec9dcf513abc_N3058 | Sec9dcf513abc_N3057 | attribute_name | 511–511 | id |
| Sec9dcf513abc_N3059 | Sec9dcf513abc_N3057 | quoted_attribute_value | 511–511 | quoted_attribute_value  |
| Sec9dcf513abc_N3060 | Sec9dcf513abc_N3059 | attribute_value | 511–511 | resume-turn |
| Sec9dcf513abc_N3061 | Sec9dcf513abc_N3051 | attribute | 511–511 | attribute  |
| Sec9dcf513abc_N3062 | Sec9dcf513abc_N3061 | attribute_name | 511–511 | onclick |
| Sec9dcf513abc_N3063 | Sec9dcf513abc_N3061 | quoted_attribute_value | 511–511 | quoted_attribute_value  |
| Sec9dcf513abc_N3064 | Sec9dcf513abc_N3063 | attribute_value | 511–511 | simulateQuoteNotice('Checking paid-but-not-delivered turn registry. Verified turns will resume without double billing.') |
| Sec9dcf513abc_N3065 | Sec9dcf513abc_N3050 | text | 512–512 | Resume Unsent Turn |
| Sec9dcf513abc_N3066 | Sec9dcf513abc_N3050 | end_tag | 513–513 | end_tag  |
| Sec9dcf513abc_N3067 | Sec9dcf513abc_N3066 | tag_name | 513–513 | button |
| Sec9dcf513abc_N3068 | Sec9dcf513abc_N3007 | end_tag | 514–514 | end_tag  |
| Sec9dcf513abc_N3069 | Sec9dcf513abc_N3068 | tag_name | 514–514 | div |
| Sec9dcf513abc_N3070 | Sec9dcf513abc_N2874 | element | 515–518 | element  |
| Sec9dcf513abc_N3071 | Sec9dcf513abc_N3070 | start_tag | 515–515 | start_tag  |
| Sec9dcf513abc_N3072 | Sec9dcf513abc_N3071 | tag_name | 515–515 | div |
| Sec9dcf513abc_N3073 | Sec9dcf513abc_N3071 | attribute | 515–515 | attribute  |
| Sec9dcf513abc_N3074 | Sec9dcf513abc_N3073 | attribute_name | 515–515 | class |
| Sec9dcf513abc_N3075 | Sec9dcf513abc_N3073 | quoted_attribute_value | 515–515 | quoted_attribute_value  |
| Sec9dcf513abc_N3076 | Sec9dcf513abc_N3075 | attribute_value | 515–515 | p-3.5 rounded-lg border border-hairline/40 bg-surface-dim/60 text-[11px] text-ash space-y-1 |
| Sec9dcf513abc_N3077 | Sec9dcf513abc_N3070 | element | 516–516 | element  |
| Sec9dcf513abc_N3078 | Sec9dcf513abc_N3077 | start_tag | 516–516 | start_tag  |
| Sec9dcf513abc_N3079 | Sec9dcf513abc_N3078 | tag_name | 516–516 | span |
| Sec9dcf513abc_N3080 | Sec9dcf513abc_N3078 | attribute | 516–516 | attribute  |
| Sec9dcf513abc_N3081 | Sec9dcf513abc_N3080 | attribute_name | 516–516 | class |
| Sec9dcf513abc_N3082 | Sec9dcf513abc_N3080 | quoted_attribute_value | 516–516 | quoted_attribute_value  |
| Sec9dcf513abc_N3083 | Sec9dcf513abc_N3082 | attribute_value | 516–516 | font-mono font-semibold text-starlight |
| Sec9dcf513abc_N3084 | Sec9dcf513abc_N3077 | text | 516–516 | Delivery Protection: |
| Sec9dcf513abc_N3085 | Sec9dcf513abc_N3077 | end_tag | 516–516 | end_tag  |
| Sec9dcf513abc_N3086 | Sec9dcf513abc_N3085 | tag_name | 516–516 | span |
| Sec9dcf513abc_N3087 | Sec9dcf513abc_N3070 | element | 517–517 | element  |
| Sec9dcf513abc_N3088 | Sec9dcf513abc_N3087 | start_tag | 517–517 | start_tag  |
| Sec9dcf513abc_N3089 | Sec9dcf513abc_N3088 | tag_name | 517–517 | p |
| Sec9dcf513abc_N3090 | Sec9dcf513abc_N3087 | text | 517–517 | If satoshis are broadcast but the reading payload is interrupted, the turn is saved in your local verification token. Simply click Resume to re-fetch without re-paying. |
| Sec9dcf513abc_N3091 | Sec9dcf513abc_N3087 | end_tag | 517–517 | end_tag  |
| Sec9dcf513abc_N3092 | Sec9dcf513abc_N3091 | tag_name | 517–517 | p |
| Sec9dcf513abc_N3093 | Sec9dcf513abc_N3070 | end_tag | 518–518 | end_tag  |
| Sec9dcf513abc_N3094 | Sec9dcf513abc_N3093 | tag_name | 518–518 | div |
| Sec9dcf513abc_N3095 | Sec9dcf513abc_N2874 | end_tag | 519–519 | end_tag  |
| Sec9dcf513abc_N3096 | Sec9dcf513abc_N3095 | tag_name | 519–519 | div |
| Sec9dcf513abc_N3097 | Sec9dcf513abc_N2781 | end_tag | 520–520 | end_tag  |
| Sec9dcf513abc_N3098 | Sec9dcf513abc_N3097 | tag_name | 520–520 | div |
| Sec9dcf513abc_N3099 | Sec9dcf513abc_N1194 | comment | 521–521 | &lt;!-- SECTION 7: ATELIER CONVERSATION --&gt; |
| Sec9dcf513abc_N3100 | Sec9dcf513abc_N1194 | element | 522–556 | element  |
| Sec9dcf513abc_N3101 | Sec9dcf513abc_N3100 | start_tag | 522–522 | start_tag  |
| Sec9dcf513abc_N3102 | Sec9dcf513abc_N3101 | tag_name | 522–522 | div |
| Sec9dcf513abc_N3103 | Sec9dcf513abc_N3101 | attribute | 522–522 | attribute  |
| Sec9dcf513abc_N3104 | Sec9dcf513abc_N3103 | attribute_name | 522–522 | class |
| Sec9dcf513abc_N3105 | Sec9dcf513abc_N3103 | quoted_attribute_value | 522–522 | quoted_attribute_value  |
| Sec9dcf513abc_N3106 | Sec9dcf513abc_N3105 | attribute_value | 522–522 | view-section space-y-6 |
| Sec9dcf513abc_N3107 | Sec9dcf513abc_N3101 | attribute | 522–522 | attribute  |
| Sec9dcf513abc_N3108 | Sec9dcf513abc_N3107 | attribute_name | 522–522 | data-view |
| Sec9dcf513abc_N3109 | Sec9dcf513abc_N3107 | quoted_attribute_value | 522–522 | quoted_attribute_value  |
| Sec9dcf513abc_N3110 | Sec9dcf513abc_N3109 | attribute_value | 522–522 | conversation |
| Sec9dcf513abc_N3111 | Sec9dcf513abc_N3101 | attribute | 522–522 | attribute  |
| Sec9dcf513abc_N3112 | Sec9dcf513abc_N3111 | attribute_name | 522–522 | id |
| Sec9dcf513abc_N3113 | Sec9dcf513abc_N3111 | quoted_attribute_value | 522–522 | quoted_attribute_value  |
| Sec9dcf513abc_N3114 | Sec9dcf513abc_N3113 | attribute_value | 522–522 | section-conversation |
| Sec9dcf513abc_N3115 | Sec9dcf513abc_N3100 | element | 523–529 | element  |
| Sec9dcf513abc_N3116 | Sec9dcf513abc_N3115 | start_tag | 523–523 | start_tag  |
| Sec9dcf513abc_N3117 | Sec9dcf513abc_N3116 | tag_name | 523–523 | div |
| Sec9dcf513abc_N3118 | Sec9dcf513abc_N3116 | attribute | 523–523 | attribute  |
| Sec9dcf513abc_N3119 | Sec9dcf513abc_N3118 | attribute_name | 523–523 | class |
| Sec9dcf513abc_N3120 | Sec9dcf513abc_N3118 | quoted_attribute_value | 523–523 | quoted_attribute_value  |
| Sec9dcf513abc_N3121 | Sec9dcf513abc_N3120 | attribute_value | 523–523 | border-b border-hairline/80 pb-4 flex items-center justify-between |
| Sec9dcf513abc_N3122 | Sec9dcf513abc_N3115 | element | 524–527 | element  |
| Sec9dcf513abc_N3123 | Sec9dcf513abc_N3122 | start_tag | 524–524 | start_tag  |
| Sec9dcf513abc_N3124 | Sec9dcf513abc_N3123 | tag_name | 524–524 | div |
| Sec9dcf513abc_N3125 | Sec9dcf513abc_N3122 | element | 525–525 | element  |
| Sec9dcf513abc_N3126 | Sec9dcf513abc_N3125 | start_tag | 525–525 | start_tag  |
| Sec9dcf513abc_N3127 | Sec9dcf513abc_N3126 | tag_name | 525–525 | span |
| Sec9dcf513abc_N3128 | Sec9dcf513abc_N3126 | attribute | 525–525 | attribute  |
| Sec9dcf513abc_N3129 | Sec9dcf513abc_N3128 | attribute_name | 525–525 | class |
| Sec9dcf513abc_N3130 | Sec9dcf513abc_N3128 | quoted_attribute_value | 525–525 | quoted_attribute_value  |
| Sec9dcf513abc_N3131 | Sec9dcf513abc_N3130 | attribute_value | 525–525 | text-xs font-mono text-celestial-brass uppercase tracking-wider |
| Sec9dcf513abc_N3132 | Sec9dcf513abc_N3125 | text | 525–525 | Atelier Space |
| Sec9dcf513abc_N3133 | Sec9dcf513abc_N3125 | end_tag | 525–525 | end_tag  |
| Sec9dcf513abc_N3134 | Sec9dcf513abc_N3133 | tag_name | 525–525 | span |
| Sec9dcf513abc_N3135 | Sec9dcf513abc_N3122 | element | 526–526 | element  |
| Sec9dcf513abc_N3136 | Sec9dcf513abc_N3135 | start_tag | 526–526 | start_tag  |
| Sec9dcf513abc_N3137 | Sec9dcf513abc_N3136 | tag_name | 526–526 | h1 |
| Sec9dcf513abc_N3138 | Sec9dcf513abc_N3136 | attribute | 526–526 | attribute  |
| Sec9dcf513abc_N3139 | Sec9dcf513abc_N3138 | attribute_name | 526–526 | class |
| Sec9dcf513abc_N3140 | Sec9dcf513abc_N3138 | quoted_attribute_value | 526–526 | quoted_attribute_value  |
| Sec9dcf513abc_N3141 | Sec9dcf513abc_N3140 | attribute_value | 526–526 | font-display text-2xl font-normal text-starlight mt-1 |
| Sec9dcf513abc_N3142 | Sec9dcf513abc_N3135 | text | 526–526 | Open Atelier Conversation |
| Sec9dcf513abc_N3143 | Sec9dcf513abc_N3135 | end_tag | 526–526 | end_tag  |
| Sec9dcf513abc_N3144 | Sec9dcf513abc_N3143 | tag_name | 526–526 | h1 |
| Sec9dcf513abc_N3145 | Sec9dcf513abc_N3122 | end_tag | 527–527 | end_tag  |
| Sec9dcf513abc_N3146 | Sec9dcf513abc_N3145 | tag_name | 527–527 | div |
| Sec9dcf513abc_N3147 | Sec9dcf513abc_N3115 | element | 528–528 | element  |
| Sec9dcf513abc_N3148 | Sec9dcf513abc_N3147 | start_tag | 528–528 | start_tag  |
| Sec9dcf513abc_N3149 | Sec9dcf513abc_N3148 | tag_name | 528–528 | button |
| Sec9dcf513abc_N3150 | Sec9dcf513abc_N3148 | attribute | 528–528 | attribute  |
| Sec9dcf513abc_N3151 | Sec9dcf513abc_N3150 | attribute_name | 528–528 | class |
| Sec9dcf513abc_N3152 | Sec9dcf513abc_N3150 | quoted_attribute_value | 528–528 | quoted_attribute_value  |
| Sec9dcf513abc_N3153 | Sec9dcf513abc_N3152 | attribute_value | 528–528 | text-xs font-mono text-ash hover:text-starlight |
| Sec9dcf513abc_N3154 | Sec9dcf513abc_N3148 | attribute | 528–528 | attribute  |
| Sec9dcf513abc_N3155 | Sec9dcf513abc_N3154 | attribute_name | 528–528 | onclick |
| Sec9dcf513abc_N3156 | Sec9dcf513abc_N3154 | quoted_attribute_value | 528–528 | quoted_attribute_value  |
| Sec9dcf513abc_N3157 | Sec9dcf513abc_N3156 | attribute_value | 528–528 | switchView('profile') |
| Sec9dcf513abc_N3158 | Sec9dcf513abc_N3147 | text | 528–528 | ← Return to Profile |
| Sec9dcf513abc_N3159 | Sec9dcf513abc_N3147 | end_tag | 528–528 | end_tag  |
| Sec9dcf513abc_N3160 | Sec9dcf513abc_N3159 | tag_name | 528–528 | button |
| Sec9dcf513abc_N3161 | Sec9dcf513abc_N3115 | end_tag | 529–529 | end_tag  |
| Sec9dcf513abc_N3162 | Sec9dcf513abc_N3161 | tag_name | 529–529 | div |
| Sec9dcf513abc_N3163 | Sec9dcf513abc_N3100 | comment | 530–530 | &lt;!-- Atelier Scene Description &amp; Asset Link --&gt; |
| Sec9dcf513abc_N3164 | Sec9dcf513abc_N3100 | element | 531–555 | element  |
| Sec9dcf513abc_N3165 | Sec9dcf513abc_N3164 | start_tag | 531–531 | start_tag  |
| Sec9dcf513abc_N3166 | Sec9dcf513abc_N3165 | tag_name | 531–531 | div |
| Sec9dcf513abc_N3167 | Sec9dcf513abc_N3165 | attribute | 531–531 | attribute  |
| Sec9dcf513abc_N3168 | Sec9dcf513abc_N3167 | attribute_name | 531–531 | class |
| Sec9dcf513abc_N3169 | Sec9dcf513abc_N3167 | quoted_attribute_value | 531–531 | quoted_attribute_value  |
| Sec9dcf513abc_N3170 | Sec9dcf513abc_N3169 | attribute_value | 531–531 | p-6 rounded-xl border border-hairline bg-surface-dim space-y-5 |
| Sec9dcf513abc_N3171 | Sec9dcf513abc_N3164 | element | 532–547 | element  |
| Sec9dcf513abc_N3172 | Sec9dcf513abc_N3171 | start_tag | 532–532 | start_tag  |
| Sec9dcf513abc_N3173 | Sec9dcf513abc_N3172 | tag_name | 532–532 | div |
| Sec9dcf513abc_N3174 | Sec9dcf513abc_N3172 | attribute | 532–532 | attribute  |
| Sec9dcf513abc_N3175 | Sec9dcf513abc_N3174 | attribute_name | 532–532 | class |
| Sec9dcf513abc_N3176 | Sec9dcf513abc_N3174 | quoted_attribute_value | 532–532 | quoted_attribute_value  |
| Sec9dcf513abc_N3177 | Sec9dcf513abc_N3176 | attribute_value | 532–532 | flex flex-col md:flex-row items-center gap-6 |
| Sec9dcf513abc_N3178 | Sec9dcf513abc_N3171 | element | 533–535 | element  |
| Sec9dcf513abc_N3179 | Sec9dcf513abc_N3178 | start_tag | 533–533 | start_tag  |
| Sec9dcf513abc_N3180 | Sec9dcf513abc_N3179 | tag_name | 533–533 | div |
| Sec9dcf513abc_N3181 | Sec9dcf513abc_N3179 | attribute | 533–533 | attribute  |
| Sec9dcf513abc_N3182 | Sec9dcf513abc_N3181 | attribute_name | 533–533 | class |
| Sec9dcf513abc_N3183 | Sec9dcf513abc_N3181 | quoted_attribute_value | 533–533 | quoted_attribute_value  |
| Sec9dcf513abc_N3184 | Sec9dcf513abc_N3183 | attribute_value | 533–533 | w-28 h-28 rounded-2xl border-2 border-celestial-brass/50 overflow-hidden flex-shrink-0 bg-observatory shadow-lg shadow-black |
| Sec9dcf513abc_N3185 | Sec9dcf513abc_N3178 | element | 534–534 | element  |
| Sec9dcf513abc_N3186 | Sec9dcf513abc_N3185 | self_closing_tag | 534–534 | self_closing_tag  |
| Sec9dcf513abc_N3187 | Sec9dcf513abc_N3186 | tag_name | 534–534 | img |
| Sec9dcf513abc_N3188 | Sec9dcf513abc_N3186 | attribute | 534–534 | attribute  |
| Sec9dcf513abc_N3189 | Sec9dcf513abc_N3188 | attribute_name | 534–534 | alt |
| Sec9dcf513abc_N3190 | Sec9dcf513abc_N3188 | quoted_attribute_value | 534–534 | quoted_attribute_value  |
| Sec9dcf513abc_N3191 | Sec9dcf513abc_N3190 | attribute_value | 534–534 | Natally Mascot in Atmospheric Atelier |
| Sec9dcf513abc_N3192 | Sec9dcf513abc_N3186 | attribute | 534–534 | attribute  |
| Sec9dcf513abc_N3193 | Sec9dcf513abc_N3192 | attribute_name | 534–534 | class |
| Sec9dcf513abc_N3194 | Sec9dcf513abc_N3192 | quoted_attribute_value | 534–534 | quoted_attribute_value  |
| Sec9dcf513abc_N3195 | Sec9dcf513abc_N3194 | attribute_value | 534–534 | w-full h-full object-cover |
| Sec9dcf513abc_N3196 | Sec9dcf513abc_N3186 | attribute | 534–534 | attribute  |
| Sec9dcf513abc_N3197 | Sec9dcf513abc_N3196 | attribute_name | 534–534 | onerror |
| Sec9dcf513abc_N3198 | Sec9dcf513abc_N3196 | quoted_attribute_value | 534–534 | quoted_attribute_value  |
| Sec9dcf513abc_N3199 | Sec9dcf513abc_N3198 | attribute_value | 534–534 | this.src='https://lh3.googleusercontent.com/aida-public/AB6AXuCrfhL4lciCS2D4SfH-I-Aq0qL6NisgPYvi8x0pRtoqm0ZT-d8DZ3OiEaetjs5aI6RcGmyzIEtUDxgO7_ke3koF5-QzSocUK-zRvNfNbssqYzFQsKrwpdaw8gTTc1ps8FBv401bQfGhzP2rbE6JEcZieIy58sIGyoSB5Eco9eB1AdxjP5bHxO8HY-EZMKACzNBCGQh6blsU9a75CNgoqxX2h-uOp59BV_C7bbgi42rkaNBJBBZ2Z7wIRxEYVpgFod3LF91tPeOSRGM' |
| Sec9dcf513abc_N3200 | Sec9dcf513abc_N3186 | attribute | 534–534 | attribute  |
| Sec9dcf513abc_N3201 | Sec9dcf513abc_N3200 | attribute_name | 534–534 | src |
| Sec9dcf513abc_N3202 | Sec9dcf513abc_N3200 | quoted_attribute_value | 534–534 | quoted_attribute_value  |
| Sec9dcf513abc_N3203 | Sec9dcf513abc_N3202 | attribute_value | 534–534 | https://www.gstatic.com/labs-code/stitch/stitch-placeholder-300x300.svg |
| Sec9dcf513abc_N3204 | Sec9dcf513abc_N3178 | end_tag | 535–535 | end_tag  |
| Sec9dcf513abc_N3205 | Sec9dcf513abc_N3204 | tag_name | 535–535 | div |
| Sec9dcf513abc_N3206 | Sec9dcf513abc_N3171 | element | 536–546 | element  |
| Sec9dcf513abc_N3207 | Sec9dcf513abc_N3206 | start_tag | 536–536 | start_tag  |
| Sec9dcf513abc_N3208 | Sec9dcf513abc_N3207 | tag_name | 536–536 | div |
| Sec9dcf513abc_N3209 | Sec9dcf513abc_N3207 | attribute | 536–536 | attribute  |
| Sec9dcf513abc_N3210 | Sec9dcf513abc_N3209 | attribute_name | 536–536 | class |
| Sec9dcf513abc_N3211 | Sec9dcf513abc_N3209 | quoted_attribute_value | 536–536 | quoted_attribute_value  |
| Sec9dcf513abc_N3212 | Sec9dcf513abc_N3211 | attribute_value | 536–536 | space-y-2 text-center md:text-left |
| Sec9dcf513abc_N3213 | Sec9dcf513abc_N3206 | element | 537–537 | element  |
| Sec9dcf513abc_N3214 | Sec9dcf513abc_N3213 | start_tag | 537–537 | start_tag  |
| Sec9dcf513abc_N3215 | Sec9dcf513abc_N3214 | tag_name | 537–537 | h2 |
| Sec9dcf513abc_N3216 | Sec9dcf513abc_N3214 | attribute | 537–537 | attribute  |
| Sec9dcf513abc_N3217 | Sec9dcf513abc_N3216 | attribute_name | 537–537 | class |
| Sec9dcf513abc_N3218 | Sec9dcf513abc_N3216 | quoted_attribute_value | 537–537 | quoted_attribute_value  |
| Sec9dcf513abc_N3219 | Sec9dcf513abc_N3218 | attribute_value | 537–537 | font-display text-xl text-starlight |
| Sec9dcf513abc_N3220 | Sec9dcf513abc_N3213 | text | 537–537 | The Nocturnal Astrolabe Sanctuary |
| Sec9dcf513abc_N3221 | Sec9dcf513abc_N3213 | end_tag | 537–537 | end_tag  |
| Sec9dcf513abc_N3222 | Sec9dcf513abc_N3221 | tag_name | 537–537 | h2 |
| Sec9dcf513abc_N3223 | Sec9dcf513abc_N3206 | element | 538–540 | element  |
| Sec9dcf513abc_N3224 | Sec9dcf513abc_N3223 | start_tag | 538–538 | start_tag  |
| Sec9dcf513abc_N3225 | Sec9dcf513abc_N3224 | tag_name | 538–538 | p |
| Sec9dcf513abc_N3226 | Sec9dcf513abc_N3224 | attribute | 538–538 | attribute  |
| Sec9dcf513abc_N3227 | Sec9dcf513abc_N3226 | attribute_name | 538–538 | class |
| Sec9dcf513abc_N3228 | Sec9dcf513abc_N3226 | quoted_attribute_value | 538–538 | quoted_attribute_value  |
| Sec9dcf513abc_N3229 | Sec9dcf513abc_N3228 | attribute_value | 538–538 | text-xs text-ash leading-relaxed |
| Sec9dcf513abc_N3230 | Sec9dcf513abc_N3223 | text | 539–539 | Preserving the original free-standing robot, warm candle gold, neatly shelved magical ephemera, night star sky, and delicate constellation lines. |
| Sec9dcf513abc_N3231 | Sec9dcf513abc_N3223 | end_tag | 540–540 | end_tag  |
| Sec9dcf513abc_N3232 | Sec9dcf513abc_N3231 | tag_name | 540–540 | p |
| Sec9dcf513abc_N3233 | Sec9dcf513abc_N3206 | element | 541–545 | element  |
| Sec9dcf513abc_N3234 | Sec9dcf513abc_N3233 | start_tag | 541–541 | start_tag  |
| Sec9dcf513abc_N3235 | Sec9dcf513abc_N3234 | tag_name | 541–541 | div |
| Sec9dcf513abc_N3236 | Sec9dcf513abc_N3234 | attribute | 541–541 | attribute  |
| Sec9dcf513abc_N3237 | Sec9dcf513abc_N3236 | attribute_name | 541–541 | class |
| Sec9dcf513abc_N3238 | Sec9dcf513abc_N3236 | quoted_attribute_value | 541–541 | quoted_attribute_value  |
| Sec9dcf513abc_N3239 | Sec9dcf513abc_N3238 | attribute_value | 541–541 | flex flex-wrap items-center justify-center md:justify-start gap-2 pt-1 |
| Sec9dcf513abc_N3240 | Sec9dcf513abc_N3233 | element | 542–542 | element  |
| Sec9dcf513abc_N3241 | Sec9dcf513abc_N3240 | start_tag | 542–542 | start_tag  |
| Sec9dcf513abc_N3242 | Sec9dcf513abc_N3241 | tag_name | 542–542 | span |
| Sec9dcf513abc_N3243 | Sec9dcf513abc_N3241 | attribute | 542–542 | attribute  |
| Sec9dcf513abc_N3244 | Sec9dcf513abc_N3243 | attribute_name | 542–542 | class |
| Sec9dcf513abc_N3245 | Sec9dcf513abc_N3243 | quoted_attribute_value | 542–542 | quoted_attribute_value  |
| Sec9dcf513abc_N3246 | Sec9dcf513abc_N3245 | attribute_value | 542–542 | px-2 py-0.5 rounded text-[11px] font-mono bg-raised-charcoal border border-hairline text-ash |
| Sec9dcf513abc_N3247 | Sec9dcf513abc_N3240 | text | 542–542 | Readable transcript |
| Sec9dcf513abc_N3248 | Sec9dcf513abc_N3240 | end_tag | 542–542 | end_tag  |
| Sec9dcf513abc_N3249 | Sec9dcf513abc_N3248 | tag_name | 542–542 | span |
| Sec9dcf513abc_N3250 | Sec9dcf513abc_N3233 | element | 543–543 | element  |
| Sec9dcf513abc_N3251 | Sec9dcf513abc_N3250 | start_tag | 543–543 | start_tag  |
| Sec9dcf513abc_N3252 | Sec9dcf513abc_N3251 | tag_name | 543–543 | span |
| Sec9dcf513abc_N3253 | Sec9dcf513abc_N3251 | attribute | 543–543 | attribute  |
| Sec9dcf513abc_N3254 | Sec9dcf513abc_N3253 | attribute_name | 543–543 | class |
| Sec9dcf513abc_N3255 | Sec9dcf513abc_N3253 | quoted_attribute_value | 543–543 | quoted_attribute_value  |
| Sec9dcf513abc_N3256 | Sec9dcf513abc_N3255 | attribute_value | 543–543 | px-2 py-0.5 rounded text-[11px] font-mono bg-raised-charcoal border border-hairline text-ash |
| Sec9dcf513abc_N3257 | Sec9dcf513abc_N3250 | text | 543–543 | Intimate composer |
| Sec9dcf513abc_N3258 | Sec9dcf513abc_N3250 | end_tag | 543–543 | end_tag  |
| Sec9dcf513abc_N3259 | Sec9dcf513abc_N3258 | tag_name | 543–543 | span |
| Sec9dcf513abc_N3260 | Sec9dcf513abc_N3233 | element | 544–544 | element  |
| Sec9dcf513abc_N3261 | Sec9dcf513abc_N3260 | start_tag | 544–544 | start_tag  |
| Sec9dcf513abc_N3262 | Sec9dcf513abc_N3261 | tag_name | 544–544 | span |
| Sec9dcf513abc_N3263 | Sec9dcf513abc_N3261 | attribute | 544–544 | attribute  |
| Sec9dcf513abc_N3264 | Sec9dcf513abc_N3263 | attribute_name | 544–544 | class |
| Sec9dcf513abc_N3265 | Sec9dcf513abc_N3263 | quoted_attribute_value | 544–544 | quoted_attribute_value  |
| Sec9dcf513abc_N3266 | Sec9dcf513abc_N3265 | attribute_value | 544–544 | px-2 py-0.5 rounded text-[11px] font-mono bg-raised-charcoal border border-hairline text-ash |
| Sec9dcf513abc_N3267 | Sec9dcf513abc_N3260 | text | 544–544 | No voice alteration |
| Sec9dcf513abc_N3268 | Sec9dcf513abc_N3260 | end_tag | 544–544 | end_tag  |
| Sec9dcf513abc_N3269 | Sec9dcf513abc_N3268 | tag_name | 544–544 | span |
| Sec9dcf513abc_N3270 | Sec9dcf513abc_N3233 | end_tag | 545–545 | end_tag  |
| Sec9dcf513abc_N3271 | Sec9dcf513abc_N3270 | tag_name | 545–545 | div |
| Sec9dcf513abc_N3272 | Sec9dcf513abc_N3206 | end_tag | 546–546 | end_tag  |
| Sec9dcf513abc_N3273 | Sec9dcf513abc_N3272 | tag_name | 546–546 | div |
| Sec9dcf513abc_N3274 | Sec9dcf513abc_N3171 | end_tag | 547–547 | end_tag  |
| Sec9dcf513abc_N3275 | Sec9dcf513abc_N3274 | tag_name | 547–547 | div |
| Sec9dcf513abc_N3276 | Sec9dcf513abc_N3164 | element | 548–554 | element  |
| Sec9dcf513abc_N3277 | Sec9dcf513abc_N3276 | start_tag | 548–548 | start_tag  |
| Sec9dcf513abc_N3278 | Sec9dcf513abc_N3277 | tag_name | 548–548 | div |
| Sec9dcf513abc_N3279 | Sec9dcf513abc_N3277 | attribute | 548–548 | attribute  |
| Sec9dcf513abc_N3280 | Sec9dcf513abc_N3279 | attribute_name | 548–548 | class |
| Sec9dcf513abc_N3281 | Sec9dcf513abc_N3279 | quoted_attribute_value | 548–548 | quoted_attribute_value  |
| Sec9dcf513abc_N3282 | Sec9dcf513abc_N3281 | attribute_value | 548–548 | pt-3 border-t border-hairline/60 flex flex-col sm:flex-row items-center justify-between gap-3 |
| Sec9dcf513abc_N3283 | Sec9dcf513abc_N3276 | element | 549–549 | element  |
| Sec9dcf513abc_N3284 | Sec9dcf513abc_N3283 | start_tag | 549–549 | start_tag  |
| Sec9dcf513abc_N3285 | Sec9dcf513abc_N3284 | tag_name | 549–549 | span |
| Sec9dcf513abc_N3286 | Sec9dcf513abc_N3284 | attribute | 549–549 | attribute  |
| Sec9dcf513abc_N3287 | Sec9dcf513abc_N3286 | attribute_name | 549–549 | class |
| Sec9dcf513abc_N3288 | Sec9dcf513abc_N3286 | quoted_attribute_value | 549–549 | quoted_attribute_value  |
| Sec9dcf513abc_N3289 | Sec9dcf513abc_N3288 | attribute_value | 549–549 | text-xs text-ash font-mono |
| Sec9dcf513abc_N3290 | Sec9dcf513abc_N3283 | text | 549–549 | Original import: LIBS/UI/OPENDESIGN/atelier-conversation-20261017 |
| Sec9dcf513abc_N3291 | Sec9dcf513abc_N3283 | end_tag | 549–549 | end_tag  |
| Sec9dcf513abc_N3292 | Sec9dcf513abc_N3291 | tag_name | 549–549 | span |
| Sec9dcf513abc_N3293 | Sec9dcf513abc_N3276 | element | 550–553 | element  |
| Sec9dcf513abc_N3294 | Sec9dcf513abc_N3293 | start_tag | 550–550 | start_tag  |
| Sec9dcf513abc_N3295 | Sec9dcf513abc_N3294 | tag_name | 550–550 | a |
| Sec9dcf513abc_N3296 | Sec9dcf513abc_N3294 | attribute | 550–550 | attribute  |
| Sec9dcf513abc_N3297 | Sec9dcf513abc_N3296 | attribute_name | 550–550 | class |
| Sec9dcf513abc_N3298 | Sec9dcf513abc_N3296 | quoted_attribute_value | 550–550 | quoted_attribute_value  |
| Sec9dcf513abc_N3299 | Sec9dcf513abc_N3298 | attribute_value | 550–550 | py-2.5 px-5 rounded-lg bg-celestial-brass text-observatory font-semibold text-xs hover:bg-celestial-brass-hover transition-colors flex items-center space-x-1.5 |
| Sec9dcf513abc_N3300 | Sec9dcf513abc_N3294 | attribute | 550–550 | attribute  |
| Sec9dcf513abc_N3301 | Sec9dcf513abc_N3300 | attribute_name | 550–550 | href |
| Sec9dcf513abc_N3302 | Sec9dcf513abc_N3300 | quoted_attribute_value | 550–550 | quoted_attribute_value  |
| Sec9dcf513abc_N3303 | Sec9dcf513abc_N3302 | attribute_value | 550–550 | #atelier |
| Sec9dcf513abc_N3304 | Sec9dcf513abc_N3294 | attribute | 550–550 | attribute  |
| Sec9dcf513abc_N3305 | Sec9dcf513abc_N3304 | attribute_name | 550–550 | id |
| Sec9dcf513abc_N3306 | Sec9dcf513abc_N3304 | quoted_attribute_value | 550–550 | quoted_attribute_value  |
| Sec9dcf513abc_N3307 | Sec9dcf513abc_N3306 | attribute_value | 550–550 | open-atelier |
| Sec9dcf513abc_N3308 | Sec9dcf513abc_N3294 | attribute | 550–550 | attribute  |
| Sec9dcf513abc_N3309 | Sec9dcf513abc_N3308 | attribute_name | 550–550 | onclick |
| Sec9dcf513abc_N3310 | Sec9dcf513abc_N3308 | quoted_attribute_value | 550–550 | quoted_attribute_value  |
| Sec9dcf513abc_N3311 | Sec9dcf513abc_N3310 | attribute_value | 550–550 | simulateQuoteNotice('Navigating to imported OpenDesign atelier view. Audio/ephemeris remain in preview mode.'); return false; |
| Sec9dcf513abc_N3312 | Sec9dcf513abc_N3293 | element | 551–551 | element  |
| Sec9dcf513abc_N3313 | Sec9dcf513abc_N3312 | start_tag | 551–551 | start_tag  |
| Sec9dcf513abc_N3314 | Sec9dcf513abc_N3313 | tag_name | 551–551 | span |
| Sec9dcf513abc_N3315 | Sec9dcf513abc_N3312 | text | 551–551 | Enter conversational atelier |
| Sec9dcf513abc_N3316 | Sec9dcf513abc_N3312 | end_tag | 551–551 | end_tag  |
| Sec9dcf513abc_N3317 | Sec9dcf513abc_N3316 | tag_name | 551–551 | span |
| Sec9dcf513abc_N3318 | Sec9dcf513abc_N3293 | element | 552–552 | element  |
| Sec9dcf513abc_N3319 | Sec9dcf513abc_N3318 | start_tag | 552–552 | start_tag  |
| Sec9dcf513abc_N3320 | Sec9dcf513abc_N3319 | tag_name | 552–552 | span |
| Sec9dcf513abc_N3321 | Sec9dcf513abc_N3318 | text | 552–552 | → |
| Sec9dcf513abc_N3322 | Sec9dcf513abc_N3318 | end_tag | 552–552 | end_tag  |
| Sec9dcf513abc_N3323 | Sec9dcf513abc_N3322 | tag_name | 552–552 | span |
| Sec9dcf513abc_N3324 | Sec9dcf513abc_N3293 | end_tag | 553–553 | end_tag  |
| Sec9dcf513abc_N3325 | Sec9dcf513abc_N3324 | tag_name | 553–553 | a |
| Sec9dcf513abc_N3326 | Sec9dcf513abc_N3276 | end_tag | 554–554 | end_tag  |
| Sec9dcf513abc_N3327 | Sec9dcf513abc_N3326 | tag_name | 554–554 | div |
| Sec9dcf513abc_N3328 | Sec9dcf513abc_N3164 | end_tag | 555–555 | end_tag  |
| Sec9dcf513abc_N3329 | Sec9dcf513abc_N3328 | tag_name | 555–555 | div |
| Sec9dcf513abc_N3330 | Sec9dcf513abc_N3100 | end_tag | 556–556 | end_tag  |
| Sec9dcf513abc_N3331 | Sec9dcf513abc_N3330 | tag_name | 556–556 | div |
| Sec9dcf513abc_N3332 | Sec9dcf513abc_N1194 | end_tag | 557–557 | end_tag  |
| Sec9dcf513abc_N3333 | Sec9dcf513abc_N3332 | tag_name | 557–557 | section |
| Sec9dcf513abc_N3334 | Sec9dcf513abc_N453 | end_tag | 558–558 | end_tag  |
| Sec9dcf513abc_N3335 | Sec9dcf513abc_N3334 | tag_name | 558–558 | div |
| Sec9dcf513abc_N3336 | Sec9dcf513abc_N446 | end_tag | 559–559 | end_tag  |
| Sec9dcf513abc_N3337 | Sec9dcf513abc_N3336 | tag_name | 559–559 | main |
| Sec9dcf513abc_N3338 | Sec9dcf513abc_N189 | comment | 560–560 | &lt;!-- FOOTER --&gt; |
| Sec9dcf513abc_N3339 | Sec9dcf513abc_N189 | element | 561–571 | element  |
| Sec9dcf513abc_N3340 | Sec9dcf513abc_N3339 | start_tag | 561–561 | start_tag  |
| Sec9dcf513abc_N3341 | Sec9dcf513abc_N3340 | tag_name | 561–561 | footer |
| Sec9dcf513abc_N3342 | Sec9dcf513abc_N3340 | attribute | 561–561 | attribute  |
| Sec9dcf513abc_N3343 | Sec9dcf513abc_N3342 | attribute_name | 561–561 | class |
| Sec9dcf513abc_N3344 | Sec9dcf513abc_N3342 | quoted_attribute_value | 561–561 | quoted_attribute_value  |
| Sec9dcf513abc_N3345 | Sec9dcf513abc_N3344 | attribute_value | 561–561 | border-t border-hairline/60 bg-surface-dim py-6 mt-auto |
| Sec9dcf513abc_N3346 | Sec9dcf513abc_N3339 | element | 562–570 | element  |
| Sec9dcf513abc_N3347 | Sec9dcf513abc_N3346 | start_tag | 562–562 | start_tag  |
| Sec9dcf513abc_N3348 | Sec9dcf513abc_N3347 | tag_name | 562–562 | div |
| Sec9dcf513abc_N3349 | Sec9dcf513abc_N3347 | attribute | 562–562 | attribute  |
| Sec9dcf513abc_N3350 | Sec9dcf513abc_N3349 | attribute_name | 562–562 | class |
| Sec9dcf513abc_N3351 | Sec9dcf513abc_N3349 | quoted_attribute_value | 562–562 | quoted_attribute_value  |
| Sec9dcf513abc_N3352 | Sec9dcf513abc_N3351 | attribute_value | 562–562 | max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between text-xs text-ash gap-4 |
| Sec9dcf513abc_N3353 | Sec9dcf513abc_N3346 | element | 563–566 | element  |
| Sec9dcf513abc_N3354 | Sec9dcf513abc_N3353 | start_tag | 563–563 | start_tag  |
| Sec9dcf513abc_N3355 | Sec9dcf513abc_N3354 | tag_name | 563–563 | div |
| Sec9dcf513abc_N3356 | Sec9dcf513abc_N3354 | attribute | 563–563 | attribute  |
| Sec9dcf513abc_N3357 | Sec9dcf513abc_N3356 | attribute_name | 563–563 | class |
| Sec9dcf513abc_N3358 | Sec9dcf513abc_N3356 | quoted_attribute_value | 563–563 | quoted_attribute_value  |
| Sec9dcf513abc_N3359 | Sec9dcf513abc_N3358 | attribute_value | 563–563 | flex items-center space-x-3 |
| Sec9dcf513abc_N3360 | Sec9dcf513abc_N3353 | element | 564–564 | element  |
| Sec9dcf513abc_N3361 | Sec9dcf513abc_N3360 | start_tag | 564–564 | start_tag  |
| Sec9dcf513abc_N3362 | Sec9dcf513abc_N3361 | tag_name | 564–564 | span |
| Sec9dcf513abc_N3363 | Sec9dcf513abc_N3361 | attribute | 564–564 | attribute  |
| Sec9dcf513abc_N3364 | Sec9dcf513abc_N3363 | attribute_name | 564–564 | class |
| Sec9dcf513abc_N3365 | Sec9dcf513abc_N3363 | quoted_attribute_value | 564–564 | quoted_attribute_value  |
| Sec9dcf513abc_N3366 | Sec9dcf513abc_N3365 | attribute_value | 564–564 | font-display text-starlight font-semibold |
| Sec9dcf513abc_N3367 | Sec9dcf513abc_N3360 | text | 564–564 | Natally |
| Sec9dcf513abc_N3368 | Sec9dcf513abc_N3360 | end_tag | 564–564 | end_tag  |
| Sec9dcf513abc_N3369 | Sec9dcf513abc_N3368 | tag_name | 564–564 | span |
| Sec9dcf513abc_N3370 | Sec9dcf513abc_N3353 | element | 565–565 | element  |
| Sec9dcf513abc_N3371 | Sec9dcf513abc_N3370 | start_tag | 565–565 | start_tag  |
| Sec9dcf513abc_N3372 | Sec9dcf513abc_N3371 | tag_name | 565–565 | span |
| Sec9dcf513abc_N3373 | Sec9dcf513abc_N3371 | attribute | 565–565 | attribute  |
| Sec9dcf513abc_N3374 | Sec9dcf513abc_N3373 | attribute_name | 565–565 | class |
| Sec9dcf513abc_N3375 | Sec9dcf513abc_N3373 | quoted_attribute_value | 565–565 | quoted_attribute_value  |
| Sec9dcf513abc_N3376 | Sec9dcf513abc_N3375 | attribute_value | 565–565 | font-mono text-[11px] |
| Sec9dcf513abc_N3377 | Sec9dcf513abc_N3370 | text | 565–565 | natally-ai-studio · codex/revenuecat-alby-preview |
| Sec9dcf513abc_N3378 | Sec9dcf513abc_N3370 | end_tag | 565–565 | end_tag  |
| Sec9dcf513abc_N3379 | Sec9dcf513abc_N3378 | tag_name | 565–565 | span |
| Sec9dcf513abc_N3380 | Sec9dcf513abc_N3353 | end_tag | 566–566 | end_tag  |
| Sec9dcf513abc_N3381 | Sec9dcf513abc_N3380 | tag_name | 566–566 | div |
| Sec9dcf513abc_N3382 | Sec9dcf513abc_N3346 | element | 567–569 | element  |
| Sec9dcf513abc_N3383 | Sec9dcf513abc_N3382 | start_tag | 567–567 | start_tag  |
| Sec9dcf513abc_N3384 | Sec9dcf513abc_N3383 | tag_name | 567–567 | div |
| Sec9dcf513abc_N3385 | Sec9dcf513abc_N3383 | attribute | 567–567 | attribute  |
| Sec9dcf513abc_N3386 | Sec9dcf513abc_N3385 | attribute_name | 567–567 | class |
| Sec9dcf513abc_N3387 | Sec9dcf513abc_N3385 | quoted_attribute_value | 567–567 | quoted_attribute_value  |
| Sec9dcf513abc_N3388 | Sec9dcf513abc_N3387 | attribute_value | 567–567 | text-center sm:text-right font-mono text-[11px] |
| Sec9dcf513abc_N3389 | Sec9dcf513abc_N3382 | text | 568–568 | Branch design review · No live payment or inference settlement |
| Sec9dcf513abc_N3390 | Sec9dcf513abc_N3382 | end_tag | 569–569 | end_tag  |
| Sec9dcf513abc_N3391 | Sec9dcf513abc_N3390 | tag_name | 569–569 | div |
| Sec9dcf513abc_N3392 | Sec9dcf513abc_N3346 | end_tag | 570–570 | end_tag  |
| Sec9dcf513abc_N3393 | Sec9dcf513abc_N3392 | tag_name | 570–570 | div |
| Sec9dcf513abc_N3394 | Sec9dcf513abc_N3339 | end_tag | 571–571 | end_tag  |
| Sec9dcf513abc_N3395 | Sec9dcf513abc_N3394 | tag_name | 571–571 | footer |
| Sec9dcf513abc_N3396 | Sec9dcf513abc_N189 | comment | 572–572 | &lt;!-- SCRIPT FOR VIEW SWITCHING &amp; ACCESSIBLE NOTICES --&gt; |
| Sec9dcf513abc_N3397 | Sec9dcf513abc_N189 | script_element | 573–622 | script_element  |
| Sec9dcf513abc_N3398 | Sec9dcf513abc_N3397 | start_tag | 573–573 | start_tag  |
| Sec9dcf513abc_N3399 | Sec9dcf513abc_N3398 | tag_name | 573–573 | script |
| Sec9dcf513abc_N3400 | Sec9dcf513abc_N3397 | raw_text | 573–622 |      function switchView(viewName) {       // Hide all view sections       const sections = document.querySelectorAll('.view-section');       sections.forEach(sec =&gt; {         sec.classList.remove('active');       });        // Show target section       const targetSec = document.getElementById('section-' + viewName);       if (targetSec) {         targetSec.classList.add('active');       }        // Update active nav-tab style       const navTabs = document.querySelectorAll('.nav-tab');       navTabs.forEach(tab =&gt; {         tab.classList.remove('bg-raised-charcoal', 'text-celestial-brass', 'border', 'border-hairline/80');         tab.classList.add('text-ash');       });        const activeTab = document.getElementById('view-' + viewName);       if (activeTab) {         activeTab.classList.add('bg-raised-charcoal', 'text-celestial-brass', 'border', 'border-hairline/80');         activeTab.classList.remove('text-ash');       }        // Update ARIA status       const statusEl = document.getElementById('preview-status');       if (statusEl) {         statusEl.textContent = viewName.toUpperCase() + ' view active in design preview. Payments not connected.';       }        // Scroll to top of content on mobile       if (window.innerWidth &lt; 1024) {         const mainSection = document.querySelector('section');         if (mainSection) {           mainSection.scrollIntoView({ behavior: 'smooth' });         }       }     }      function simulateQuoteNotice(message) {       const statusEl = document.getElementById('preview-status');       if (statusEl) {         statusEl.textContent = message;       }       alert(message);     }    |
| Sec9dcf513abc_N3401 | Sec9dcf513abc_N3397 | end_tag | 622–622 | end_tag  |
| Sec9dcf513abc_N3402 | Sec9dcf513abc_N3401 | tag_name | 622–622 | script |
| Sec9dcf513abc_N3403 | Sec9dcf513abc_N3397 | program | 2–50 | program  |
| Sec9dcf513abc_N3404 | Sec9dcf513abc_N3403 | function_declaration | 2–41 | function_declaration switchView |
| Sec9dcf513abc_N3405 | Sec9dcf513abc_N3404 | identifier | 2–2 | switchView |
| Sec9dcf513abc_N3406 | Sec9dcf513abc_N3404 | formal_parameters | 2–2 | formal_parameters  |
| Sec9dcf513abc_N3407 | Sec9dcf513abc_N3406 | identifier | 2–2 | viewName |
| Sec9dcf513abc_N3408 | Sec9dcf513abc_N3404 | statement_block | 2–41 | statement_block  |
| Sec9dcf513abc_N3409 | Sec9dcf513abc_N3408 | comment | 3–3 | // Hide all view sections |
| Sec9dcf513abc_N3410 | Sec9dcf513abc_N3408 | lexical_declaration | 4–4 | lexical_declaration  |
| Sec9dcf513abc_N3411 | Sec9dcf513abc_N3410 | variable_declarator | 4–4 | variable_declarator sections |
| Sec9dcf513abc_N3412 | Sec9dcf513abc_N3411 | identifier | 4–4 | sections |
| Sec9dcf513abc_N3413 | Sec9dcf513abc_N3411 | call_expression | 4–4 | call_expression  |
| Sec9dcf513abc_N3414 | Sec9dcf513abc_N3413 | member_expression | 4–4 | member_expression  |
| Sec9dcf513abc_N3415 | Sec9dcf513abc_N3414 | identifier | 4–4 | document |
| Sec9dcf513abc_N3416 | Sec9dcf513abc_N3414 | property_identifier | 4–4 | querySelectorAll |
| Sec9dcf513abc_N3417 | Sec9dcf513abc_N3413 | arguments | 4–4 | arguments  |
| Sec9dcf513abc_N3418 | Sec9dcf513abc_N3417 | string | 4–4 | string  |
| Sec9dcf513abc_N3419 | Sec9dcf513abc_N3418 | string_fragment | 4–4 | .view-section |
| Sec9dcf513abc_N3420 | Sec9dcf513abc_N3408 | expression_statement | 5–7 | expression_statement  |
| Sec9dcf513abc_N3421 | Sec9dcf513abc_N3420 | call_expression | 5–7 | call_expression  |
| Sec9dcf513abc_N3422 | Sec9dcf513abc_N3421 | member_expression | 5–5 | member_expression  |
| Sec9dcf513abc_N3423 | Sec9dcf513abc_N3422 | identifier | 5–5 | sections |
| Sec9dcf513abc_N3424 | Sec9dcf513abc_N3422 | property_identifier | 5–5 | forEach |
| Sec9dcf513abc_N3425 | Sec9dcf513abc_N3421 | arguments | 5–7 | arguments  |
| Sec9dcf513abc_N3426 | Sec9dcf513abc_N3425 | arrow_function | 5–7 | arrow_function  |
| Sec9dcf513abc_N3427 | Sec9dcf513abc_N3426 | identifier | 5–5 | sec |
| Sec9dcf513abc_N3428 | Sec9dcf513abc_N3426 | statement_block | 5–7 | statement_block  |
| Sec9dcf513abc_N3429 | Sec9dcf513abc_N3428 | expression_statement | 6–6 | expression_statement  |
| Sec9dcf513abc_N3430 | Sec9dcf513abc_N3429 | call_expression | 6–6 | call_expression  |
| Sec9dcf513abc_N3431 | Sec9dcf513abc_N3430 | member_expression | 6–6 | member_expression  |
| Sec9dcf513abc_N3432 | Sec9dcf513abc_N3431 | member_expression | 6–6 | member_expression  |
| Sec9dcf513abc_N3433 | Sec9dcf513abc_N3432 | identifier | 6–6 | sec |
| Sec9dcf513abc_N3434 | Sec9dcf513abc_N3432 | property_identifier | 6–6 | classList |
| Sec9dcf513abc_N3435 | Sec9dcf513abc_N3431 | property_identifier | 6–6 | remove |
| Sec9dcf513abc_N3436 | Sec9dcf513abc_N3430 | arguments | 6–6 | arguments  |
| Sec9dcf513abc_N3437 | Sec9dcf513abc_N3436 | string | 6–6 | string  |
| Sec9dcf513abc_N3438 | Sec9dcf513abc_N3437 | string_fragment | 6–6 | active |
| Sec9dcf513abc_N3439 | Sec9dcf513abc_N3408 | comment | 9–9 | // Show target section |
| Sec9dcf513abc_N3440 | Sec9dcf513abc_N3408 | lexical_declaration | 10–10 | lexical_declaration  |
| Sec9dcf513abc_N3441 | Sec9dcf513abc_N3440 | variable_declarator | 10–10 | variable_declarator targetSec |
| Sec9dcf513abc_N3442 | Sec9dcf513abc_N3441 | identifier | 10–10 | targetSec |
| Sec9dcf513abc_N3443 | Sec9dcf513abc_N3441 | call_expression | 10–10 | call_expression  |
| Sec9dcf513abc_N3444 | Sec9dcf513abc_N3443 | member_expression | 10–10 | member_expression  |
| Sec9dcf513abc_N3445 | Sec9dcf513abc_N3444 | identifier | 10–10 | document |
| Sec9dcf513abc_N3446 | Sec9dcf513abc_N3444 | property_identifier | 10–10 | getElementById |
| Sec9dcf513abc_N3447 | Sec9dcf513abc_N3443 | arguments | 10–10 | arguments  |
| Sec9dcf513abc_N3448 | Sec9dcf513abc_N3447 | binary_expression | 10–10 | binary_expression  |
| Sec9dcf513abc_N3449 | Sec9dcf513abc_N3448 | string | 10–10 | string  |
| Sec9dcf513abc_N3450 | Sec9dcf513abc_N3449 | string_fragment | 10–10 | section- |
| Sec9dcf513abc_N3451 | Sec9dcf513abc_N3448 | identifier | 10–10 | viewName |
| Sec9dcf513abc_N3452 | Sec9dcf513abc_N3408 | if_statement | 11–13 | if_statement  |
| Sec9dcf513abc_N3453 | Sec9dcf513abc_N3452 | parenthesized_expression | 11–11 | parenthesized_expression  |
| Sec9dcf513abc_N3454 | Sec9dcf513abc_N3453 | identifier | 11–11 | targetSec |
| Sec9dcf513abc_N3455 | Sec9dcf513abc_N3452 | statement_block | 11–13 | statement_block  |
| Sec9dcf513abc_N3456 | Sec9dcf513abc_N3455 | expression_statement | 12–12 | expression_statement  |
| Sec9dcf513abc_N3457 | Sec9dcf513abc_N3456 | call_expression | 12–12 | call_expression  |
| Sec9dcf513abc_N3458 | Sec9dcf513abc_N3457 | member_expression | 12–12 | member_expression  |
| Sec9dcf513abc_N3459 | Sec9dcf513abc_N3458 | member_expression | 12–12 | member_expression  |
| Sec9dcf513abc_N3460 | Sec9dcf513abc_N3459 | identifier | 12–12 | targetSec |
| Sec9dcf513abc_N3461 | Sec9dcf513abc_N3459 | property_identifier | 12–12 | classList |
| Sec9dcf513abc_N3462 | Sec9dcf513abc_N3458 | property_identifier | 12–12 | add |
| Sec9dcf513abc_N3463 | Sec9dcf513abc_N3457 | arguments | 12–12 | arguments  |
| Sec9dcf513abc_N3464 | Sec9dcf513abc_N3463 | string | 12–12 | string  |
| Sec9dcf513abc_N3465 | Sec9dcf513abc_N3464 | string_fragment | 12–12 | active |
| Sec9dcf513abc_N3466 | Sec9dcf513abc_N3408 | comment | 15–15 | // Update active nav-tab style |
| Sec9dcf513abc_N3467 | Sec9dcf513abc_N3408 | lexical_declaration | 16–16 | lexical_declaration  |
| Sec9dcf513abc_N3468 | Sec9dcf513abc_N3467 | variable_declarator | 16–16 | variable_declarator navTabs |
| Sec9dcf513abc_N3469 | Sec9dcf513abc_N3468 | identifier | 16–16 | navTabs |
| Sec9dcf513abc_N3470 | Sec9dcf513abc_N3468 | call_expression | 16–16 | call_expression  |
| Sec9dcf513abc_N3471 | Sec9dcf513abc_N3470 | member_expression | 16–16 | member_expression  |
| Sec9dcf513abc_N3472 | Sec9dcf513abc_N3471 | identifier | 16–16 | document |
| Sec9dcf513abc_N3473 | Sec9dcf513abc_N3471 | property_identifier | 16–16 | querySelectorAll |
| Sec9dcf513abc_N3474 | Sec9dcf513abc_N3470 | arguments | 16–16 | arguments  |
| Sec9dcf513abc_N3475 | Sec9dcf513abc_N3474 | string | 16–16 | string  |
| Sec9dcf513abc_N3476 | Sec9dcf513abc_N3475 | string_fragment | 16–16 | .nav-tab |
| Sec9dcf513abc_N3477 | Sec9dcf513abc_N3408 | expression_statement | 17–20 | expression_statement  |
| Sec9dcf513abc_N3478 | Sec9dcf513abc_N3477 | call_expression | 17–20 | call_expression  |
| Sec9dcf513abc_N3479 | Sec9dcf513abc_N3478 | member_expression | 17–17 | member_expression  |
| Sec9dcf513abc_N3480 | Sec9dcf513abc_N3479 | identifier | 17–17 | navTabs |
| Sec9dcf513abc_N3481 | Sec9dcf513abc_N3479 | property_identifier | 17–17 | forEach |
| Sec9dcf513abc_N3482 | Sec9dcf513abc_N3478 | arguments | 17–20 | arguments  |
| Sec9dcf513abc_N3483 | Sec9dcf513abc_N3482 | arrow_function | 17–20 | arrow_function  |
| Sec9dcf513abc_N3484 | Sec9dcf513abc_N3483 | identifier | 17–17 | tab |
| Sec9dcf513abc_N3485 | Sec9dcf513abc_N3483 | statement_block | 17–20 | statement_block  |
| Sec9dcf513abc_N3486 | Sec9dcf513abc_N3485 | expression_statement | 18–18 | expression_statement  |
| Sec9dcf513abc_N3487 | Sec9dcf513abc_N3486 | call_expression | 18–18 | call_expression  |
| Sec9dcf513abc_N3488 | Sec9dcf513abc_N3487 | member_expression | 18–18 | member_expression  |
| Sec9dcf513abc_N3489 | Sec9dcf513abc_N3488 | member_expression | 18–18 | member_expression  |
| Sec9dcf513abc_N3490 | Sec9dcf513abc_N3489 | identifier | 18–18 | tab |
| Sec9dcf513abc_N3491 | Sec9dcf513abc_N3489 | property_identifier | 18–18 | classList |
| Sec9dcf513abc_N3492 | Sec9dcf513abc_N3488 | property_identifier | 18–18 | remove |
| Sec9dcf513abc_N3493 | Sec9dcf513abc_N3487 | arguments | 18–18 | arguments  |
| Sec9dcf513abc_N3494 | Sec9dcf513abc_N3493 | string | 18–18 | string  |
| Sec9dcf513abc_N3495 | Sec9dcf513abc_N3494 | string_fragment | 18–18 | bg-raised-charcoal |
| Sec9dcf513abc_N3496 | Sec9dcf513abc_N3493 | string | 18–18 | string  |
| Sec9dcf513abc_N3497 | Sec9dcf513abc_N3496 | string_fragment | 18–18 | text-celestial-brass |
| Sec9dcf513abc_N3498 | Sec9dcf513abc_N3493 | string | 18–18 | string  |
| Sec9dcf513abc_N3499 | Sec9dcf513abc_N3498 | string_fragment | 18–18 | border |
| Sec9dcf513abc_N3500 | Sec9dcf513abc_N3493 | string | 18–18 | string  |
| Sec9dcf513abc_N3501 | Sec9dcf513abc_N3500 | string_fragment | 18–18 | border-hairline/80 |
| Sec9dcf513abc_N3502 | Sec9dcf513abc_N3485 | expression_statement | 19–19 | expression_statement  |
| Sec9dcf513abc_N3503 | Sec9dcf513abc_N3502 | call_expression | 19–19 | call_expression  |
| Sec9dcf513abc_N3504 | Sec9dcf513abc_N3503 | member_expression | 19–19 | member_expression  |
| Sec9dcf513abc_N3505 | Sec9dcf513abc_N3504 | member_expression | 19–19 | member_expression  |
| Sec9dcf513abc_N3506 | Sec9dcf513abc_N3505 | identifier | 19–19 | tab |
| Sec9dcf513abc_N3507 | Sec9dcf513abc_N3505 | property_identifier | 19–19 | classList |
| Sec9dcf513abc_N3508 | Sec9dcf513abc_N3504 | property_identifier | 19–19 | add |
| Sec9dcf513abc_N3509 | Sec9dcf513abc_N3503 | arguments | 19–19 | arguments  |
| Sec9dcf513abc_N3510 | Sec9dcf513abc_N3509 | string | 19–19 | string  |
| Sec9dcf513abc_N3511 | Sec9dcf513abc_N3510 | string_fragment | 19–19 | text-ash |
| Sec9dcf513abc_N3512 | Sec9dcf513abc_N3408 | lexical_declaration | 22–22 | lexical_declaration  |
| Sec9dcf513abc_N3513 | Sec9dcf513abc_N3512 | variable_declarator | 22–22 | variable_declarator activeTab |
| Sec9dcf513abc_N3514 | Sec9dcf513abc_N3513 | identifier | 22–22 | activeTab |
| Sec9dcf513abc_N3515 | Sec9dcf513abc_N3513 | call_expression | 22–22 | call_expression  |
| Sec9dcf513abc_N3516 | Sec9dcf513abc_N3515 | member_expression | 22–22 | member_expression  |
| Sec9dcf513abc_N3517 | Sec9dcf513abc_N3516 | identifier | 22–22 | document |
| Sec9dcf513abc_N3518 | Sec9dcf513abc_N3516 | property_identifier | 22–22 | getElementById |
| Sec9dcf513abc_N3519 | Sec9dcf513abc_N3515 | arguments | 22–22 | arguments  |
| Sec9dcf513abc_N3520 | Sec9dcf513abc_N3519 | binary_expression | 22–22 | binary_expression  |
| Sec9dcf513abc_N3521 | Sec9dcf513abc_N3520 | string | 22–22 | string  |
| Sec9dcf513abc_N3522 | Sec9dcf513abc_N3521 | string_fragment | 22–22 | view- |
| Sec9dcf513abc_N3523 | Sec9dcf513abc_N3520 | identifier | 22–22 | viewName |
| Sec9dcf513abc_N3524 | Sec9dcf513abc_N3408 | if_statement | 23–26 | if_statement  |
| Sec9dcf513abc_N3525 | Sec9dcf513abc_N3524 | parenthesized_expression | 23–23 | parenthesized_expression  |
| Sec9dcf513abc_N3526 | Sec9dcf513abc_N3525 | identifier | 23–23 | activeTab |
| Sec9dcf513abc_N3527 | Sec9dcf513abc_N3524 | statement_block | 23–26 | statement_block  |
| Sec9dcf513abc_N3528 | Sec9dcf513abc_N3527 | expression_statement | 24–24 | expression_statement  |
| Sec9dcf513abc_N3529 | Sec9dcf513abc_N3528 | call_expression | 24–24 | call_expression  |
| Sec9dcf513abc_N3530 | Sec9dcf513abc_N3529 | member_expression | 24–24 | member_expression  |
| Sec9dcf513abc_N3531 | Sec9dcf513abc_N3530 | member_expression | 24–24 | member_expression  |
| Sec9dcf513abc_N3532 | Sec9dcf513abc_N3531 | identifier | 24–24 | activeTab |
| Sec9dcf513abc_N3533 | Sec9dcf513abc_N3531 | property_identifier | 24–24 | classList |
| Sec9dcf513abc_N3534 | Sec9dcf513abc_N3530 | property_identifier | 24–24 | add |
| Sec9dcf513abc_N3535 | Sec9dcf513abc_N3529 | arguments | 24–24 | arguments  |
| Sec9dcf513abc_N3536 | Sec9dcf513abc_N3535 | string | 24–24 | string  |
| Sec9dcf513abc_N3537 | Sec9dcf513abc_N3536 | string_fragment | 24–24 | bg-raised-charcoal |
| Sec9dcf513abc_N3538 | Sec9dcf513abc_N3535 | string | 24–24 | string  |
| Sec9dcf513abc_N3539 | Sec9dcf513abc_N3538 | string_fragment | 24–24 | text-celestial-brass |
| Sec9dcf513abc_N3540 | Sec9dcf513abc_N3535 | string | 24–24 | string  |
| Sec9dcf513abc_N3541 | Sec9dcf513abc_N3540 | string_fragment | 24–24 | border |
| Sec9dcf513abc_N3542 | Sec9dcf513abc_N3535 | string | 24–24 | string  |
| Sec9dcf513abc_N3543 | Sec9dcf513abc_N3542 | string_fragment | 24–24 | border-hairline/80 |
| Sec9dcf513abc_N3544 | Sec9dcf513abc_N3527 | expression_statement | 25–25 | expression_statement  |
| Sec9dcf513abc_N3545 | Sec9dcf513abc_N3544 | call_expression | 25–25 | call_expression  |
| Sec9dcf513abc_N3546 | Sec9dcf513abc_N3545 | member_expression | 25–25 | member_expression  |
| Sec9dcf513abc_N3547 | Sec9dcf513abc_N3546 | member_expression | 25–25 | member_expression  |
| Sec9dcf513abc_N3548 | Sec9dcf513abc_N3547 | identifier | 25–25 | activeTab |
| Sec9dcf513abc_N3549 | Sec9dcf513abc_N3547 | property_identifier | 25–25 | classList |
| Sec9dcf513abc_N3550 | Sec9dcf513abc_N3546 | property_identifier | 25–25 | remove |
| Sec9dcf513abc_N3551 | Sec9dcf513abc_N3545 | arguments | 25–25 | arguments  |
| Sec9dcf513abc_N3552 | Sec9dcf513abc_N3551 | string | 25–25 | string  |
| Sec9dcf513abc_N3553 | Sec9dcf513abc_N3552 | string_fragment | 25–25 | text-ash |
| Sec9dcf513abc_N3554 | Sec9dcf513abc_N3408 | comment | 28–28 | // Update ARIA status |
| Sec9dcf513abc_N3555 | Sec9dcf513abc_N3408 | lexical_declaration | 29–29 | lexical_declaration  |
| Sec9dcf513abc_N3556 | Sec9dcf513abc_N3555 | variable_declarator | 29–29 | variable_declarator statusEl |
| Sec9dcf513abc_N3557 | Sec9dcf513abc_N3556 | identifier | 29–29 | statusEl |
| Sec9dcf513abc_N3558 | Sec9dcf513abc_N3556 | call_expression | 29–29 | call_expression  |
| Sec9dcf513abc_N3559 | Sec9dcf513abc_N3558 | member_expression | 29–29 | member_expression  |
| Sec9dcf513abc_N3560 | Sec9dcf513abc_N3559 | identifier | 29–29 | document |
| Sec9dcf513abc_N3561 | Sec9dcf513abc_N3559 | property_identifier | 29–29 | getElementById |
| Sec9dcf513abc_N3562 | Sec9dcf513abc_N3558 | arguments | 29–29 | arguments  |
| Sec9dcf513abc_N3563 | Sec9dcf513abc_N3562 | string | 29–29 | string  |
| Sec9dcf513abc_N3564 | Sec9dcf513abc_N3563 | string_fragment | 29–29 | preview-status |
| Sec9dcf513abc_N3565 | Sec9dcf513abc_N3408 | if_statement | 30–32 | if_statement  |
| Sec9dcf513abc_N3566 | Sec9dcf513abc_N3565 | parenthesized_expression | 30–30 | parenthesized_expression  |
| Sec9dcf513abc_N3567 | Sec9dcf513abc_N3566 | identifier | 30–30 | statusEl |
| Sec9dcf513abc_N3568 | Sec9dcf513abc_N3565 | statement_block | 30–32 | statement_block  |
| Sec9dcf513abc_N3569 | Sec9dcf513abc_N3568 | expression_statement | 31–31 | expression_statement  |
| Sec9dcf513abc_N3570 | Sec9dcf513abc_N3569 | assignment_expression | 31–31 | assignment_expression  |
| Sec9dcf513abc_N3571 | Sec9dcf513abc_N3570 | member_expression | 31–31 | member_expression  |
| Sec9dcf513abc_N3572 | Sec9dcf513abc_N3571 | identifier | 31–31 | statusEl |
| Sec9dcf513abc_N3573 | Sec9dcf513abc_N3571 | property_identifier | 31–31 | textContent |
| Sec9dcf513abc_N3574 | Sec9dcf513abc_N3570 | binary_expression | 31–31 | binary_expression  |
| Sec9dcf513abc_N3575 | Sec9dcf513abc_N3574 | call_expression | 31–31 | call_expression  |
| Sec9dcf513abc_N3576 | Sec9dcf513abc_N3575 | member_expression | 31–31 | member_expression  |
| Sec9dcf513abc_N3577 | Sec9dcf513abc_N3576 | identifier | 31–31 | viewName |
| Sec9dcf513abc_N3578 | Sec9dcf513abc_N3576 | property_identifier | 31–31 | toUpperCase |
| Sec9dcf513abc_N3579 | Sec9dcf513abc_N3575 | arguments | 31–31 | () |
| Sec9dcf513abc_N3580 | Sec9dcf513abc_N3574 | string | 31–31 | string  |
| Sec9dcf513abc_N3581 | Sec9dcf513abc_N3580 | string_fragment | 31–31 |  view active in design preview. Payments not connected. |
| Sec9dcf513abc_N3582 | Sec9dcf513abc_N3408 | comment | 34–34 | // Scroll to top of content on mobile |
| Sec9dcf513abc_N3583 | Sec9dcf513abc_N3408 | if_statement | 35–40 | if_statement  |
| Sec9dcf513abc_N3584 | Sec9dcf513abc_N3583 | parenthesized_expression | 35–35 | parenthesized_expression  |
| Sec9dcf513abc_N3585 | Sec9dcf513abc_N3584 | binary_expression | 35–35 | binary_expression  |
| Sec9dcf513abc_N3586 | Sec9dcf513abc_N3585 | member_expression | 35–35 | member_expression  |
| Sec9dcf513abc_N3587 | Sec9dcf513abc_N3586 | identifier | 35–35 | window |
| Sec9dcf513abc_N3588 | Sec9dcf513abc_N3586 | property_identifier | 35–35 | innerWidth |
| Sec9dcf513abc_N3589 | Sec9dcf513abc_N3585 | number | 35–35 | 1024 |
| Sec9dcf513abc_N3590 | Sec9dcf513abc_N3583 | statement_block | 35–40 | statement_block  |
| Sec9dcf513abc_N3591 | Sec9dcf513abc_N3590 | lexical_declaration | 36–36 | lexical_declaration  |
| Sec9dcf513abc_N3592 | Sec9dcf513abc_N3591 | variable_declarator | 36–36 | variable_declarator mainSection |
| Sec9dcf513abc_N3593 | Sec9dcf513abc_N3592 | identifier | 36–36 | mainSection |
| Sec9dcf513abc_N3594 | Sec9dcf513abc_N3592 | call_expression | 36–36 | call_expression  |
| Sec9dcf513abc_N3595 | Sec9dcf513abc_N3594 | member_expression | 36–36 | member_expression  |
| Sec9dcf513abc_N3596 | Sec9dcf513abc_N3595 | identifier | 36–36 | document |
| Sec9dcf513abc_N3597 | Sec9dcf513abc_N3595 | property_identifier | 36–36 | querySelector |
| Sec9dcf513abc_N3598 | Sec9dcf513abc_N3594 | arguments | 36–36 | arguments  |
| Sec9dcf513abc_N3599 | Sec9dcf513abc_N3598 | string | 36–36 | string  |
| Sec9dcf513abc_N3600 | Sec9dcf513abc_N3599 | string_fragment | 36–36 | section |
| Sec9dcf513abc_N3601 | Sec9dcf513abc_N3590 | if_statement | 37–39 | if_statement  |
| Sec9dcf513abc_N3602 | Sec9dcf513abc_N3601 | parenthesized_expression | 37–37 | parenthesized_expression  |
| Sec9dcf513abc_N3603 | Sec9dcf513abc_N3602 | identifier | 37–37 | mainSection |
| Sec9dcf513abc_N3604 | Sec9dcf513abc_N3601 | statement_block | 37–39 | statement_block  |
| Sec9dcf513abc_N3605 | Sec9dcf513abc_N3604 | expression_statement | 38–38 | expression_statement  |
| Sec9dcf513abc_N3606 | Sec9dcf513abc_N3605 | call_expression | 38–38 | call_expression  |
| Sec9dcf513abc_N3607 | Sec9dcf513abc_N3606 | member_expression | 38–38 | member_expression  |
| Sec9dcf513abc_N3608 | Sec9dcf513abc_N3607 | identifier | 38–38 | mainSection |
| Sec9dcf513abc_N3609 | Sec9dcf513abc_N3607 | property_identifier | 38–38 | scrollIntoView |
| Sec9dcf513abc_N3610 | Sec9dcf513abc_N3606 | arguments | 38–38 | arguments  |
| Sec9dcf513abc_N3611 | Sec9dcf513abc_N3610 | object | 38–38 | object  |
| Sec9dcf513abc_N3612 | Sec9dcf513abc_N3611 | pair | 38–38 | pair  |
| Sec9dcf513abc_N3613 | Sec9dcf513abc_N3612 | property_identifier | 38–38 | behavior |
| Sec9dcf513abc_N3614 | Sec9dcf513abc_N3612 | string | 38–38 | string  |
| Sec9dcf513abc_N3615 | Sec9dcf513abc_N3614 | string_fragment | 38–38 | smooth |
| Sec9dcf513abc_N3616 | Sec9dcf513abc_N3403 | function_declaration | 43–49 | function_declaration simulateQuoteNotice |
| Sec9dcf513abc_N3617 | Sec9dcf513abc_N3616 | identifier | 43–43 | simulateQuoteNotice |
| Sec9dcf513abc_N3618 | Sec9dcf513abc_N3616 | formal_parameters | 43–43 | formal_parameters  |
| Sec9dcf513abc_N3619 | Sec9dcf513abc_N3618 | identifier | 43–43 | message |
| Sec9dcf513abc_N3620 | Sec9dcf513abc_N3616 | statement_block | 43–49 | statement_block  |
| Sec9dcf513abc_N3621 | Sec9dcf513abc_N3620 | lexical_declaration | 44–44 | lexical_declaration  |
| Sec9dcf513abc_N3622 | Sec9dcf513abc_N3621 | variable_declarator | 44–44 | variable_declarator statusEl |
| Sec9dcf513abc_N3623 | Sec9dcf513abc_N3622 | identifier | 44–44 | statusEl |
| Sec9dcf513abc_N3624 | Sec9dcf513abc_N3622 | call_expression | 44–44 | call_expression  |
| Sec9dcf513abc_N3625 | Sec9dcf513abc_N3624 | member_expression | 44–44 | member_expression  |
| Sec9dcf513abc_N3626 | Sec9dcf513abc_N3625 | identifier | 44–44 | document |
| Sec9dcf513abc_N3627 | Sec9dcf513abc_N3625 | property_identifier | 44–44 | getElementById |
| Sec9dcf513abc_N3628 | Sec9dcf513abc_N3624 | arguments | 44–44 | arguments  |
| Sec9dcf513abc_N3629 | Sec9dcf513abc_N3628 | string | 44–44 | string  |
| Sec9dcf513abc_N3630 | Sec9dcf513abc_N3629 | string_fragment | 44–44 | preview-status |
| Sec9dcf513abc_N3631 | Sec9dcf513abc_N3620 | if_statement | 45–47 | if_statement  |
| Sec9dcf513abc_N3632 | Sec9dcf513abc_N3631 | parenthesized_expression | 45–45 | parenthesized_expression  |
| Sec9dcf513abc_N3633 | Sec9dcf513abc_N3632 | identifier | 45–45 | statusEl |
| Sec9dcf513abc_N3634 | Sec9dcf513abc_N3631 | statement_block | 45–47 | statement_block  |
| Sec9dcf513abc_N3635 | Sec9dcf513abc_N3634 | expression_statement | 46–46 | expression_statement  |
| Sec9dcf513abc_N3636 | Sec9dcf513abc_N3635 | assignment_expression | 46–46 | assignment_expression  |
| Sec9dcf513abc_N3637 | Sec9dcf513abc_N3636 | member_expression | 46–46 | member_expression  |
| Sec9dcf513abc_N3638 | Sec9dcf513abc_N3637 | identifier | 46–46 | statusEl |
| Sec9dcf513abc_N3639 | Sec9dcf513abc_N3637 | property_identifier | 46–46 | textContent |
| Sec9dcf513abc_N3640 | Sec9dcf513abc_N3636 | identifier | 46–46 | message |
| Sec9dcf513abc_N3641 | Sec9dcf513abc_N3620 | expression_statement | 48–48 | expression_statement  |
| Sec9dcf513abc_N3642 | Sec9dcf513abc_N3641 | call_expression | 48–48 | call_expression  |
| Sec9dcf513abc_N3643 | Sec9dcf513abc_N3642 | identifier | 48–48 | alert |
| Sec9dcf513abc_N3644 | Sec9dcf513abc_N3642 | arguments | 48–48 | arguments  |
| Sec9dcf513abc_N3645 | Sec9dcf513abc_N3644 | identifier | 48–48 | message |
| Sec9dcf513abc_N3646 | Sec9dcf513abc_N189 | end_tag | 623–623 | end_tag  |
| Sec9dcf513abc_N3647 | Sec9dcf513abc_N3646 | tag_name | 623–623 | body |
| Sec9dcf513abc_N3648 | Sec9dcf513abc_N3 | end_tag | 624–624 | end_tag  |
| Sec9dcf513abc_N3649 | Sec9dcf513abc_N3648 | tag_name | 624–624 | html |