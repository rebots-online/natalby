# DOCS/verification/firestore-intake-before-login-first.json

Source SHA-256: c0d0bc818e1dafc026ec08c6e5ac44912619c1d3997567eb3bb46d0215e22eba

| ID | Parent | Syntax kind | Lines | Source text |
| --- | --- | --- | --- | --- |
| S9b03e0dcedc7_N1 | — | document | 1–8 | document  |
| S9b03e0dcedc7_N2 | S9b03e0dcedc7_N1 | object | 1–7 | object  |
| S9b03e0dcedc7_N3 | S9b03e0dcedc7_N2 | pair | 2–2 | pair  |
| S9b03e0dcedc7_N4 | S9b03e0dcedc7_N3 | string | 2–2 | string  |
| S9b03e0dcedc7_N5 | S9b03e0dcedc7_N4 | string_content | 2–2 | release |
| S9b03e0dcedc7_N6 | S9b03e0dcedc7_N3 | string | 2–2 | string  |
| S9b03e0dcedc7_N7 | S9b03e0dcedc7_N6 | string_content | 2–2 | projects/gen-lang-client-0714568880/releases/cloud.firestore/ai-studio-remixastrosphere-1ee57c33-6487-411a-a872-59fbf4cbfc63 |
| S9b03e0dcedc7_N8 | S9b03e0dcedc7_N2 | pair | 3–3 | pair  |
| S9b03e0dcedc7_N9 | S9b03e0dcedc7_N8 | string | 3–3 | string  |
| S9b03e0dcedc7_N10 | S9b03e0dcedc7_N9 | string_content | 3–3 | previous_ruleset |
| S9b03e0dcedc7_N11 | S9b03e0dcedc7_N8 | string | 3–3 | string  |
| S9b03e0dcedc7_N12 | S9b03e0dcedc7_N11 | string_content | 3–3 | projects/gen-lang-client-0714568880/rulesets/221b78e8-2d9c-4c17-a54d-57f374cbeacc |
| S9b03e0dcedc7_N13 | S9b03e0dcedc7_N2 | pair | 4–4 | pair  |
| S9b03e0dcedc7_N14 | S9b03e0dcedc7_N13 | string | 4–4 | string  |
| S9b03e0dcedc7_N15 | S9b03e0dcedc7_N14 | string_content | 4–4 | previous_update_time |
| S9b03e0dcedc7_N16 | S9b03e0dcedc7_N13 | string | 4–4 | string  |
| S9b03e0dcedc7_N17 | S9b03e0dcedc7_N16 | string_content | 4–4 | 2026-10-09T18:06:50.335038Z |
| S9b03e0dcedc7_N18 | S9b03e0dcedc7_N2 | pair | 5–5 | pair  |
| S9b03e0dcedc7_N19 | S9b03e0dcedc7_N18 | string | 5–5 | string  |
| S9b03e0dcedc7_N20 | S9b03e0dcedc7_N19 | string_content | 5–5 | previous_source |
| S9b03e0dcedc7_N21 | S9b03e0dcedc7_N18 | string | 5–5 | string  |
| S9b03e0dcedc7_N22 | S9b03e0dcedc7_N21 | string_content | 5–5 | string_content  |
| S9b03e0dcedc7_N23 | S9b03e0dcedc7_N22 | escape_sequence | 5–5 | \n |
| S9b03e0dcedc7_N24 | S9b03e0dcedc7_N22 | escape_sequence | 5–5 | \n |
| S9b03e0dcedc7_N25 | S9b03e0dcedc7_N22 | escape_sequence | 5–5 | \n |
| S9b03e0dcedc7_N26 | S9b03e0dcedc7_N22 | escape_sequence | 5–5 | \n |
| S9b03e0dcedc7_N27 | S9b03e0dcedc7_N22 | escape_sequence | 5–5 | \n |
| S9b03e0dcedc7_N28 | S9b03e0dcedc7_N22 | escape_sequence | 5–5 | \n |
| S9b03e0dcedc7_N29 | S9b03e0dcedc7_N22 | escape_sequence | 5–5 | \n |
| S9b03e0dcedc7_N30 | S9b03e0dcedc7_N22 | escape_sequence | 5–5 | \n |
| S9b03e0dcedc7_N31 | S9b03e0dcedc7_N22 | escape_sequence | 5–5 | \n |
| S9b03e0dcedc7_N32 | S9b03e0dcedc7_N22 | escape_sequence | 5–5 | \n |
| S9b03e0dcedc7_N33 | S9b03e0dcedc7_N2 | pair | 6–6 | pair  |
| S9b03e0dcedc7_N34 | S9b03e0dcedc7_N33 | string | 6–6 | string  |
| S9b03e0dcedc7_N35 | S9b03e0dcedc7_N34 | string_content | 6–6 | rollback |
| S9b03e0dcedc7_N36 | S9b03e0dcedc7_N33 | string | 6–6 | string  |
| S9b03e0dcedc7_N37 | S9b03e0dcedc7_N36 | string_content | 6–6 | Set this named release rulesetName to previous_ruleset; never change other database releases. |