# LIBS/UI/STITCH/screens/prepaid_02_make_your_chart_interactive/code.html

Source SHA-256: fc1ebad04316a4d2c64578d12308b024da7f4d10e1813bcfdcac91ee945f381a

| ID | Parent | Syntax kind | Lines | Source text |
| --- | --- | --- | --- | --- |
| S1aa9c6beb27f_N1 | — | document | 1–341 | document  |
| S1aa9c6beb27f_N2 | S1aa9c6beb27f_N1 | doctype | 1–1 | &lt;!DOCTYPE html&gt; |
| S1aa9c6beb27f_N3 | S1aa9c6beb27f_N1 | element | 3–340 | element  |
| S1aa9c6beb27f_N4 | S1aa9c6beb27f_N3 | start_tag | 3–3 | start_tag  |
| S1aa9c6beb27f_N5 | S1aa9c6beb27f_N4 | tag_name | 3–3 | html |
| S1aa9c6beb27f_N6 | S1aa9c6beb27f_N4 | attribute | 3–3 | attribute  |
| S1aa9c6beb27f_N7 | S1aa9c6beb27f_N6 | attribute_name | 3–3 | class |
| S1aa9c6beb27f_N8 | S1aa9c6beb27f_N6 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S1aa9c6beb27f_N9 | S1aa9c6beb27f_N8 | attribute_value | 3–3 | dark |
| S1aa9c6beb27f_N10 | S1aa9c6beb27f_N4 | attribute | 3–3 | attribute  |
| S1aa9c6beb27f_N11 | S1aa9c6beb27f_N10 | attribute_name | 3–3 | lang |
| S1aa9c6beb27f_N12 | S1aa9c6beb27f_N10 | quoted_attribute_value | 3–3 | quoted_attribute_value  |
| S1aa9c6beb27f_N13 | S1aa9c6beb27f_N12 | attribute_value | 3–3 | en |
| S1aa9c6beb27f_N14 | S1aa9c6beb27f_N3 | element | 3–49 | element  |
| S1aa9c6beb27f_N15 | S1aa9c6beb27f_N14 | start_tag | 3–3 | start_tag  |
| S1aa9c6beb27f_N16 | S1aa9c6beb27f_N15 | tag_name | 3–3 | head |
| S1aa9c6beb27f_N17 | S1aa9c6beb27f_N14 | element | 4–4 | element  |
| S1aa9c6beb27f_N18 | S1aa9c6beb27f_N17 | self_closing_tag | 4–4 | self_closing_tag  |
| S1aa9c6beb27f_N19 | S1aa9c6beb27f_N18 | tag_name | 4–4 | meta |
| S1aa9c6beb27f_N20 | S1aa9c6beb27f_N18 | attribute | 4–4 | attribute  |
| S1aa9c6beb27f_N21 | S1aa9c6beb27f_N20 | attribute_name | 4–4 | charset |
| S1aa9c6beb27f_N22 | S1aa9c6beb27f_N20 | quoted_attribute_value | 4–4 | quoted_attribute_value  |
| S1aa9c6beb27f_N23 | S1aa9c6beb27f_N22 | attribute_value | 4–4 | utf-8 |
| S1aa9c6beb27f_N24 | S1aa9c6beb27f_N14 | element | 5–5 | element  |
| S1aa9c6beb27f_N25 | S1aa9c6beb27f_N24 | self_closing_tag | 5–5 | self_closing_tag  |
| S1aa9c6beb27f_N26 | S1aa9c6beb27f_N25 | tag_name | 5–5 | meta |
| S1aa9c6beb27f_N27 | S1aa9c6beb27f_N25 | attribute | 5–5 | attribute  |
| S1aa9c6beb27f_N28 | S1aa9c6beb27f_N27 | attribute_name | 5–5 | content |
| S1aa9c6beb27f_N29 | S1aa9c6beb27f_N27 | quoted_attribute_value | 5–5 | quoted_attribute_value  |
| S1aa9c6beb27f_N30 | S1aa9c6beb27f_N29 | attribute_value | 5–5 | width=device-width, initial-scale=1.0 |
| S1aa9c6beb27f_N31 | S1aa9c6beb27f_N25 | attribute | 5–5 | attribute  |
| S1aa9c6beb27f_N32 | S1aa9c6beb27f_N31 | attribute_name | 5–5 | name |
| S1aa9c6beb27f_N33 | S1aa9c6beb27f_N31 | quoted_attribute_value | 5–5 | quoted_attribute_value  |
| S1aa9c6beb27f_N34 | S1aa9c6beb27f_N33 | attribute_value | 5–5 | viewport |
| S1aa9c6beb27f_N35 | S1aa9c6beb27f_N14 | element | 6–6 | element  |
| S1aa9c6beb27f_N36 | S1aa9c6beb27f_N35 | self_closing_tag | 6–6 | self_closing_tag  |
| S1aa9c6beb27f_N37 | S1aa9c6beb27f_N36 | tag_name | 6–6 | meta |
| S1aa9c6beb27f_N38 | S1aa9c6beb27f_N36 | attribute | 6–6 | attribute  |
| S1aa9c6beb27f_N39 | S1aa9c6beb27f_N38 | attribute_name | 6–6 | content |
| S1aa9c6beb27f_N40 | S1aa9c6beb27f_N38 | quoted_attribute_value | 6–6 | quoted_attribute_value  |
| S1aa9c6beb27f_N41 | S1aa9c6beb27f_N40 | attribute_value | 6–6 | web_standard |
| S1aa9c6beb27f_N42 | S1aa9c6beb27f_N36 | attribute | 6–6 | attribute  |
| S1aa9c6beb27f_N43 | S1aa9c6beb27f_N42 | attribute_name | 6–6 | name |
| S1aa9c6beb27f_N44 | S1aa9c6beb27f_N42 | quoted_attribute_value | 6–6 | quoted_attribute_value  |
| S1aa9c6beb27f_N45 | S1aa9c6beb27f_N44 | attribute_value | 6–6 | shell-type |
| S1aa9c6beb27f_N46 | S1aa9c6beb27f_N14 | element | 7–7 | element  |
| S1aa9c6beb27f_N47 | S1aa9c6beb27f_N46 | start_tag | 7–7 | start_tag  |
| S1aa9c6beb27f_N48 | S1aa9c6beb27f_N47 | tag_name | 7–7 | title |
| S1aa9c6beb27f_N49 | S1aa9c6beb27f_N46 | text | 7–7 | PREPAID-02 · Make your chart interactive |
| S1aa9c6beb27f_N50 | S1aa9c6beb27f_N46 | end_tag | 7–7 | end_tag  |
| S1aa9c6beb27f_N51 | S1aa9c6beb27f_N50 | tag_name | 7–7 | title |
| S1aa9c6beb27f_N52 | S1aa9c6beb27f_N14 | element | 8–8 | element  |
| S1aa9c6beb27f_N53 | S1aa9c6beb27f_N52 | self_closing_tag | 8–8 | self_closing_tag  |
| S1aa9c6beb27f_N54 | S1aa9c6beb27f_N53 | tag_name | 8–8 | link |
| S1aa9c6beb27f_N55 | S1aa9c6beb27f_N53 | attribute | 8–8 | attribute  |
| S1aa9c6beb27f_N56 | S1aa9c6beb27f_N55 | attribute_name | 8–8 | href |
| S1aa9c6beb27f_N57 | S1aa9c6beb27f_N55 | quoted_attribute_value | 8–8 | quoted_attribute_value  |
| S1aa9c6beb27f_N58 | S1aa9c6beb27f_N57 | attribute_value | 8–8 | https://fonts.googleapis.com |
| S1aa9c6beb27f_N59 | S1aa9c6beb27f_N53 | attribute | 8–8 | attribute  |
| S1aa9c6beb27f_N60 | S1aa9c6beb27f_N59 | attribute_name | 8–8 | rel |
| S1aa9c6beb27f_N61 | S1aa9c6beb27f_N59 | quoted_attribute_value | 8–8 | quoted_attribute_value  |
| S1aa9c6beb27f_N62 | S1aa9c6beb27f_N61 | attribute_value | 8–8 | preconnect |
| S1aa9c6beb27f_N63 | S1aa9c6beb27f_N14 | element | 9–9 | element  |
| S1aa9c6beb27f_N64 | S1aa9c6beb27f_N63 | self_closing_tag | 9–9 | self_closing_tag  |
| S1aa9c6beb27f_N65 | S1aa9c6beb27f_N64 | tag_name | 9–9 | link |
| S1aa9c6beb27f_N66 | S1aa9c6beb27f_N64 | attribute | 9–9 | attribute  |
| S1aa9c6beb27f_N67 | S1aa9c6beb27f_N66 | attribute_name | 9–9 | crossorigin |
| S1aa9c6beb27f_N68 | S1aa9c6beb27f_N66 | quoted_attribute_value | 9–9 | "" |
| S1aa9c6beb27f_N69 | S1aa9c6beb27f_N64 | attribute | 9–9 | attribute  |
| S1aa9c6beb27f_N70 | S1aa9c6beb27f_N69 | attribute_name | 9–9 | href |
| S1aa9c6beb27f_N71 | S1aa9c6beb27f_N69 | quoted_attribute_value | 9–9 | quoted_attribute_value  |
| S1aa9c6beb27f_N72 | S1aa9c6beb27f_N71 | attribute_value | 9–9 | https://fonts.gstatic.com |
| S1aa9c6beb27f_N73 | S1aa9c6beb27f_N64 | attribute | 9–9 | attribute  |
| S1aa9c6beb27f_N74 | S1aa9c6beb27f_N73 | attribute_name | 9–9 | rel |
| S1aa9c6beb27f_N75 | S1aa9c6beb27f_N73 | quoted_attribute_value | 9–9 | quoted_attribute_value  |
| S1aa9c6beb27f_N76 | S1aa9c6beb27f_N75 | attribute_value | 9–9 | preconnect |
| S1aa9c6beb27f_N77 | S1aa9c6beb27f_N14 | element | 10–10 | element  |
| S1aa9c6beb27f_N78 | S1aa9c6beb27f_N77 | self_closing_tag | 10–10 | self_closing_tag  |
| S1aa9c6beb27f_N79 | S1aa9c6beb27f_N78 | tag_name | 10–10 | link |
| S1aa9c6beb27f_N80 | S1aa9c6beb27f_N78 | attribute | 10–10 | attribute  |
| S1aa9c6beb27f_N81 | S1aa9c6beb27f_N80 | attribute_name | 10–10 | href |
| S1aa9c6beb27f_N82 | S1aa9c6beb27f_N80 | quoted_attribute_value | 10–10 | quoted_attribute_value  |
| S1aa9c6beb27f_N83 | S1aa9c6beb27f_N82 | attribute_value | 10–10 | https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300..700;1,9..144,300..700&amp;amp;family=IBM+Plex+Mono:wght@400;500;600&amp;amp;family=Nunito+Sans:ital,wght@0,300..800;1,300..800&amp;amp;display=swap |
| S1aa9c6beb27f_N84 | S1aa9c6beb27f_N78 | attribute | 10–10 | attribute  |
| S1aa9c6beb27f_N85 | S1aa9c6beb27f_N84 | attribute_name | 10–10 | rel |
| S1aa9c6beb27f_N86 | S1aa9c6beb27f_N84 | quoted_attribute_value | 10–10 | quoted_attribute_value  |
| S1aa9c6beb27f_N87 | S1aa9c6beb27f_N86 | attribute_value | 10–10 | stylesheet |
| S1aa9c6beb27f_N88 | S1aa9c6beb27f_N14 | element | 11–11 | element  |
| S1aa9c6beb27f_N89 | S1aa9c6beb27f_N88 | self_closing_tag | 11–11 | self_closing_tag  |
| S1aa9c6beb27f_N90 | S1aa9c6beb27f_N89 | tag_name | 11–11 | link |
| S1aa9c6beb27f_N91 | S1aa9c6beb27f_N89 | attribute | 11–11 | attribute  |
| S1aa9c6beb27f_N92 | S1aa9c6beb27f_N91 | attribute_name | 11–11 | href |
| S1aa9c6beb27f_N93 | S1aa9c6beb27f_N91 | quoted_attribute_value | 11–11 | quoted_attribute_value  |
| S1aa9c6beb27f_N94 | S1aa9c6beb27f_N93 | attribute_value | 11–11 | https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200 |
| S1aa9c6beb27f_N95 | S1aa9c6beb27f_N89 | attribute | 11–11 | attribute  |
| S1aa9c6beb27f_N96 | S1aa9c6beb27f_N95 | attribute_name | 11–11 | rel |
| S1aa9c6beb27f_N97 | S1aa9c6beb27f_N95 | quoted_attribute_value | 11–11 | quoted_attribute_value  |
| S1aa9c6beb27f_N98 | S1aa9c6beb27f_N97 | attribute_value | 11–11 | stylesheet |
| S1aa9c6beb27f_N99 | S1aa9c6beb27f_N14 | element | 12–12 | element  |
| S1aa9c6beb27f_N100 | S1aa9c6beb27f_N99 | self_closing_tag | 12–12 | self_closing_tag  |
| S1aa9c6beb27f_N101 | S1aa9c6beb27f_N100 | tag_name | 12–12 | link |
| S1aa9c6beb27f_N102 | S1aa9c6beb27f_N100 | attribute | 12–12 | attribute  |
| S1aa9c6beb27f_N103 | S1aa9c6beb27f_N102 | attribute_name | 12–12 | href |
| S1aa9c6beb27f_N104 | S1aa9c6beb27f_N102 | quoted_attribute_value | 12–12 | quoted_attribute_value  |
| S1aa9c6beb27f_N105 | S1aa9c6beb27f_N104 | attribute_value | 12–12 | https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;amp;display=swap |
| S1aa9c6beb27f_N106 | S1aa9c6beb27f_N100 | attribute | 12–12 | attribute  |
| S1aa9c6beb27f_N107 | S1aa9c6beb27f_N106 | attribute_name | 12–12 | rel |
| S1aa9c6beb27f_N108 | S1aa9c6beb27f_N106 | quoted_attribute_value | 12–12 | quoted_attribute_value  |
| S1aa9c6beb27f_N109 | S1aa9c6beb27f_N108 | attribute_value | 12–12 | stylesheet |
| S1aa9c6beb27f_N110 | S1aa9c6beb27f_N14 | style_element | 13–21 | style_element  |
| S1aa9c6beb27f_N111 | S1aa9c6beb27f_N110 | start_tag | 13–13 | start_tag  |
| S1aa9c6beb27f_N112 | S1aa9c6beb27f_N111 | tag_name | 13–13 | style |
| S1aa9c6beb27f_N113 | S1aa9c6beb27f_N110 | raw_text | 13–21 |      @layer base {       html, body { margin:0; padding:0; }       body { overscroll-behavior:none; }       main&gt;:first-child { margin-top:0!important; }       main&gt;:last-child { margin-bottom:0!important; }     }     ::-webkit-scrollbar { display:none; }    |
| S1aa9c6beb27f_N114 | S1aa9c6beb27f_N110 | end_tag | 21–21 | end_tag  |
| S1aa9c6beb27f_N115 | S1aa9c6beb27f_N114 | tag_name | 21–21 | style |
| S1aa9c6beb27f_N116 | S1aa9c6beb27f_N14 | script_element | 22–22 | script_element  |
| S1aa9c6beb27f_N117 | S1aa9c6beb27f_N116 | start_tag | 22–22 | start_tag  |
| S1aa9c6beb27f_N118 | S1aa9c6beb27f_N117 | tag_name | 22–22 | script |
| S1aa9c6beb27f_N119 | S1aa9c6beb27f_N117 | attribute | 22–22 | attribute  |
| S1aa9c6beb27f_N120 | S1aa9c6beb27f_N119 | attribute_name | 22–22 | src |
| S1aa9c6beb27f_N121 | S1aa9c6beb27f_N119 | quoted_attribute_value | 22–22 | quoted_attribute_value  |
| S1aa9c6beb27f_N122 | S1aa9c6beb27f_N121 | attribute_value | 22–22 | https://cdn.tailwindcss.com?plugins=forms,container-queries |
| S1aa9c6beb27f_N123 | S1aa9c6beb27f_N116 | raw_text | 22–22 |  |
| S1aa9c6beb27f_N124 | S1aa9c6beb27f_N116 | end_tag | 22–22 | end_tag  |
| S1aa9c6beb27f_N125 | S1aa9c6beb27f_N124 | tag_name | 22–22 | script |
| S1aa9c6beb27f_N126 | S1aa9c6beb27f_N116 | program | 1–1 |  |
| S1aa9c6beb27f_N127 | S1aa9c6beb27f_N14 | script_element | 23–48 | script_element  |
| S1aa9c6beb27f_N128 | S1aa9c6beb27f_N127 | start_tag | 23–23 | start_tag  |
| S1aa9c6beb27f_N129 | S1aa9c6beb27f_N128 | tag_name | 23–23 | script |
| S1aa9c6beb27f_N130 | S1aa9c6beb27f_N128 | attribute | 23–23 | attribute  |
| S1aa9c6beb27f_N131 | S1aa9c6beb27f_N130 | attribute_name | 23–23 | id |
| S1aa9c6beb27f_N132 | S1aa9c6beb27f_N130 | quoted_attribute_value | 23–23 | quoted_attribute_value  |
| S1aa9c6beb27f_N133 | S1aa9c6beb27f_N132 | attribute_value | 23–23 | tailwind-config |
| S1aa9c6beb27f_N134 | S1aa9c6beb27f_N127 | raw_text | 23–48 |      tailwind.config = {       darkMode: "class",       theme: {         extend: {           colors: {             obs: "#18161B",             raised: "#242127",             starlight: "#F5F2E9",             brass: "#C9AA60",             "brass-light": "#DFC37D",             "brass-dark": "#937736",             "surface-dim": "#131115",             "surface-subtle": "#2e2a33",             "muted-text": "#A39EAA",             "soft-text": "#D2CECC"           },           fontFamily: {             serif: ["Fraunces", "serif"],             mono: ["IBM Plex Mono", "monospace"],             sans: ["Nunito Sans", "sans-serif"]           }         }       }     }    |
| S1aa9c6beb27f_N135 | S1aa9c6beb27f_N127 | end_tag | 48–48 | end_tag  |
| S1aa9c6beb27f_N136 | S1aa9c6beb27f_N135 | tag_name | 48–48 | script |
| S1aa9c6beb27f_N137 | S1aa9c6beb27f_N127 | program | 2–26 | program  |
| S1aa9c6beb27f_N138 | S1aa9c6beb27f_N137 | expression_statement | 2–25 | expression_statement  |
| S1aa9c6beb27f_N139 | S1aa9c6beb27f_N138 | assignment_expression | 2–25 | assignment_expression  |
| S1aa9c6beb27f_N140 | S1aa9c6beb27f_N139 | member_expression | 2–2 | member_expression  |
| S1aa9c6beb27f_N141 | S1aa9c6beb27f_N140 | identifier | 2–2 | tailwind |
| S1aa9c6beb27f_N142 | S1aa9c6beb27f_N140 | property_identifier | 2–2 | config |
| S1aa9c6beb27f_N143 | S1aa9c6beb27f_N139 | object | 2–25 | object  |
| S1aa9c6beb27f_N144 | S1aa9c6beb27f_N143 | pair | 3–3 | pair  |
| S1aa9c6beb27f_N145 | S1aa9c6beb27f_N144 | property_identifier | 3–3 | darkMode |
| S1aa9c6beb27f_N146 | S1aa9c6beb27f_N144 | string | 3–3 | string  |
| S1aa9c6beb27f_N147 | S1aa9c6beb27f_N146 | string_fragment | 3–3 | class |
| S1aa9c6beb27f_N148 | S1aa9c6beb27f_N143 | pair | 4–24 | pair  |
| S1aa9c6beb27f_N149 | S1aa9c6beb27f_N148 | property_identifier | 4–4 | theme |
| S1aa9c6beb27f_N150 | S1aa9c6beb27f_N148 | object | 4–24 | object  |
| S1aa9c6beb27f_N151 | S1aa9c6beb27f_N150 | pair | 5–23 | pair  |
| S1aa9c6beb27f_N152 | S1aa9c6beb27f_N151 | property_identifier | 5–5 | extend |
| S1aa9c6beb27f_N153 | S1aa9c6beb27f_N151 | object | 5–23 | object  |
| S1aa9c6beb27f_N154 | S1aa9c6beb27f_N153 | pair | 6–17 | pair  |
| S1aa9c6beb27f_N155 | S1aa9c6beb27f_N154 | property_identifier | 6–6 | colors |
| S1aa9c6beb27f_N156 | S1aa9c6beb27f_N154 | object | 6–17 | object  |
| S1aa9c6beb27f_N157 | S1aa9c6beb27f_N156 | pair | 7–7 | pair  |
| S1aa9c6beb27f_N158 | S1aa9c6beb27f_N157 | property_identifier | 7–7 | obs |
| S1aa9c6beb27f_N159 | S1aa9c6beb27f_N157 | string | 7–7 | string  |
| S1aa9c6beb27f_N160 | S1aa9c6beb27f_N159 | string_fragment | 7–7 | #18161B |
| S1aa9c6beb27f_N161 | S1aa9c6beb27f_N156 | pair | 8–8 | pair  |
| S1aa9c6beb27f_N162 | S1aa9c6beb27f_N161 | property_identifier | 8–8 | raised |
| S1aa9c6beb27f_N163 | S1aa9c6beb27f_N161 | string | 8–8 | string  |
| S1aa9c6beb27f_N164 | S1aa9c6beb27f_N163 | string_fragment | 8–8 | #242127 |
| S1aa9c6beb27f_N165 | S1aa9c6beb27f_N156 | pair | 9–9 | pair  |
| S1aa9c6beb27f_N166 | S1aa9c6beb27f_N165 | property_identifier | 9–9 | starlight |
| S1aa9c6beb27f_N167 | S1aa9c6beb27f_N165 | string | 9–9 | string  |
| S1aa9c6beb27f_N168 | S1aa9c6beb27f_N167 | string_fragment | 9–9 | #F5F2E9 |
| S1aa9c6beb27f_N169 | S1aa9c6beb27f_N156 | pair | 10–10 | pair  |
| S1aa9c6beb27f_N170 | S1aa9c6beb27f_N169 | property_identifier | 10–10 | brass |
| S1aa9c6beb27f_N171 | S1aa9c6beb27f_N169 | string | 10–10 | string  |
| S1aa9c6beb27f_N172 | S1aa9c6beb27f_N171 | string_fragment | 10–10 | #C9AA60 |
| S1aa9c6beb27f_N173 | S1aa9c6beb27f_N156 | pair | 11–11 | pair  |
| S1aa9c6beb27f_N174 | S1aa9c6beb27f_N173 | string | 11–11 | string  |
| S1aa9c6beb27f_N175 | S1aa9c6beb27f_N174 | string_fragment | 11–11 | brass-light |
| S1aa9c6beb27f_N176 | S1aa9c6beb27f_N173 | string | 11–11 | string  |
| S1aa9c6beb27f_N177 | S1aa9c6beb27f_N176 | string_fragment | 11–11 | #DFC37D |
| S1aa9c6beb27f_N178 | S1aa9c6beb27f_N156 | pair | 12–12 | pair  |
| S1aa9c6beb27f_N179 | S1aa9c6beb27f_N178 | string | 12–12 | string  |
| S1aa9c6beb27f_N180 | S1aa9c6beb27f_N179 | string_fragment | 12–12 | brass-dark |
| S1aa9c6beb27f_N181 | S1aa9c6beb27f_N178 | string | 12–12 | string  |
| S1aa9c6beb27f_N182 | S1aa9c6beb27f_N181 | string_fragment | 12–12 | #937736 |
| S1aa9c6beb27f_N183 | S1aa9c6beb27f_N156 | pair | 13–13 | pair  |
| S1aa9c6beb27f_N184 | S1aa9c6beb27f_N183 | string | 13–13 | string  |
| S1aa9c6beb27f_N185 | S1aa9c6beb27f_N184 | string_fragment | 13–13 | surface-dim |
| S1aa9c6beb27f_N186 | S1aa9c6beb27f_N183 | string | 13–13 | string  |
| S1aa9c6beb27f_N187 | S1aa9c6beb27f_N186 | string_fragment | 13–13 | #131115 |
| S1aa9c6beb27f_N188 | S1aa9c6beb27f_N156 | pair | 14–14 | pair  |
| S1aa9c6beb27f_N189 | S1aa9c6beb27f_N188 | string | 14–14 | string  |
| S1aa9c6beb27f_N190 | S1aa9c6beb27f_N189 | string_fragment | 14–14 | surface-subtle |
| S1aa9c6beb27f_N191 | S1aa9c6beb27f_N188 | string | 14–14 | string  |
| S1aa9c6beb27f_N192 | S1aa9c6beb27f_N191 | string_fragment | 14–14 | #2e2a33 |
| S1aa9c6beb27f_N193 | S1aa9c6beb27f_N156 | pair | 15–15 | pair  |
| S1aa9c6beb27f_N194 | S1aa9c6beb27f_N193 | string | 15–15 | string  |
| S1aa9c6beb27f_N195 | S1aa9c6beb27f_N194 | string_fragment | 15–15 | muted-text |
| S1aa9c6beb27f_N196 | S1aa9c6beb27f_N193 | string | 15–15 | string  |
| S1aa9c6beb27f_N197 | S1aa9c6beb27f_N196 | string_fragment | 15–15 | #A39EAA |
| S1aa9c6beb27f_N198 | S1aa9c6beb27f_N156 | pair | 16–16 | pair  |
| S1aa9c6beb27f_N199 | S1aa9c6beb27f_N198 | string | 16–16 | string  |
| S1aa9c6beb27f_N200 | S1aa9c6beb27f_N199 | string_fragment | 16–16 | soft-text |
| S1aa9c6beb27f_N201 | S1aa9c6beb27f_N198 | string | 16–16 | string  |
| S1aa9c6beb27f_N202 | S1aa9c6beb27f_N201 | string_fragment | 16–16 | #D2CECC |
| S1aa9c6beb27f_N203 | S1aa9c6beb27f_N153 | pair | 18–22 | pair  |
| S1aa9c6beb27f_N204 | S1aa9c6beb27f_N203 | property_identifier | 18–18 | fontFamily |
| S1aa9c6beb27f_N205 | S1aa9c6beb27f_N203 | object | 18–22 | object  |
| S1aa9c6beb27f_N206 | S1aa9c6beb27f_N205 | pair | 19–19 | pair  |
| S1aa9c6beb27f_N207 | S1aa9c6beb27f_N206 | property_identifier | 19–19 | serif |
| S1aa9c6beb27f_N208 | S1aa9c6beb27f_N206 | array | 19–19 | array  |
| S1aa9c6beb27f_N209 | S1aa9c6beb27f_N208 | string | 19–19 | string  |
| S1aa9c6beb27f_N210 | S1aa9c6beb27f_N209 | string_fragment | 19–19 | Fraunces |
| S1aa9c6beb27f_N211 | S1aa9c6beb27f_N208 | string | 19–19 | string  |
| S1aa9c6beb27f_N212 | S1aa9c6beb27f_N211 | string_fragment | 19–19 | serif |
| S1aa9c6beb27f_N213 | S1aa9c6beb27f_N205 | pair | 20–20 | pair  |
| S1aa9c6beb27f_N214 | S1aa9c6beb27f_N213 | property_identifier | 20–20 | mono |
| S1aa9c6beb27f_N215 | S1aa9c6beb27f_N213 | array | 20–20 | array  |
| S1aa9c6beb27f_N216 | S1aa9c6beb27f_N215 | string | 20–20 | string  |
| S1aa9c6beb27f_N217 | S1aa9c6beb27f_N216 | string_fragment | 20–20 | IBM Plex Mono |
| S1aa9c6beb27f_N218 | S1aa9c6beb27f_N215 | string | 20–20 | string  |
| S1aa9c6beb27f_N219 | S1aa9c6beb27f_N218 | string_fragment | 20–20 | monospace |
| S1aa9c6beb27f_N220 | S1aa9c6beb27f_N205 | pair | 21–21 | pair  |
| S1aa9c6beb27f_N221 | S1aa9c6beb27f_N220 | property_identifier | 21–21 | sans |
| S1aa9c6beb27f_N222 | S1aa9c6beb27f_N220 | array | 21–21 | array  |
| S1aa9c6beb27f_N223 | S1aa9c6beb27f_N222 | string | 21–21 | string  |
| S1aa9c6beb27f_N224 | S1aa9c6beb27f_N223 | string_fragment | 21–21 | Nunito Sans |
| S1aa9c6beb27f_N225 | S1aa9c6beb27f_N222 | string | 21–21 | string  |
| S1aa9c6beb27f_N226 | S1aa9c6beb27f_N225 | string_fragment | 21–21 | sans-serif |
| S1aa9c6beb27f_N227 | S1aa9c6beb27f_N14 | style_element | 49–49 | style_element  |
| S1aa9c6beb27f_N228 | S1aa9c6beb27f_N227 | start_tag | 49–49 | start_tag  |
| S1aa9c6beb27f_N229 | S1aa9c6beb27f_N228 | tag_name | 49–49 | style |
| S1aa9c6beb27f_N230 | S1aa9c6beb27f_N228 | attribute | 49–49 | attribute  |
| S1aa9c6beb27f_N231 | S1aa9c6beb27f_N230 | attribute_name | 49–49 | data-prototype-touch-targets |
| S1aa9c6beb27f_N232 | S1aa9c6beb27f_N227 | raw_text | 49–49 | @media(max-width:767px){button,a[href],label:has(input[type=radio]){min-height:44px}} |
| S1aa9c6beb27f_N233 | S1aa9c6beb27f_N227 | end_tag | 49–49 | end_tag  |
| S1aa9c6beb27f_N234 | S1aa9c6beb27f_N233 | tag_name | 49–49 | style |
| S1aa9c6beb27f_N235 | S1aa9c6beb27f_N14 | end_tag | 49–49 | end_tag  |
| S1aa9c6beb27f_N236 | S1aa9c6beb27f_N235 | tag_name | 49–49 | head |
| S1aa9c6beb27f_N237 | S1aa9c6beb27f_N3 | element | 50–340 | element  |
| S1aa9c6beb27f_N238 | S1aa9c6beb27f_N237 | start_tag | 50–50 | start_tag  |
| S1aa9c6beb27f_N239 | S1aa9c6beb27f_N238 | tag_name | 50–50 | body |
| S1aa9c6beb27f_N240 | S1aa9c6beb27f_N238 | attribute | 50–50 | attribute  |
| S1aa9c6beb27f_N241 | S1aa9c6beb27f_N240 | attribute_name | 50–50 | class |
| S1aa9c6beb27f_N242 | S1aa9c6beb27f_N240 | quoted_attribute_value | 50–50 | quoted_attribute_value  |
| S1aa9c6beb27f_N243 | S1aa9c6beb27f_N242 | attribute_value | 50–50 | bg-obs font-sans text-starlight antialiased selection:bg-brass/20 selection:text-brass |
| S1aa9c6beb27f_N244 | S1aa9c6beb27f_N237 | comment | 51–51 | &lt;!-- Top Funnel Navigation --&gt; |
| S1aa9c6beb27f_N245 | S1aa9c6beb27f_N237 | element | 52–84 | element  |
| S1aa9c6beb27f_N246 | S1aa9c6beb27f_N245 | start_tag | 52–52 | start_tag  |
| S1aa9c6beb27f_N247 | S1aa9c6beb27f_N246 | tag_name | 52–52 | header |
| S1aa9c6beb27f_N248 | S1aa9c6beb27f_N246 | attribute | 52–52 | attribute  |
| S1aa9c6beb27f_N249 | S1aa9c6beb27f_N248 | attribute_name | 52–52 | class |
| S1aa9c6beb27f_N250 | S1aa9c6beb27f_N248 | quoted_attribute_value | 52–52 | quoted_attribute_value  |
| S1aa9c6beb27f_N251 | S1aa9c6beb27f_N250 | attribute_value | 52–52 | fixed top-0 w-full z-50 bg-obs/90 backdrop-blur-md border-b border-white/5 |
| S1aa9c6beb27f_N252 | S1aa9c6beb27f_N245 | element | 53–83 | element  |
| S1aa9c6beb27f_N253 | S1aa9c6beb27f_N252 | start_tag | 53–53 | start_tag  |
| S1aa9c6beb27f_N254 | S1aa9c6beb27f_N253 | tag_name | 53–53 | div |
| S1aa9c6beb27f_N255 | S1aa9c6beb27f_N253 | attribute | 53–53 | attribute  |
| S1aa9c6beb27f_N256 | S1aa9c6beb27f_N255 | attribute_name | 53–53 | class |
| S1aa9c6beb27f_N257 | S1aa9c6beb27f_N255 | quoted_attribute_value | 53–53 | quoted_attribute_value  |
| S1aa9c6beb27f_N258 | S1aa9c6beb27f_N257 | attribute_value | 53–53 | h-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between |
| S1aa9c6beb27f_N259 | S1aa9c6beb27f_N252 | element | 54–62 | element  |
| S1aa9c6beb27f_N260 | S1aa9c6beb27f_N259 | start_tag | 54–54 | start_tag  |
| S1aa9c6beb27f_N261 | S1aa9c6beb27f_N260 | tag_name | 54–54 | div |
| S1aa9c6beb27f_N262 | S1aa9c6beb27f_N260 | attribute | 54–54 | attribute  |
| S1aa9c6beb27f_N263 | S1aa9c6beb27f_N262 | attribute_name | 54–54 | class |
| S1aa9c6beb27f_N264 | S1aa9c6beb27f_N262 | quoted_attribute_value | 54–54 | quoted_attribute_value  |
| S1aa9c6beb27f_N265 | S1aa9c6beb27f_N264 | attribute_value | 54–54 | flex items-center gap-3 |
| S1aa9c6beb27f_N266 | S1aa9c6beb27f_N259 | element | 55–58 | element  |
| S1aa9c6beb27f_N267 | S1aa9c6beb27f_N266 | start_tag | 55–55 | start_tag  |
| S1aa9c6beb27f_N268 | S1aa9c6beb27f_N267 | tag_name | 55–55 | div |
| S1aa9c6beb27f_N269 | S1aa9c6beb27f_N267 | attribute | 55–55 | attribute  |
| S1aa9c6beb27f_N270 | S1aa9c6beb27f_N269 | attribute_name | 55–55 | class |
| S1aa9c6beb27f_N271 | S1aa9c6beb27f_N269 | quoted_attribute_value | 55–55 | quoted_attribute_value  |
| S1aa9c6beb27f_N272 | S1aa9c6beb27f_N271 | attribute_value | 55–55 | flex items-center gap-2 |
| S1aa9c6beb27f_N273 | S1aa9c6beb27f_N266 | element | 56–56 | element  |
| S1aa9c6beb27f_N274 | S1aa9c6beb27f_N273 | start_tag | 56–56 | start_tag  |
| S1aa9c6beb27f_N275 | S1aa9c6beb27f_N274 | tag_name | 56–56 | span |
| S1aa9c6beb27f_N276 | S1aa9c6beb27f_N274 | attribute | 56–56 | attribute  |
| S1aa9c6beb27f_N277 | S1aa9c6beb27f_N276 | attribute_name | 56–56 | class |
| S1aa9c6beb27f_N278 | S1aa9c6beb27f_N276 | quoted_attribute_value | 56–56 | quoted_attribute_value  |
| S1aa9c6beb27f_N279 | S1aa9c6beb27f_N278 | attribute_value | 56–56 | material-symbols-outlined text-brass text-2xl |
| S1aa9c6beb27f_N280 | S1aa9c6beb27f_N273 | text | 56–56 | auto_awesome |
| S1aa9c6beb27f_N281 | S1aa9c6beb27f_N273 | end_tag | 56–56 | end_tag  |
| S1aa9c6beb27f_N282 | S1aa9c6beb27f_N281 | tag_name | 56–56 | span |
| S1aa9c6beb27f_N283 | S1aa9c6beb27f_N266 | element | 57–57 | element  |
| S1aa9c6beb27f_N284 | S1aa9c6beb27f_N283 | start_tag | 57–57 | start_tag  |
| S1aa9c6beb27f_N285 | S1aa9c6beb27f_N284 | tag_name | 57–57 | span |
| S1aa9c6beb27f_N286 | S1aa9c6beb27f_N284 | attribute | 57–57 | attribute  |
| S1aa9c6beb27f_N287 | S1aa9c6beb27f_N286 | attribute_name | 57–57 | class |
| S1aa9c6beb27f_N288 | S1aa9c6beb27f_N286 | quoted_attribute_value | 57–57 | quoted_attribute_value  |
| S1aa9c6beb27f_N289 | S1aa9c6beb27f_N288 | attribute_value | 57–57 | font-serif text-xl tracking-tight text-starlight font-semibold |
| S1aa9c6beb27f_N290 | S1aa9c6beb27f_N283 | text | 57–57 | Natally |
| S1aa9c6beb27f_N291 | S1aa9c6beb27f_N283 | end_tag | 57–57 | end_tag  |
| S1aa9c6beb27f_N292 | S1aa9c6beb27f_N291 | tag_name | 57–57 | span |
| S1aa9c6beb27f_N293 | S1aa9c6beb27f_N266 | end_tag | 58–58 | end_tag  |
| S1aa9c6beb27f_N294 | S1aa9c6beb27f_N293 | tag_name | 58–58 | div |
| S1aa9c6beb27f_N295 | S1aa9c6beb27f_N259 | element | 59–61 | element  |
| S1aa9c6beb27f_N296 | S1aa9c6beb27f_N295 | start_tag | 59–59 | start_tag  |
| S1aa9c6beb27f_N297 | S1aa9c6beb27f_N296 | tag_name | 59–59 | span |
| S1aa9c6beb27f_N298 | S1aa9c6beb27f_N296 | attribute | 59–59 | attribute  |
| S1aa9c6beb27f_N299 | S1aa9c6beb27f_N298 | attribute_name | 59–59 | class |
| S1aa9c6beb27f_N300 | S1aa9c6beb27f_N298 | quoted_attribute_value | 59–59 | quoted_attribute_value  |
| S1aa9c6beb27f_N301 | S1aa9c6beb27f_N300 | attribute_value | 59–59 | hidden sm:inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-mono bg-raised text-brass border border-brass/20 |
| S1aa9c6beb27f_N302 | S1aa9c6beb27f_N295 | text | 60–60 | Step 2 of 4 · Upgrade |
| S1aa9c6beb27f_N303 | S1aa9c6beb27f_N295 | end_tag | 61–61 | end_tag  |
| S1aa9c6beb27f_N304 | S1aa9c6beb27f_N303 | tag_name | 61–61 | span |
| S1aa9c6beb27f_N305 | S1aa9c6beb27f_N259 | end_tag | 62–62 | end_tag  |
| S1aa9c6beb27f_N306 | S1aa9c6beb27f_N305 | tag_name | 62–62 | div |
| S1aa9c6beb27f_N307 | S1aa9c6beb27f_N252 | comment | 63–63 | &lt;!-- Funnel Progress Breadcrumbs --&gt; |
| S1aa9c6beb27f_N308 | S1aa9c6beb27f_N252 | element | 64–72 | element  |
| S1aa9c6beb27f_N309 | S1aa9c6beb27f_N308 | start_tag | 64–64 | start_tag  |
| S1aa9c6beb27f_N310 | S1aa9c6beb27f_N309 | tag_name | 64–64 | nav |
| S1aa9c6beb27f_N311 | S1aa9c6beb27f_N309 | attribute | 64–64 | attribute  |
| S1aa9c6beb27f_N312 | S1aa9c6beb27f_N311 | attribute_name | 64–64 | class |
| S1aa9c6beb27f_N313 | S1aa9c6beb27f_N311 | quoted_attribute_value | 64–64 | quoted_attribute_value  |
| S1aa9c6beb27f_N314 | S1aa9c6beb27f_N313 | attribute_value | 64–64 | hidden md:flex items-center gap-1 font-mono text-xs text-muted-text |
| S1aa9c6beb27f_N315 | S1aa9c6beb27f_N308 | element | 65–65 | element  |
| S1aa9c6beb27f_N316 | S1aa9c6beb27f_N315 | start_tag | 65–65 | start_tag  |
| S1aa9c6beb27f_N317 | S1aa9c6beb27f_N316 | tag_name | 65–65 | span |
| S1aa9c6beb27f_N318 | S1aa9c6beb27f_N316 | attribute | 65–65 | attribute  |
| S1aa9c6beb27f_N319 | S1aa9c6beb27f_N318 | attribute_name | 65–65 | class |
| S1aa9c6beb27f_N320 | S1aa9c6beb27f_N318 | quoted_attribute_value | 65–65 | quoted_attribute_value  |
| S1aa9c6beb27f_N321 | S1aa9c6beb27f_N320 | attribute_value | 65–65 | px-2.5 py-1 text-muted-text/70 |
| S1aa9c6beb27f_N322 | S1aa9c6beb27f_N315 | text | 65–65 | 1. Reading Options |
| S1aa9c6beb27f_N323 | S1aa9c6beb27f_N315 | end_tag | 65–65 | end_tag  |
| S1aa9c6beb27f_N324 | S1aa9c6beb27f_N323 | tag_name | 65–65 | span |
| S1aa9c6beb27f_N325 | S1aa9c6beb27f_N308 | element | 66–66 | element  |
| S1aa9c6beb27f_N326 | S1aa9c6beb27f_N325 | start_tag | 66–66 | start_tag  |
| S1aa9c6beb27f_N327 | S1aa9c6beb27f_N326 | tag_name | 66–66 | span |
| S1aa9c6beb27f_N328 | S1aa9c6beb27f_N326 | attribute | 66–66 | attribute  |
| S1aa9c6beb27f_N329 | S1aa9c6beb27f_N328 | attribute_name | 66–66 | class |
| S1aa9c6beb27f_N330 | S1aa9c6beb27f_N328 | quoted_attribute_value | 66–66 | quoted_attribute_value  |
| S1aa9c6beb27f_N331 | S1aa9c6beb27f_N330 | attribute_value | 66–66 | text-white/20 |
| S1aa9c6beb27f_N332 | S1aa9c6beb27f_N325 | text | 66–66 | / |
| S1aa9c6beb27f_N333 | S1aa9c6beb27f_N325 | end_tag | 66–66 | end_tag  |
| S1aa9c6beb27f_N334 | S1aa9c6beb27f_N333 | tag_name | 66–66 | span |
| S1aa9c6beb27f_N335 | S1aa9c6beb27f_N308 | element | 67–67 | element  |
| S1aa9c6beb27f_N336 | S1aa9c6beb27f_N335 | start_tag | 67–67 | start_tag  |
| S1aa9c6beb27f_N337 | S1aa9c6beb27f_N336 | tag_name | 67–67 | span |
| S1aa9c6beb27f_N338 | S1aa9c6beb27f_N336 | attribute | 67–67 | attribute  |
| S1aa9c6beb27f_N339 | S1aa9c6beb27f_N338 | attribute_name | 67–67 | class |
| S1aa9c6beb27f_N340 | S1aa9c6beb27f_N338 | quoted_attribute_value | 67–67 | quoted_attribute_value  |
| S1aa9c6beb27f_N341 | S1aa9c6beb27f_N340 | attribute_value | 67–67 | px-2.5 py-1 text-brass font-medium bg-raised/80 rounded-md border border-brass/20 |
| S1aa9c6beb27f_N342 | S1aa9c6beb27f_N335 | text | 67–67 | 2. Interactive Chart |
| S1aa9c6beb27f_N343 | S1aa9c6beb27f_N335 | end_tag | 67–67 | end_tag  |
| S1aa9c6beb27f_N344 | S1aa9c6beb27f_N343 | tag_name | 67–67 | span |
| S1aa9c6beb27f_N345 | S1aa9c6beb27f_N308 | element | 68–68 | element  |
| S1aa9c6beb27f_N346 | S1aa9c6beb27f_N345 | start_tag | 68–68 | start_tag  |
| S1aa9c6beb27f_N347 | S1aa9c6beb27f_N346 | tag_name | 68–68 | span |
| S1aa9c6beb27f_N348 | S1aa9c6beb27f_N346 | attribute | 68–68 | attribute  |
| S1aa9c6beb27f_N349 | S1aa9c6beb27f_N348 | attribute_name | 68–68 | class |
| S1aa9c6beb27f_N350 | S1aa9c6beb27f_N348 | quoted_attribute_value | 68–68 | quoted_attribute_value  |
| S1aa9c6beb27f_N351 | S1aa9c6beb27f_N350 | attribute_value | 68–68 | text-white/20 |
| S1aa9c6beb27f_N352 | S1aa9c6beb27f_N345 | text | 68–68 | / |
| S1aa9c6beb27f_N353 | S1aa9c6beb27f_N345 | end_tag | 68–68 | end_tag  |
| S1aa9c6beb27f_N354 | S1aa9c6beb27f_N353 | tag_name | 68–68 | span |
| S1aa9c6beb27f_N355 | S1aa9c6beb27f_N308 | element | 69–69 | element  |
| S1aa9c6beb27f_N356 | S1aa9c6beb27f_N355 | start_tag | 69–69 | start_tag  |
| S1aa9c6beb27f_N357 | S1aa9c6beb27f_N356 | tag_name | 69–69 | span |
| S1aa9c6beb27f_N358 | S1aa9c6beb27f_N356 | attribute | 69–69 | attribute  |
| S1aa9c6beb27f_N359 | S1aa9c6beb27f_N358 | attribute_name | 69–69 | class |
| S1aa9c6beb27f_N360 | S1aa9c6beb27f_N358 | quoted_attribute_value | 69–69 | quoted_attribute_value  |
| S1aa9c6beb27f_N361 | S1aa9c6beb27f_N360 | attribute_value | 69–69 | px-2.5 py-1 text-muted-text/70 |
| S1aa9c6beb27f_N362 | S1aa9c6beb27f_N355 | text | 69–69 | 3. Personalization |
| S1aa9c6beb27f_N363 | S1aa9c6beb27f_N355 | end_tag | 69–69 | end_tag  |
| S1aa9c6beb27f_N364 | S1aa9c6beb27f_N363 | tag_name | 69–69 | span |
| S1aa9c6beb27f_N365 | S1aa9c6beb27f_N308 | element | 70–70 | element  |
| S1aa9c6beb27f_N366 | S1aa9c6beb27f_N365 | start_tag | 70–70 | start_tag  |
| S1aa9c6beb27f_N367 | S1aa9c6beb27f_N366 | tag_name | 70–70 | span |
| S1aa9c6beb27f_N368 | S1aa9c6beb27f_N366 | attribute | 70–70 | attribute  |
| S1aa9c6beb27f_N369 | S1aa9c6beb27f_N368 | attribute_name | 70–70 | class |
| S1aa9c6beb27f_N370 | S1aa9c6beb27f_N368 | quoted_attribute_value | 70–70 | quoted_attribute_value  |
| S1aa9c6beb27f_N371 | S1aa9c6beb27f_N370 | attribute_value | 70–70 | text-white/20 |
| S1aa9c6beb27f_N372 | S1aa9c6beb27f_N365 | text | 70–70 | / |
| S1aa9c6beb27f_N373 | S1aa9c6beb27f_N365 | end_tag | 70–70 | end_tag  |
| S1aa9c6beb27f_N374 | S1aa9c6beb27f_N373 | tag_name | 70–70 | span |
| S1aa9c6beb27f_N375 | S1aa9c6beb27f_N308 | element | 71–71 | element  |
| S1aa9c6beb27f_N376 | S1aa9c6beb27f_N375 | start_tag | 71–71 | start_tag  |
| S1aa9c6beb27f_N377 | S1aa9c6beb27f_N376 | tag_name | 71–71 | span |
| S1aa9c6beb27f_N378 | S1aa9c6beb27f_N376 | attribute | 71–71 | attribute  |
| S1aa9c6beb27f_N379 | S1aa9c6beb27f_N378 | attribute_name | 71–71 | class |
| S1aa9c6beb27f_N380 | S1aa9c6beb27f_N378 | quoted_attribute_value | 71–71 | quoted_attribute_value  |
| S1aa9c6beb27f_N381 | S1aa9c6beb27f_N380 | attribute_value | 71–71 | px-2.5 py-1 text-muted-text/70 |
| S1aa9c6beb27f_N382 | S1aa9c6beb27f_N375 | text | 71–71 | 4. Review |
| S1aa9c6beb27f_N383 | S1aa9c6beb27f_N375 | end_tag | 71–71 | end_tag  |
| S1aa9c6beb27f_N384 | S1aa9c6beb27f_N383 | tag_name | 71–71 | span |
| S1aa9c6beb27f_N385 | S1aa9c6beb27f_N308 | end_tag | 72–72 | end_tag  |
| S1aa9c6beb27f_N386 | S1aa9c6beb27f_N385 | tag_name | 72–72 | nav |
| S1aa9c6beb27f_N387 | S1aa9c6beb27f_N252 | comment | 73–73 | &lt;!-- Natally Companion Pill --&gt; |
| S1aa9c6beb27f_N388 | S1aa9c6beb27f_N252 | element | 74–82 | element  |
| S1aa9c6beb27f_N389 | S1aa9c6beb27f_N388 | start_tag | 74–74 | start_tag  |
| S1aa9c6beb27f_N390 | S1aa9c6beb27f_N389 | tag_name | 74–74 | div |
| S1aa9c6beb27f_N391 | S1aa9c6beb27f_N389 | attribute | 74–74 | attribute  |
| S1aa9c6beb27f_N392 | S1aa9c6beb27f_N391 | attribute_name | 74–74 | class |
| S1aa9c6beb27f_N393 | S1aa9c6beb27f_N391 | quoted_attribute_value | 74–74 | quoted_attribute_value  |
| S1aa9c6beb27f_N394 | S1aa9c6beb27f_N393 | attribute_value | 74–74 | flex items-center gap-2.5 bg-raised/90 border border-white/5 pl-2 pr-3 py-1.5 rounded-full shadow-sm |
| S1aa9c6beb27f_N395 | S1aa9c6beb27f_N388 | element | 75–77 | element  |
| S1aa9c6beb27f_N396 | S1aa9c6beb27f_N395 | start_tag | 75–75 | start_tag  |
| S1aa9c6beb27f_N397 | S1aa9c6beb27f_N396 | tag_name | 75–75 | div |
| S1aa9c6beb27f_N398 | S1aa9c6beb27f_N396 | attribute | 75–75 | attribute  |
| S1aa9c6beb27f_N399 | S1aa9c6beb27f_N398 | attribute_name | 75–75 | class |
| S1aa9c6beb27f_N400 | S1aa9c6beb27f_N398 | quoted_attribute_value | 75–75 | quoted_attribute_value  |
| S1aa9c6beb27f_N401 | S1aa9c6beb27f_N400 | attribute_value | 75–75 | relative w-7 h-7 rounded-full overflow-hidden ring-1 ring-brass/40 shrink-0 |
| S1aa9c6beb27f_N402 | S1aa9c6beb27f_N395 | element | 76–76 | element  |
| S1aa9c6beb27f_N403 | S1aa9c6beb27f_N402 | self_closing_tag | 76–76 | self_closing_tag  |
| S1aa9c6beb27f_N404 | S1aa9c6beb27f_N403 | tag_name | 76–76 | img |
| S1aa9c6beb27f_N405 | S1aa9c6beb27f_N403 | attribute | 76–76 | attribute  |
| S1aa9c6beb27f_N406 | S1aa9c6beb27f_N405 | attribute_name | 76–76 | alt |
| S1aa9c6beb27f_N407 | S1aa9c6beb27f_N405 | quoted_attribute_value | 76–76 | quoted_attribute_value  |
| S1aa9c6beb27f_N408 | S1aa9c6beb27f_N407 | attribute_value | 76–76 | Natally |
| S1aa9c6beb27f_N409 | S1aa9c6beb27f_N403 | attribute | 76–76 | attribute  |
| S1aa9c6beb27f_N410 | S1aa9c6beb27f_N409 | attribute_name | 76–76 | class |
| S1aa9c6beb27f_N411 | S1aa9c6beb27f_N409 | quoted_attribute_value | 76–76 | quoted_attribute_value  |
| S1aa9c6beb27f_N412 | S1aa9c6beb27f_N411 | attribute_value | 76–76 | w-full h-full object-cover |
| S1aa9c6beb27f_N413 | S1aa9c6beb27f_N403 | attribute | 76–76 | attribute  |
| S1aa9c6beb27f_N414 | S1aa9c6beb27f_N413 | attribute_name | 76–76 | src |
| S1aa9c6beb27f_N415 | S1aa9c6beb27f_N413 | quoted_attribute_value | 76–76 | quoted_attribute_value  |
| S1aa9c6beb27f_N416 | S1aa9c6beb27f_N415 | attribute_value | 76–76 | ../../assets/natally-mascot.webp |
| S1aa9c6beb27f_N417 | S1aa9c6beb27f_N395 | end_tag | 77–77 | end_tag  |
| S1aa9c6beb27f_N418 | S1aa9c6beb27f_N417 | tag_name | 77–77 | div |
| S1aa9c6beb27f_N419 | S1aa9c6beb27f_N388 | element | 78–81 | element  |
| S1aa9c6beb27f_N420 | S1aa9c6beb27f_N419 | start_tag | 78–78 | start_tag  |
| S1aa9c6beb27f_N421 | S1aa9c6beb27f_N420 | tag_name | 78–78 | div |
| S1aa9c6beb27f_N422 | S1aa9c6beb27f_N420 | attribute | 78–78 | attribute  |
| S1aa9c6beb27f_N423 | S1aa9c6beb27f_N422 | attribute_name | 78–78 | class |
| S1aa9c6beb27f_N424 | S1aa9c6beb27f_N422 | quoted_attribute_value | 78–78 | quoted_attribute_value  |
| S1aa9c6beb27f_N425 | S1aa9c6beb27f_N424 | attribute_value | 78–78 | flex flex-col text-left |
| S1aa9c6beb27f_N426 | S1aa9c6beb27f_N419 | element | 79–79 | element  |
| S1aa9c6beb27f_N427 | S1aa9c6beb27f_N426 | start_tag | 79–79 | start_tag  |
| S1aa9c6beb27f_N428 | S1aa9c6beb27f_N427 | tag_name | 79–79 | span |
| S1aa9c6beb27f_N429 | S1aa9c6beb27f_N427 | attribute | 79–79 | attribute  |
| S1aa9c6beb27f_N430 | S1aa9c6beb27f_N429 | attribute_name | 79–79 | class |
| S1aa9c6beb27f_N431 | S1aa9c6beb27f_N429 | quoted_attribute_value | 79–79 | quoted_attribute_value  |
| S1aa9c6beb27f_N432 | S1aa9c6beb27f_N431 | attribute_value | 79–79 | text-xs font-serif font-medium leading-none text-starlight |
| S1aa9c6beb27f_N433 | S1aa9c6beb27f_N426 | text | 79–79 | Natally |
| S1aa9c6beb27f_N434 | S1aa9c6beb27f_N426 | end_tag | 79–79 | end_tag  |
| S1aa9c6beb27f_N435 | S1aa9c6beb27f_N434 | tag_name | 79–79 | span |
| S1aa9c6beb27f_N436 | S1aa9c6beb27f_N419 | element | 80–80 | element  |
| S1aa9c6beb27f_N437 | S1aa9c6beb27f_N436 | start_tag | 80–80 | start_tag  |
| S1aa9c6beb27f_N438 | S1aa9c6beb27f_N437 | tag_name | 80–80 | span |
| S1aa9c6beb27f_N439 | S1aa9c6beb27f_N437 | attribute | 80–80 | attribute  |
| S1aa9c6beb27f_N440 | S1aa9c6beb27f_N439 | attribute_name | 80–80 | class |
| S1aa9c6beb27f_N441 | S1aa9c6beb27f_N439 | quoted_attribute_value | 80–80 | quoted_attribute_value  |
| S1aa9c6beb27f_N442 | S1aa9c6beb27f_N441 | attribute_value | 80–80 | text-[10px] font-mono text-brass leading-tight |
| S1aa9c6beb27f_N443 | S1aa9c6beb27f_N436 | text | 80–80 | Your Seer |
| S1aa9c6beb27f_N444 | S1aa9c6beb27f_N436 | end_tag | 80–80 | end_tag  |
| S1aa9c6beb27f_N445 | S1aa9c6beb27f_N444 | tag_name | 80–80 | span |
| S1aa9c6beb27f_N446 | S1aa9c6beb27f_N419 | end_tag | 81–81 | end_tag  |
| S1aa9c6beb27f_N447 | S1aa9c6beb27f_N446 | tag_name | 81–81 | div |
| S1aa9c6beb27f_N448 | S1aa9c6beb27f_N388 | end_tag | 82–82 | end_tag  |
| S1aa9c6beb27f_N449 | S1aa9c6beb27f_N448 | tag_name | 82–82 | div |
| S1aa9c6beb27f_N450 | S1aa9c6beb27f_N252 | end_tag | 83–83 | end_tag  |
| S1aa9c6beb27f_N451 | S1aa9c6beb27f_N450 | tag_name | 83–83 | div |
| S1aa9c6beb27f_N452 | S1aa9c6beb27f_N245 | end_tag | 84–84 | end_tag  |
| S1aa9c6beb27f_N453 | S1aa9c6beb27f_N452 | tag_name | 84–84 | header |
| S1aa9c6beb27f_N454 | S1aa9c6beb27f_N237 | element | 85–339 | element  |
| S1aa9c6beb27f_N455 | S1aa9c6beb27f_N454 | start_tag | 85–85 | start_tag  |
| S1aa9c6beb27f_N456 | S1aa9c6beb27f_N455 | tag_name | 85–85 | main |
| S1aa9c6beb27f_N457 | S1aa9c6beb27f_N455 | attribute | 85–85 | attribute  |
| S1aa9c6beb27f_N458 | S1aa9c6beb27f_N457 | attribute_name | 85–85 | class |
| S1aa9c6beb27f_N459 | S1aa9c6beb27f_N457 | quoted_attribute_value | 85–85 | quoted_attribute_value  |
| S1aa9c6beb27f_N460 | S1aa9c6beb27f_N459 | attribute_value | 85–85 | w-full pt-20 pb-16 min-h-screen flex flex-col justify-between |
| S1aa9c6beb27f_N461 | S1aa9c6beb27f_N454 | element | 86–332 | element  |
| S1aa9c6beb27f_N462 | S1aa9c6beb27f_N461 | start_tag | 86–86 | start_tag  |
| S1aa9c6beb27f_N463 | S1aa9c6beb27f_N462 | tag_name | 86–86 | div |
| S1aa9c6beb27f_N464 | S1aa9c6beb27f_N462 | attribute | 86–86 | attribute  |
| S1aa9c6beb27f_N465 | S1aa9c6beb27f_N464 | attribute_name | 86–86 | class |
| S1aa9c6beb27f_N466 | S1aa9c6beb27f_N464 | quoted_attribute_value | 86–86 | quoted_attribute_value  |
| S1aa9c6beb27f_N467 | S1aa9c6beb27f_N466 | attribute_value | 86–86 | max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 w-full pt-4 |
| S1aa9c6beb27f_N468 | S1aa9c6beb27f_N461 | comment | 87–87 | &lt;!-- Hero Section --&gt; |
| S1aa9c6beb27f_N469 | S1aa9c6beb27f_N461 | element | 88–99 | element  |
| S1aa9c6beb27f_N470 | S1aa9c6beb27f_N469 | start_tag | 88–88 | start_tag  |
| S1aa9c6beb27f_N471 | S1aa9c6beb27f_N470 | tag_name | 88–88 | div |
| S1aa9c6beb27f_N472 | S1aa9c6beb27f_N470 | attribute | 88–88 | attribute  |
| S1aa9c6beb27f_N473 | S1aa9c6beb27f_N472 | attribute_name | 88–88 | class |
| S1aa9c6beb27f_N474 | S1aa9c6beb27f_N472 | quoted_attribute_value | 88–88 | quoted_attribute_value  |
| S1aa9c6beb27f_N475 | S1aa9c6beb27f_N474 | attribute_value | 88–88 | text-center max-w-3xl mx-auto mb-10 |
| S1aa9c6beb27f_N476 | S1aa9c6beb27f_N469 | element | 89–92 | element  |
| S1aa9c6beb27f_N477 | S1aa9c6beb27f_N476 | start_tag | 89–89 | start_tag  |
| S1aa9c6beb27f_N478 | S1aa9c6beb27f_N477 | tag_name | 89–89 | div |
| S1aa9c6beb27f_N479 | S1aa9c6beb27f_N477 | attribute | 89–89 | attribute  |
| S1aa9c6beb27f_N480 | S1aa9c6beb27f_N479 | attribute_name | 89–89 | class |
| S1aa9c6beb27f_N481 | S1aa9c6beb27f_N479 | quoted_attribute_value | 89–89 | quoted_attribute_value  |
| S1aa9c6beb27f_N482 | S1aa9c6beb27f_N481 | attribute_value | 89–89 | inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-raised text-brass font-mono text-xs mb-4 border border-brass/20 |
| S1aa9c6beb27f_N483 | S1aa9c6beb27f_N476 | element | 90–90 | element  |
| S1aa9c6beb27f_N484 | S1aa9c6beb27f_N483 | start_tag | 90–90 | start_tag  |
| S1aa9c6beb27f_N485 | S1aa9c6beb27f_N484 | tag_name | 90–90 | span |
| S1aa9c6beb27f_N486 | S1aa9c6beb27f_N484 | attribute | 90–90 | attribute  |
| S1aa9c6beb27f_N487 | S1aa9c6beb27f_N486 | attribute_name | 90–90 | class |
| S1aa9c6beb27f_N488 | S1aa9c6beb27f_N486 | quoted_attribute_value | 90–90 | quoted_attribute_value  |
| S1aa9c6beb27f_N489 | S1aa9c6beb27f_N488 | attribute_value | 90–90 | w-1.5 h-1.5 rounded-full bg-brass animate-pulse |
| S1aa9c6beb27f_N490 | S1aa9c6beb27f_N483 | end_tag | 90–90 | end_tag  |
| S1aa9c6beb27f_N491 | S1aa9c6beb27f_N490 | tag_name | 90–90 | span |
| S1aa9c6beb27f_N492 | S1aa9c6beb27f_N476 | element | 91–91 | element  |
| S1aa9c6beb27f_N493 | S1aa9c6beb27f_N492 | start_tag | 91–91 | start_tag  |
| S1aa9c6beb27f_N494 | S1aa9c6beb27f_N493 | tag_name | 91–91 | span |
| S1aa9c6beb27f_N495 | S1aa9c6beb27f_N492 | text | 91–91 | Enhance your astrological reading |
| S1aa9c6beb27f_N496 | S1aa9c6beb27f_N492 | end_tag | 91–91 | end_tag  |
| S1aa9c6beb27f_N497 | S1aa9c6beb27f_N496 | tag_name | 91–91 | span |
| S1aa9c6beb27f_N498 | S1aa9c6beb27f_N476 | end_tag | 92–92 | end_tag  |
| S1aa9c6beb27f_N499 | S1aa9c6beb27f_N498 | tag_name | 92–92 | div |
| S1aa9c6beb27f_N500 | S1aa9c6beb27f_N469 | element | 93–95 | element  |
| S1aa9c6beb27f_N501 | S1aa9c6beb27f_N500 | start_tag | 93–93 | start_tag  |
| S1aa9c6beb27f_N502 | S1aa9c6beb27f_N501 | tag_name | 93–93 | h1 |
| S1aa9c6beb27f_N503 | S1aa9c6beb27f_N501 | attribute | 93–93 | attribute  |
| S1aa9c6beb27f_N504 | S1aa9c6beb27f_N503 | attribute_name | 93–93 | class |
| S1aa9c6beb27f_N505 | S1aa9c6beb27f_N503 | quoted_attribute_value | 93–93 | quoted_attribute_value  |
| S1aa9c6beb27f_N506 | S1aa9c6beb27f_N505 | attribute_value | 93–93 | font-serif text-3xl sm:text-4xl md:text-5xl text-starlight font-medium tracking-tight leading-tight |
| S1aa9c6beb27f_N507 | S1aa9c6beb27f_N500 | text | 94–94 | Bring your natal chart to life. |
| S1aa9c6beb27f_N508 | S1aa9c6beb27f_N500 | end_tag | 95–95 | end_tag  |
| S1aa9c6beb27f_N509 | S1aa9c6beb27f_N508 | tag_name | 95–95 | h1 |
| S1aa9c6beb27f_N510 | S1aa9c6beb27f_N469 | element | 96–98 | element  |
| S1aa9c6beb27f_N511 | S1aa9c6beb27f_N510 | start_tag | 96–96 | start_tag  |
| S1aa9c6beb27f_N512 | S1aa9c6beb27f_N511 | tag_name | 96–96 | p |
| S1aa9c6beb27f_N513 | S1aa9c6beb27f_N511 | attribute | 96–96 | attribute  |
| S1aa9c6beb27f_N514 | S1aa9c6beb27f_N513 | attribute_name | 96–96 | class |
| S1aa9c6beb27f_N515 | S1aa9c6beb27f_N513 | quoted_attribute_value | 96–96 | quoted_attribute_value  |
| S1aa9c6beb27f_N516 | S1aa9c6beb27f_N515 | attribute_value | 96–96 | mt-3 text-base sm:text-lg text-soft-text max-w-2xl mx-auto leading-relaxed |
| S1aa9c6beb27f_N517 | S1aa9c6beb27f_N510 | text | 97–97 | Add the interactive chart web experience to your downloadable reading. |
| S1aa9c6beb27f_N518 | S1aa9c6beb27f_N510 | end_tag | 98–98 | end_tag  |
| S1aa9c6beb27f_N519 | S1aa9c6beb27f_N518 | tag_name | 98–98 | p |
| S1aa9c6beb27f_N520 | S1aa9c6beb27f_N469 | end_tag | 99–99 | end_tag  |
| S1aa9c6beb27f_N521 | S1aa9c6beb27f_N520 | tag_name | 99–99 | div |
| S1aa9c6beb27f_N522 | S1aa9c6beb27f_N461 | comment | 100–100 | &lt;!-- Friendly Natally Voice Note --&gt; |
| S1aa9c6beb27f_N523 | S1aa9c6beb27f_N461 | element | 101–114 | element  |
| S1aa9c6beb27f_N524 | S1aa9c6beb27f_N523 | start_tag | 101–101 | start_tag  |
| S1aa9c6beb27f_N525 | S1aa9c6beb27f_N524 | tag_name | 101–101 | div |
| S1aa9c6beb27f_N526 | S1aa9c6beb27f_N524 | attribute | 101–101 | attribute  |
| S1aa9c6beb27f_N527 | S1aa9c6beb27f_N526 | attribute_name | 101–101 | class |
| S1aa9c6beb27f_N528 | S1aa9c6beb27f_N526 | quoted_attribute_value | 101–101 | quoted_attribute_value  |
| S1aa9c6beb27f_N529 | S1aa9c6beb27f_N528 | attribute_value | 101–101 | max-w-3xl mx-auto bg-raised/60 border border-white/5 rounded-2xl p-4 sm:p-5 mb-10 flex items-center gap-4 |
| S1aa9c6beb27f_N530 | S1aa9c6beb27f_N523 | element | 102–104 | element  |
| S1aa9c6beb27f_N531 | S1aa9c6beb27f_N530 | start_tag | 102–102 | start_tag  |
| S1aa9c6beb27f_N532 | S1aa9c6beb27f_N531 | tag_name | 102–102 | div |
| S1aa9c6beb27f_N533 | S1aa9c6beb27f_N531 | attribute | 102–102 | attribute  |
| S1aa9c6beb27f_N534 | S1aa9c6beb27f_N533 | attribute_name | 102–102 | class |
| S1aa9c6beb27f_N535 | S1aa9c6beb27f_N533 | quoted_attribute_value | 102–102 | quoted_attribute_value  |
| S1aa9c6beb27f_N536 | S1aa9c6beb27f_N535 | attribute_value | 102–102 | relative w-14 h-14 sm:w-16 sm:h-16 rounded-full overflow-hidden ring-2 ring-brass/30 shrink-0 shadow-md |
| S1aa9c6beb27f_N537 | S1aa9c6beb27f_N530 | element | 103–103 | element  |
| S1aa9c6beb27f_N538 | S1aa9c6beb27f_N537 | self_closing_tag | 103–103 | self_closing_tag  |
| S1aa9c6beb27f_N539 | S1aa9c6beb27f_N538 | tag_name | 103–103 | img |
| S1aa9c6beb27f_N540 | S1aa9c6beb27f_N538 | attribute | 103–103 | attribute  |
| S1aa9c6beb27f_N541 | S1aa9c6beb27f_N540 | attribute_name | 103–103 | alt |
| S1aa9c6beb27f_N542 | S1aa9c6beb27f_N540 | quoted_attribute_value | 103–103 | quoted_attribute_value  |
| S1aa9c6beb27f_N543 | S1aa9c6beb27f_N542 | attribute_value | 103–103 | Natally companion |
| S1aa9c6beb27f_N544 | S1aa9c6beb27f_N538 | attribute | 103–103 | attribute  |
| S1aa9c6beb27f_N545 | S1aa9c6beb27f_N544 | attribute_name | 103–103 | class |
| S1aa9c6beb27f_N546 | S1aa9c6beb27f_N544 | quoted_attribute_value | 103–103 | quoted_attribute_value  |
| S1aa9c6beb27f_N547 | S1aa9c6beb27f_N546 | attribute_value | 103–103 | w-full h-full object-cover |
| S1aa9c6beb27f_N548 | S1aa9c6beb27f_N538 | attribute | 103–103 | attribute  |
| S1aa9c6beb27f_N549 | S1aa9c6beb27f_N548 | attribute_name | 103–103 | src |
| S1aa9c6beb27f_N550 | S1aa9c6beb27f_N548 | quoted_attribute_value | 103–103 | quoted_attribute_value  |
| S1aa9c6beb27f_N551 | S1aa9c6beb27f_N550 | attribute_value | 103–103 | ../../assets/natally-mascot.webp |
| S1aa9c6beb27f_N552 | S1aa9c6beb27f_N530 | end_tag | 104–104 | end_tag  |
| S1aa9c6beb27f_N553 | S1aa9c6beb27f_N552 | tag_name | 104–104 | div |
| S1aa9c6beb27f_N554 | S1aa9c6beb27f_N523 | element | 105–113 | element  |
| S1aa9c6beb27f_N555 | S1aa9c6beb27f_N554 | start_tag | 105–105 | start_tag  |
| S1aa9c6beb27f_N556 | S1aa9c6beb27f_N555 | tag_name | 105–105 | div |
| S1aa9c6beb27f_N557 | S1aa9c6beb27f_N555 | attribute | 105–105 | attribute  |
| S1aa9c6beb27f_N558 | S1aa9c6beb27f_N557 | attribute_name | 105–105 | class |
| S1aa9c6beb27f_N559 | S1aa9c6beb27f_N557 | quoted_attribute_value | 105–105 | quoted_attribute_value  |
| S1aa9c6beb27f_N560 | S1aa9c6beb27f_N559 | attribute_value | 105–105 | space-y-1 |
| S1aa9c6beb27f_N561 | S1aa9c6beb27f_N554 | element | 106–109 | element  |
| S1aa9c6beb27f_N562 | S1aa9c6beb27f_N561 | start_tag | 106–106 | start_tag  |
| S1aa9c6beb27f_N563 | S1aa9c6beb27f_N562 | tag_name | 106–106 | div |
| S1aa9c6beb27f_N564 | S1aa9c6beb27f_N562 | attribute | 106–106 | attribute  |
| S1aa9c6beb27f_N565 | S1aa9c6beb27f_N564 | attribute_name | 106–106 | class |
| S1aa9c6beb27f_N566 | S1aa9c6beb27f_N564 | quoted_attribute_value | 106–106 | quoted_attribute_value  |
| S1aa9c6beb27f_N567 | S1aa9c6beb27f_N566 | attribute_value | 106–106 | flex items-center gap-2 |
| S1aa9c6beb27f_N568 | S1aa9c6beb27f_N561 | element | 107–107 | element  |
| S1aa9c6beb27f_N569 | S1aa9c6beb27f_N568 | start_tag | 107–107 | start_tag  |
| S1aa9c6beb27f_N570 | S1aa9c6beb27f_N569 | tag_name | 107–107 | span |
| S1aa9c6beb27f_N571 | S1aa9c6beb27f_N569 | attribute | 107–107 | attribute  |
| S1aa9c6beb27f_N572 | S1aa9c6beb27f_N571 | attribute_name | 107–107 | class |
| S1aa9c6beb27f_N573 | S1aa9c6beb27f_N571 | quoted_attribute_value | 107–107 | quoted_attribute_value  |
| S1aa9c6beb27f_N574 | S1aa9c6beb27f_N573 | attribute_value | 107–107 | font-serif text-sm font-semibold text-brass |
| S1aa9c6beb27f_N575 | S1aa9c6beb27f_N568 | text | 107–107 | Natally’s Note |
| S1aa9c6beb27f_N576 | S1aa9c6beb27f_N568 | end_tag | 107–107 | end_tag  |
| S1aa9c6beb27f_N577 | S1aa9c6beb27f_N576 | tag_name | 107–107 | span |
| S1aa9c6beb27f_N578 | S1aa9c6beb27f_N561 | element | 108–108 | element  |
| S1aa9c6beb27f_N579 | S1aa9c6beb27f_N578 | start_tag | 108–108 | start_tag  |
| S1aa9c6beb27f_N580 | S1aa9c6beb27f_N579 | tag_name | 108–108 | span |
| S1aa9c6beb27f_N581 | S1aa9c6beb27f_N579 | attribute | 108–108 | attribute  |
| S1aa9c6beb27f_N582 | S1aa9c6beb27f_N581 | attribute_name | 108–108 | class |
| S1aa9c6beb27f_N583 | S1aa9c6beb27f_N581 | quoted_attribute_value | 108–108 | quoted_attribute_value  |
| S1aa9c6beb27f_N584 | S1aa9c6beb27f_N583 | attribute_value | 108–108 | text-xs font-mono text-muted-text |
| S1aa9c6beb27f_N585 | S1aa9c6beb27f_N578 | text | 108–108 | · Friendly Advice |
| S1aa9c6beb27f_N586 | S1aa9c6beb27f_N578 | end_tag | 108–108 | end_tag  |
| S1aa9c6beb27f_N587 | S1aa9c6beb27f_N586 | tag_name | 108–108 | span |
| S1aa9c6beb27f_N588 | S1aa9c6beb27f_N561 | end_tag | 109–109 | end_tag  |
| S1aa9c6beb27f_N589 | S1aa9c6beb27f_N588 | tag_name | 109–109 | div |
| S1aa9c6beb27f_N590 | S1aa9c6beb27f_N554 | element | 110–112 | element  |
| S1aa9c6beb27f_N591 | S1aa9c6beb27f_N590 | start_tag | 110–110 | start_tag  |
| S1aa9c6beb27f_N592 | S1aa9c6beb27f_N591 | tag_name | 110–110 | p |
| S1aa9c6beb27f_N593 | S1aa9c6beb27f_N591 | attribute | 110–110 | attribute  |
| S1aa9c6beb27f_N594 | S1aa9c6beb27f_N593 | attribute_name | 110–110 | class |
| S1aa9c6beb27f_N595 | S1aa9c6beb27f_N593 | quoted_attribute_value | 110–110 | quoted_attribute_value  |
| S1aa9c6beb27f_N596 | S1aa9c6beb27f_N595 | attribute_value | 110–110 | font-serif text-sm sm:text-base text-starlight/90 italic leading-snug |
| S1aa9c6beb27f_N597 | S1aa9c6beb27f_N590 | text | 111–111 | “Your PDF is lovely to keep and print, but touching each planetary line and watching your houses illuminate directly in your browser makes exploring your astrology feel effortless and intuitive.” |
| S1aa9c6beb27f_N598 | S1aa9c6beb27f_N590 | end_tag | 112–112 | end_tag  |
| S1aa9c6beb27f_N599 | S1aa9c6beb27f_N598 | tag_name | 112–112 | p |
| S1aa9c6beb27f_N600 | S1aa9c6beb27f_N554 | end_tag | 113–113 | end_tag  |
| S1aa9c6beb27f_N601 | S1aa9c6beb27f_N600 | tag_name | 113–113 | div |
| S1aa9c6beb27f_N602 | S1aa9c6beb27f_N523 | end_tag | 114–114 | end_tag  |
| S1aa9c6beb27f_N603 | S1aa9c6beb27f_N602 | tag_name | 114–114 | div |
| S1aa9c6beb27f_N604 | S1aa9c6beb27f_N461 | comment | 115–115 | &lt;!-- Side-by-Side Comparison --&gt; |
| S1aa9c6beb27f_N605 | S1aa9c6beb27f_N461 | element | 116–258 | element  |
| S1aa9c6beb27f_N606 | S1aa9c6beb27f_N605 | start_tag | 116–116 | start_tag  |
| S1aa9c6beb27f_N607 | S1aa9c6beb27f_N606 | tag_name | 116–116 | div |
| S1aa9c6beb27f_N608 | S1aa9c6beb27f_N606 | attribute | 116–116 | attribute  |
| S1aa9c6beb27f_N609 | S1aa9c6beb27f_N608 | attribute_name | 116–116 | class |
| S1aa9c6beb27f_N610 | S1aa9c6beb27f_N608 | quoted_attribute_value | 116–116 | quoted_attribute_value  |
| S1aa9c6beb27f_N611 | S1aa9c6beb27f_N610 | attribute_value | 116–116 | grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12 |
| S1aa9c6beb27f_N612 | S1aa9c6beb27f_N605 | comment | 117–117 | &lt;!-- Left: PDF Only --&gt; |
| S1aa9c6beb27f_N613 | S1aa9c6beb27f_N605 | element | 118–180 | element  |
| S1aa9c6beb27f_N614 | S1aa9c6beb27f_N613 | start_tag | 118–118 | start_tag  |
| S1aa9c6beb27f_N615 | S1aa9c6beb27f_N614 | tag_name | 118–118 | div |
| S1aa9c6beb27f_N616 | S1aa9c6beb27f_N614 | attribute | 118–118 | attribute  |
| S1aa9c6beb27f_N617 | S1aa9c6beb27f_N616 | attribute_name | 118–118 | class |
| S1aa9c6beb27f_N618 | S1aa9c6beb27f_N616 | quoted_attribute_value | 118–118 | quoted_attribute_value  |
| S1aa9c6beb27f_N619 | S1aa9c6beb27f_N618 | attribute_value | 118–118 | bg-raised/70 border border-white/10 rounded-2xl p-6 sm:p-7 flex flex-col justify-between relative overflow-hidden group hover:border-white/20 transition-all |
| S1aa9c6beb27f_N620 | S1aa9c6beb27f_N613 | element | 119–175 | element  |
| S1aa9c6beb27f_N621 | S1aa9c6beb27f_N620 | start_tag | 119–119 | start_tag  |
| S1aa9c6beb27f_N622 | S1aa9c6beb27f_N621 | tag_name | 119–119 | div |
| S1aa9c6beb27f_N623 | S1aa9c6beb27f_N620 | element | 120–128 | element  |
| S1aa9c6beb27f_N624 | S1aa9c6beb27f_N623 | start_tag | 120–120 | start_tag  |
| S1aa9c6beb27f_N625 | S1aa9c6beb27f_N624 | tag_name | 120–120 | div |
| S1aa9c6beb27f_N626 | S1aa9c6beb27f_N624 | attribute | 120–120 | attribute  |
| S1aa9c6beb27f_N627 | S1aa9c6beb27f_N626 | attribute_name | 120–120 | class |
| S1aa9c6beb27f_N628 | S1aa9c6beb27f_N626 | quoted_attribute_value | 120–120 | quoted_attribute_value  |
| S1aa9c6beb27f_N629 | S1aa9c6beb27f_N628 | attribute_value | 120–120 | flex items-center justify-between pb-4 border-b border-white/5 mb-5 |
| S1aa9c6beb27f_N630 | S1aa9c6beb27f_N623 | element | 121–124 | element  |
| S1aa9c6beb27f_N631 | S1aa9c6beb27f_N630 | start_tag | 121–121 | start_tag  |
| S1aa9c6beb27f_N632 | S1aa9c6beb27f_N631 | tag_name | 121–121 | div |
| S1aa9c6beb27f_N633 | S1aa9c6beb27f_N630 | element | 122–122 | element  |
| S1aa9c6beb27f_N634 | S1aa9c6beb27f_N633 | start_tag | 122–122 | start_tag  |
| S1aa9c6beb27f_N635 | S1aa9c6beb27f_N634 | tag_name | 122–122 | span |
| S1aa9c6beb27f_N636 | S1aa9c6beb27f_N634 | attribute | 122–122 | attribute  |
| S1aa9c6beb27f_N637 | S1aa9c6beb27f_N636 | attribute_name | 122–122 | class |
| S1aa9c6beb27f_N638 | S1aa9c6beb27f_N636 | quoted_attribute_value | 122–122 | quoted_attribute_value  |
| S1aa9c6beb27f_N639 | S1aa9c6beb27f_N638 | attribute_value | 122–122 | text-xs font-mono text-muted-text uppercase tracking-wider block |
| S1aa9c6beb27f_N640 | S1aa9c6beb27f_N633 | text | 122–122 | Standard Format |
| S1aa9c6beb27f_N641 | S1aa9c6beb27f_N633 | end_tag | 122–122 | end_tag  |
| S1aa9c6beb27f_N642 | S1aa9c6beb27f_N641 | tag_name | 122–122 | span |
| S1aa9c6beb27f_N643 | S1aa9c6beb27f_N630 | element | 123–123 | element  |
| S1aa9c6beb27f_N644 | S1aa9c6beb27f_N643 | start_tag | 123–123 | start_tag  |
| S1aa9c6beb27f_N645 | S1aa9c6beb27f_N644 | tag_name | 123–123 | h2 |
| S1aa9c6beb27f_N646 | S1aa9c6beb27f_N644 | attribute | 123–123 | attribute  |
| S1aa9c6beb27f_N647 | S1aa9c6beb27f_N646 | attribute_name | 123–123 | class |
| S1aa9c6beb27f_N648 | S1aa9c6beb27f_N646 | quoted_attribute_value | 123–123 | quoted_attribute_value  |
| S1aa9c6beb27f_N649 | S1aa9c6beb27f_N648 | attribute_value | 123–123 | font-serif text-xl sm:text-2xl text-starlight font-medium mt-0.5 |
| S1aa9c6beb27f_N650 | S1aa9c6beb27f_N643 | text | 123–123 | Natal chart — PDF only |
| S1aa9c6beb27f_N651 | S1aa9c6beb27f_N643 | end_tag | 123–123 | end_tag  |
| S1aa9c6beb27f_N652 | S1aa9c6beb27f_N651 | tag_name | 123–123 | h2 |
| S1aa9c6beb27f_N653 | S1aa9c6beb27f_N630 | end_tag | 124–124 | end_tag  |
| S1aa9c6beb27f_N654 | S1aa9c6beb27f_N653 | tag_name | 124–124 | div |
| S1aa9c6beb27f_N655 | S1aa9c6beb27f_N623 | element | 125–127 | element  |
| S1aa9c6beb27f_N656 | S1aa9c6beb27f_N655 | start_tag | 125–125 | start_tag  |
| S1aa9c6beb27f_N657 | S1aa9c6beb27f_N656 | tag_name | 125–125 | span |
| S1aa9c6beb27f_N658 | S1aa9c6beb27f_N656 | attribute | 125–125 | attribute  |
| S1aa9c6beb27f_N659 | S1aa9c6beb27f_N658 | attribute_name | 125–125 | class |
| S1aa9c6beb27f_N660 | S1aa9c6beb27f_N658 | quoted_attribute_value | 125–125 | quoted_attribute_value  |
| S1aa9c6beb27f_N661 | S1aa9c6beb27f_N660 | attribute_value | 125–125 | px-2.5 py-1 rounded bg-obs text-muted-text text-xs font-mono border border-white/5 |
| S1aa9c6beb27f_N662 | S1aa9c6beb27f_N655 | text | 126–126 | Sample reading |
| S1aa9c6beb27f_N663 | S1aa9c6beb27f_N655 | end_tag | 127–127 | end_tag  |
| S1aa9c6beb27f_N664 | S1aa9c6beb27f_N663 | tag_name | 127–127 | span |
| S1aa9c6beb27f_N665 | S1aa9c6beb27f_N623 | end_tag | 128–128 | end_tag  |
| S1aa9c6beb27f_N666 | S1aa9c6beb27f_N665 | tag_name | 128–128 | div |
| S1aa9c6beb27f_N667 | S1aa9c6beb27f_N620 | comment | 129–129 | &lt;!-- PDF Visual Graphic / Illustration --&gt; |
| S1aa9c6beb27f_N668 | S1aa9c6beb27f_N620 | element | 130–160 | element  |
| S1aa9c6beb27f_N669 | S1aa9c6beb27f_N668 | start_tag | 130–130 | start_tag  |
| S1aa9c6beb27f_N670 | S1aa9c6beb27f_N669 | tag_name | 130–130 | div |
| S1aa9c6beb27f_N671 | S1aa9c6beb27f_N669 | attribute | 130–130 | attribute  |
| S1aa9c6beb27f_N672 | S1aa9c6beb27f_N671 | attribute_name | 130–130 | class |
| S1aa9c6beb27f_N673 | S1aa9c6beb27f_N671 | quoted_attribute_value | 130–130 | quoted_attribute_value  |
| S1aa9c6beb27f_N674 | S1aa9c6beb27f_N673 | attribute_value | 130–130 | bg-obs/90 border border-white/5 rounded-xl p-5 mb-5 |
| S1aa9c6beb27f_N675 | S1aa9c6beb27f_N668 | element | 131–134 | element  |
| S1aa9c6beb27f_N676 | S1aa9c6beb27f_N675 | start_tag | 131–131 | start_tag  |
| S1aa9c6beb27f_N677 | S1aa9c6beb27f_N676 | tag_name | 131–131 | div |
| S1aa9c6beb27f_N678 | S1aa9c6beb27f_N676 | attribute | 131–131 | attribute  |
| S1aa9c6beb27f_N679 | S1aa9c6beb27f_N678 | attribute_name | 131–131 | class |
| S1aa9c6beb27f_N680 | S1aa9c6beb27f_N678 | quoted_attribute_value | 131–131 | quoted_attribute_value  |
| S1aa9c6beb27f_N681 | S1aa9c6beb27f_N680 | attribute_value | 131–131 | flex items-center justify-between font-mono text-xs text-muted-text pb-3 border-b border-white/5 |
| S1aa9c6beb27f_N682 | S1aa9c6beb27f_N675 | element | 132–132 | element  |
| S1aa9c6beb27f_N683 | S1aa9c6beb27f_N682 | start_tag | 132–132 | start_tag  |
| S1aa9c6beb27f_N684 | S1aa9c6beb27f_N683 | tag_name | 132–132 | span |
| S1aa9c6beb27f_N685 | S1aa9c6beb27f_N683 | attribute | 132–132 | attribute  |
| S1aa9c6beb27f_N686 | S1aa9c6beb27f_N685 | attribute_name | 132–132 | class |
| S1aa9c6beb27f_N687 | S1aa9c6beb27f_N685 | quoted_attribute_value | 132–132 | quoted_attribute_value  |
| S1aa9c6beb27f_N688 | S1aa9c6beb27f_N687 | attribute_value | 132–132 | flex items-center gap-1.5 |
| S1aa9c6beb27f_N689 | S1aa9c6beb27f_N682 | element | 132–132 | element  |
| S1aa9c6beb27f_N690 | S1aa9c6beb27f_N689 | start_tag | 132–132 | start_tag  |
| S1aa9c6beb27f_N691 | S1aa9c6beb27f_N690 | tag_name | 132–132 | span |
| S1aa9c6beb27f_N692 | S1aa9c6beb27f_N690 | attribute | 132–132 | attribute  |
| S1aa9c6beb27f_N693 | S1aa9c6beb27f_N692 | attribute_name | 132–132 | class |
| S1aa9c6beb27f_N694 | S1aa9c6beb27f_N692 | quoted_attribute_value | 132–132 | quoted_attribute_value  |
| S1aa9c6beb27f_N695 | S1aa9c6beb27f_N694 | attribute_value | 132–132 | material-symbols-outlined text-sm |
| S1aa9c6beb27f_N696 | S1aa9c6beb27f_N689 | text | 132–132 | picture_as_pdf |
| S1aa9c6beb27f_N697 | S1aa9c6beb27f_N689 | end_tag | 132–132 | end_tag  |
| S1aa9c6beb27f_N698 | S1aa9c6beb27f_N697 | tag_name | 132–132 | span |
| S1aa9c6beb27f_N699 | S1aa9c6beb27f_N682 | text | 132–132 | Downloadable reading folio |
| S1aa9c6beb27f_N700 | S1aa9c6beb27f_N682 | end_tag | 132–132 | end_tag  |
| S1aa9c6beb27f_N701 | S1aa9c6beb27f_N700 | tag_name | 132–132 | span |
| S1aa9c6beb27f_N702 | S1aa9c6beb27f_N675 | element | 133–133 | element  |
| S1aa9c6beb27f_N703 | S1aa9c6beb27f_N702 | start_tag | 133–133 | start_tag  |
| S1aa9c6beb27f_N704 | S1aa9c6beb27f_N703 | tag_name | 133–133 | span |
| S1aa9c6beb27f_N705 | S1aa9c6beb27f_N702 | text | 133–133 | Static overview |
| S1aa9c6beb27f_N706 | S1aa9c6beb27f_N702 | end_tag | 133–133 | end_tag  |
| S1aa9c6beb27f_N707 | S1aa9c6beb27f_N706 | tag_name | 133–133 | span |
| S1aa9c6beb27f_N708 | S1aa9c6beb27f_N675 | end_tag | 134–134 | end_tag  |
| S1aa9c6beb27f_N709 | S1aa9c6beb27f_N708 | tag_name | 134–134 | div |
| S1aa9c6beb27f_N710 | S1aa9c6beb27f_N668 | comment | 135–135 | &lt;!-- Clean Mock Document Representation --&gt; |
| S1aa9c6beb27f_N711 | S1aa9c6beb27f_N668 | element | 136–149 | element  |
| S1aa9c6beb27f_N712 | S1aa9c6beb27f_N711 | start_tag | 136–136 | start_tag  |
| S1aa9c6beb27f_N713 | S1aa9c6beb27f_N712 | tag_name | 136–136 | div |
| S1aa9c6beb27f_N714 | S1aa9c6beb27f_N712 | attribute | 136–136 | attribute  |
| S1aa9c6beb27f_N715 | S1aa9c6beb27f_N714 | attribute_name | 136–136 | class |
| S1aa9c6beb27f_N716 | S1aa9c6beb27f_N714 | quoted_attribute_value | 136–136 | quoted_attribute_value  |
| S1aa9c6beb27f_N717 | S1aa9c6beb27f_N716 | attribute_value | 136–136 | py-4 space-y-2.5 font-mono text-xs |
| S1aa9c6beb27f_N718 | S1aa9c6beb27f_N711 | element | 137–140 | element  |
| S1aa9c6beb27f_N719 | S1aa9c6beb27f_N718 | start_tag | 137–137 | start_tag  |
| S1aa9c6beb27f_N720 | S1aa9c6beb27f_N719 | tag_name | 137–137 | div |
| S1aa9c6beb27f_N721 | S1aa9c6beb27f_N719 | attribute | 137–137 | attribute  |
| S1aa9c6beb27f_N722 | S1aa9c6beb27f_N721 | attribute_name | 137–137 | class |
| S1aa9c6beb27f_N723 | S1aa9c6beb27f_N721 | quoted_attribute_value | 137–137 | quoted_attribute_value  |
| S1aa9c6beb27f_N724 | S1aa9c6beb27f_N723 | attribute_value | 137–137 | flex justify-between items-center py-1.5 px-2.5 rounded bg-raised/40 text-soft-text |
| S1aa9c6beb27f_N725 | S1aa9c6beb27f_N718 | element | 138–138 | element  |
| S1aa9c6beb27f_N726 | S1aa9c6beb27f_N725 | start_tag | 138–138 | start_tag  |
| S1aa9c6beb27f_N727 | S1aa9c6beb27f_N726 | tag_name | 138–138 | span |
| S1aa9c6beb27f_N728 | S1aa9c6beb27f_N726 | attribute | 138–138 | attribute  |
| S1aa9c6beb27f_N729 | S1aa9c6beb27f_N728 | attribute_name | 138–138 | class |
| S1aa9c6beb27f_N730 | S1aa9c6beb27f_N728 | quoted_attribute_value | 138–138 | quoted_attribute_value  |
| S1aa9c6beb27f_N731 | S1aa9c6beb27f_N730 | attribute_value | 138–138 | text-starlight font-medium |
| S1aa9c6beb27f_N732 | S1aa9c6beb27f_N725 | text | 138–138 | ☉ Sun in Taurus |
| S1aa9c6beb27f_N733 | S1aa9c6beb27f_N725 | end_tag | 138–138 | end_tag  |
| S1aa9c6beb27f_N734 | S1aa9c6beb27f_N733 | tag_name | 138–138 | span |
| S1aa9c6beb27f_N735 | S1aa9c6beb27f_N718 | element | 139–139 | element  |
| S1aa9c6beb27f_N736 | S1aa9c6beb27f_N735 | start_tag | 139–139 | start_tag  |
| S1aa9c6beb27f_N737 | S1aa9c6beb27f_N736 | tag_name | 139–139 | span |
| S1aa9c6beb27f_N738 | S1aa9c6beb27f_N736 | attribute | 139–139 | attribute  |
| S1aa9c6beb27f_N739 | S1aa9c6beb27f_N738 | attribute_name | 139–139 | class |
| S1aa9c6beb27f_N740 | S1aa9c6beb27f_N738 | quoted_attribute_value | 139–139 | quoted_attribute_value  |
| S1aa9c6beb27f_N741 | S1aa9c6beb27f_N740 | attribute_value | 139–139 | text-muted-text |
| S1aa9c6beb27f_N742 | S1aa9c6beb27f_N735 | text | 139–139 | House 9 |
| S1aa9c6beb27f_N743 | S1aa9c6beb27f_N735 | end_tag | 139–139 | end_tag  |
| S1aa9c6beb27f_N744 | S1aa9c6beb27f_N743 | tag_name | 139–139 | span |
| S1aa9c6beb27f_N745 | S1aa9c6beb27f_N718 | end_tag | 140–140 | end_tag  |
| S1aa9c6beb27f_N746 | S1aa9c6beb27f_N745 | tag_name | 140–140 | div |
| S1aa9c6beb27f_N747 | S1aa9c6beb27f_N711 | element | 141–144 | element  |
| S1aa9c6beb27f_N748 | S1aa9c6beb27f_N747 | start_tag | 141–141 | start_tag  |
| S1aa9c6beb27f_N749 | S1aa9c6beb27f_N748 | tag_name | 141–141 | div |
| S1aa9c6beb27f_N750 | S1aa9c6beb27f_N748 | attribute | 141–141 | attribute  |
| S1aa9c6beb27f_N751 | S1aa9c6beb27f_N750 | attribute_name | 141–141 | class |
| S1aa9c6beb27f_N752 | S1aa9c6beb27f_N750 | quoted_attribute_value | 141–141 | quoted_attribute_value  |
| S1aa9c6beb27f_N753 | S1aa9c6beb27f_N752 | attribute_value | 141–141 | flex justify-between items-center py-1.5 px-2.5 rounded bg-raised/20 text-soft-text |
| S1aa9c6beb27f_N754 | S1aa9c6beb27f_N747 | element | 142–142 | element  |
| S1aa9c6beb27f_N755 | S1aa9c6beb27f_N754 | start_tag | 142–142 | start_tag  |
| S1aa9c6beb27f_N756 | S1aa9c6beb27f_N755 | tag_name | 142–142 | span |
| S1aa9c6beb27f_N757 | S1aa9c6beb27f_N755 | attribute | 142–142 | attribute  |
| S1aa9c6beb27f_N758 | S1aa9c6beb27f_N757 | attribute_name | 142–142 | class |
| S1aa9c6beb27f_N759 | S1aa9c6beb27f_N757 | quoted_attribute_value | 142–142 | quoted_attribute_value  |
| S1aa9c6beb27f_N760 | S1aa9c6beb27f_N759 | attribute_value | 142–142 | text-starlight font-medium |
| S1aa9c6beb27f_N761 | S1aa9c6beb27f_N754 | text | 142–142 | ☽ Moon in Scorpio |
| S1aa9c6beb27f_N762 | S1aa9c6beb27f_N754 | end_tag | 142–142 | end_tag  |
| S1aa9c6beb27f_N763 | S1aa9c6beb27f_N762 | tag_name | 142–142 | span |
| S1aa9c6beb27f_N764 | S1aa9c6beb27f_N747 | element | 143–143 | element  |
| S1aa9c6beb27f_N765 | S1aa9c6beb27f_N764 | start_tag | 143–143 | start_tag  |
| S1aa9c6beb27f_N766 | S1aa9c6beb27f_N765 | tag_name | 143–143 | span |
| S1aa9c6beb27f_N767 | S1aa9c6beb27f_N765 | attribute | 143–143 | attribute  |
| S1aa9c6beb27f_N768 | S1aa9c6beb27f_N767 | attribute_name | 143–143 | class |
| S1aa9c6beb27f_N769 | S1aa9c6beb27f_N767 | quoted_attribute_value | 143–143 | quoted_attribute_value  |
| S1aa9c6beb27f_N770 | S1aa9c6beb27f_N769 | attribute_value | 143–143 | text-muted-text |
| S1aa9c6beb27f_N771 | S1aa9c6beb27f_N764 | text | 143–143 | House 3 |
| S1aa9c6beb27f_N772 | S1aa9c6beb27f_N764 | end_tag | 143–143 | end_tag  |
| S1aa9c6beb27f_N773 | S1aa9c6beb27f_N772 | tag_name | 143–143 | span |
| S1aa9c6beb27f_N774 | S1aa9c6beb27f_N747 | end_tag | 144–144 | end_tag  |
| S1aa9c6beb27f_N775 | S1aa9c6beb27f_N774 | tag_name | 144–144 | div |
| S1aa9c6beb27f_N776 | S1aa9c6beb27f_N711 | element | 145–148 | element  |
| S1aa9c6beb27f_N777 | S1aa9c6beb27f_N776 | start_tag | 145–145 | start_tag  |
| S1aa9c6beb27f_N778 | S1aa9c6beb27f_N777 | tag_name | 145–145 | div |
| S1aa9c6beb27f_N779 | S1aa9c6beb27f_N777 | attribute | 145–145 | attribute  |
| S1aa9c6beb27f_N780 | S1aa9c6beb27f_N779 | attribute_name | 145–145 | class |
| S1aa9c6beb27f_N781 | S1aa9c6beb27f_N779 | quoted_attribute_value | 145–145 | quoted_attribute_value  |
| S1aa9c6beb27f_N782 | S1aa9c6beb27f_N781 | attribute_value | 145–145 | flex justify-between items-center py-1.5 px-2.5 rounded bg-raised/40 text-soft-text |
| S1aa9c6beb27f_N783 | S1aa9c6beb27f_N776 | element | 146–146 | element  |
| S1aa9c6beb27f_N784 | S1aa9c6beb27f_N783 | start_tag | 146–146 | start_tag  |
| S1aa9c6beb27f_N785 | S1aa9c6beb27f_N784 | tag_name | 146–146 | span |
| S1aa9c6beb27f_N786 | S1aa9c6beb27f_N784 | attribute | 146–146 | attribute  |
| S1aa9c6beb27f_N787 | S1aa9c6beb27f_N786 | attribute_name | 146–146 | class |
| S1aa9c6beb27f_N788 | S1aa9c6beb27f_N786 | quoted_attribute_value | 146–146 | quoted_attribute_value  |
| S1aa9c6beb27f_N789 | S1aa9c6beb27f_N788 | attribute_value | 146–146 | text-starlight font-medium |
| S1aa9c6beb27f_N790 | S1aa9c6beb27f_N783 | text | 146–146 | ↑ Ascendant in Virgo |
| S1aa9c6beb27f_N791 | S1aa9c6beb27f_N783 | end_tag | 146–146 | end_tag  |
| S1aa9c6beb27f_N792 | S1aa9c6beb27f_N791 | tag_name | 146–146 | span |
| S1aa9c6beb27f_N793 | S1aa9c6beb27f_N776 | element | 147–147 | element  |
| S1aa9c6beb27f_N794 | S1aa9c6beb27f_N793 | start_tag | 147–147 | start_tag  |
| S1aa9c6beb27f_N795 | S1aa9c6beb27f_N794 | tag_name | 147–147 | span |
| S1aa9c6beb27f_N796 | S1aa9c6beb27f_N794 | attribute | 147–147 | attribute  |
| S1aa9c6beb27f_N797 | S1aa9c6beb27f_N796 | attribute_name | 147–147 | class |
| S1aa9c6beb27f_N798 | S1aa9c6beb27f_N796 | quoted_attribute_value | 147–147 | quoted_attribute_value  |
| S1aa9c6beb27f_N799 | S1aa9c6beb27f_N798 | attribute_value | 147–147 | text-muted-text |
| S1aa9c6beb27f_N800 | S1aa9c6beb27f_N793 | text | 147–147 | Rising Sign |
| S1aa9c6beb27f_N801 | S1aa9c6beb27f_N793 | end_tag | 147–147 | end_tag  |
| S1aa9c6beb27f_N802 | S1aa9c6beb27f_N801 | tag_name | 147–147 | span |
| S1aa9c6beb27f_N803 | S1aa9c6beb27f_N776 | end_tag | 148–148 | end_tag  |
| S1aa9c6beb27f_N804 | S1aa9c6beb27f_N803 | tag_name | 148–148 | div |
| S1aa9c6beb27f_N805 | S1aa9c6beb27f_N711 | end_tag | 149–149 | end_tag  |
| S1aa9c6beb27f_N806 | S1aa9c6beb27f_N805 | tag_name | 149–149 | div |
| S1aa9c6beb27f_N807 | S1aa9c6beb27f_N668 | comment | 150–150 | &lt;!-- Static wheel sketch --&gt; |
| S1aa9c6beb27f_N808 | S1aa9c6beb27f_N668 | element | 151–159 | element  |
| S1aa9c6beb27f_N809 | S1aa9c6beb27f_N808 | start_tag | 151–151 | start_tag  |
| S1aa9c6beb27f_N810 | S1aa9c6beb27f_N809 | tag_name | 151–151 | div |
| S1aa9c6beb27f_N811 | S1aa9c6beb27f_N809 | attribute | 151–151 | attribute  |
| S1aa9c6beb27f_N812 | S1aa9c6beb27f_N811 | attribute_name | 151–151 | class |
| S1aa9c6beb27f_N813 | S1aa9c6beb27f_N811 | quoted_attribute_value | 151–151 | quoted_attribute_value  |
| S1aa9c6beb27f_N814 | S1aa9c6beb27f_N813 | attribute_value | 151–151 | mt-2 pt-3 border-t border-white/5 flex items-center justify-center py-3 |
| S1aa9c6beb27f_N815 | S1aa9c6beb27f_N808 | element | 152–158 | element  |
| S1aa9c6beb27f_N816 | S1aa9c6beb27f_N815 | start_tag | 152–152 | start_tag  |
| S1aa9c6beb27f_N817 | S1aa9c6beb27f_N816 | tag_name | 152–152 | div |
| S1aa9c6beb27f_N818 | S1aa9c6beb27f_N816 | attribute | 152–152 | attribute  |
| S1aa9c6beb27f_N819 | S1aa9c6beb27f_N818 | attribute_name | 152–152 | class |
| S1aa9c6beb27f_N820 | S1aa9c6beb27f_N818 | quoted_attribute_value | 152–152 | quoted_attribute_value  |
| S1aa9c6beb27f_N821 | S1aa9c6beb27f_N820 | attribute_value | 152–152 | w-32 h-32 rounded-full border border-dashed border-white/20 flex items-center justify-center relative |
| S1aa9c6beb27f_N822 | S1aa9c6beb27f_N815 | element | 153–155 | element  |
| S1aa9c6beb27f_N823 | S1aa9c6beb27f_N822 | start_tag | 153–153 | start_tag  |
| S1aa9c6beb27f_N824 | S1aa9c6beb27f_N823 | tag_name | 153–153 | div |
| S1aa9c6beb27f_N825 | S1aa9c6beb27f_N823 | attribute | 153–153 | attribute  |
| S1aa9c6beb27f_N826 | S1aa9c6beb27f_N825 | attribute_name | 153–153 | class |
| S1aa9c6beb27f_N827 | S1aa9c6beb27f_N825 | quoted_attribute_value | 153–153 | quoted_attribute_value  |
| S1aa9c6beb27f_N828 | S1aa9c6beb27f_N827 | attribute_value | 153–153 | w-20 h-20 rounded-full border border-white/10 flex items-center justify-center |
| S1aa9c6beb27f_N829 | S1aa9c6beb27f_N822 | element | 154–154 | element  |
| S1aa9c6beb27f_N830 | S1aa9c6beb27f_N829 | start_tag | 154–154 | start_tag  |
| S1aa9c6beb27f_N831 | S1aa9c6beb27f_N830 | tag_name | 154–154 | span |
| S1aa9c6beb27f_N832 | S1aa9c6beb27f_N830 | attribute | 154–154 | attribute  |
| S1aa9c6beb27f_N833 | S1aa9c6beb27f_N832 | attribute_name | 154–154 | class |
| S1aa9c6beb27f_N834 | S1aa9c6beb27f_N832 | quoted_attribute_value | 154–154 | quoted_attribute_value  |
| S1aa9c6beb27f_N835 | S1aa9c6beb27f_N834 | attribute_value | 154–154 | material-symbols-outlined text-muted-text text-xl |
| S1aa9c6beb27f_N836 | S1aa9c6beb27f_N829 | text | 154–154 | menu_book |
| S1aa9c6beb27f_N837 | S1aa9c6beb27f_N829 | end_tag | 154–154 | end_tag  |
| S1aa9c6beb27f_N838 | S1aa9c6beb27f_N837 | tag_name | 154–154 | span |
| S1aa9c6beb27f_N839 | S1aa9c6beb27f_N822 | end_tag | 155–155 | end_tag  |
| S1aa9c6beb27f_N840 | S1aa9c6beb27f_N839 | tag_name | 155–155 | div |
| S1aa9c6beb27f_N841 | S1aa9c6beb27f_N815 | element | 156–156 | element  |
| S1aa9c6beb27f_N842 | S1aa9c6beb27f_N841 | start_tag | 156–156 | start_tag  |
| S1aa9c6beb27f_N843 | S1aa9c6beb27f_N842 | tag_name | 156–156 | span |
| S1aa9c6beb27f_N844 | S1aa9c6beb27f_N842 | attribute | 156–156 | attribute  |
| S1aa9c6beb27f_N845 | S1aa9c6beb27f_N844 | attribute_name | 156–156 | class |
| S1aa9c6beb27f_N846 | S1aa9c6beb27f_N844 | quoted_attribute_value | 156–156 | quoted_attribute_value  |
| S1aa9c6beb27f_N847 | S1aa9c6beb27f_N846 | attribute_value | 156–156 | absolute top-2 text-[10px] font-mono text-muted-text |
| S1aa9c6beb27f_N848 | S1aa9c6beb27f_N841 | text | 156–156 | 12 Houses |
| S1aa9c6beb27f_N849 | S1aa9c6beb27f_N841 | end_tag | 156–156 | end_tag  |
| S1aa9c6beb27f_N850 | S1aa9c6beb27f_N849 | tag_name | 156–156 | span |
| S1aa9c6beb27f_N851 | S1aa9c6beb27f_N815 | element | 157–157 | element  |
| S1aa9c6beb27f_N852 | S1aa9c6beb27f_N851 | start_tag | 157–157 | start_tag  |
| S1aa9c6beb27f_N853 | S1aa9c6beb27f_N852 | tag_name | 157–157 | span |
| S1aa9c6beb27f_N854 | S1aa9c6beb27f_N852 | attribute | 157–157 | attribute  |
| S1aa9c6beb27f_N855 | S1aa9c6beb27f_N854 | attribute_name | 157–157 | class |
| S1aa9c6beb27f_N856 | S1aa9c6beb27f_N854 | quoted_attribute_value | 157–157 | quoted_attribute_value  |
| S1aa9c6beb27f_N857 | S1aa9c6beb27f_N856 | attribute_value | 157–157 | absolute bottom-2 text-[10px] font-mono text-muted-text |
| S1aa9c6beb27f_N858 | S1aa9c6beb27f_N851 | text | 157–157 | Fixed Print Layout |
| S1aa9c6beb27f_N859 | S1aa9c6beb27f_N851 | end_tag | 157–157 | end_tag  |
| S1aa9c6beb27f_N860 | S1aa9c6beb27f_N859 | tag_name | 157–157 | span |
| S1aa9c6beb27f_N861 | S1aa9c6beb27f_N815 | end_tag | 158–158 | end_tag  |
| S1aa9c6beb27f_N862 | S1aa9c6beb27f_N861 | tag_name | 158–158 | div |
| S1aa9c6beb27f_N863 | S1aa9c6beb27f_N808 | end_tag | 159–159 | end_tag  |
| S1aa9c6beb27f_N864 | S1aa9c6beb27f_N863 | tag_name | 159–159 | div |
| S1aa9c6beb27f_N865 | S1aa9c6beb27f_N668 | end_tag | 160–160 | end_tag  |
| S1aa9c6beb27f_N866 | S1aa9c6beb27f_N865 | tag_name | 160–160 | div |
| S1aa9c6beb27f_N867 | S1aa9c6beb27f_N620 | element | 161–174 | element  |
| S1aa9c6beb27f_N868 | S1aa9c6beb27f_N867 | start_tag | 161–161 | start_tag  |
| S1aa9c6beb27f_N869 | S1aa9c6beb27f_N868 | tag_name | 161–161 | ul |
| S1aa9c6beb27f_N870 | S1aa9c6beb27f_N868 | attribute | 161–161 | attribute  |
| S1aa9c6beb27f_N871 | S1aa9c6beb27f_N870 | attribute_name | 161–161 | class |
| S1aa9c6beb27f_N872 | S1aa9c6beb27f_N870 | quoted_attribute_value | 161–161 | quoted_attribute_value  |
| S1aa9c6beb27f_N873 | S1aa9c6beb27f_N872 | attribute_value | 161–161 | space-y-2 text-sm text-soft-text font-sans |
| S1aa9c6beb27f_N874 | S1aa9c6beb27f_N867 | element | 162–165 | element  |
| S1aa9c6beb27f_N875 | S1aa9c6beb27f_N874 | start_tag | 162–162 | start_tag  |
| S1aa9c6beb27f_N876 | S1aa9c6beb27f_N875 | tag_name | 162–162 | li |
| S1aa9c6beb27f_N877 | S1aa9c6beb27f_N875 | attribute | 162–162 | attribute  |
| S1aa9c6beb27f_N878 | S1aa9c6beb27f_N877 | attribute_name | 162–162 | class |
| S1aa9c6beb27f_N879 | S1aa9c6beb27f_N877 | quoted_attribute_value | 162–162 | quoted_attribute_value  |
| S1aa9c6beb27f_N880 | S1aa9c6beb27f_N879 | attribute_value | 162–162 | flex items-start gap-2 |
| S1aa9c6beb27f_N881 | S1aa9c6beb27f_N874 | element | 163–163 | element  |
| S1aa9c6beb27f_N882 | S1aa9c6beb27f_N881 | start_tag | 163–163 | start_tag  |
| S1aa9c6beb27f_N883 | S1aa9c6beb27f_N882 | tag_name | 163–163 | span |
| S1aa9c6beb27f_N884 | S1aa9c6beb27f_N882 | attribute | 163–163 | attribute  |
| S1aa9c6beb27f_N885 | S1aa9c6beb27f_N884 | attribute_name | 163–163 | class |
| S1aa9c6beb27f_N886 | S1aa9c6beb27f_N884 | quoted_attribute_value | 163–163 | quoted_attribute_value  |
| S1aa9c6beb27f_N887 | S1aa9c6beb27f_N886 | attribute_value | 163–163 | material-symbols-outlined text-muted-text text-base shrink-0 mt-0.5 |
| S1aa9c6beb27f_N888 | S1aa9c6beb27f_N881 | text | 163–163 | check_circle |
| S1aa9c6beb27f_N889 | S1aa9c6beb27f_N881 | end_tag | 163–163 | end_tag  |
| S1aa9c6beb27f_N890 | S1aa9c6beb27f_N889 | tag_name | 163–163 | span |
| S1aa9c6beb27f_N891 | S1aa9c6beb27f_N874 | element | 164–164 | element  |
| S1aa9c6beb27f_N892 | S1aa9c6beb27f_N891 | start_tag | 164–164 | start_tag  |
| S1aa9c6beb27f_N893 | S1aa9c6beb27f_N892 | tag_name | 164–164 | span |
| S1aa9c6beb27f_N894 | S1aa9c6beb27f_N891 | text | 164–164 | Full illustrated natal reading in downloadable PDF format |
| S1aa9c6beb27f_N895 | S1aa9c6beb27f_N891 | end_tag | 164–164 | end_tag  |
| S1aa9c6beb27f_N896 | S1aa9c6beb27f_N895 | tag_name | 164–164 | span |
| S1aa9c6beb27f_N897 | S1aa9c6beb27f_N874 | end_tag | 165–165 | end_tag  |
| S1aa9c6beb27f_N898 | S1aa9c6beb27f_N897 | tag_name | 165–165 | li |
| S1aa9c6beb27f_N899 | S1aa9c6beb27f_N867 | element | 166–169 | element  |
| S1aa9c6beb27f_N900 | S1aa9c6beb27f_N899 | start_tag | 166–166 | start_tag  |
| S1aa9c6beb27f_N901 | S1aa9c6beb27f_N900 | tag_name | 166–166 | li |
| S1aa9c6beb27f_N902 | S1aa9c6beb27f_N900 | attribute | 166–166 | attribute  |
| S1aa9c6beb27f_N903 | S1aa9c6beb27f_N902 | attribute_name | 166–166 | class |
| S1aa9c6beb27f_N904 | S1aa9c6beb27f_N902 | quoted_attribute_value | 166–166 | quoted_attribute_value  |
| S1aa9c6beb27f_N905 | S1aa9c6beb27f_N904 | attribute_value | 166–166 | flex items-start gap-2 |
| S1aa9c6beb27f_N906 | S1aa9c6beb27f_N899 | element | 167–167 | element  |
| S1aa9c6beb27f_N907 | S1aa9c6beb27f_N906 | start_tag | 167–167 | start_tag  |
| S1aa9c6beb27f_N908 | S1aa9c6beb27f_N907 | tag_name | 167–167 | span |
| S1aa9c6beb27f_N909 | S1aa9c6beb27f_N907 | attribute | 167–167 | attribute  |
| S1aa9c6beb27f_N910 | S1aa9c6beb27f_N909 | attribute_name | 167–167 | class |
| S1aa9c6beb27f_N911 | S1aa9c6beb27f_N909 | quoted_attribute_value | 167–167 | quoted_attribute_value  |
| S1aa9c6beb27f_N912 | S1aa9c6beb27f_N911 | attribute_value | 167–167 | material-symbols-outlined text-muted-text text-base shrink-0 mt-0.5 |
| S1aa9c6beb27f_N913 | S1aa9c6beb27f_N906 | text | 167–167 | check_circle |
| S1aa9c6beb27f_N914 | S1aa9c6beb27f_N906 | end_tag | 167–167 | end_tag  |
| S1aa9c6beb27f_N915 | S1aa9c6beb27f_N914 | tag_name | 167–167 | span |
| S1aa9c6beb27f_N916 | S1aa9c6beb27f_N899 | element | 168–168 | element  |
| S1aa9c6beb27f_N917 | S1aa9c6beb27f_N916 | start_tag | 168–168 | start_tag  |
| S1aa9c6beb27f_N918 | S1aa9c6beb27f_N917 | tag_name | 168–168 | span |
| S1aa9c6beb27f_N919 | S1aa9c6beb27f_N916 | text | 168–168 | Easy to save, archive, or print for personal keepsakes |
| S1aa9c6beb27f_N920 | S1aa9c6beb27f_N916 | end_tag | 168–168 | end_tag  |
| S1aa9c6beb27f_N921 | S1aa9c6beb27f_N920 | tag_name | 168–168 | span |
| S1aa9c6beb27f_N922 | S1aa9c6beb27f_N899 | end_tag | 169–169 | end_tag  |
| S1aa9c6beb27f_N923 | S1aa9c6beb27f_N922 | tag_name | 169–169 | li |
| S1aa9c6beb27f_N924 | S1aa9c6beb27f_N867 | element | 170–173 | element  |
| S1aa9c6beb27f_N925 | S1aa9c6beb27f_N924 | start_tag | 170–170 | start_tag  |
| S1aa9c6beb27f_N926 | S1aa9c6beb27f_N925 | tag_name | 170–170 | li |
| S1aa9c6beb27f_N927 | S1aa9c6beb27f_N925 | attribute | 170–170 | attribute  |
| S1aa9c6beb27f_N928 | S1aa9c6beb27f_N927 | attribute_name | 170–170 | class |
| S1aa9c6beb27f_N929 | S1aa9c6beb27f_N927 | quoted_attribute_value | 170–170 | quoted_attribute_value  |
| S1aa9c6beb27f_N930 | S1aa9c6beb27f_N929 | attribute_value | 170–170 | flex items-start gap-2 |
| S1aa9c6beb27f_N931 | S1aa9c6beb27f_N924 | element | 171–171 | element  |
| S1aa9c6beb27f_N932 | S1aa9c6beb27f_N931 | start_tag | 171–171 | start_tag  |
| S1aa9c6beb27f_N933 | S1aa9c6beb27f_N932 | tag_name | 171–171 | span |
| S1aa9c6beb27f_N934 | S1aa9c6beb27f_N932 | attribute | 171–171 | attribute  |
| S1aa9c6beb27f_N935 | S1aa9c6beb27f_N934 | attribute_name | 171–171 | class |
| S1aa9c6beb27f_N936 | S1aa9c6beb27f_N934 | quoted_attribute_value | 171–171 | quoted_attribute_value  |
| S1aa9c6beb27f_N937 | S1aa9c6beb27f_N936 | attribute_value | 171–171 | material-symbols-outlined text-muted-text text-base shrink-0 mt-0.5 |
| S1aa9c6beb27f_N938 | S1aa9c6beb27f_N931 | text | 171–171 | check_circle |
| S1aa9c6beb27f_N939 | S1aa9c6beb27f_N931 | end_tag | 171–171 | end_tag  |
| S1aa9c6beb27f_N940 | S1aa9c6beb27f_N939 | tag_name | 171–171 | span |
| S1aa9c6beb27f_N941 | S1aa9c6beb27f_N924 | element | 172–172 | element  |
| S1aa9c6beb27f_N942 | S1aa9c6beb27f_N941 | start_tag | 172–172 | start_tag  |
| S1aa9c6beb27f_N943 | S1aa9c6beb27f_N942 | tag_name | 172–172 | span |
| S1aa9c6beb27f_N944 | S1aa9c6beb27f_N941 | text | 172–172 | Static natal wheel and comprehensive interpretation chapters |
| S1aa9c6beb27f_N945 | S1aa9c6beb27f_N941 | end_tag | 172–172 | end_tag  |
| S1aa9c6beb27f_N946 | S1aa9c6beb27f_N945 | tag_name | 172–172 | span |
| S1aa9c6beb27f_N947 | S1aa9c6beb27f_N924 | end_tag | 173–173 | end_tag  |
| S1aa9c6beb27f_N948 | S1aa9c6beb27f_N947 | tag_name | 173–173 | li |
| S1aa9c6beb27f_N949 | S1aa9c6beb27f_N867 | end_tag | 174–174 | end_tag  |
| S1aa9c6beb27f_N950 | S1aa9c6beb27f_N949 | tag_name | 174–174 | ul |
| S1aa9c6beb27f_N951 | S1aa9c6beb27f_N620 | end_tag | 175–175 | end_tag  |
| S1aa9c6beb27f_N952 | S1aa9c6beb27f_N951 | tag_name | 175–175 | div |
| S1aa9c6beb27f_N953 | S1aa9c6beb27f_N613 | element | 176–179 | element  |
| S1aa9c6beb27f_N954 | S1aa9c6beb27f_N953 | start_tag | 176–176 | start_tag  |
| S1aa9c6beb27f_N955 | S1aa9c6beb27f_N954 | tag_name | 176–176 | div |
| S1aa9c6beb27f_N956 | S1aa9c6beb27f_N954 | attribute | 176–176 | attribute  |
| S1aa9c6beb27f_N957 | S1aa9c6beb27f_N956 | attribute_name | 176–176 | class |
| S1aa9c6beb27f_N958 | S1aa9c6beb27f_N956 | quoted_attribute_value | 176–176 | quoted_attribute_value  |
| S1aa9c6beb27f_N959 | S1aa9c6beb27f_N958 | attribute_value | 176–176 | pt-6 mt-6 border-t border-white/5 text-xs text-muted-text font-mono flex items-center gap-1.5 |
| S1aa9c6beb27f_N960 | S1aa9c6beb27f_N953 | element | 177–177 | element  |
| S1aa9c6beb27f_N961 | S1aa9c6beb27f_N960 | start_tag | 177–177 | start_tag  |
| S1aa9c6beb27f_N962 | S1aa9c6beb27f_N961 | tag_name | 177–177 | span |
| S1aa9c6beb27f_N963 | S1aa9c6beb27f_N961 | attribute | 177–177 | attribute  |
| S1aa9c6beb27f_N964 | S1aa9c6beb27f_N963 | attribute_name | 177–177 | class |
| S1aa9c6beb27f_N965 | S1aa9c6beb27f_N963 | quoted_attribute_value | 177–177 | quoted_attribute_value  |
| S1aa9c6beb27f_N966 | S1aa9c6beb27f_N965 | attribute_value | 177–177 | material-symbols-outlined text-sm |
| S1aa9c6beb27f_N967 | S1aa9c6beb27f_N960 | text | 177–177 | check |
| S1aa9c6beb27f_N968 | S1aa9c6beb27f_N960 | end_tag | 177–177 | end_tag  |
| S1aa9c6beb27f_N969 | S1aa9c6beb27f_N968 | tag_name | 177–177 | span |
| S1aa9c6beb27f_N970 | S1aa9c6beb27f_N953 | element | 178–178 | element  |
| S1aa9c6beb27f_N971 | S1aa9c6beb27f_N970 | start_tag | 178–178 | start_tag  |
| S1aa9c6beb27f_N972 | S1aa9c6beb27f_N971 | tag_name | 178–178 | span |
| S1aa9c6beb27f_N973 | S1aa9c6beb27f_N970 | text | 178–178 | Included in your current selection |
| S1aa9c6beb27f_N974 | S1aa9c6beb27f_N970 | end_tag | 178–178 | end_tag  |
| S1aa9c6beb27f_N975 | S1aa9c6beb27f_N974 | tag_name | 178–178 | span |
| S1aa9c6beb27f_N976 | S1aa9c6beb27f_N953 | end_tag | 179–179 | end_tag  |
| S1aa9c6beb27f_N977 | S1aa9c6beb27f_N976 | tag_name | 179–179 | div |
| S1aa9c6beb27f_N978 | S1aa9c6beb27f_N613 | end_tag | 180–180 | end_tag  |
| S1aa9c6beb27f_N979 | S1aa9c6beb27f_N978 | tag_name | 180–180 | div |
| S1aa9c6beb27f_N980 | S1aa9c6beb27f_N605 | comment | 181–181 | &lt;!-- Right: PDF + SPA Upgrade --&gt; |
| S1aa9c6beb27f_N981 | S1aa9c6beb27f_N605 | element | 182–257 | element  |
| S1aa9c6beb27f_N982 | S1aa9c6beb27f_N981 | start_tag | 182–182 | start_tag  |
| S1aa9c6beb27f_N983 | S1aa9c6beb27f_N982 | tag_name | 182–182 | div |
| S1aa9c6beb27f_N984 | S1aa9c6beb27f_N982 | attribute | 182–182 | attribute  |
| S1aa9c6beb27f_N985 | S1aa9c6beb27f_N984 | attribute_name | 182–182 | class |
| S1aa9c6beb27f_N986 | S1aa9c6beb27f_N984 | quoted_attribute_value | 182–182 | quoted_attribute_value  |
| S1aa9c6beb27f_N987 | S1aa9c6beb27f_N986 | attribute_value | 182–182 | bg-raised border-2 border-brass/40 rounded-2xl p-6 sm:p-7 flex flex-col justify-between relative overflow-hidden shadow-[0_4px_30px_rgba(201,170,96,0.1)] group |
| S1aa9c6beb27f_N988 | S1aa9c6beb27f_N981 | element | 183–183 | element  |
| S1aa9c6beb27f_N989 | S1aa9c6beb27f_N988 | start_tag | 183–183 | start_tag  |
| S1aa9c6beb27f_N990 | S1aa9c6beb27f_N989 | tag_name | 183–183 | div |
| S1aa9c6beb27f_N991 | S1aa9c6beb27f_N989 | attribute | 183–183 | attribute  |
| S1aa9c6beb27f_N992 | S1aa9c6beb27f_N991 | attribute_name | 183–183 | class |
| S1aa9c6beb27f_N993 | S1aa9c6beb27f_N991 | quoted_attribute_value | 183–183 | quoted_attribute_value  |
| S1aa9c6beb27f_N994 | S1aa9c6beb27f_N993 | attribute_value | 183–183 | absolute top-0 right-0 w-44 h-44 bg-brass/10 rounded-full blur-2xl pointer-events-none -mr-10 -mt-10 |
| S1aa9c6beb27f_N995 | S1aa9c6beb27f_N988 | end_tag | 183–183 | end_tag  |
| S1aa9c6beb27f_N996 | S1aa9c6beb27f_N995 | tag_name | 183–183 | div |
| S1aa9c6beb27f_N997 | S1aa9c6beb27f_N981 | element | 184–252 | element  |
| S1aa9c6beb27f_N998 | S1aa9c6beb27f_N997 | start_tag | 184–184 | start_tag  |
| S1aa9c6beb27f_N999 | S1aa9c6beb27f_N998 | tag_name | 184–184 | div |
| S1aa9c6beb27f_N1000 | S1aa9c6beb27f_N997 | element | 185–193 | element  |
| S1aa9c6beb27f_N1001 | S1aa9c6beb27f_N1000 | start_tag | 185–185 | start_tag  |
| S1aa9c6beb27f_N1002 | S1aa9c6beb27f_N1001 | tag_name | 185–185 | div |
| S1aa9c6beb27f_N1003 | S1aa9c6beb27f_N1001 | attribute | 185–185 | attribute  |
| S1aa9c6beb27f_N1004 | S1aa9c6beb27f_N1003 | attribute_name | 185–185 | class |
| S1aa9c6beb27f_N1005 | S1aa9c6beb27f_N1003 | quoted_attribute_value | 185–185 | quoted_attribute_value  |
| S1aa9c6beb27f_N1006 | S1aa9c6beb27f_N1005 | attribute_value | 185–185 | flex items-center justify-between pb-4 border-b border-white/5 mb-5 |
| S1aa9c6beb27f_N1007 | S1aa9c6beb27f_N1000 | element | 186–189 | element  |
| S1aa9c6beb27f_N1008 | S1aa9c6beb27f_N1007 | start_tag | 186–186 | start_tag  |
| S1aa9c6beb27f_N1009 | S1aa9c6beb27f_N1008 | tag_name | 186–186 | div |
| S1aa9c6beb27f_N1010 | S1aa9c6beb27f_N1007 | element | 187–187 | element  |
| S1aa9c6beb27f_N1011 | S1aa9c6beb27f_N1010 | start_tag | 187–187 | start_tag  |
| S1aa9c6beb27f_N1012 | S1aa9c6beb27f_N1011 | tag_name | 187–187 | span |
| S1aa9c6beb27f_N1013 | S1aa9c6beb27f_N1011 | attribute | 187–187 | attribute  |
| S1aa9c6beb27f_N1014 | S1aa9c6beb27f_N1013 | attribute_name | 187–187 | class |
| S1aa9c6beb27f_N1015 | S1aa9c6beb27f_N1013 | quoted_attribute_value | 187–187 | quoted_attribute_value  |
| S1aa9c6beb27f_N1016 | S1aa9c6beb27f_N1015 | attribute_value | 187–187 | text-xs font-mono text-brass font-medium uppercase tracking-wider block |
| S1aa9c6beb27f_N1017 | S1aa9c6beb27f_N1010 | text | 187–187 | Recommended Upgrade |
| S1aa9c6beb27f_N1018 | S1aa9c6beb27f_N1010 | end_tag | 187–187 | end_tag  |
| S1aa9c6beb27f_N1019 | S1aa9c6beb27f_N1018 | tag_name | 187–187 | span |
| S1aa9c6beb27f_N1020 | S1aa9c6beb27f_N1007 | element | 188–188 | element  |
| S1aa9c6beb27f_N1021 | S1aa9c6beb27f_N1020 | start_tag | 188–188 | start_tag  |
| S1aa9c6beb27f_N1022 | S1aa9c6beb27f_N1021 | tag_name | 188–188 | h2 |
| S1aa9c6beb27f_N1023 | S1aa9c6beb27f_N1021 | attribute | 188–188 | attribute  |
| S1aa9c6beb27f_N1024 | S1aa9c6beb27f_N1023 | attribute_name | 188–188 | class |
| S1aa9c6beb27f_N1025 | S1aa9c6beb27f_N1023 | quoted_attribute_value | 188–188 | quoted_attribute_value  |
| S1aa9c6beb27f_N1026 | S1aa9c6beb27f_N1025 | attribute_value | 188–188 | font-serif text-xl sm:text-2xl text-starlight font-medium mt-0.5 |
| S1aa9c6beb27f_N1027 | S1aa9c6beb27f_N1020 | text | 188–188 | Natal chart — PDF + SPA |
| S1aa9c6beb27f_N1028 | S1aa9c6beb27f_N1020 | end_tag | 188–188 | end_tag  |
| S1aa9c6beb27f_N1029 | S1aa9c6beb27f_N1028 | tag_name | 188–188 | h2 |
| S1aa9c6beb27f_N1030 | S1aa9c6beb27f_N1007 | end_tag | 189–189 | end_tag  |
| S1aa9c6beb27f_N1031 | S1aa9c6beb27f_N1030 | tag_name | 189–189 | div |
| S1aa9c6beb27f_N1032 | S1aa9c6beb27f_N1000 | element | 190–192 | element  |
| S1aa9c6beb27f_N1033 | S1aa9c6beb27f_N1032 | start_tag | 190–190 | start_tag  |
| S1aa9c6beb27f_N1034 | S1aa9c6beb27f_N1033 | tag_name | 190–190 | span |
| S1aa9c6beb27f_N1035 | S1aa9c6beb27f_N1033 | attribute | 190–190 | attribute  |
| S1aa9c6beb27f_N1036 | S1aa9c6beb27f_N1035 | attribute_name | 190–190 | class |
| S1aa9c6beb27f_N1037 | S1aa9c6beb27f_N1035 | quoted_attribute_value | 190–190 | quoted_attribute_value  |
| S1aa9c6beb27f_N1038 | S1aa9c6beb27f_N1037 | attribute_value | 190–190 | px-2.5 py-1 rounded bg-brass/20 text-brass text-xs font-mono border border-brass/30 |
| S1aa9c6beb27f_N1039 | S1aa9c6beb27f_N1032 | text | 191–191 | Sample reading |
| S1aa9c6beb27f_N1040 | S1aa9c6beb27f_N1032 | end_tag | 192–192 | end_tag  |
| S1aa9c6beb27f_N1041 | S1aa9c6beb27f_N1040 | tag_name | 192–192 | span |
| S1aa9c6beb27f_N1042 | S1aa9c6beb27f_N1000 | end_tag | 193–193 | end_tag  |
| S1aa9c6beb27f_N1043 | S1aa9c6beb27f_N1042 | tag_name | 193–193 | div |
| S1aa9c6beb27f_N1044 | S1aa9c6beb27f_N997 | comment | 194–194 | &lt;!-- Interactive Chart Preview Simulation --&gt; |
| S1aa9c6beb27f_N1045 | S1aa9c6beb27f_N997 | element | 195–233 | element  |
| S1aa9c6beb27f_N1046 | S1aa9c6beb27f_N1045 | start_tag | 195–195 | start_tag  |
| S1aa9c6beb27f_N1047 | S1aa9c6beb27f_N1046 | tag_name | 195–195 | div |
| S1aa9c6beb27f_N1048 | S1aa9c6beb27f_N1046 | attribute | 195–195 | attribute  |
| S1aa9c6beb27f_N1049 | S1aa9c6beb27f_N1048 | attribute_name | 195–195 | class |
| S1aa9c6beb27f_N1050 | S1aa9c6beb27f_N1048 | quoted_attribute_value | 195–195 | quoted_attribute_value  |
| S1aa9c6beb27f_N1051 | S1aa9c6beb27f_N1050 | attribute_value | 195–195 | bg-obs border border-brass/20 rounded-xl p-5 mb-5 relative overflow-hidden |
| S1aa9c6beb27f_N1052 | S1aa9c6beb27f_N1045 | element | 196–199 | element  |
| S1aa9c6beb27f_N1053 | S1aa9c6beb27f_N1052 | start_tag | 196–196 | start_tag  |
| S1aa9c6beb27f_N1054 | S1aa9c6beb27f_N1053 | tag_name | 196–196 | div |
| S1aa9c6beb27f_N1055 | S1aa9c6beb27f_N1053 | attribute | 196–196 | attribute  |
| S1aa9c6beb27f_N1056 | S1aa9c6beb27f_N1055 | attribute_name | 196–196 | class |
| S1aa9c6beb27f_N1057 | S1aa9c6beb27f_N1055 | quoted_attribute_value | 196–196 | quoted_attribute_value  |
| S1aa9c6beb27f_N1058 | S1aa9c6beb27f_N1057 | attribute_value | 196–196 | flex items-center justify-between font-mono text-xs text-brass pb-3 border-b border-white/5 |
| S1aa9c6beb27f_N1059 | S1aa9c6beb27f_N1052 | element | 197–197 | element  |
| S1aa9c6beb27f_N1060 | S1aa9c6beb27f_N1059 | start_tag | 197–197 | start_tag  |
| S1aa9c6beb27f_N1061 | S1aa9c6beb27f_N1060 | tag_name | 197–197 | span |
| S1aa9c6beb27f_N1062 | S1aa9c6beb27f_N1060 | attribute | 197–197 | attribute  |
| S1aa9c6beb27f_N1063 | S1aa9c6beb27f_N1062 | attribute_name | 197–197 | class |
| S1aa9c6beb27f_N1064 | S1aa9c6beb27f_N1062 | quoted_attribute_value | 197–197 | quoted_attribute_value  |
| S1aa9c6beb27f_N1065 | S1aa9c6beb27f_N1064 | attribute_value | 197–197 | flex items-center gap-1.5 |
| S1aa9c6beb27f_N1066 | S1aa9c6beb27f_N1059 | element | 197–197 | element  |
| S1aa9c6beb27f_N1067 | S1aa9c6beb27f_N1066 | start_tag | 197–197 | start_tag  |
| S1aa9c6beb27f_N1068 | S1aa9c6beb27f_N1067 | tag_name | 197–197 | span |
| S1aa9c6beb27f_N1069 | S1aa9c6beb27f_N1067 | attribute | 197–197 | attribute  |
| S1aa9c6beb27f_N1070 | S1aa9c6beb27f_N1069 | attribute_name | 197–197 | class |
| S1aa9c6beb27f_N1071 | S1aa9c6beb27f_N1069 | quoted_attribute_value | 197–197 | quoted_attribute_value  |
| S1aa9c6beb27f_N1072 | S1aa9c6beb27f_N1071 | attribute_value | 197–197 | material-symbols-outlined text-sm |
| S1aa9c6beb27f_N1073 | S1aa9c6beb27f_N1066 | text | 197–197 | touch_app |
| S1aa9c6beb27f_N1074 | S1aa9c6beb27f_N1066 | end_tag | 197–197 | end_tag  |
| S1aa9c6beb27f_N1075 | S1aa9c6beb27f_N1074 | tag_name | 197–197 | span |
| S1aa9c6beb27f_N1076 | S1aa9c6beb27f_N1059 | text | 197–197 | Interactive chart experience in your browser |
| S1aa9c6beb27f_N1077 | S1aa9c6beb27f_N1059 | end_tag | 197–197 | end_tag  |
| S1aa9c6beb27f_N1078 | S1aa9c6beb27f_N1077 | tag_name | 197–197 | span |
| S1aa9c6beb27f_N1079 | S1aa9c6beb27f_N1052 | element | 198–198 | element  |
| S1aa9c6beb27f_N1080 | S1aa9c6beb27f_N1079 | start_tag | 198–198 | start_tag  |
| S1aa9c6beb27f_N1081 | S1aa9c6beb27f_N1080 | tag_name | 198–198 | span |
| S1aa9c6beb27f_N1082 | S1aa9c6beb27f_N1080 | attribute | 198–198 | attribute  |
| S1aa9c6beb27f_N1083 | S1aa9c6beb27f_N1082 | attribute_name | 198–198 | class |
| S1aa9c6beb27f_N1084 | S1aa9c6beb27f_N1082 | quoted_attribute_value | 198–198 | quoted_attribute_value  |
| S1aa9c6beb27f_N1085 | S1aa9c6beb27f_N1084 | attribute_value | 198–198 | text-xs bg-raised px-2 py-0.5 rounded text-starlight |
| S1aa9c6beb27f_N1086 | S1aa9c6beb27f_N1079 | text | 198–198 | Live view |
| S1aa9c6beb27f_N1087 | S1aa9c6beb27f_N1079 | end_tag | 198–198 | end_tag  |
| S1aa9c6beb27f_N1088 | S1aa9c6beb27f_N1087 | tag_name | 198–198 | span |
| S1aa9c6beb27f_N1089 | S1aa9c6beb27f_N1052 | end_tag | 199–199 | end_tag  |
| S1aa9c6beb27f_N1090 | S1aa9c6beb27f_N1089 | tag_name | 199–199 | div |
| S1aa9c6beb27f_N1091 | S1aa9c6beb27f_N1045 | comment | 200–200 | &lt;!-- Interactive Chart Visual Wheel --&gt; |
| S1aa9c6beb27f_N1092 | S1aa9c6beb27f_N1045 | element | 201–232 | element  |
| S1aa9c6beb27f_N1093 | S1aa9c6beb27f_N1092 | start_tag | 201–201 | start_tag  |
| S1aa9c6beb27f_N1094 | S1aa9c6beb27f_N1093 | tag_name | 201–201 | div |
| S1aa9c6beb27f_N1095 | S1aa9c6beb27f_N1093 | attribute | 201–201 | attribute  |
| S1aa9c6beb27f_N1096 | S1aa9c6beb27f_N1095 | attribute_name | 201–201 | class |
| S1aa9c6beb27f_N1097 | S1aa9c6beb27f_N1095 | quoted_attribute_value | 201–201 | quoted_attribute_value  |
| S1aa9c6beb27f_N1098 | S1aa9c6beb27f_N1097 | attribute_value | 201–201 | py-3 flex flex-col items-center justify-center relative |
| S1aa9c6beb27f_N1099 | S1aa9c6beb27f_N1092 | element | 202–224 | element  |
| S1aa9c6beb27f_N1100 | S1aa9c6beb27f_N1099 | start_tag | 202–202 | start_tag  |
| S1aa9c6beb27f_N1101 | S1aa9c6beb27f_N1100 | tag_name | 202–202 | div |
| S1aa9c6beb27f_N1102 | S1aa9c6beb27f_N1100 | attribute | 202–202 | attribute  |
| S1aa9c6beb27f_N1103 | S1aa9c6beb27f_N1102 | attribute_name | 202–202 | class |
| S1aa9c6beb27f_N1104 | S1aa9c6beb27f_N1102 | quoted_attribute_value | 202–202 | quoted_attribute_value  |
| S1aa9c6beb27f_N1105 | S1aa9c6beb27f_N1104 | attribute_value | 202–202 | relative w-40 h-40 flex items-center justify-center my-2 cursor-pointer group/wheel |
| S1aa9c6beb27f_N1106 | S1aa9c6beb27f_N1100 | attribute | 202–202 | attribute  |
| S1aa9c6beb27f_N1107 | S1aa9c6beb27f_N1106 | attribute_name | 202–202 | id |
| S1aa9c6beb27f_N1108 | S1aa9c6beb27f_N1106 | quoted_attribute_value | 202–202 | quoted_attribute_value  |
| S1aa9c6beb27f_N1109 | S1aa9c6beb27f_N1108 | attribute_value | 202–202 | interactive-wheel |
| S1aa9c6beb27f_N1110 | S1aa9c6beb27f_N1099 | comment | 203–203 | &lt;!-- Ambient Ring Glow --&gt; |
| S1aa9c6beb27f_N1111 | S1aa9c6beb27f_N1099 | element | 204–204 | element  |
| S1aa9c6beb27f_N1112 | S1aa9c6beb27f_N1111 | start_tag | 204–204 | start_tag  |
| S1aa9c6beb27f_N1113 | S1aa9c6beb27f_N1112 | tag_name | 204–204 | div |
| S1aa9c6beb27f_N1114 | S1aa9c6beb27f_N1112 | attribute | 204–204 | attribute  |
| S1aa9c6beb27f_N1115 | S1aa9c6beb27f_N1114 | attribute_name | 204–204 | class |
| S1aa9c6beb27f_N1116 | S1aa9c6beb27f_N1114 | quoted_attribute_value | 204–204 | quoted_attribute_value  |
| S1aa9c6beb27f_N1117 | S1aa9c6beb27f_N1116 | attribute_value | 204–204 | absolute inset-0 rounded-full bg-brass/5 group-hover/wheel:bg-brass/15 transition-all |
| S1aa9c6beb27f_N1118 | S1aa9c6beb27f_N1111 | end_tag | 204–204 | end_tag  |
| S1aa9c6beb27f_N1119 | S1aa9c6beb27f_N1118 | tag_name | 204–204 | div |
| S1aa9c6beb27f_N1120 | S1aa9c6beb27f_N1099 | comment | 205–205 | &lt;!-- Outer Dial --&gt; |
| S1aa9c6beb27f_N1121 | S1aa9c6beb27f_N1099 | element | 206–206 | element  |
| S1aa9c6beb27f_N1122 | S1aa9c6beb27f_N1121 | start_tag | 206–206 | start_tag  |
| S1aa9c6beb27f_N1123 | S1aa9c6beb27f_N1122 | tag_name | 206–206 | div |
| S1aa9c6beb27f_N1124 | S1aa9c6beb27f_N1122 | attribute | 206–206 | attribute  |
| S1aa9c6beb27f_N1125 | S1aa9c6beb27f_N1124 | attribute_name | 206–206 | class |
| S1aa9c6beb27f_N1126 | S1aa9c6beb27f_N1124 | quoted_attribute_value | 206–206 | quoted_attribute_value  |
| S1aa9c6beb27f_N1127 | S1aa9c6beb27f_N1126 | attribute_value | 206–206 | absolute inset-0 rounded-full border border-brass/30 |
| S1aa9c6beb27f_N1128 | S1aa9c6beb27f_N1121 | end_tag | 206–206 | end_tag  |
| S1aa9c6beb27f_N1129 | S1aa9c6beb27f_N1128 | tag_name | 206–206 | div |
| S1aa9c6beb27f_N1130 | S1aa9c6beb27f_N1099 | element | 207–207 | element  |
| S1aa9c6beb27f_N1131 | S1aa9c6beb27f_N1130 | start_tag | 207–207 | start_tag  |
| S1aa9c6beb27f_N1132 | S1aa9c6beb27f_N1131 | tag_name | 207–207 | div |
| S1aa9c6beb27f_N1133 | S1aa9c6beb27f_N1131 | attribute | 207–207 | attribute  |
| S1aa9c6beb27f_N1134 | S1aa9c6beb27f_N1133 | attribute_name | 207–207 | class |
| S1aa9c6beb27f_N1135 | S1aa9c6beb27f_N1133 | quoted_attribute_value | 207–207 | quoted_attribute_value  |
| S1aa9c6beb27f_N1136 | S1aa9c6beb27f_N1135 | attribute_value | 207–207 | absolute inset-3 rounded-full border border-dashed border-brass/20 |
| S1aa9c6beb27f_N1137 | S1aa9c6beb27f_N1130 | end_tag | 207–207 | end_tag  |
| S1aa9c6beb27f_N1138 | S1aa9c6beb27f_N1137 | tag_name | 207–207 | div |
| S1aa9c6beb27f_N1139 | S1aa9c6beb27f_N1099 | comment | 208–208 | &lt;!-- Aspect Lines --&gt; |
| S1aa9c6beb27f_N1140 | S1aa9c6beb27f_N1099 | element | 209–219 | element  |
| S1aa9c6beb27f_N1141 | S1aa9c6beb27f_N1140 | start_tag | 209–209 | start_tag  |
| S1aa9c6beb27f_N1142 | S1aa9c6beb27f_N1141 | tag_name | 209–209 | svg |
| S1aa9c6beb27f_N1143 | S1aa9c6beb27f_N1141 | attribute | 209–209 | attribute  |
| S1aa9c6beb27f_N1144 | S1aa9c6beb27f_N1143 | attribute_name | 209–209 | class |
| S1aa9c6beb27f_N1145 | S1aa9c6beb27f_N1143 | quoted_attribute_value | 209–209 | quoted_attribute_value  |
| S1aa9c6beb27f_N1146 | S1aa9c6beb27f_N1145 | attribute_value | 209–209 | absolute inset-0 w-full h-full |
| S1aa9c6beb27f_N1147 | S1aa9c6beb27f_N1141 | attribute | 209–209 | attribute  |
| S1aa9c6beb27f_N1148 | S1aa9c6beb27f_N1147 | attribute_name | 209–209 | viewbox |
| S1aa9c6beb27f_N1149 | S1aa9c6beb27f_N1147 | quoted_attribute_value | 209–209 | quoted_attribute_value  |
| S1aa9c6beb27f_N1150 | S1aa9c6beb27f_N1149 | attribute_value | 209–209 | 0 0 160 160 |
| S1aa9c6beb27f_N1151 | S1aa9c6beb27f_N1140 | element | 210–210 | element  |
| S1aa9c6beb27f_N1152 | S1aa9c6beb27f_N1151 | start_tag | 210–210 | start_tag  |
| S1aa9c6beb27f_N1153 | S1aa9c6beb27f_N1152 | tag_name | 210–210 | line |
| S1aa9c6beb27f_N1154 | S1aa9c6beb27f_N1152 | attribute | 210–210 | attribute  |
| S1aa9c6beb27f_N1155 | S1aa9c6beb27f_N1154 | attribute_name | 210–210 | stroke |
| S1aa9c6beb27f_N1156 | S1aa9c6beb27f_N1154 | quoted_attribute_value | 210–210 | quoted_attribute_value  |
| S1aa9c6beb27f_N1157 | S1aa9c6beb27f_N1156 | attribute_value | 210–210 | #C9AA60 |
| S1aa9c6beb27f_N1158 | S1aa9c6beb27f_N1152 | attribute | 210–210 | attribute  |
| S1aa9c6beb27f_N1159 | S1aa9c6beb27f_N1158 | attribute_name | 210–210 | stroke-opacity |
| S1aa9c6beb27f_N1160 | S1aa9c6beb27f_N1158 | quoted_attribute_value | 210–210 | quoted_attribute_value  |
| S1aa9c6beb27f_N1161 | S1aa9c6beb27f_N1160 | attribute_value | 210–210 | 0.3 |
| S1aa9c6beb27f_N1162 | S1aa9c6beb27f_N1152 | attribute | 210–210 | attribute  |
| S1aa9c6beb27f_N1163 | S1aa9c6beb27f_N1162 | attribute_name | 210–210 | stroke-width |
| S1aa9c6beb27f_N1164 | S1aa9c6beb27f_N1162 | quoted_attribute_value | 210–210 | quoted_attribute_value  |
| S1aa9c6beb27f_N1165 | S1aa9c6beb27f_N1164 | attribute_value | 210–210 | 0.75 |
| S1aa9c6beb27f_N1166 | S1aa9c6beb27f_N1152 | attribute | 210–210 | attribute  |
| S1aa9c6beb27f_N1167 | S1aa9c6beb27f_N1166 | attribute_name | 210–210 | x1 |
| S1aa9c6beb27f_N1168 | S1aa9c6beb27f_N1166 | quoted_attribute_value | 210–210 | quoted_attribute_value  |
| S1aa9c6beb27f_N1169 | S1aa9c6beb27f_N1168 | attribute_value | 210–210 | 80 |
| S1aa9c6beb27f_N1170 | S1aa9c6beb27f_N1152 | attribute | 210–210 | attribute  |
| S1aa9c6beb27f_N1171 | S1aa9c6beb27f_N1170 | attribute_name | 210–210 | x2 |
| S1aa9c6beb27f_N1172 | S1aa9c6beb27f_N1170 | quoted_attribute_value | 210–210 | quoted_attribute_value  |
| S1aa9c6beb27f_N1173 | S1aa9c6beb27f_N1172 | attribute_value | 210–210 | 80 |
| S1aa9c6beb27f_N1174 | S1aa9c6beb27f_N1152 | attribute | 210–210 | attribute  |
| S1aa9c6beb27f_N1175 | S1aa9c6beb27f_N1174 | attribute_name | 210–210 | y1 |
| S1aa9c6beb27f_N1176 | S1aa9c6beb27f_N1174 | quoted_attribute_value | 210–210 | quoted_attribute_value  |
| S1aa9c6beb27f_N1177 | S1aa9c6beb27f_N1176 | attribute_value | 210–210 | 20 |
| S1aa9c6beb27f_N1178 | S1aa9c6beb27f_N1152 | attribute | 210–210 | attribute  |
| S1aa9c6beb27f_N1179 | S1aa9c6beb27f_N1178 | attribute_name | 210–210 | y2 |
| S1aa9c6beb27f_N1180 | S1aa9c6beb27f_N1178 | quoted_attribute_value | 210–210 | quoted_attribute_value  |
| S1aa9c6beb27f_N1181 | S1aa9c6beb27f_N1180 | attribute_value | 210–210 | 140 |
| S1aa9c6beb27f_N1182 | S1aa9c6beb27f_N1151 | end_tag | 210–210 | end_tag  |
| S1aa9c6beb27f_N1183 | S1aa9c6beb27f_N1182 | tag_name | 210–210 | line |
| S1aa9c6beb27f_N1184 | S1aa9c6beb27f_N1140 | element | 211–211 | element  |
| S1aa9c6beb27f_N1185 | S1aa9c6beb27f_N1184 | start_tag | 211–211 | start_tag  |
| S1aa9c6beb27f_N1186 | S1aa9c6beb27f_N1185 | tag_name | 211–211 | line |
| S1aa9c6beb27f_N1187 | S1aa9c6beb27f_N1185 | attribute | 211–211 | attribute  |
| S1aa9c6beb27f_N1188 | S1aa9c6beb27f_N1187 | attribute_name | 211–211 | stroke |
| S1aa9c6beb27f_N1189 | S1aa9c6beb27f_N1187 | quoted_attribute_value | 211–211 | quoted_attribute_value  |
| S1aa9c6beb27f_N1190 | S1aa9c6beb27f_N1189 | attribute_value | 211–211 | #C9AA60 |
| S1aa9c6beb27f_N1191 | S1aa9c6beb27f_N1185 | attribute | 211–211 | attribute  |
| S1aa9c6beb27f_N1192 | S1aa9c6beb27f_N1191 | attribute_name | 211–211 | stroke-opacity |
| S1aa9c6beb27f_N1193 | S1aa9c6beb27f_N1191 | quoted_attribute_value | 211–211 | quoted_attribute_value  |
| S1aa9c6beb27f_N1194 | S1aa9c6beb27f_N1193 | attribute_value | 211–211 | 0.3 |
| S1aa9c6beb27f_N1195 | S1aa9c6beb27f_N1185 | attribute | 211–211 | attribute  |
| S1aa9c6beb27f_N1196 | S1aa9c6beb27f_N1195 | attribute_name | 211–211 | stroke-width |
| S1aa9c6beb27f_N1197 | S1aa9c6beb27f_N1195 | quoted_attribute_value | 211–211 | quoted_attribute_value  |
| S1aa9c6beb27f_N1198 | S1aa9c6beb27f_N1197 | attribute_value | 211–211 | 0.75 |
| S1aa9c6beb27f_N1199 | S1aa9c6beb27f_N1185 | attribute | 211–211 | attribute  |
| S1aa9c6beb27f_N1200 | S1aa9c6beb27f_N1199 | attribute_name | 211–211 | x1 |
| S1aa9c6beb27f_N1201 | S1aa9c6beb27f_N1199 | quoted_attribute_value | 211–211 | quoted_attribute_value  |
| S1aa9c6beb27f_N1202 | S1aa9c6beb27f_N1201 | attribute_value | 211–211 | 20 |
| S1aa9c6beb27f_N1203 | S1aa9c6beb27f_N1185 | attribute | 211–211 | attribute  |
| S1aa9c6beb27f_N1204 | S1aa9c6beb27f_N1203 | attribute_name | 211–211 | x2 |
| S1aa9c6beb27f_N1205 | S1aa9c6beb27f_N1203 | quoted_attribute_value | 211–211 | quoted_attribute_value  |
| S1aa9c6beb27f_N1206 | S1aa9c6beb27f_N1205 | attribute_value | 211–211 | 140 |
| S1aa9c6beb27f_N1207 | S1aa9c6beb27f_N1185 | attribute | 211–211 | attribute  |
| S1aa9c6beb27f_N1208 | S1aa9c6beb27f_N1207 | attribute_name | 211–211 | y1 |
| S1aa9c6beb27f_N1209 | S1aa9c6beb27f_N1207 | quoted_attribute_value | 211–211 | quoted_attribute_value  |
| S1aa9c6beb27f_N1210 | S1aa9c6beb27f_N1209 | attribute_value | 211–211 | 80 |
| S1aa9c6beb27f_N1211 | S1aa9c6beb27f_N1185 | attribute | 211–211 | attribute  |
| S1aa9c6beb27f_N1212 | S1aa9c6beb27f_N1211 | attribute_name | 211–211 | y2 |
| S1aa9c6beb27f_N1213 | S1aa9c6beb27f_N1211 | quoted_attribute_value | 211–211 | quoted_attribute_value  |
| S1aa9c6beb27f_N1214 | S1aa9c6beb27f_N1213 | attribute_value | 211–211 | 80 |
| S1aa9c6beb27f_N1215 | S1aa9c6beb27f_N1184 | end_tag | 211–211 | end_tag  |
| S1aa9c6beb27f_N1216 | S1aa9c6beb27f_N1215 | tag_name | 211–211 | line |
| S1aa9c6beb27f_N1217 | S1aa9c6beb27f_N1140 | element | 212–212 | element  |
| S1aa9c6beb27f_N1218 | S1aa9c6beb27f_N1217 | start_tag | 212–212 | start_tag  |
| S1aa9c6beb27f_N1219 | S1aa9c6beb27f_N1218 | tag_name | 212–212 | line |
| S1aa9c6beb27f_N1220 | S1aa9c6beb27f_N1218 | attribute | 212–212 | attribute  |
| S1aa9c6beb27f_N1221 | S1aa9c6beb27f_N1220 | attribute_name | 212–212 | stroke |
| S1aa9c6beb27f_N1222 | S1aa9c6beb27f_N1220 | quoted_attribute_value | 212–212 | quoted_attribute_value  |
| S1aa9c6beb27f_N1223 | S1aa9c6beb27f_N1222 | attribute_value | 212–212 | #C9AA60 |
| S1aa9c6beb27f_N1224 | S1aa9c6beb27f_N1218 | attribute | 212–212 | attribute  |
| S1aa9c6beb27f_N1225 | S1aa9c6beb27f_N1224 | attribute_name | 212–212 | stroke-dasharray |
| S1aa9c6beb27f_N1226 | S1aa9c6beb27f_N1224 | quoted_attribute_value | 212–212 | quoted_attribute_value  |
| S1aa9c6beb27f_N1227 | S1aa9c6beb27f_N1226 | attribute_value | 212–212 | 3 3 |
| S1aa9c6beb27f_N1228 | S1aa9c6beb27f_N1218 | attribute | 212–212 | attribute  |
| S1aa9c6beb27f_N1229 | S1aa9c6beb27f_N1228 | attribute_name | 212–212 | stroke-width |
| S1aa9c6beb27f_N1230 | S1aa9c6beb27f_N1228 | quoted_attribute_value | 212–212 | quoted_attribute_value  |
| S1aa9c6beb27f_N1231 | S1aa9c6beb27f_N1230 | attribute_value | 212–212 | 1.2 |
| S1aa9c6beb27f_N1232 | S1aa9c6beb27f_N1218 | attribute | 212–212 | attribute  |
| S1aa9c6beb27f_N1233 | S1aa9c6beb27f_N1232 | attribute_name | 212–212 | x1 |
| S1aa9c6beb27f_N1234 | S1aa9c6beb27f_N1232 | quoted_attribute_value | 212–212 | quoted_attribute_value  |
| S1aa9c6beb27f_N1235 | S1aa9c6beb27f_N1234 | attribute_value | 212–212 | 40 |
| S1aa9c6beb27f_N1236 | S1aa9c6beb27f_N1218 | attribute | 212–212 | attribute  |
| S1aa9c6beb27f_N1237 | S1aa9c6beb27f_N1236 | attribute_name | 212–212 | x2 |
| S1aa9c6beb27f_N1238 | S1aa9c6beb27f_N1236 | quoted_attribute_value | 212–212 | quoted_attribute_value  |
| S1aa9c6beb27f_N1239 | S1aa9c6beb27f_N1238 | attribute_value | 212–212 | 120 |
| S1aa9c6beb27f_N1240 | S1aa9c6beb27f_N1218 | attribute | 212–212 | attribute  |
| S1aa9c6beb27f_N1241 | S1aa9c6beb27f_N1240 | attribute_name | 212–212 | y1 |
| S1aa9c6beb27f_N1242 | S1aa9c6beb27f_N1240 | quoted_attribute_value | 212–212 | quoted_attribute_value  |
| S1aa9c6beb27f_N1243 | S1aa9c6beb27f_N1242 | attribute_value | 212–212 | 40 |
| S1aa9c6beb27f_N1244 | S1aa9c6beb27f_N1218 | attribute | 212–212 | attribute  |
| S1aa9c6beb27f_N1245 | S1aa9c6beb27f_N1244 | attribute_name | 212–212 | y2 |
| S1aa9c6beb27f_N1246 | S1aa9c6beb27f_N1244 | quoted_attribute_value | 212–212 | quoted_attribute_value  |
| S1aa9c6beb27f_N1247 | S1aa9c6beb27f_N1246 | attribute_value | 212–212 | 120 |
| S1aa9c6beb27f_N1248 | S1aa9c6beb27f_N1217 | end_tag | 212–212 | end_tag  |
| S1aa9c6beb27f_N1249 | S1aa9c6beb27f_N1248 | tag_name | 212–212 | line |
| S1aa9c6beb27f_N1250 | S1aa9c6beb27f_N1140 | element | 213–213 | element  |
| S1aa9c6beb27f_N1251 | S1aa9c6beb27f_N1250 | start_tag | 213–213 | start_tag  |
| S1aa9c6beb27f_N1252 | S1aa9c6beb27f_N1251 | tag_name | 213–213 | line |
| S1aa9c6beb27f_N1253 | S1aa9c6beb27f_N1251 | attribute | 213–213 | attribute  |
| S1aa9c6beb27f_N1254 | S1aa9c6beb27f_N1253 | attribute_name | 213–213 | stroke |
| S1aa9c6beb27f_N1255 | S1aa9c6beb27f_N1253 | quoted_attribute_value | 213–213 | quoted_attribute_value  |
| S1aa9c6beb27f_N1256 | S1aa9c6beb27f_N1255 | attribute_value | 213–213 | #DFC37D |
| S1aa9c6beb27f_N1257 | S1aa9c6beb27f_N1251 | attribute | 213–213 | attribute  |
| S1aa9c6beb27f_N1258 | S1aa9c6beb27f_N1257 | attribute_name | 213–213 | stroke-width |
| S1aa9c6beb27f_N1259 | S1aa9c6beb27f_N1257 | quoted_attribute_value | 213–213 | quoted_attribute_value  |
| S1aa9c6beb27f_N1260 | S1aa9c6beb27f_N1259 | attribute_value | 213–213 | 1.2 |
| S1aa9c6beb27f_N1261 | S1aa9c6beb27f_N1251 | attribute | 213–213 | attribute  |
| S1aa9c6beb27f_N1262 | S1aa9c6beb27f_N1261 | attribute_name | 213–213 | x1 |
| S1aa9c6beb27f_N1263 | S1aa9c6beb27f_N1261 | quoted_attribute_value | 213–213 | quoted_attribute_value  |
| S1aa9c6beb27f_N1264 | S1aa9c6beb27f_N1263 | attribute_value | 213–213 | 120 |
| S1aa9c6beb27f_N1265 | S1aa9c6beb27f_N1251 | attribute | 213–213 | attribute  |
| S1aa9c6beb27f_N1266 | S1aa9c6beb27f_N1265 | attribute_name | 213–213 | x2 |
| S1aa9c6beb27f_N1267 | S1aa9c6beb27f_N1265 | quoted_attribute_value | 213–213 | quoted_attribute_value  |
| S1aa9c6beb27f_N1268 | S1aa9c6beb27f_N1267 | attribute_value | 213–213 | 40 |
| S1aa9c6beb27f_N1269 | S1aa9c6beb27f_N1251 | attribute | 213–213 | attribute  |
| S1aa9c6beb27f_N1270 | S1aa9c6beb27f_N1269 | attribute_name | 213–213 | y1 |
| S1aa9c6beb27f_N1271 | S1aa9c6beb27f_N1269 | quoted_attribute_value | 213–213 | quoted_attribute_value  |
| S1aa9c6beb27f_N1272 | S1aa9c6beb27f_N1271 | attribute_value | 213–213 | 40 |
| S1aa9c6beb27f_N1273 | S1aa9c6beb27f_N1251 | attribute | 213–213 | attribute  |
| S1aa9c6beb27f_N1274 | S1aa9c6beb27f_N1273 | attribute_name | 213–213 | y2 |
| S1aa9c6beb27f_N1275 | S1aa9c6beb27f_N1273 | quoted_attribute_value | 213–213 | quoted_attribute_value  |
| S1aa9c6beb27f_N1276 | S1aa9c6beb27f_N1275 | attribute_value | 213–213 | 120 |
| S1aa9c6beb27f_N1277 | S1aa9c6beb27f_N1250 | end_tag | 213–213 | end_tag  |
| S1aa9c6beb27f_N1278 | S1aa9c6beb27f_N1277 | tag_name | 213–213 | line |
| S1aa9c6beb27f_N1279 | S1aa9c6beb27f_N1140 | comment | 214–214 | &lt;!-- Nodes with gentle glow --&gt; |
| S1aa9c6beb27f_N1280 | S1aa9c6beb27f_N1140 | element | 215–215 | element  |
| S1aa9c6beb27f_N1281 | S1aa9c6beb27f_N1280 | start_tag | 215–215 | start_tag  |
| S1aa9c6beb27f_N1282 | S1aa9c6beb27f_N1281 | tag_name | 215–215 | circle |
| S1aa9c6beb27f_N1283 | S1aa9c6beb27f_N1281 | attribute | 215–215 | attribute  |
| S1aa9c6beb27f_N1284 | S1aa9c6beb27f_N1283 | attribute_name | 215–215 | class |
| S1aa9c6beb27f_N1285 | S1aa9c6beb27f_N1283 | quoted_attribute_value | 215–215 | quoted_attribute_value  |
| S1aa9c6beb27f_N1286 | S1aa9c6beb27f_N1285 | attribute_value | 215–215 | animate-pulse |
| S1aa9c6beb27f_N1287 | S1aa9c6beb27f_N1281 | attribute | 215–215 | attribute  |
| S1aa9c6beb27f_N1288 | S1aa9c6beb27f_N1287 | attribute_name | 215–215 | cx |
| S1aa9c6beb27f_N1289 | S1aa9c6beb27f_N1287 | quoted_attribute_value | 215–215 | quoted_attribute_value  |
| S1aa9c6beb27f_N1290 | S1aa9c6beb27f_N1289 | attribute_value | 215–215 | 80 |
| S1aa9c6beb27f_N1291 | S1aa9c6beb27f_N1281 | attribute | 215–215 | attribute  |
| S1aa9c6beb27f_N1292 | S1aa9c6beb27f_N1291 | attribute_name | 215–215 | cy |
| S1aa9c6beb27f_N1293 | S1aa9c6beb27f_N1291 | quoted_attribute_value | 215–215 | quoted_attribute_value  |
| S1aa9c6beb27f_N1294 | S1aa9c6beb27f_N1293 | attribute_value | 215–215 | 24 |
| S1aa9c6beb27f_N1295 | S1aa9c6beb27f_N1281 | attribute | 215–215 | attribute  |
| S1aa9c6beb27f_N1296 | S1aa9c6beb27f_N1295 | attribute_name | 215–215 | fill |
| S1aa9c6beb27f_N1297 | S1aa9c6beb27f_N1295 | quoted_attribute_value | 215–215 | quoted_attribute_value  |
| S1aa9c6beb27f_N1298 | S1aa9c6beb27f_N1297 | attribute_value | 215–215 | #C9AA60 |
| S1aa9c6beb27f_N1299 | S1aa9c6beb27f_N1281 | attribute | 215–215 | attribute  |
| S1aa9c6beb27f_N1300 | S1aa9c6beb27f_N1299 | attribute_name | 215–215 | r |
| S1aa9c6beb27f_N1301 | S1aa9c6beb27f_N1299 | quoted_attribute_value | 215–215 | quoted_attribute_value  |
| S1aa9c6beb27f_N1302 | S1aa9c6beb27f_N1301 | attribute_value | 215–215 | 5 |
| S1aa9c6beb27f_N1303 | S1aa9c6beb27f_N1280 | end_tag | 215–215 | end_tag  |
| S1aa9c6beb27f_N1304 | S1aa9c6beb27f_N1303 | tag_name | 215–215 | circle |
| S1aa9c6beb27f_N1305 | S1aa9c6beb27f_N1140 | element | 216–216 | element  |
| S1aa9c6beb27f_N1306 | S1aa9c6beb27f_N1305 | start_tag | 216–216 | start_tag  |
| S1aa9c6beb27f_N1307 | S1aa9c6beb27f_N1306 | tag_name | 216–216 | circle |
| S1aa9c6beb27f_N1308 | S1aa9c6beb27f_N1306 | attribute | 216–216 | attribute  |
| S1aa9c6beb27f_N1309 | S1aa9c6beb27f_N1308 | attribute_name | 216–216 | cx |
| S1aa9c6beb27f_N1310 | S1aa9c6beb27f_N1308 | quoted_attribute_value | 216–216 | quoted_attribute_value  |
| S1aa9c6beb27f_N1311 | S1aa9c6beb27f_N1310 | attribute_value | 216–216 | 132 |
| S1aa9c6beb27f_N1312 | S1aa9c6beb27f_N1306 | attribute | 216–216 | attribute  |
| S1aa9c6beb27f_N1313 | S1aa9c6beb27f_N1312 | attribute_name | 216–216 | cy |
| S1aa9c6beb27f_N1314 | S1aa9c6beb27f_N1312 | quoted_attribute_value | 216–216 | quoted_attribute_value  |
| S1aa9c6beb27f_N1315 | S1aa9c6beb27f_N1314 | attribute_value | 216–216 | 80 |
| S1aa9c6beb27f_N1316 | S1aa9c6beb27f_N1306 | attribute | 216–216 | attribute  |
| S1aa9c6beb27f_N1317 | S1aa9c6beb27f_N1316 | attribute_name | 216–216 | fill |
| S1aa9c6beb27f_N1318 | S1aa9c6beb27f_N1316 | quoted_attribute_value | 216–216 | quoted_attribute_value  |
| S1aa9c6beb27f_N1319 | S1aa9c6beb27f_N1318 | attribute_value | 216–216 | #F5F2E9 |
| S1aa9c6beb27f_N1320 | S1aa9c6beb27f_N1306 | attribute | 216–216 | attribute  |
| S1aa9c6beb27f_N1321 | S1aa9c6beb27f_N1320 | attribute_name | 216–216 | r |
| S1aa9c6beb27f_N1322 | S1aa9c6beb27f_N1320 | quoted_attribute_value | 216–216 | quoted_attribute_value  |
| S1aa9c6beb27f_N1323 | S1aa9c6beb27f_N1322 | attribute_value | 216–216 | 4 |
| S1aa9c6beb27f_N1324 | S1aa9c6beb27f_N1305 | end_tag | 216–216 | end_tag  |
| S1aa9c6beb27f_N1325 | S1aa9c6beb27f_N1324 | tag_name | 216–216 | circle |
| S1aa9c6beb27f_N1326 | S1aa9c6beb27f_N1140 | element | 217–217 | element  |
| S1aa9c6beb27f_N1327 | S1aa9c6beb27f_N1326 | start_tag | 217–217 | start_tag  |
| S1aa9c6beb27f_N1328 | S1aa9c6beb27f_N1327 | tag_name | 217–217 | circle |
| S1aa9c6beb27f_N1329 | S1aa9c6beb27f_N1327 | attribute | 217–217 | attribute  |
| S1aa9c6beb27f_N1330 | S1aa9c6beb27f_N1329 | attribute_name | 217–217 | cx |
| S1aa9c6beb27f_N1331 | S1aa9c6beb27f_N1329 | quoted_attribute_value | 217–217 | quoted_attribute_value  |
| S1aa9c6beb27f_N1332 | S1aa9c6beb27f_N1331 | attribute_value | 217–217 | 40 |
| S1aa9c6beb27f_N1333 | S1aa9c6beb27f_N1327 | attribute | 217–217 | attribute  |
| S1aa9c6beb27f_N1334 | S1aa9c6beb27f_N1333 | attribute_name | 217–217 | cy |
| S1aa9c6beb27f_N1335 | S1aa9c6beb27f_N1333 | quoted_attribute_value | 217–217 | quoted_attribute_value  |
| S1aa9c6beb27f_N1336 | S1aa9c6beb27f_N1335 | attribute_value | 217–217 | 120 |
| S1aa9c6beb27f_N1337 | S1aa9c6beb27f_N1327 | attribute | 217–217 | attribute  |
| S1aa9c6beb27f_N1338 | S1aa9c6beb27f_N1337 | attribute_name | 217–217 | fill |
| S1aa9c6beb27f_N1339 | S1aa9c6beb27f_N1337 | quoted_attribute_value | 217–217 | quoted_attribute_value  |
| S1aa9c6beb27f_N1340 | S1aa9c6beb27f_N1339 | attribute_value | 217–217 | #DFC37D |
| S1aa9c6beb27f_N1341 | S1aa9c6beb27f_N1327 | attribute | 217–217 | attribute  |
| S1aa9c6beb27f_N1342 | S1aa9c6beb27f_N1341 | attribute_name | 217–217 | r |
| S1aa9c6beb27f_N1343 | S1aa9c6beb27f_N1341 | quoted_attribute_value | 217–217 | quoted_attribute_value  |
| S1aa9c6beb27f_N1344 | S1aa9c6beb27f_N1343 | attribute_value | 217–217 | 4.5 |
| S1aa9c6beb27f_N1345 | S1aa9c6beb27f_N1326 | end_tag | 217–217 | end_tag  |
| S1aa9c6beb27f_N1346 | S1aa9c6beb27f_N1345 | tag_name | 217–217 | circle |
| S1aa9c6beb27f_N1347 | S1aa9c6beb27f_N1140 | element | 218–218 | element  |
| S1aa9c6beb27f_N1348 | S1aa9c6beb27f_N1347 | start_tag | 218–218 | start_tag  |
| S1aa9c6beb27f_N1349 | S1aa9c6beb27f_N1348 | tag_name | 218–218 | circle |
| S1aa9c6beb27f_N1350 | S1aa9c6beb27f_N1348 | attribute | 218–218 | attribute  |
| S1aa9c6beb27f_N1351 | S1aa9c6beb27f_N1350 | attribute_name | 218–218 | cx |
| S1aa9c6beb27f_N1352 | S1aa9c6beb27f_N1350 | quoted_attribute_value | 218–218 | quoted_attribute_value  |
| S1aa9c6beb27f_N1353 | S1aa9c6beb27f_N1352 | attribute_value | 218–218 | 120 |
| S1aa9c6beb27f_N1354 | S1aa9c6beb27f_N1348 | attribute | 218–218 | attribute  |
| S1aa9c6beb27f_N1355 | S1aa9c6beb27f_N1354 | attribute_name | 218–218 | cy |
| S1aa9c6beb27f_N1356 | S1aa9c6beb27f_N1354 | quoted_attribute_value | 218–218 | quoted_attribute_value  |
| S1aa9c6beb27f_N1357 | S1aa9c6beb27f_N1356 | attribute_value | 218–218 | 40 |
| S1aa9c6beb27f_N1358 | S1aa9c6beb27f_N1348 | attribute | 218–218 | attribute  |
| S1aa9c6beb27f_N1359 | S1aa9c6beb27f_N1358 | attribute_name | 218–218 | fill |
| S1aa9c6beb27f_N1360 | S1aa9c6beb27f_N1358 | quoted_attribute_value | 218–218 | quoted_attribute_value  |
| S1aa9c6beb27f_N1361 | S1aa9c6beb27f_N1360 | attribute_value | 218–218 | #C9AA60 |
| S1aa9c6beb27f_N1362 | S1aa9c6beb27f_N1348 | attribute | 218–218 | attribute  |
| S1aa9c6beb27f_N1363 | S1aa9c6beb27f_N1362 | attribute_name | 218–218 | r |
| S1aa9c6beb27f_N1364 | S1aa9c6beb27f_N1362 | quoted_attribute_value | 218–218 | quoted_attribute_value  |
| S1aa9c6beb27f_N1365 | S1aa9c6beb27f_N1364 | attribute_value | 218–218 | 3.5 |
| S1aa9c6beb27f_N1366 | S1aa9c6beb27f_N1347 | end_tag | 218–218 | end_tag  |
| S1aa9c6beb27f_N1367 | S1aa9c6beb27f_N1366 | tag_name | 218–218 | circle |
| S1aa9c6beb27f_N1368 | S1aa9c6beb27f_N1140 | end_tag | 219–219 | end_tag  |
| S1aa9c6beb27f_N1369 | S1aa9c6beb27f_N1368 | tag_name | 219–219 | svg |
| S1aa9c6beb27f_N1370 | S1aa9c6beb27f_N1099 | comment | 220–220 | &lt;!-- Center Compass --&gt; |
| S1aa9c6beb27f_N1371 | S1aa9c6beb27f_N1099 | element | 221–223 | element  |
| S1aa9c6beb27f_N1372 | S1aa9c6beb27f_N1371 | start_tag | 221–221 | start_tag  |
| S1aa9c6beb27f_N1373 | S1aa9c6beb27f_N1372 | tag_name | 221–221 | div |
| S1aa9c6beb27f_N1374 | S1aa9c6beb27f_N1372 | attribute | 221–221 | attribute  |
| S1aa9c6beb27f_N1375 | S1aa9c6beb27f_N1374 | attribute_name | 221–221 | class |
| S1aa9c6beb27f_N1376 | S1aa9c6beb27f_N1374 | quoted_attribute_value | 221–221 | quoted_attribute_value  |
| S1aa9c6beb27f_N1377 | S1aa9c6beb27f_N1376 | attribute_value | 221–221 | w-12 h-12 rounded-full bg-raised border border-brass/40 flex items-center justify-center text-brass shadow-inner |
| S1aa9c6beb27f_N1378 | S1aa9c6beb27f_N1371 | element | 222–222 | element  |
| S1aa9c6beb27f_N1379 | S1aa9c6beb27f_N1378 | start_tag | 222–222 | start_tag  |
| S1aa9c6beb27f_N1380 | S1aa9c6beb27f_N1379 | tag_name | 222–222 | span |
| S1aa9c6beb27f_N1381 | S1aa9c6beb27f_N1379 | attribute | 222–222 | attribute  |
| S1aa9c6beb27f_N1382 | S1aa9c6beb27f_N1381 | attribute_name | 222–222 | class |
| S1aa9c6beb27f_N1383 | S1aa9c6beb27f_N1381 | quoted_attribute_value | 222–222 | quoted_attribute_value  |
| S1aa9c6beb27f_N1384 | S1aa9c6beb27f_N1383 | attribute_value | 222–222 | material-symbols-outlined text-lg |
| S1aa9c6beb27f_N1385 | S1aa9c6beb27f_N1378 | text | 222–222 | explore |
| S1aa9c6beb27f_N1386 | S1aa9c6beb27f_N1378 | end_tag | 222–222 | end_tag  |
| S1aa9c6beb27f_N1387 | S1aa9c6beb27f_N1386 | tag_name | 222–222 | span |
| S1aa9c6beb27f_N1388 | S1aa9c6beb27f_N1371 | end_tag | 223–223 | end_tag  |
| S1aa9c6beb27f_N1389 | S1aa9c6beb27f_N1388 | tag_name | 223–223 | div |
| S1aa9c6beb27f_N1390 | S1aa9c6beb27f_N1099 | end_tag | 224–224 | end_tag  |
| S1aa9c6beb27f_N1391 | S1aa9c6beb27f_N1390 | tag_name | 224–224 | div |
| S1aa9c6beb27f_N1392 | S1aa9c6beb27f_N1092 | element | 225–231 | element  |
| S1aa9c6beb27f_N1393 | S1aa9c6beb27f_N1392 | start_tag | 225–225 | start_tag  |
| S1aa9c6beb27f_N1394 | S1aa9c6beb27f_N1393 | tag_name | 225–225 | div |
| S1aa9c6beb27f_N1395 | S1aa9c6beb27f_N1393 | attribute | 225–225 | attribute  |
| S1aa9c6beb27f_N1396 | S1aa9c6beb27f_N1395 | attribute_name | 225–225 | class |
| S1aa9c6beb27f_N1397 | S1aa9c6beb27f_N1395 | quoted_attribute_value | 225–225 | quoted_attribute_value  |
| S1aa9c6beb27f_N1398 | S1aa9c6beb27f_N1397 | attribute_value | 225–225 | w-full bg-raised/80 rounded-lg py-2 px-3 flex items-center justify-between text-xs font-mono text-soft-text border border-white/5 |
| S1aa9c6beb27f_N1399 | S1aa9c6beb27f_N1392 | element | 226–229 | element  |
| S1aa9c6beb27f_N1400 | S1aa9c6beb27f_N1399 | start_tag | 226–226 | start_tag  |
| S1aa9c6beb27f_N1401 | S1aa9c6beb27f_N1400 | tag_name | 226–226 | span |
| S1aa9c6beb27f_N1402 | S1aa9c6beb27f_N1400 | attribute | 226–226 | attribute  |
| S1aa9c6beb27f_N1403 | S1aa9c6beb27f_N1402 | attribute_name | 226–226 | class |
| S1aa9c6beb27f_N1404 | S1aa9c6beb27f_N1402 | quoted_attribute_value | 226–226 | quoted_attribute_value  |
| S1aa9c6beb27f_N1405 | S1aa9c6beb27f_N1404 | attribute_value | 226–226 | flex items-center gap-1.5 text-brass |
| S1aa9c6beb27f_N1406 | S1aa9c6beb27f_N1399 | element | 227–227 | element  |
| S1aa9c6beb27f_N1407 | S1aa9c6beb27f_N1406 | start_tag | 227–227 | start_tag  |
| S1aa9c6beb27f_N1408 | S1aa9c6beb27f_N1407 | tag_name | 227–227 | span |
| S1aa9c6beb27f_N1409 | S1aa9c6beb27f_N1407 | attribute | 227–227 | attribute  |
| S1aa9c6beb27f_N1410 | S1aa9c6beb27f_N1409 | attribute_name | 227–227 | class |
| S1aa9c6beb27f_N1411 | S1aa9c6beb27f_N1409 | quoted_attribute_value | 227–227 | quoted_attribute_value  |
| S1aa9c6beb27f_N1412 | S1aa9c6beb27f_N1411 | attribute_value | 227–227 | w-2 h-2 rounded-full bg-brass |
| S1aa9c6beb27f_N1413 | S1aa9c6beb27f_N1406 | end_tag | 227–227 | end_tag  |
| S1aa9c6beb27f_N1414 | S1aa9c6beb27f_N1413 | tag_name | 227–227 | span |
| S1aa9c6beb27f_N1415 | S1aa9c6beb27f_N1399 | element | 228–228 | element  |
| S1aa9c6beb27f_N1416 | S1aa9c6beb27f_N1415 | start_tag | 228–228 | start_tag  |
| S1aa9c6beb27f_N1417 | S1aa9c6beb27f_N1416 | tag_name | 228–228 | span |
| S1aa9c6beb27f_N1418 | S1aa9c6beb27f_N1415 | text | 228–228 | Tactile planetary inspection |
| S1aa9c6beb27f_N1419 | S1aa9c6beb27f_N1415 | end_tag | 228–228 | end_tag  |
| S1aa9c6beb27f_N1420 | S1aa9c6beb27f_N1419 | tag_name | 228–228 | span |
| S1aa9c6beb27f_N1421 | S1aa9c6beb27f_N1399 | end_tag | 229–229 | end_tag  |
| S1aa9c6beb27f_N1422 | S1aa9c6beb27f_N1421 | tag_name | 229–229 | span |
| S1aa9c6beb27f_N1423 | S1aa9c6beb27f_N1392 | element | 230–230 | element  |
| S1aa9c6beb27f_N1424 | S1aa9c6beb27f_N1423 | start_tag | 230–230 | start_tag  |
| S1aa9c6beb27f_N1425 | S1aa9c6beb27f_N1424 | tag_name | 230–230 | span |
| S1aa9c6beb27f_N1426 | S1aa9c6beb27f_N1424 | attribute | 230–230 | attribute  |
| S1aa9c6beb27f_N1427 | S1aa9c6beb27f_N1426 | attribute_name | 230–230 | class |
| S1aa9c6beb27f_N1428 | S1aa9c6beb27f_N1426 | quoted_attribute_value | 230–230 | quoted_attribute_value  |
| S1aa9c6beb27f_N1429 | S1aa9c6beb27f_N1428 | attribute_value | 230–230 | text-muted-text |
| S1aa9c6beb27f_N1430 | S1aa9c6beb27f_N1423 | text | 230–230 | Placidus houses |
| S1aa9c6beb27f_N1431 | S1aa9c6beb27f_N1423 | entity | 230–230 | &amp;amp; |
| S1aa9c6beb27f_N1432 | S1aa9c6beb27f_N1423 | text | 230–230 | aspect chords |
| S1aa9c6beb27f_N1433 | S1aa9c6beb27f_N1423 | end_tag | 230–230 | end_tag  |
| S1aa9c6beb27f_N1434 | S1aa9c6beb27f_N1433 | tag_name | 230–230 | span |
| S1aa9c6beb27f_N1435 | S1aa9c6beb27f_N1392 | end_tag | 231–231 | end_tag  |
| S1aa9c6beb27f_N1436 | S1aa9c6beb27f_N1435 | tag_name | 231–231 | div |
| S1aa9c6beb27f_N1437 | S1aa9c6beb27f_N1092 | end_tag | 232–232 | end_tag  |
| S1aa9c6beb27f_N1438 | S1aa9c6beb27f_N1437 | tag_name | 232–232 | div |
| S1aa9c6beb27f_N1439 | S1aa9c6beb27f_N1045 | end_tag | 233–233 | end_tag  |
| S1aa9c6beb27f_N1440 | S1aa9c6beb27f_N1439 | tag_name | 233–233 | div |
| S1aa9c6beb27f_N1441 | S1aa9c6beb27f_N997 | element | 234–251 | element  |
| S1aa9c6beb27f_N1442 | S1aa9c6beb27f_N1441 | start_tag | 234–234 | start_tag  |
| S1aa9c6beb27f_N1443 | S1aa9c6beb27f_N1442 | tag_name | 234–234 | ul |
| S1aa9c6beb27f_N1444 | S1aa9c6beb27f_N1442 | attribute | 234–234 | attribute  |
| S1aa9c6beb27f_N1445 | S1aa9c6beb27f_N1444 | attribute_name | 234–234 | class |
| S1aa9c6beb27f_N1446 | S1aa9c6beb27f_N1444 | quoted_attribute_value | 234–234 | quoted_attribute_value  |
| S1aa9c6beb27f_N1447 | S1aa9c6beb27f_N1446 | attribute_value | 234–234 | space-y-2 text-sm text-soft-text font-sans |
| S1aa9c6beb27f_N1448 | S1aa9c6beb27f_N1441 | element | 235–238 | element  |
| S1aa9c6beb27f_N1449 | S1aa9c6beb27f_N1448 | start_tag | 235–235 | start_tag  |
| S1aa9c6beb27f_N1450 | S1aa9c6beb27f_N1449 | tag_name | 235–235 | li |
| S1aa9c6beb27f_N1451 | S1aa9c6beb27f_N1449 | attribute | 235–235 | attribute  |
| S1aa9c6beb27f_N1452 | S1aa9c6beb27f_N1451 | attribute_name | 235–235 | class |
| S1aa9c6beb27f_N1453 | S1aa9c6beb27f_N1451 | quoted_attribute_value | 235–235 | quoted_attribute_value  |
| S1aa9c6beb27f_N1454 | S1aa9c6beb27f_N1453 | attribute_value | 235–235 | flex items-start gap-2 |
| S1aa9c6beb27f_N1455 | S1aa9c6beb27f_N1448 | element | 236–236 | element  |
| S1aa9c6beb27f_N1456 | S1aa9c6beb27f_N1455 | start_tag | 236–236 | start_tag  |
| S1aa9c6beb27f_N1457 | S1aa9c6beb27f_N1456 | tag_name | 236–236 | span |
| S1aa9c6beb27f_N1458 | S1aa9c6beb27f_N1456 | attribute | 236–236 | attribute  |
| S1aa9c6beb27f_N1459 | S1aa9c6beb27f_N1458 | attribute_name | 236–236 | class |
| S1aa9c6beb27f_N1460 | S1aa9c6beb27f_N1458 | quoted_attribute_value | 236–236 | quoted_attribute_value  |
| S1aa9c6beb27f_N1461 | S1aa9c6beb27f_N1460 | attribute_value | 236–236 | material-symbols-outlined text-brass text-base shrink-0 mt-0.5 |
| S1aa9c6beb27f_N1462 | S1aa9c6beb27f_N1455 | text | 236–236 | check_circle |
| S1aa9c6beb27f_N1463 | S1aa9c6beb27f_N1455 | end_tag | 236–236 | end_tag  |
| S1aa9c6beb27f_N1464 | S1aa9c6beb27f_N1463 | tag_name | 236–236 | span |
| S1aa9c6beb27f_N1465 | S1aa9c6beb27f_N1448 | element | 237–237 | element  |
| S1aa9c6beb27f_N1466 | S1aa9c6beb27f_N1465 | start_tag | 237–237 | start_tag  |
| S1aa9c6beb27f_N1467 | S1aa9c6beb27f_N1466 | tag_name | 237–237 | span |
| S1aa9c6beb27f_N1468 | S1aa9c6beb27f_N1465 | text | 237–237 | Everything in the PDF reading, plus instant web app access |
| S1aa9c6beb27f_N1469 | S1aa9c6beb27f_N1465 | end_tag | 237–237 | end_tag  |
| S1aa9c6beb27f_N1470 | S1aa9c6beb27f_N1469 | tag_name | 237–237 | span |
| S1aa9c6beb27f_N1471 | S1aa9c6beb27f_N1448 | end_tag | 238–238 | end_tag  |
| S1aa9c6beb27f_N1472 | S1aa9c6beb27f_N1471 | tag_name | 238–238 | li |
| S1aa9c6beb27f_N1473 | S1aa9c6beb27f_N1441 | element | 239–242 | element  |
| S1aa9c6beb27f_N1474 | S1aa9c6beb27f_N1473 | start_tag | 239–239 | start_tag  |
| S1aa9c6beb27f_N1475 | S1aa9c6beb27f_N1474 | tag_name | 239–239 | li |
| S1aa9c6beb27f_N1476 | S1aa9c6beb27f_N1474 | attribute | 239–239 | attribute  |
| S1aa9c6beb27f_N1477 | S1aa9c6beb27f_N1476 | attribute_name | 239–239 | class |
| S1aa9c6beb27f_N1478 | S1aa9c6beb27f_N1476 | quoted_attribute_value | 239–239 | quoted_attribute_value  |
| S1aa9c6beb27f_N1479 | S1aa9c6beb27f_N1478 | attribute_value | 239–239 | flex items-start gap-2 |
| S1aa9c6beb27f_N1480 | S1aa9c6beb27f_N1473 | element | 240–240 | element  |
| S1aa9c6beb27f_N1481 | S1aa9c6beb27f_N1480 | start_tag | 240–240 | start_tag  |
| S1aa9c6beb27f_N1482 | S1aa9c6beb27f_N1481 | tag_name | 240–240 | span |
| S1aa9c6beb27f_N1483 | S1aa9c6beb27f_N1481 | attribute | 240–240 | attribute  |
| S1aa9c6beb27f_N1484 | S1aa9c6beb27f_N1483 | attribute_name | 240–240 | class |
| S1aa9c6beb27f_N1485 | S1aa9c6beb27f_N1483 | quoted_attribute_value | 240–240 | quoted_attribute_value  |
| S1aa9c6beb27f_N1486 | S1aa9c6beb27f_N1485 | attribute_value | 240–240 | material-symbols-outlined text-brass text-base shrink-0 mt-0.5 |
| S1aa9c6beb27f_N1487 | S1aa9c6beb27f_N1480 | text | 240–240 | check_circle |
| S1aa9c6beb27f_N1488 | S1aa9c6beb27f_N1480 | end_tag | 240–240 | end_tag  |
| S1aa9c6beb27f_N1489 | S1aa9c6beb27f_N1488 | tag_name | 240–240 | span |
| S1aa9c6beb27f_N1490 | S1aa9c6beb27f_N1473 | element | 241–241 | element  |
| S1aa9c6beb27f_N1491 | S1aa9c6beb27f_N1490 | start_tag | 241–241 | start_tag  |
| S1aa9c6beb27f_N1492 | S1aa9c6beb27f_N1491 | tag_name | 241–241 | span |
| S1aa9c6beb27f_N1493 | S1aa9c6beb27f_N1490 | text | 241–241 | Tap any planet or house cusp to view plain-language meanings |
| S1aa9c6beb27f_N1494 | S1aa9c6beb27f_N1490 | end_tag | 241–241 | end_tag  |
| S1aa9c6beb27f_N1495 | S1aa9c6beb27f_N1494 | tag_name | 241–241 | span |
| S1aa9c6beb27f_N1496 | S1aa9c6beb27f_N1473 | end_tag | 242–242 | end_tag  |
| S1aa9c6beb27f_N1497 | S1aa9c6beb27f_N1496 | tag_name | 242–242 | li |
| S1aa9c6beb27f_N1498 | S1aa9c6beb27f_N1441 | element | 243–246 | element  |
| S1aa9c6beb27f_N1499 | S1aa9c6beb27f_N1498 | start_tag | 243–243 | start_tag  |
| S1aa9c6beb27f_N1500 | S1aa9c6beb27f_N1499 | tag_name | 243–243 | li |
| S1aa9c6beb27f_N1501 | S1aa9c6beb27f_N1499 | attribute | 243–243 | attribute  |
| S1aa9c6beb27f_N1502 | S1aa9c6beb27f_N1501 | attribute_name | 243–243 | class |
| S1aa9c6beb27f_N1503 | S1aa9c6beb27f_N1501 | quoted_attribute_value | 243–243 | quoted_attribute_value  |
| S1aa9c6beb27f_N1504 | S1aa9c6beb27f_N1503 | attribute_value | 243–243 | flex items-start gap-2 |
| S1aa9c6beb27f_N1505 | S1aa9c6beb27f_N1498 | element | 244–244 | element  |
| S1aa9c6beb27f_N1506 | S1aa9c6beb27f_N1505 | start_tag | 244–244 | start_tag  |
| S1aa9c6beb27f_N1507 | S1aa9c6beb27f_N1506 | tag_name | 244–244 | span |
| S1aa9c6beb27f_N1508 | S1aa9c6beb27f_N1506 | attribute | 244–244 | attribute  |
| S1aa9c6beb27f_N1509 | S1aa9c6beb27f_N1508 | attribute_name | 244–244 | class |
| S1aa9c6beb27f_N1510 | S1aa9c6beb27f_N1508 | quoted_attribute_value | 244–244 | quoted_attribute_value  |
| S1aa9c6beb27f_N1511 | S1aa9c6beb27f_N1510 | attribute_value | 244–244 | material-symbols-outlined text-brass text-base shrink-0 mt-0.5 |
| S1aa9c6beb27f_N1512 | S1aa9c6beb27f_N1505 | text | 244–244 | check_circle |
| S1aa9c6beb27f_N1513 | S1aa9c6beb27f_N1505 | end_tag | 244–244 | end_tag  |
| S1aa9c6beb27f_N1514 | S1aa9c6beb27f_N1513 | tag_name | 244–244 | span |
| S1aa9c6beb27f_N1515 | S1aa9c6beb27f_N1498 | element | 245–245 | element  |
| S1aa9c6beb27f_N1516 | S1aa9c6beb27f_N1515 | start_tag | 245–245 | start_tag  |
| S1aa9c6beb27f_N1517 | S1aa9c6beb27f_N1516 | tag_name | 245–245 | span |
| S1aa9c6beb27f_N1518 | S1aa9c6beb27f_N1515 | text | 245–245 | Highlight harmony, challenge, and major aspect lines smoothly |
| S1aa9c6beb27f_N1519 | S1aa9c6beb27f_N1515 | end_tag | 245–245 | end_tag  |
| S1aa9c6beb27f_N1520 | S1aa9c6beb27f_N1519 | tag_name | 245–245 | span |
| S1aa9c6beb27f_N1521 | S1aa9c6beb27f_N1498 | end_tag | 246–246 | end_tag  |
| S1aa9c6beb27f_N1522 | S1aa9c6beb27f_N1521 | tag_name | 246–246 | li |
| S1aa9c6beb27f_N1523 | S1aa9c6beb27f_N1441 | element | 247–250 | element  |
| S1aa9c6beb27f_N1524 | S1aa9c6beb27f_N1523 | start_tag | 247–247 | start_tag  |
| S1aa9c6beb27f_N1525 | S1aa9c6beb27f_N1524 | tag_name | 247–247 | li |
| S1aa9c6beb27f_N1526 | S1aa9c6beb27f_N1524 | attribute | 247–247 | attribute  |
| S1aa9c6beb27f_N1527 | S1aa9c6beb27f_N1526 | attribute_name | 247–247 | class |
| S1aa9c6beb27f_N1528 | S1aa9c6beb27f_N1526 | quoted_attribute_value | 247–247 | quoted_attribute_value  |
| S1aa9c6beb27f_N1529 | S1aa9c6beb27f_N1528 | attribute_value | 247–247 | flex items-start gap-2 |
| S1aa9c6beb27f_N1530 | S1aa9c6beb27f_N1523 | element | 248–248 | element  |
| S1aa9c6beb27f_N1531 | S1aa9c6beb27f_N1530 | start_tag | 248–248 | start_tag  |
| S1aa9c6beb27f_N1532 | S1aa9c6beb27f_N1531 | tag_name | 248–248 | span |
| S1aa9c6beb27f_N1533 | S1aa9c6beb27f_N1531 | attribute | 248–248 | attribute  |
| S1aa9c6beb27f_N1534 | S1aa9c6beb27f_N1533 | attribute_name | 248–248 | class |
| S1aa9c6beb27f_N1535 | S1aa9c6beb27f_N1533 | quoted_attribute_value | 248–248 | quoted_attribute_value  |
| S1aa9c6beb27f_N1536 | S1aa9c6beb27f_N1535 | attribute_value | 248–248 | material-symbols-outlined text-brass text-base shrink-0 mt-0.5 |
| S1aa9c6beb27f_N1537 | S1aa9c6beb27f_N1530 | text | 248–248 | check_circle |
| S1aa9c6beb27f_N1538 | S1aa9c6beb27f_N1530 | end_tag | 248–248 | end_tag  |
| S1aa9c6beb27f_N1539 | S1aa9c6beb27f_N1538 | tag_name | 248–248 | span |
| S1aa9c6beb27f_N1540 | S1aa9c6beb27f_N1523 | element | 249–249 | element  |
| S1aa9c6beb27f_N1541 | S1aa9c6beb27f_N1540 | start_tag | 249–249 | start_tag  |
| S1aa9c6beb27f_N1542 | S1aa9c6beb27f_N1541 | tag_name | 249–249 | span |
| S1aa9c6beb27f_N1543 | S1aa9c6beb27f_N1540 | text | 249–249 | Works on your phone, tablet, and computer with no installation |
| S1aa9c6beb27f_N1544 | S1aa9c6beb27f_N1540 | end_tag | 249–249 | end_tag  |
| S1aa9c6beb27f_N1545 | S1aa9c6beb27f_N1544 | tag_name | 249–249 | span |
| S1aa9c6beb27f_N1546 | S1aa9c6beb27f_N1523 | end_tag | 250–250 | end_tag  |
| S1aa9c6beb27f_N1547 | S1aa9c6beb27f_N1546 | tag_name | 250–250 | li |
| S1aa9c6beb27f_N1548 | S1aa9c6beb27f_N1441 | end_tag | 251–251 | end_tag  |
| S1aa9c6beb27f_N1549 | S1aa9c6beb27f_N1548 | tag_name | 251–251 | ul |
| S1aa9c6beb27f_N1550 | S1aa9c6beb27f_N997 | end_tag | 252–252 | end_tag  |
| S1aa9c6beb27f_N1551 | S1aa9c6beb27f_N1550 | tag_name | 252–252 | div |
| S1aa9c6beb27f_N1552 | S1aa9c6beb27f_N981 | element | 253–256 | element  |
| S1aa9c6beb27f_N1553 | S1aa9c6beb27f_N1552 | start_tag | 253–253 | start_tag  |
| S1aa9c6beb27f_N1554 | S1aa9c6beb27f_N1553 | tag_name | 253–253 | div |
| S1aa9c6beb27f_N1555 | S1aa9c6beb27f_N1553 | attribute | 253–253 | attribute  |
| S1aa9c6beb27f_N1556 | S1aa9c6beb27f_N1555 | attribute_name | 253–253 | class |
| S1aa9c6beb27f_N1557 | S1aa9c6beb27f_N1555 | quoted_attribute_value | 253–253 | quoted_attribute_value  |
| S1aa9c6beb27f_N1558 | S1aa9c6beb27f_N1557 | attribute_value | 253–253 | pt-6 mt-6 border-t border-white/5 text-xs text-brass font-mono flex items-center gap-1.5 |
| S1aa9c6beb27f_N1559 | S1aa9c6beb27f_N1552 | element | 254–254 | element  |
| S1aa9c6beb27f_N1560 | S1aa9c6beb27f_N1559 | start_tag | 254–254 | start_tag  |
| S1aa9c6beb27f_N1561 | S1aa9c6beb27f_N1560 | tag_name | 254–254 | span |
| S1aa9c6beb27f_N1562 | S1aa9c6beb27f_N1560 | attribute | 254–254 | attribute  |
| S1aa9c6beb27f_N1563 | S1aa9c6beb27f_N1562 | attribute_name | 254–254 | class |
| S1aa9c6beb27f_N1564 | S1aa9c6beb27f_N1562 | quoted_attribute_value | 254–254 | quoted_attribute_value  |
| S1aa9c6beb27f_N1565 | S1aa9c6beb27f_N1564 | attribute_value | 254–254 | material-symbols-outlined text-sm |
| S1aa9c6beb27f_N1566 | S1aa9c6beb27f_N1559 | text | 254–254 | stars |
| S1aa9c6beb27f_N1567 | S1aa9c6beb27f_N1559 | end_tag | 254–254 | end_tag  |
| S1aa9c6beb27f_N1568 | S1aa9c6beb27f_N1567 | tag_name | 254–254 | span |
| S1aa9c6beb27f_N1569 | S1aa9c6beb27f_N1552 | element | 255–255 | element  |
| S1aa9c6beb27f_N1570 | S1aa9c6beb27f_N1569 | start_tag | 255–255 | start_tag  |
| S1aa9c6beb27f_N1571 | S1aa9c6beb27f_N1570 | tag_name | 255–255 | span |
| S1aa9c6beb27f_N1572 | S1aa9c6beb27f_N1569 | text | 255–255 | Seamless upgrade with one click below |
| S1aa9c6beb27f_N1573 | S1aa9c6beb27f_N1569 | end_tag | 255–255 | end_tag  |
| S1aa9c6beb27f_N1574 | S1aa9c6beb27f_N1573 | tag_name | 255–255 | span |
| S1aa9c6beb27f_N1575 | S1aa9c6beb27f_N1552 | end_tag | 256–256 | end_tag  |
| S1aa9c6beb27f_N1576 | S1aa9c6beb27f_N1575 | tag_name | 256–256 | div |
| S1aa9c6beb27f_N1577 | S1aa9c6beb27f_N981 | end_tag | 257–257 | end_tag  |
| S1aa9c6beb27f_N1578 | S1aa9c6beb27f_N1577 | tag_name | 257–257 | div |
| S1aa9c6beb27f_N1579 | S1aa9c6beb27f_N605 | end_tag | 258–258 | end_tag  |
| S1aa9c6beb27f_N1580 | S1aa9c6beb27f_N1579 | tag_name | 258–258 | div |
| S1aa9c6beb27f_N1581 | S1aa9c6beb27f_N461 | comment | 259–259 | &lt;!-- Concise Approachable Customer Benefits --&gt; |
| S1aa9c6beb27f_N1582 | S1aa9c6beb27f_N461 | element | 260–297 | element  |
| S1aa9c6beb27f_N1583 | S1aa9c6beb27f_N1582 | start_tag | 260–260 | start_tag  |
| S1aa9c6beb27f_N1584 | S1aa9c6beb27f_N1583 | tag_name | 260–260 | div |
| S1aa9c6beb27f_N1585 | S1aa9c6beb27f_N1583 | attribute | 260–260 | attribute  |
| S1aa9c6beb27f_N1586 | S1aa9c6beb27f_N1585 | attribute_name | 260–260 | class |
| S1aa9c6beb27f_N1587 | S1aa9c6beb27f_N1585 | quoted_attribute_value | 260–260 | quoted_attribute_value  |
| S1aa9c6beb27f_N1588 | S1aa9c6beb27f_N1587 | attribute_value | 260–260 | mb-12 |
| S1aa9c6beb27f_N1589 | S1aa9c6beb27f_N1582 | element | 261–264 | element  |
| S1aa9c6beb27f_N1590 | S1aa9c6beb27f_N1589 | start_tag | 261–261 | start_tag  |
| S1aa9c6beb27f_N1591 | S1aa9c6beb27f_N1590 | tag_name | 261–261 | div |
| S1aa9c6beb27f_N1592 | S1aa9c6beb27f_N1590 | attribute | 261–261 | attribute  |
| S1aa9c6beb27f_N1593 | S1aa9c6beb27f_N1592 | attribute_name | 261–261 | class |
| S1aa9c6beb27f_N1594 | S1aa9c6beb27f_N1592 | quoted_attribute_value | 261–261 | quoted_attribute_value  |
| S1aa9c6beb27f_N1595 | S1aa9c6beb27f_N1594 | attribute_value | 261–261 | text-center mb-6 |
| S1aa9c6beb27f_N1596 | S1aa9c6beb27f_N1589 | element | 262–262 | element  |
| S1aa9c6beb27f_N1597 | S1aa9c6beb27f_N1596 | start_tag | 262–262 | start_tag  |
| S1aa9c6beb27f_N1598 | S1aa9c6beb27f_N1597 | tag_name | 262–262 | h3 |
| S1aa9c6beb27f_N1599 | S1aa9c6beb27f_N1597 | attribute | 262–262 | attribute  |
| S1aa9c6beb27f_N1600 | S1aa9c6beb27f_N1599 | attribute_name | 262–262 | class |
| S1aa9c6beb27f_N1601 | S1aa9c6beb27f_N1599 | quoted_attribute_value | 262–262 | quoted_attribute_value  |
| S1aa9c6beb27f_N1602 | S1aa9c6beb27f_N1601 | attribute_value | 262–262 | font-serif text-2xl text-starlight font-medium |
| S1aa9c6beb27f_N1603 | S1aa9c6beb27f_N1596 | text | 262–262 | Why explore your chart interactively? |
| S1aa9c6beb27f_N1604 | S1aa9c6beb27f_N1596 | end_tag | 262–262 | end_tag  |
| S1aa9c6beb27f_N1605 | S1aa9c6beb27f_N1604 | tag_name | 262–262 | h3 |
| S1aa9c6beb27f_N1606 | S1aa9c6beb27f_N1589 | element | 263–263 | element  |
| S1aa9c6beb27f_N1607 | S1aa9c6beb27f_N1606 | start_tag | 263–263 | start_tag  |
| S1aa9c6beb27f_N1608 | S1aa9c6beb27f_N1607 | tag_name | 263–263 | p |
| S1aa9c6beb27f_N1609 | S1aa9c6beb27f_N1607 | attribute | 263–263 | attribute  |
| S1aa9c6beb27f_N1610 | S1aa9c6beb27f_N1609 | attribute_name | 263–263 | class |
| S1aa9c6beb27f_N1611 | S1aa9c6beb27f_N1609 | quoted_attribute_value | 263–263 | quoted_attribute_value  |
| S1aa9c6beb27f_N1612 | S1aa9c6beb27f_N1611 | attribute_value | 263–263 | text-soft-text text-sm mt-1 |
| S1aa9c6beb27f_N1613 | S1aa9c6beb27f_N1606 | text | 263–263 | Simple, intuitive discovery designed for everyone |
| S1aa9c6beb27f_N1614 | S1aa9c6beb27f_N1606 | end_tag | 263–263 | end_tag  |
| S1aa9c6beb27f_N1615 | S1aa9c6beb27f_N1614 | tag_name | 263–263 | p |
| S1aa9c6beb27f_N1616 | S1aa9c6beb27f_N1589 | end_tag | 264–264 | end_tag  |
| S1aa9c6beb27f_N1617 | S1aa9c6beb27f_N1616 | tag_name | 264–264 | div |
| S1aa9c6beb27f_N1618 | S1aa9c6beb27f_N1582 | element | 265–296 | element  |
| S1aa9c6beb27f_N1619 | S1aa9c6beb27f_N1618 | start_tag | 265–265 | start_tag  |
| S1aa9c6beb27f_N1620 | S1aa9c6beb27f_N1619 | tag_name | 265–265 | div |
| S1aa9c6beb27f_N1621 | S1aa9c6beb27f_N1619 | attribute | 265–265 | attribute  |
| S1aa9c6beb27f_N1622 | S1aa9c6beb27f_N1621 | attribute_name | 265–265 | class |
| S1aa9c6beb27f_N1623 | S1aa9c6beb27f_N1621 | quoted_attribute_value | 265–265 | quoted_attribute_value  |
| S1aa9c6beb27f_N1624 | S1aa9c6beb27f_N1623 | attribute_value | 265–265 | grid grid-cols-1 md:grid-cols-3 gap-5 |
| S1aa9c6beb27f_N1625 | S1aa9c6beb27f_N1618 | comment | 266–266 | &lt;!-- Benefit 1 --&gt; |
| S1aa9c6beb27f_N1626 | S1aa9c6beb27f_N1618 | element | 267–275 | element  |
| S1aa9c6beb27f_N1627 | S1aa9c6beb27f_N1626 | start_tag | 267–267 | start_tag  |
| S1aa9c6beb27f_N1628 | S1aa9c6beb27f_N1627 | tag_name | 267–267 | div |
| S1aa9c6beb27f_N1629 | S1aa9c6beb27f_N1627 | attribute | 267–267 | attribute  |
| S1aa9c6beb27f_N1630 | S1aa9c6beb27f_N1629 | attribute_name | 267–267 | class |
| S1aa9c6beb27f_N1631 | S1aa9c6beb27f_N1629 | quoted_attribute_value | 267–267 | quoted_attribute_value  |
| S1aa9c6beb27f_N1632 | S1aa9c6beb27f_N1631 | attribute_value | 267–267 | bg-raised/60 border border-white/5 rounded-xl p-5 hover:border-white/10 transition-colors |
| S1aa9c6beb27f_N1633 | S1aa9c6beb27f_N1626 | element | 268–270 | element  |
| S1aa9c6beb27f_N1634 | S1aa9c6beb27f_N1633 | start_tag | 268–268 | start_tag  |
| S1aa9c6beb27f_N1635 | S1aa9c6beb27f_N1634 | tag_name | 268–268 | div |
| S1aa9c6beb27f_N1636 | S1aa9c6beb27f_N1634 | attribute | 268–268 | attribute  |
| S1aa9c6beb27f_N1637 | S1aa9c6beb27f_N1636 | attribute_name | 268–268 | class |
| S1aa9c6beb27f_N1638 | S1aa9c6beb27f_N1636 | quoted_attribute_value | 268–268 | quoted_attribute_value  |
| S1aa9c6beb27f_N1639 | S1aa9c6beb27f_N1638 | attribute_value | 268–268 | w-10 h-10 rounded-lg bg-obs border border-brass/20 flex items-center justify-center text-brass mb-3.5 |
| S1aa9c6beb27f_N1640 | S1aa9c6beb27f_N1633 | element | 269–269 | element  |
| S1aa9c6beb27f_N1641 | S1aa9c6beb27f_N1640 | start_tag | 269–269 | start_tag  |
| S1aa9c6beb27f_N1642 | S1aa9c6beb27f_N1641 | tag_name | 269–269 | span |
| S1aa9c6beb27f_N1643 | S1aa9c6beb27f_N1641 | attribute | 269–269 | attribute  |
| S1aa9c6beb27f_N1644 | S1aa9c6beb27f_N1643 | attribute_name | 269–269 | class |
| S1aa9c6beb27f_N1645 | S1aa9c6beb27f_N1643 | quoted_attribute_value | 269–269 | quoted_attribute_value  |
| S1aa9c6beb27f_N1646 | S1aa9c6beb27f_N1645 | attribute_value | 269–269 | material-symbols-outlined |
| S1aa9c6beb27f_N1647 | S1aa9c6beb27f_N1640 | text | 269–269 | touch_app |
| S1aa9c6beb27f_N1648 | S1aa9c6beb27f_N1640 | end_tag | 269–269 | end_tag  |
| S1aa9c6beb27f_N1649 | S1aa9c6beb27f_N1648 | tag_name | 269–269 | span |
| S1aa9c6beb27f_N1650 | S1aa9c6beb27f_N1633 | end_tag | 270–270 | end_tag  |
| S1aa9c6beb27f_N1651 | S1aa9c6beb27f_N1650 | tag_name | 270–270 | div |
| S1aa9c6beb27f_N1652 | S1aa9c6beb27f_N1626 | element | 271–271 | element  |
| S1aa9c6beb27f_N1653 | S1aa9c6beb27f_N1652 | start_tag | 271–271 | start_tag  |
| S1aa9c6beb27f_N1654 | S1aa9c6beb27f_N1653 | tag_name | 271–271 | h4 |
| S1aa9c6beb27f_N1655 | S1aa9c6beb27f_N1653 | attribute | 271–271 | attribute  |
| S1aa9c6beb27f_N1656 | S1aa9c6beb27f_N1655 | attribute_name | 271–271 | class |
| S1aa9c6beb27f_N1657 | S1aa9c6beb27f_N1655 | quoted_attribute_value | 271–271 | quoted_attribute_value  |
| S1aa9c6beb27f_N1658 | S1aa9c6beb27f_N1657 | attribute_value | 271–271 | font-serif text-lg text-starlight font-medium mb-1.5 |
| S1aa9c6beb27f_N1659 | S1aa9c6beb27f_N1652 | text | 271–271 | Interactive Discovery |
| S1aa9c6beb27f_N1660 | S1aa9c6beb27f_N1652 | end_tag | 271–271 | end_tag  |
| S1aa9c6beb27f_N1661 | S1aa9c6beb27f_N1660 | tag_name | 271–271 | h4 |
| S1aa9c6beb27f_N1662 | S1aa9c6beb27f_N1626 | element | 272–274 | element  |
| S1aa9c6beb27f_N1663 | S1aa9c6beb27f_N1662 | start_tag | 272–272 | start_tag  |
| S1aa9c6beb27f_N1664 | S1aa9c6beb27f_N1663 | tag_name | 272–272 | p |
| S1aa9c6beb27f_N1665 | S1aa9c6beb27f_N1663 | attribute | 272–272 | attribute  |
| S1aa9c6beb27f_N1666 | S1aa9c6beb27f_N1665 | attribute_name | 272–272 | class |
| S1aa9c6beb27f_N1667 | S1aa9c6beb27f_N1665 | quoted_attribute_value | 272–272 | quoted_attribute_value  |
| S1aa9c6beb27f_N1668 | S1aa9c6beb27f_N1667 | attribute_value | 272–272 | text-soft-text text-sm leading-relaxed |
| S1aa9c6beb27f_N1669 | S1aa9c6beb27f_N1662 | text | 273–273 | Touch or click any planet to reveal how its placements shape your strengths, relationships, and everyday rhythm. |
| S1aa9c6beb27f_N1670 | S1aa9c6beb27f_N1662 | end_tag | 274–274 | end_tag  |
| S1aa9c6beb27f_N1671 | S1aa9c6beb27f_N1670 | tag_name | 274–274 | p |
| S1aa9c6beb27f_N1672 | S1aa9c6beb27f_N1626 | end_tag | 275–275 | end_tag  |
| S1aa9c6beb27f_N1673 | S1aa9c6beb27f_N1672 | tag_name | 275–275 | div |
| S1aa9c6beb27f_N1674 | S1aa9c6beb27f_N1618 | comment | 276–276 | &lt;!-- Benefit 2 --&gt; |
| S1aa9c6beb27f_N1675 | S1aa9c6beb27f_N1618 | element | 277–285 | element  |
| S1aa9c6beb27f_N1676 | S1aa9c6beb27f_N1675 | start_tag | 277–277 | start_tag  |
| S1aa9c6beb27f_N1677 | S1aa9c6beb27f_N1676 | tag_name | 277–277 | div |
| S1aa9c6beb27f_N1678 | S1aa9c6beb27f_N1676 | attribute | 277–277 | attribute  |
| S1aa9c6beb27f_N1679 | S1aa9c6beb27f_N1678 | attribute_name | 277–277 | class |
| S1aa9c6beb27f_N1680 | S1aa9c6beb27f_N1678 | quoted_attribute_value | 277–277 | quoted_attribute_value  |
| S1aa9c6beb27f_N1681 | S1aa9c6beb27f_N1680 | attribute_value | 277–277 | bg-raised/60 border border-white/5 rounded-xl p-5 hover:border-white/10 transition-colors |
| S1aa9c6beb27f_N1682 | S1aa9c6beb27f_N1675 | element | 278–280 | element  |
| S1aa9c6beb27f_N1683 | S1aa9c6beb27f_N1682 | start_tag | 278–278 | start_tag  |
| S1aa9c6beb27f_N1684 | S1aa9c6beb27f_N1683 | tag_name | 278–278 | div |
| S1aa9c6beb27f_N1685 | S1aa9c6beb27f_N1683 | attribute | 278–278 | attribute  |
| S1aa9c6beb27f_N1686 | S1aa9c6beb27f_N1685 | attribute_name | 278–278 | class |
| S1aa9c6beb27f_N1687 | S1aa9c6beb27f_N1685 | quoted_attribute_value | 278–278 | quoted_attribute_value  |
| S1aa9c6beb27f_N1688 | S1aa9c6beb27f_N1687 | attribute_value | 278–278 | w-10 h-10 rounded-lg bg-obs border border-brass/20 flex items-center justify-center text-brass mb-3.5 |
| S1aa9c6beb27f_N1689 | S1aa9c6beb27f_N1682 | element | 279–279 | element  |
| S1aa9c6beb27f_N1690 | S1aa9c6beb27f_N1689 | start_tag | 279–279 | start_tag  |
| S1aa9c6beb27f_N1691 | S1aa9c6beb27f_N1690 | tag_name | 279–279 | span |
| S1aa9c6beb27f_N1692 | S1aa9c6beb27f_N1690 | attribute | 279–279 | attribute  |
| S1aa9c6beb27f_N1693 | S1aa9c6beb27f_N1692 | attribute_name | 279–279 | class |
| S1aa9c6beb27f_N1694 | S1aa9c6beb27f_N1692 | quoted_attribute_value | 279–279 | quoted_attribute_value  |
| S1aa9c6beb27f_N1695 | S1aa9c6beb27f_N1694 | attribute_value | 279–279 | material-symbols-outlined |
| S1aa9c6beb27f_N1696 | S1aa9c6beb27f_N1689 | text | 279–279 | visibility |
| S1aa9c6beb27f_N1697 | S1aa9c6beb27f_N1689 | end_tag | 279–279 | end_tag  |
| S1aa9c6beb27f_N1698 | S1aa9c6beb27f_N1697 | tag_name | 279–279 | span |
| S1aa9c6beb27f_N1699 | S1aa9c6beb27f_N1682 | end_tag | 280–280 | end_tag  |
| S1aa9c6beb27f_N1700 | S1aa9c6beb27f_N1699 | tag_name | 280–280 | div |
| S1aa9c6beb27f_N1701 | S1aa9c6beb27f_N1675 | element | 281–281 | element  |
| S1aa9c6beb27f_N1702 | S1aa9c6beb27f_N1701 | start_tag | 281–281 | start_tag  |
| S1aa9c6beb27f_N1703 | S1aa9c6beb27f_N1702 | tag_name | 281–281 | h4 |
| S1aa9c6beb27f_N1704 | S1aa9c6beb27f_N1702 | attribute | 281–281 | attribute  |
| S1aa9c6beb27f_N1705 | S1aa9c6beb27f_N1704 | attribute_name | 281–281 | class |
| S1aa9c6beb27f_N1706 | S1aa9c6beb27f_N1704 | quoted_attribute_value | 281–281 | quoted_attribute_value  |
| S1aa9c6beb27f_N1707 | S1aa9c6beb27f_N1706 | attribute_value | 281–281 | font-serif text-lg text-starlight font-medium mb-1.5 |
| S1aa9c6beb27f_N1708 | S1aa9c6beb27f_N1701 | text | 281–281 | Clear Planetary Aspect Chords |
| S1aa9c6beb27f_N1709 | S1aa9c6beb27f_N1701 | end_tag | 281–281 | end_tag  |
| S1aa9c6beb27f_N1710 | S1aa9c6beb27f_N1709 | tag_name | 281–281 | h4 |
| S1aa9c6beb27f_N1711 | S1aa9c6beb27f_N1675 | element | 282–284 | element  |
| S1aa9c6beb27f_N1712 | S1aa9c6beb27f_N1711 | start_tag | 282–282 | start_tag  |
| S1aa9c6beb27f_N1713 | S1aa9c6beb27f_N1712 | tag_name | 282–282 | p |
| S1aa9c6beb27f_N1714 | S1aa9c6beb27f_N1712 | attribute | 282–282 | attribute  |
| S1aa9c6beb27f_N1715 | S1aa9c6beb27f_N1714 | attribute_name | 282–282 | class |
| S1aa9c6beb27f_N1716 | S1aa9c6beb27f_N1714 | quoted_attribute_value | 282–282 | quoted_attribute_value  |
| S1aa9c6beb27f_N1717 | S1aa9c6beb27f_N1716 | attribute_value | 282–282 | text-soft-text text-sm leading-relaxed |
| S1aa9c6beb27f_N1718 | S1aa9c6beb27f_N1711 | text | 283–283 | Unclutter the sky. Isolate pairings like Sun and Moon with a single click to easily see your astrological connections. |
| S1aa9c6beb27f_N1719 | S1aa9c6beb27f_N1711 | end_tag | 284–284 | end_tag  |
| S1aa9c6beb27f_N1720 | S1aa9c6beb27f_N1719 | tag_name | 284–284 | p |
| S1aa9c6beb27f_N1721 | S1aa9c6beb27f_N1675 | end_tag | 285–285 | end_tag  |
| S1aa9c6beb27f_N1722 | S1aa9c6beb27f_N1721 | tag_name | 285–285 | div |
| S1aa9c6beb27f_N1723 | S1aa9c6beb27f_N1618 | comment | 286–286 | &lt;!-- Benefit 3 --&gt; |
| S1aa9c6beb27f_N1724 | S1aa9c6beb27f_N1618 | element | 287–295 | element  |
| S1aa9c6beb27f_N1725 | S1aa9c6beb27f_N1724 | start_tag | 287–287 | start_tag  |
| S1aa9c6beb27f_N1726 | S1aa9c6beb27f_N1725 | tag_name | 287–287 | div |
| S1aa9c6beb27f_N1727 | S1aa9c6beb27f_N1725 | attribute | 287–287 | attribute  |
| S1aa9c6beb27f_N1728 | S1aa9c6beb27f_N1727 | attribute_name | 287–287 | class |
| S1aa9c6beb27f_N1729 | S1aa9c6beb27f_N1727 | quoted_attribute_value | 287–287 | quoted_attribute_value  |
| S1aa9c6beb27f_N1730 | S1aa9c6beb27f_N1729 | attribute_value | 287–287 | bg-raised/60 border border-white/5 rounded-xl p-5 hover:border-white/10 transition-colors |
| S1aa9c6beb27f_N1731 | S1aa9c6beb27f_N1724 | element | 288–290 | element  |
| S1aa9c6beb27f_N1732 | S1aa9c6beb27f_N1731 | start_tag | 288–288 | start_tag  |
| S1aa9c6beb27f_N1733 | S1aa9c6beb27f_N1732 | tag_name | 288–288 | div |
| S1aa9c6beb27f_N1734 | S1aa9c6beb27f_N1732 | attribute | 288–288 | attribute  |
| S1aa9c6beb27f_N1735 | S1aa9c6beb27f_N1734 | attribute_name | 288–288 | class |
| S1aa9c6beb27f_N1736 | S1aa9c6beb27f_N1734 | quoted_attribute_value | 288–288 | quoted_attribute_value  |
| S1aa9c6beb27f_N1737 | S1aa9c6beb27f_N1736 | attribute_value | 288–288 | w-10 h-10 rounded-lg bg-obs border border-brass/20 flex items-center justify-center text-brass mb-3.5 |
| S1aa9c6beb27f_N1738 | S1aa9c6beb27f_N1731 | element | 289–289 | element  |
| S1aa9c6beb27f_N1739 | S1aa9c6beb27f_N1738 | start_tag | 289–289 | start_tag  |
| S1aa9c6beb27f_N1740 | S1aa9c6beb27f_N1739 | tag_name | 289–289 | span |
| S1aa9c6beb27f_N1741 | S1aa9c6beb27f_N1739 | attribute | 289–289 | attribute  |
| S1aa9c6beb27f_N1742 | S1aa9c6beb27f_N1741 | attribute_name | 289–289 | class |
| S1aa9c6beb27f_N1743 | S1aa9c6beb27f_N1741 | quoted_attribute_value | 289–289 | quoted_attribute_value  |
| S1aa9c6beb27f_N1744 | S1aa9c6beb27f_N1743 | attribute_value | 289–289 | material-symbols-outlined |
| S1aa9c6beb27f_N1745 | S1aa9c6beb27f_N1738 | text | 289–289 | devices |
| S1aa9c6beb27f_N1746 | S1aa9c6beb27f_N1738 | end_tag | 289–289 | end_tag  |
| S1aa9c6beb27f_N1747 | S1aa9c6beb27f_N1746 | tag_name | 289–289 | span |
| S1aa9c6beb27f_N1748 | S1aa9c6beb27f_N1731 | end_tag | 290–290 | end_tag  |
| S1aa9c6beb27f_N1749 | S1aa9c6beb27f_N1748 | tag_name | 290–290 | div |
| S1aa9c6beb27f_N1750 | S1aa9c6beb27f_N1724 | element | 291–291 | element  |
| S1aa9c6beb27f_N1751 | S1aa9c6beb27f_N1750 | start_tag | 291–291 | start_tag  |
| S1aa9c6beb27f_N1752 | S1aa9c6beb27f_N1751 | tag_name | 291–291 | h4 |
| S1aa9c6beb27f_N1753 | S1aa9c6beb27f_N1751 | attribute | 291–291 | attribute  |
| S1aa9c6beb27f_N1754 | S1aa9c6beb27f_N1753 | attribute_name | 291–291 | class |
| S1aa9c6beb27f_N1755 | S1aa9c6beb27f_N1753 | quoted_attribute_value | 291–291 | quoted_attribute_value  |
| S1aa9c6beb27f_N1756 | S1aa9c6beb27f_N1755 | attribute_value | 291–291 | font-serif text-lg text-starlight font-medium mb-1.5 |
| S1aa9c6beb27f_N1757 | S1aa9c6beb27f_N1750 | text | 291–291 | Ready on Any Device |
| S1aa9c6beb27f_N1758 | S1aa9c6beb27f_N1750 | end_tag | 291–291 | end_tag  |
| S1aa9c6beb27f_N1759 | S1aa9c6beb27f_N1758 | tag_name | 291–291 | h4 |
| S1aa9c6beb27f_N1760 | S1aa9c6beb27f_N1724 | element | 292–294 | element  |
| S1aa9c6beb27f_N1761 | S1aa9c6beb27f_N1760 | start_tag | 292–292 | start_tag  |
| S1aa9c6beb27f_N1762 | S1aa9c6beb27f_N1761 | tag_name | 292–292 | p |
| S1aa9c6beb27f_N1763 | S1aa9c6beb27f_N1761 | attribute | 292–292 | attribute  |
| S1aa9c6beb27f_N1764 | S1aa9c6beb27f_N1763 | attribute_name | 292–292 | class |
| S1aa9c6beb27f_N1765 | S1aa9c6beb27f_N1763 | quoted_attribute_value | 292–292 | quoted_attribute_value  |
| S1aa9c6beb27f_N1766 | S1aa9c6beb27f_N1765 | attribute_value | 292–292 | text-soft-text text-sm leading-relaxed |
| S1aa9c6beb27f_N1767 | S1aa9c6beb27f_N1760 | text | 293–293 | Open your private link on your mobile phone or laptop browser whenever you want to reference your natal alignments. |
| S1aa9c6beb27f_N1768 | S1aa9c6beb27f_N1760 | end_tag | 294–294 | end_tag  |
| S1aa9c6beb27f_N1769 | S1aa9c6beb27f_N1768 | tag_name | 294–294 | p |
| S1aa9c6beb27f_N1770 | S1aa9c6beb27f_N1724 | end_tag | 295–295 | end_tag  |
| S1aa9c6beb27f_N1771 | S1aa9c6beb27f_N1770 | tag_name | 295–295 | div |
| S1aa9c6beb27f_N1772 | S1aa9c6beb27f_N1618 | end_tag | 296–296 | end_tag  |
| S1aa9c6beb27f_N1773 | S1aa9c6beb27f_N1772 | tag_name | 296–296 | div |
| S1aa9c6beb27f_N1774 | S1aa9c6beb27f_N1582 | end_tag | 297–297 | end_tag  |
| S1aa9c6beb27f_N1775 | S1aa9c6beb27f_N1774 | tag_name | 297–297 | div |
| S1aa9c6beb27f_N1776 | S1aa9c6beb27f_N461 | comment | 298–298 | &lt;!-- Pricing Terms &amp; Decision Console --&gt; |
| S1aa9c6beb27f_N1777 | S1aa9c6beb27f_N461 | element | 299–331 | element  |
| S1aa9c6beb27f_N1778 | S1aa9c6beb27f_N1777 | start_tag | 299–299 | start_tag  |
| S1aa9c6beb27f_N1779 | S1aa9c6beb27f_N1778 | tag_name | 299–299 | div |
| S1aa9c6beb27f_N1780 | S1aa9c6beb27f_N1778 | attribute | 299–299 | attribute  |
| S1aa9c6beb27f_N1781 | S1aa9c6beb27f_N1780 | attribute_name | 299–299 | class |
| S1aa9c6beb27f_N1782 | S1aa9c6beb27f_N1780 | quoted_attribute_value | 299–299 | quoted_attribute_value  |
| S1aa9c6beb27f_N1783 | S1aa9c6beb27f_N1782 | attribute_value | 299–299 | max-w-3xl mx-auto bg-raised border border-brass/30 rounded-2xl p-6 sm:p-8 shadow-xl |
| S1aa9c6beb27f_N1784 | S1aa9c6beb27f_N1777 | element | 300–314 | element  |
| S1aa9c6beb27f_N1785 | S1aa9c6beb27f_N1784 | start_tag | 300–300 | start_tag  |
| S1aa9c6beb27f_N1786 | S1aa9c6beb27f_N1785 | tag_name | 300–300 | div |
| S1aa9c6beb27f_N1787 | S1aa9c6beb27f_N1785 | attribute | 300–300 | attribute  |
| S1aa9c6beb27f_N1788 | S1aa9c6beb27f_N1787 | attribute_name | 300–300 | class |
| S1aa9c6beb27f_N1789 | S1aa9c6beb27f_N1787 | quoted_attribute_value | 300–300 | quoted_attribute_value  |
| S1aa9c6beb27f_N1790 | S1aa9c6beb27f_N1789 | attribute_value | 300–300 | flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-white/10 |
| S1aa9c6beb27f_N1791 | S1aa9c6beb27f_N1784 | element | 301–309 | element  |
| S1aa9c6beb27f_N1792 | S1aa9c6beb27f_N1791 | start_tag | 301–301 | start_tag  |
| S1aa9c6beb27f_N1793 | S1aa9c6beb27f_N1792 | tag_name | 301–301 | div |
| S1aa9c6beb27f_N1794 | S1aa9c6beb27f_N1791 | element | 302–306 | element  |
| S1aa9c6beb27f_N1795 | S1aa9c6beb27f_N1794 | start_tag | 302–302 | start_tag  |
| S1aa9c6beb27f_N1796 | S1aa9c6beb27f_N1795 | tag_name | 302–302 | div |
| S1aa9c6beb27f_N1797 | S1aa9c6beb27f_N1795 | attribute | 302–302 | attribute  |
| S1aa9c6beb27f_N1798 | S1aa9c6beb27f_N1797 | attribute_name | 302–302 | class |
| S1aa9c6beb27f_N1799 | S1aa9c6beb27f_N1797 | quoted_attribute_value | 302–302 | quoted_attribute_value  |
| S1aa9c6beb27f_N1800 | S1aa9c6beb27f_N1799 | attribute_value | 302–302 | flex items-center gap-2 |
| S1aa9c6beb27f_N1801 | S1aa9c6beb27f_N1794 | element | 303–303 | element  |
| S1aa9c6beb27f_N1802 | S1aa9c6beb27f_N1801 | start_tag | 303–303 | start_tag  |
| S1aa9c6beb27f_N1803 | S1aa9c6beb27f_N1802 | tag_name | 303–303 | span |
| S1aa9c6beb27f_N1804 | S1aa9c6beb27f_N1802 | attribute | 303–303 | attribute  |
| S1aa9c6beb27f_N1805 | S1aa9c6beb27f_N1804 | attribute_name | 303–303 | class |
| S1aa9c6beb27f_N1806 | S1aa9c6beb27f_N1804 | quoted_attribute_value | 303–303 | quoted_attribute_value  |
| S1aa9c6beb27f_N1807 | S1aa9c6beb27f_N1806 | attribute_value | 303–303 | font-mono text-xs uppercase tracking-wider text-brass font-medium |
| S1aa9c6beb27f_N1808 | S1aa9c6beb27f_N1801 | text | 303–303 | One-time prepaid |
| S1aa9c6beb27f_N1809 | S1aa9c6beb27f_N1801 | end_tag | 303–303 | end_tag  |
| S1aa9c6beb27f_N1810 | S1aa9c6beb27f_N1809 | tag_name | 303–303 | span |
| S1aa9c6beb27f_N1811 | S1aa9c6beb27f_N1794 | element | 304–304 | element  |
| S1aa9c6beb27f_N1812 | S1aa9c6beb27f_N1811 | start_tag | 304–304 | start_tag  |
| S1aa9c6beb27f_N1813 | S1aa9c6beb27f_N1812 | tag_name | 304–304 | span |
| S1aa9c6beb27f_N1814 | S1aa9c6beb27f_N1812 | attribute | 304–304 | attribute  |
| S1aa9c6beb27f_N1815 | S1aa9c6beb27f_N1814 | attribute_name | 304–304 | class |
| S1aa9c6beb27f_N1816 | S1aa9c6beb27f_N1814 | quoted_attribute_value | 304–304 | quoted_attribute_value  |
| S1aa9c6beb27f_N1817 | S1aa9c6beb27f_N1816 | attribute_value | 304–304 | text-white/20 |
| S1aa9c6beb27f_N1818 | S1aa9c6beb27f_N1811 | text | 304–304 | · |
| S1aa9c6beb27f_N1819 | S1aa9c6beb27f_N1811 | end_tag | 304–304 | end_tag  |
| S1aa9c6beb27f_N1820 | S1aa9c6beb27f_N1819 | tag_name | 304–304 | span |
| S1aa9c6beb27f_N1821 | S1aa9c6beb27f_N1794 | element | 305–305 | element  |
| S1aa9c6beb27f_N1822 | S1aa9c6beb27f_N1821 | start_tag | 305–305 | start_tag  |
| S1aa9c6beb27f_N1823 | S1aa9c6beb27f_N1822 | tag_name | 305–305 | span |
| S1aa9c6beb27f_N1824 | S1aa9c6beb27f_N1822 | attribute | 305–305 | attribute  |
| S1aa9c6beb27f_N1825 | S1aa9c6beb27f_N1824 | attribute_name | 305–305 | class |
| S1aa9c6beb27f_N1826 | S1aa9c6beb27f_N1824 | quoted_attribute_value | 305–305 | quoted_attribute_value  |
| S1aa9c6beb27f_N1827 | S1aa9c6beb27f_N1826 | attribute_value | 305–305 | text-xs text-muted-text |
| S1aa9c6beb27f_N1828 | S1aa9c6beb27f_N1821 | text | 305–305 | Simple and transparent |
| S1aa9c6beb27f_N1829 | S1aa9c6beb27f_N1821 | end_tag | 305–305 | end_tag  |
| S1aa9c6beb27f_N1830 | S1aa9c6beb27f_N1829 | tag_name | 305–305 | span |
| S1aa9c6beb27f_N1831 | S1aa9c6beb27f_N1794 | end_tag | 306–306 | end_tag  |
| S1aa9c6beb27f_N1832 | S1aa9c6beb27f_N1831 | tag_name | 306–306 | div |
| S1aa9c6beb27f_N1833 | S1aa9c6beb27f_N1791 | element | 307–307 | element  |
| S1aa9c6beb27f_N1834 | S1aa9c6beb27f_N1833 | start_tag | 307–307 | start_tag  |
| S1aa9c6beb27f_N1835 | S1aa9c6beb27f_N1834 | tag_name | 307–307 | h3 |
| S1aa9c6beb27f_N1836 | S1aa9c6beb27f_N1834 | attribute | 307–307 | attribute  |
| S1aa9c6beb27f_N1837 | S1aa9c6beb27f_N1836 | attribute_name | 307–307 | class |
| S1aa9c6beb27f_N1838 | S1aa9c6beb27f_N1836 | quoted_attribute_value | 307–307 | quoted_attribute_value  |
| S1aa9c6beb27f_N1839 | S1aa9c6beb27f_N1838 | attribute_value | 307–307 | font-serif text-xl sm:text-2xl text-starlight font-medium mt-1 |
| S1aa9c6beb27f_N1840 | S1aa9c6beb27f_N1833 | text | 307–307 | Upgrade your natal reading |
| S1aa9c6beb27f_N1841 | S1aa9c6beb27f_N1833 | end_tag | 307–307 | end_tag  |
| S1aa9c6beb27f_N1842 | S1aa9c6beb27f_N1841 | tag_name | 307–307 | h3 |
| S1aa9c6beb27f_N1843 | S1aa9c6beb27f_N1791 | element | 308–308 | element  |
| S1aa9c6beb27f_N1844 | S1aa9c6beb27f_N1843 | start_tag | 308–308 | start_tag  |
| S1aa9c6beb27f_N1845 | S1aa9c6beb27f_N1844 | tag_name | 308–308 | p |
| S1aa9c6beb27f_N1846 | S1aa9c6beb27f_N1844 | attribute | 308–308 | attribute  |
| S1aa9c6beb27f_N1847 | S1aa9c6beb27f_N1846 | attribute_name | 308–308 | class |
| S1aa9c6beb27f_N1848 | S1aa9c6beb27f_N1846 | quoted_attribute_value | 308–308 | quoted_attribute_value  |
| S1aa9c6beb27f_N1849 | S1aa9c6beb27f_N1848 | attribute_value | 308–308 | text-sm text-soft-text mt-0.5 |
| S1aa9c6beb27f_N1850 | S1aa9c6beb27f_N1843 | text | 308–308 | Price shown in your quote |
| S1aa9c6beb27f_N1851 | S1aa9c6beb27f_N1843 | end_tag | 308–308 | end_tag  |
| S1aa9c6beb27f_N1852 | S1aa9c6beb27f_N1851 | tag_name | 308–308 | p |
| S1aa9c6beb27f_N1853 | S1aa9c6beb27f_N1791 | end_tag | 309–309 | end_tag  |
| S1aa9c6beb27f_N1854 | S1aa9c6beb27f_N1853 | tag_name | 309–309 | div |
| S1aa9c6beb27f_N1855 | S1aa9c6beb27f_N1784 | element | 310–313 | element  |
| S1aa9c6beb27f_N1856 | S1aa9c6beb27f_N1855 | start_tag | 310–310 | start_tag  |
| S1aa9c6beb27f_N1857 | S1aa9c6beb27f_N1856 | tag_name | 310–310 | div |
| S1aa9c6beb27f_N1858 | S1aa9c6beb27f_N1856 | attribute | 310–310 | attribute  |
| S1aa9c6beb27f_N1859 | S1aa9c6beb27f_N1858 | attribute_name | 310–310 | class |
| S1aa9c6beb27f_N1860 | S1aa9c6beb27f_N1858 | quoted_attribute_value | 310–310 | quoted_attribute_value  |
| S1aa9c6beb27f_N1861 | S1aa9c6beb27f_N1860 | attribute_value | 310–310 | bg-obs/80 border border-white/5 rounded-xl px-4 py-3 sm:text-right shrink-0 |
| S1aa9c6beb27f_N1862 | S1aa9c6beb27f_N1855 | element | 311–311 | element  |
| S1aa9c6beb27f_N1863 | S1aa9c6beb27f_N1862 | start_tag | 311–311 | start_tag  |
| S1aa9c6beb27f_N1864 | S1aa9c6beb27f_N1863 | tag_name | 311–311 | span |
| S1aa9c6beb27f_N1865 | S1aa9c6beb27f_N1863 | attribute | 311–311 | attribute  |
| S1aa9c6beb27f_N1866 | S1aa9c6beb27f_N1865 | attribute_name | 311–311 | class |
| S1aa9c6beb27f_N1867 | S1aa9c6beb27f_N1865 | quoted_attribute_value | 311–311 | quoted_attribute_value  |
| S1aa9c6beb27f_N1868 | S1aa9c6beb27f_N1867 | attribute_value | 311–311 | text-[11px] font-mono uppercase text-muted-text block |
| S1aa9c6beb27f_N1869 | S1aa9c6beb27f_N1862 | text | 311–311 | Selected reading option |
| S1aa9c6beb27f_N1870 | S1aa9c6beb27f_N1862 | end_tag | 311–311 | end_tag  |
| S1aa9c6beb27f_N1871 | S1aa9c6beb27f_N1870 | tag_name | 311–311 | span |
| S1aa9c6beb27f_N1872 | S1aa9c6beb27f_N1855 | element | 312–312 | element  |
| S1aa9c6beb27f_N1873 | S1aa9c6beb27f_N1872 | start_tag | 312–312 | start_tag  |
| S1aa9c6beb27f_N1874 | S1aa9c6beb27f_N1873 | tag_name | 312–312 | span |
| S1aa9c6beb27f_N1875 | S1aa9c6beb27f_N1873 | attribute | 312–312 | attribute  |
| S1aa9c6beb27f_N1876 | S1aa9c6beb27f_N1875 | attribute_name | 312–312 | class |
| S1aa9c6beb27f_N1877 | S1aa9c6beb27f_N1875 | quoted_attribute_value | 312–312 | quoted_attribute_value  |
| S1aa9c6beb27f_N1878 | S1aa9c6beb27f_N1877 | attribute_value | 312–312 | text-sm font-serif font-medium text-brass |
| S1aa9c6beb27f_N1879 | S1aa9c6beb27f_N1872 | text | 312–312 | PDF + Interactive SPA Available |
| S1aa9c6beb27f_N1880 | S1aa9c6beb27f_N1872 | end_tag | 312–312 | end_tag  |
| S1aa9c6beb27f_N1881 | S1aa9c6beb27f_N1880 | tag_name | 312–312 | span |
| S1aa9c6beb27f_N1882 | S1aa9c6beb27f_N1855 | end_tag | 313–313 | end_tag  |
| S1aa9c6beb27f_N1883 | S1aa9c6beb27f_N1882 | tag_name | 313–313 | div |
| S1aa9c6beb27f_N1884 | S1aa9c6beb27f_N1784 | end_tag | 314–314 | end_tag  |
| S1aa9c6beb27f_N1885 | S1aa9c6beb27f_N1884 | tag_name | 314–314 | div |
| S1aa9c6beb27f_N1886 | S1aa9c6beb27f_N1777 | comment | 315–315 | &lt;!-- Balanced Action Controls: No Preselected Paid Upgrade --&gt; |
| S1aa9c6beb27f_N1887 | S1aa9c6beb27f_N1777 | element | 316–327 | element  |
| S1aa9c6beb27f_N1888 | S1aa9c6beb27f_N1887 | start_tag | 316–316 | start_tag  |
| S1aa9c6beb27f_N1889 | S1aa9c6beb27f_N1888 | tag_name | 316–316 | div |
| S1aa9c6beb27f_N1890 | S1aa9c6beb27f_N1888 | attribute | 316–316 | attribute  |
| S1aa9c6beb27f_N1891 | S1aa9c6beb27f_N1890 | attribute_name | 316–316 | class |
| S1aa9c6beb27f_N1892 | S1aa9c6beb27f_N1890 | quoted_attribute_value | 316–316 | quoted_attribute_value  |
| S1aa9c6beb27f_N1893 | S1aa9c6beb27f_N1892 | attribute_value | 316–316 | pt-6 flex flex-col sm:flex-row items-center justify-center gap-4 |
| S1aa9c6beb27f_N1894 | S1aa9c6beb27f_N1887 | comment | 317–317 | &lt;!-- Plainly visible secondary decline button --&gt; |
| S1aa9c6beb27f_N1895 | S1aa9c6beb27f_N1887 | element | 318–321 | element  |
| S1aa9c6beb27f_N1896 | S1aa9c6beb27f_N1895 | start_tag | 318–318 | start_tag  |
| S1aa9c6beb27f_N1897 | S1aa9c6beb27f_N1896 | tag_name | 318–318 | a |
| S1aa9c6beb27f_N1898 | S1aa9c6beb27f_N1896 | attribute | 318–318 | attribute  |
| S1aa9c6beb27f_N1899 | S1aa9c6beb27f_N1898 | attribute_name | 318–318 | class |
| S1aa9c6beb27f_N1900 | S1aa9c6beb27f_N1898 | quoted_attribute_value | 318–318 | quoted_attribute_value  |
| S1aa9c6beb27f_N1901 | S1aa9c6beb27f_N1900 | attribute_value | 318–318 | w-full sm:w-1/2 py-3.5 px-6 rounded-xl bg-surface-subtle hover:bg-white/10 text-starlight font-sans text-sm font-semibold transition-all border border-white/10 flex items-center justify-center gap-2 text-center |
| S1aa9c6beb27f_N1902 | S1aa9c6beb27f_N1896 | attribute | 318–318 | attribute  |
| S1aa9c6beb27f_N1903 | S1aa9c6beb27f_N1902 | attribute_name | 318–318 | href |
| S1aa9c6beb27f_N1904 | S1aa9c6beb27f_N1902 | quoted_attribute_value | 318–318 | quoted_attribute_value  |
| S1aa9c6beb27f_N1905 | S1aa9c6beb27f_N1904 | attribute_value | 318–318 | # |
| S1aa9c6beb27f_N1906 | S1aa9c6beb27f_N1896 | attribute | 318–318 | attribute  |
| S1aa9c6beb27f_N1907 | S1aa9c6beb27f_N1906 | attribute_name | 318–318 | role |
| S1aa9c6beb27f_N1908 | S1aa9c6beb27f_N1906 | quoted_attribute_value | 318–318 | quoted_attribute_value  |
| S1aa9c6beb27f_N1909 | S1aa9c6beb27f_N1908 | attribute_value | 318–318 | button |
| S1aa9c6beb27f_N1910 | S1aa9c6beb27f_N1895 | element | 319–319 | element  |
| S1aa9c6beb27f_N1911 | S1aa9c6beb27f_N1910 | start_tag | 319–319 | start_tag  |
| S1aa9c6beb27f_N1912 | S1aa9c6beb27f_N1911 | tag_name | 319–319 | span |
| S1aa9c6beb27f_N1913 | S1aa9c6beb27f_N1911 | attribute | 319–319 | attribute  |
| S1aa9c6beb27f_N1914 | S1aa9c6beb27f_N1913 | attribute_name | 319–319 | class |
| S1aa9c6beb27f_N1915 | S1aa9c6beb27f_N1913 | quoted_attribute_value | 319–319 | quoted_attribute_value  |
| S1aa9c6beb27f_N1916 | S1aa9c6beb27f_N1915 | attribute_value | 319–319 | material-symbols-outlined text-muted-text text-base |
| S1aa9c6beb27f_N1917 | S1aa9c6beb27f_N1910 | text | 319–319 | arrow_back |
| S1aa9c6beb27f_N1918 | S1aa9c6beb27f_N1910 | end_tag | 319–319 | end_tag  |
| S1aa9c6beb27f_N1919 | S1aa9c6beb27f_N1918 | tag_name | 319–319 | span |
| S1aa9c6beb27f_N1920 | S1aa9c6beb27f_N1895 | element | 320–320 | element  |
| S1aa9c6beb27f_N1921 | S1aa9c6beb27f_N1920 | start_tag | 320–320 | start_tag  |
| S1aa9c6beb27f_N1922 | S1aa9c6beb27f_N1921 | tag_name | 320–320 | span |
| S1aa9c6beb27f_N1923 | S1aa9c6beb27f_N1920 | text | 320–320 | Keep PDF only |
| S1aa9c6beb27f_N1924 | S1aa9c6beb27f_N1920 | end_tag | 320–320 | end_tag  |
| S1aa9c6beb27f_N1925 | S1aa9c6beb27f_N1924 | tag_name | 320–320 | span |
| S1aa9c6beb27f_N1926 | S1aa9c6beb27f_N1895 | end_tag | 321–321 | end_tag  |
| S1aa9c6beb27f_N1927 | S1aa9c6beb27f_N1926 | tag_name | 321–321 | a |
| S1aa9c6beb27f_N1928 | S1aa9c6beb27f_N1887 | comment | 322–322 | &lt;!-- Primary CTA: Brass upgrade button --&gt; |
| S1aa9c6beb27f_N1929 | S1aa9c6beb27f_N1887 | element | 323–326 | element  |
| S1aa9c6beb27f_N1930 | S1aa9c6beb27f_N1929 | start_tag | 323–323 | start_tag  |
| S1aa9c6beb27f_N1931 | S1aa9c6beb27f_N1930 | tag_name | 323–323 | a |
| S1aa9c6beb27f_N1932 | S1aa9c6beb27f_N1930 | attribute | 323–323 | attribute  |
| S1aa9c6beb27f_N1933 | S1aa9c6beb27f_N1932 | attribute_name | 323–323 | class |
| S1aa9c6beb27f_N1934 | S1aa9c6beb27f_N1932 | quoted_attribute_value | 323–323 | quoted_attribute_value  |
| S1aa9c6beb27f_N1935 | S1aa9c6beb27f_N1934 | attribute_value | 323–323 | w-full sm:w-1/2 py-3.5 px-6 rounded-xl bg-brass hover:bg-brass-light text-obs font-sans text-sm font-bold transition-all shadow-lg hover:shadow-brass/20 flex items-center justify-center gap-2 text-center |
| S1aa9c6beb27f_N1936 | S1aa9c6beb27f_N1930 | attribute | 323–323 | attribute  |
| S1aa9c6beb27f_N1937 | S1aa9c6beb27f_N1936 | attribute_name | 323–323 | href |
| S1aa9c6beb27f_N1938 | S1aa9c6beb27f_N1936 | quoted_attribute_value | 323–323 | quoted_attribute_value  |
| S1aa9c6beb27f_N1939 | S1aa9c6beb27f_N1938 | attribute_value | 323–323 | # |
| S1aa9c6beb27f_N1940 | S1aa9c6beb27f_N1930 | attribute | 323–323 | attribute  |
| S1aa9c6beb27f_N1941 | S1aa9c6beb27f_N1940 | attribute_name | 323–323 | role |
| S1aa9c6beb27f_N1942 | S1aa9c6beb27f_N1940 | quoted_attribute_value | 323–323 | quoted_attribute_value  |
| S1aa9c6beb27f_N1943 | S1aa9c6beb27f_N1942 | attribute_value | 323–323 | button |
| S1aa9c6beb27f_N1944 | S1aa9c6beb27f_N1929 | element | 324–324 | element  |
| S1aa9c6beb27f_N1945 | S1aa9c6beb27f_N1944 | start_tag | 324–324 | start_tag  |
| S1aa9c6beb27f_N1946 | S1aa9c6beb27f_N1945 | tag_name | 324–324 | span |
| S1aa9c6beb27f_N1947 | S1aa9c6beb27f_N1945 | attribute | 324–324 | attribute  |
| S1aa9c6beb27f_N1948 | S1aa9c6beb27f_N1947 | attribute_name | 324–324 | class |
| S1aa9c6beb27f_N1949 | S1aa9c6beb27f_N1947 | quoted_attribute_value | 324–324 | quoted_attribute_value  |
| S1aa9c6beb27f_N1950 | S1aa9c6beb27f_N1949 | attribute_value | 324–324 | material-symbols-outlined text-base |
| S1aa9c6beb27f_N1951 | S1aa9c6beb27f_N1944 | text | 324–324 | auto_awesome |
| S1aa9c6beb27f_N1952 | S1aa9c6beb27f_N1944 | end_tag | 324–324 | end_tag  |
| S1aa9c6beb27f_N1953 | S1aa9c6beb27f_N1952 | tag_name | 324–324 | span |
| S1aa9c6beb27f_N1954 | S1aa9c6beb27f_N1929 | element | 325–325 | element  |
| S1aa9c6beb27f_N1955 | S1aa9c6beb27f_N1954 | start_tag | 325–325 | start_tag  |
| S1aa9c6beb27f_N1956 | S1aa9c6beb27f_N1955 | tag_name | 325–325 | span |
| S1aa9c6beb27f_N1957 | S1aa9c6beb27f_N1954 | text | 325–325 | Add the interactive chart |
| S1aa9c6beb27f_N1958 | S1aa9c6beb27f_N1954 | end_tag | 325–325 | end_tag  |
| S1aa9c6beb27f_N1959 | S1aa9c6beb27f_N1958 | tag_name | 325–325 | span |
| S1aa9c6beb27f_N1960 | S1aa9c6beb27f_N1929 | end_tag | 326–326 | end_tag  |
| S1aa9c6beb27f_N1961 | S1aa9c6beb27f_N1960 | tag_name | 326–326 | a |
| S1aa9c6beb27f_N1962 | S1aa9c6beb27f_N1887 | end_tag | 327–327 | end_tag  |
| S1aa9c6beb27f_N1963 | S1aa9c6beb27f_N1962 | tag_name | 327–327 | div |
| S1aa9c6beb27f_N1964 | S1aa9c6beb27f_N1777 | element | 328–330 | element  |
| S1aa9c6beb27f_N1965 | S1aa9c6beb27f_N1964 | start_tag | 328–328 | start_tag  |
| S1aa9c6beb27f_N1966 | S1aa9c6beb27f_N1965 | tag_name | 328–328 | p |
| S1aa9c6beb27f_N1967 | S1aa9c6beb27f_N1965 | attribute | 328–328 | attribute  |
| S1aa9c6beb27f_N1968 | S1aa9c6beb27f_N1967 | attribute_name | 328–328 | class |
| S1aa9c6beb27f_N1969 | S1aa9c6beb27f_N1967 | quoted_attribute_value | 328–328 | quoted_attribute_value  |
| S1aa9c6beb27f_N1970 | S1aa9c6beb27f_N1969 | attribute_value | 328–328 | text-center text-xs text-muted-text mt-4 |
| S1aa9c6beb27f_N1971 | S1aa9c6beb27f_N1964 | text | 329–329 | Your choice can be reviewed again before final order confirmation. |
| S1aa9c6beb27f_N1972 | S1aa9c6beb27f_N1964 | end_tag | 330–330 | end_tag  |
| S1aa9c6beb27f_N1973 | S1aa9c6beb27f_N1972 | tag_name | 330–330 | p |
| S1aa9c6beb27f_N1974 | S1aa9c6beb27f_N1777 | end_tag | 331–331 | end_tag  |
| S1aa9c6beb27f_N1975 | S1aa9c6beb27f_N1974 | tag_name | 331–331 | div |
| S1aa9c6beb27f_N1976 | S1aa9c6beb27f_N461 | end_tag | 332–332 | end_tag  |
| S1aa9c6beb27f_N1977 | S1aa9c6beb27f_N1976 | tag_name | 332–332 | div |
| S1aa9c6beb27f_N1978 | S1aa9c6beb27f_N454 | comment | 333–333 | &lt;!-- Quiet Footer --&gt; |
| S1aa9c6beb27f_N1979 | S1aa9c6beb27f_N454 | element | 334–338 | element  |
| S1aa9c6beb27f_N1980 | S1aa9c6beb27f_N1979 | start_tag | 334–334 | start_tag  |
| S1aa9c6beb27f_N1981 | S1aa9c6beb27f_N1980 | tag_name | 334–334 | footer |
| S1aa9c6beb27f_N1982 | S1aa9c6beb27f_N1980 | attribute | 334–334 | attribute  |
| S1aa9c6beb27f_N1983 | S1aa9c6beb27f_N1982 | attribute_name | 334–334 | class |
| S1aa9c6beb27f_N1984 | S1aa9c6beb27f_N1982 | quoted_attribute_value | 334–334 | quoted_attribute_value  |
| S1aa9c6beb27f_N1985 | S1aa9c6beb27f_N1984 | attribute_value | 334–334 | mt-12 text-center py-6 border-t border-white/5 |
| S1aa9c6beb27f_N1986 | S1aa9c6beb27f_N1979 | element | 335–337 | element  |
| S1aa9c6beb27f_N1987 | S1aa9c6beb27f_N1986 | start_tag | 335–335 | start_tag  |
| S1aa9c6beb27f_N1988 | S1aa9c6beb27f_N1987 | tag_name | 335–335 | p |
| S1aa9c6beb27f_N1989 | S1aa9c6beb27f_N1987 | attribute | 335–335 | attribute  |
| S1aa9c6beb27f_N1990 | S1aa9c6beb27f_N1989 | attribute_name | 335–335 | class |
| S1aa9c6beb27f_N1991 | S1aa9c6beb27f_N1989 | quoted_attribute_value | 335–335 | quoted_attribute_value  |
| S1aa9c6beb27f_N1992 | S1aa9c6beb27f_N1991 | attribute_value | 335–335 | font-mono text-xs text-muted-text/80 |
| S1aa9c6beb27f_N1993 | S1aa9c6beb27f_N1986 | text | 336–336 | Design prototype · no payment is collected |
| S1aa9c6beb27f_N1994 | S1aa9c6beb27f_N1986 | end_tag | 337–337 | end_tag  |
| S1aa9c6beb27f_N1995 | S1aa9c6beb27f_N1994 | tag_name | 337–337 | p |
| S1aa9c6beb27f_N1996 | S1aa9c6beb27f_N1979 | end_tag | 338–338 | end_tag  |
| S1aa9c6beb27f_N1997 | S1aa9c6beb27f_N1996 | tag_name | 338–338 | footer |
| S1aa9c6beb27f_N1998 | S1aa9c6beb27f_N454 | end_tag | 339–339 | end_tag  |
| S1aa9c6beb27f_N1999 | S1aa9c6beb27f_N1998 | tag_name | 339–339 | main |
| S1aa9c6beb27f_N2000 | S1aa9c6beb27f_N237 | end_tag | 340–340 | end_tag  |
| S1aa9c6beb27f_N2001 | S1aa9c6beb27f_N2000 | tag_name | 340–340 | body |
| S1aa9c6beb27f_N2002 | S1aa9c6beb27f_N3 | end_tag | 340–340 | end_tag  |
| S1aa9c6beb27f_N2003 | S1aa9c6beb27f_N2002 | tag_name | 340–340 | html |