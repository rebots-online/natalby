const CACHE_NAME="natally-shell-1.10.86133-58a22c36-c710-43c9-9651-bb7156ee3e5d";
const PRECACHE_URLS=["/assets/App-CJjG-3cL.js","/assets/App-tf-ZfiJN.css","/assets/BuildStamp-BWQzgIgo.js","/assets/BuildStamp-CjVufAY1.css","/assets/PurchaseAccess-1Kvs3Nn3.js","/assets/PurchaseAccess-r1hji0ul.css","/assets/VoiceDownloadStatus-DcosK-DC.js","/assets/__vite-browser-external-oYSjS54R.js","/assets/accountStorage-B-NbRf2y.js","/assets/app-BRfF0ogx.js","/assets/buildIdentity-DvsrI_-k.js","/assets/client-BJFRBXmV.js","/assets/firebase-applet-config-BumQkWRk.js","/assets/html2canvas-DQvxrKtW.js","/assets/index.es-DhiII7wY.js","/assets/jspdf.es.min-CLIVO-Ty.js","/assets/marketing-PXePjCjY.js","/assets/modulepreload-polyfill-P2Xu9kJm.js","/assets/natallyHistory-BVEZbjJO.js","/assets/nativeAuth-vS66y0lg.js","/assets/ort-wasm-simd-threaded.asyncify-CxOG5pUO.wasm","/assets/preload-helper-6addhe8V.js","/assets/purify.es-Dn3VvdGh.js","/assets/react-DC_4KZfT.js","/assets/react-dom-DEhZRoZz.js","/assets/src-CIP5vKMK.css","/assets/supertonic.worker-BQarrr-O.js","/assets/supertonicTts-C83AMqL_.js","/assets/swisseph-BqKK9TOX.wasm","/branding/192x192.png","/branding/512x512.png","/index.html","/manifest.webmanifest","/marketing.html","/pwa.js"];
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE_URLS)));
});
self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const names = await caches.keys();
    await Promise.all(names.filter((n) => n.startsWith('natally-shell-') && n !== CACHE_NAME).map((n) => caches.delete(n)));
    await self.clients.claim();
  })());
});
const SHELL_ROUTES = new Map([['/', '/index.html'], ['/index.html', '/index.html'], ['/marketing.html', '/marketing.html']]);
self.addEventListener('fetch', (event) => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (PRECACHE_URLS.includes(url.pathname)) {
    event.respondWith(caches.open(CACHE_NAME).then(cache => cache.match(url.pathname)).then((hit) => hit || fetch(request)));
    return;
  }
  const shell = SHELL_ROUTES.get(url.pathname);
  if (shell && request.mode === 'navigate') {
    event.respondWith(caches.open(CACHE_NAME).then(cache => cache.match(shell)).then((hit) => hit || fetch(request)));
  }
});
